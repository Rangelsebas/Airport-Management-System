package interfazTest.login.enums;

public enum ComandoLoginEnum {
    INICIAR_SESION, OLVIDAR_CONTRASENA
}
