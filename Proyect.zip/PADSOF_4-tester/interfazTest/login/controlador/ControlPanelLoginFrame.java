package interfazTest.login.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

//import funcionalidad.aplicacion.Aplicacion;
import interfazTest.gestor.controlador.ControlVentanaGestor;
import interfazTest.gestor.vista.VentanaGestor;
import interfazTest.login.enums.ComandoLoginEnum;
import interfazTest.login.vista.PanelLoginFrame;
import interfazTest.operador.controlador.ControlVentanaOperador;
import interfazTest.operador.vista.VentanaOperador;

public class ControlPanelLoginFrame implements ActionListener {
    private final PanelLoginFrame vista;
    //private final Aplicacion aplicacion;

    public ControlPanelLoginFrame(PanelLoginFrame vista) {
        this.vista = vista;
        //this.aplicacion = Aplicacion.init("acceder");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoLoginEnum comando = ComandoLoginEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case INICIAR_SESION:
                procesarInicioSesion();
                break;

            case OLVIDAR_CONTRASENA:
                procesarOlvidoContrasena();
                break;
        }
    }

    private void procesarInicioSesion() {
        /*-----DUMMY CODE FOR TESTING-----*/
        String username = vista.getUsuario().toLowerCase();
        String password = vista.getContrasena();

        if (username.isBlank() || password.isBlank()) {
            JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (username.isBlank() || username.equals("Usuario") ||
            password.isBlank() || password.equals("Contraseña")) {

            JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (username.contains("operador")) {
            VentanaOperador ventana = new VentanaOperador();
            new ControlVentanaOperador(ventana);
            ventana.setVisible(true);
        } else if (username.contains("gestor")) {
            VentanaGestor ventana = new VentanaGestor();
            new ControlVentanaGestor(ventana);
            ventana.setVisible(true);
        // } else if (username.equalsIgnoreCase("controlador")) {
        //     VentanaControlador ventana = new VentanaControlador();
        //     new ControlVentanaControlador(ventana);
        //     ventana.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Usuario desconocido para prueba.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        vista.dispose(); // Cierra login

        /* ------ Esto es lo que de verda va a ir ------- */
        // // boolean exito = aplicacion.iniciarSesion(username, password);

        // // if (exito) {
        // //     Usuario usuario = aplicacion.getUsuarioLogueado();

        // //     if (usuario.getPrimerLogin()) {
        // //         // Primer inicio → Solicitar nueva contraseña
        // //         String nuevaContrasena = JOptionPane.showInputDialog(null,
        // //             "Es tu primer inicio de sesión.\nPor favor, introduce una nueva contraseña:",
        // //             "Primer Inicio", JOptionPane.PLAIN_MESSAGE);

        // //         if (nuevaContrasena != null && !nuevaContrasena.isBlank()) {
        // //             usuario.cambiarContrasena(password, nuevaContrasena);
        // //             usuario.setPrimerLogin(); // Marcar como ya iniciado
        // //             JOptionPane.showMessageDialog(null, "Contraseña actualizada correctamente.", "Actualizado", JOptionPane.INFORMATION_MESSAGE);
        // //         } else {
        // //             JOptionPane.showMessageDialog(null, "Debes establecer una contraseña válida.", "Error", JOptionPane.ERROR_MESSAGE);
        // //             aplicacion.cerrarSesion();
        // //             return;
        // //         }
        // //     }

        // //     // Redirigir según rol
        // //     if (usuario.checkRol("GESTORAEROPUERTO")) {
        // //         new interfazTest.gestor.vista.VentanaGestor().setVisible(true);
        // //     } else if (usuario.checkRol("OPERADORAEROLINEA")) {
        // //         new interfazTest.operador.vista.VentanaOperador().setVisible(true);
        // //     } else if (usuario.checkRol("CONTROLADORAEREO")) {
        // //         new interfazTest.controlador.vista.VentanaControlador().setVisible(true);
        // //     } else {
        // //         JOptionPane.showMessageDialog(null, "Rol de usuario no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
        // //         aplicacion.cerrarSesion();
        // //         return;
        // //     }

        // //     vista.dispose(); // Cerrar ventana de login al entrar
        // // } else {
        // //     JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos.", "Acceso denegado", JOptionPane.ERROR_MESSAGE);
        // // }
    }

    private void procesarOlvidoContrasena() {
        JOptionPane.showMessageDialog(null,
            "Se ha enviado una notificación al Gestor de Aeropuerto para restablecer tu contraseña.\nPor favor, espera instrucciones.",
            "Solicitud enviada", JOptionPane.INFORMATION_MESSAGE);
    }
}
