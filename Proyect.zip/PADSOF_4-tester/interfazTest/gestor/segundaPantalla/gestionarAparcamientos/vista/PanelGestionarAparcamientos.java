package interfazTest.gestor.segundaPantalla.gestionarAparcamientos.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelGestionarAparcamientos extends JPanel {

    private JPanel panelListado;
    private JButton botonAñadirAparcamiento;

    public PanelGestionarAparcamientos() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Título
        JLabel titulo = new JLabel("Listado de Aparcamientos", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Panel de listado
        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(900, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);

        // Botón "Añadir Aparcamiento"
        botonAñadirAparcamiento = new JButton("Añadir Aparcamiento");
        botonAñadirAparcamiento.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadirAparcamiento.setActionCommand(ComandoVentanaGestorEnum.AÑADIR_APARCAMIENTO.name());

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(Color.WHITE);
        panelBoton.setBorder(new EmptyBorder(20, 0, 20, 0));
        panelBoton.add(botonAñadirAparcamiento);

        add(panelBoton, BorderLayout.SOUTH);
    }

    public void agregarAparcamiento(int capacidad, int largo, int ancho, int alto) {
        JLabel aparcamientoLabel = new JLabel(
            String.format(
                "Aparcamiento | Capacidad: %d | Dimensiones de plaza: %dm x %dm x %dm",
                capacidad, largo, ancho, alto
            )
        );
        aparcamientoLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        aparcamientoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelAparcamiento = new JPanel();
        panelAparcamiento.setLayout(new BoxLayout(panelAparcamiento, BoxLayout.Y_AXIS));
        panelAparcamiento.setBackground(Color.WHITE);
        panelAparcamiento.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelAparcamiento.add(aparcamientoLabel);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelAparcamiento);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void setControlador(ActionListener c) {
        botonAñadirAparcamiento.addActionListener(c);
    }
}