package interfazTest.gestor.segundaPantalla.gestionarAparcamientos.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.controlador.ControlPanelAñadirAparcamiento;
import interfazTest.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.vista.PanelAñadirAparcamiento;
import interfazTest.gestor.segundaPantalla.gestionarAparcamientos.vista.PanelGestionarAparcamientos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelGestionarAparcamientos implements ActionListener {

    private PanelGestionarAparcamientos vista;
    private PantallaBase pantalla;

    public ControlPanelGestionarAparcamientos(PanelGestionarAparcamientos vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        cargarAparcamientosDePrueba();
    }

    private void cargarAparcamientosDePrueba() {
        // Mock de aparcamientos para visualizar
        vista.agregarAparcamiento(200, 5, 3, 2);
        vista.agregarAparcamiento(150, 5, 2, 2);
        vista.agregarAparcamiento(300, 6, 3, 2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case AÑADIR_APARCAMIENTO:
                PanelAñadirAparcamiento panelAñadirAparcamiento = new PanelAñadirAparcamiento();
                new ControlPanelAñadirAparcamiento(panelAñadirAparcamiento, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelAñadirAparcamiento);
                break;

            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }
}
