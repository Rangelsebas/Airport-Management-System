package interfazTest.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelAñadirAparcamiento extends JPanel {

    private JSpinner spinnerCapacidad;
    private JSpinner spinnerLargo;
    private JSpinner spinnerAncho;
    private JSpinner spinnerAlto;
    private JButton botonAñadir;

    public PanelAñadirAparcamiento() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Márgenes generosos

        // Spinner Capacidad
        spinnerCapacidad = crearSpinner(200, 0, 1000, 10);
        add(crearEtiqueta("Capacidad de aparcamiento"));
        add(spinnerCapacidad);

        add(Box.createVerticalStrut(20));

        // Spinner Largo de plaza
        spinnerLargo = crearSpinner(5, 2, 10, 1);
        add(crearEtiqueta("Largo de plaza (m)"));
        add(spinnerLargo);

        add(Box.createVerticalStrut(20));

        // Spinner Ancho de plaza
        spinnerAncho = crearSpinner(3, 2, 6, 1);
        add(crearEtiqueta("Ancho de plaza (m)"));
        add(spinnerAncho);

        add(Box.createVerticalStrut(20));

        // Spinner Alto de plaza
        spinnerAlto = crearSpinner(2, 2, 6, 1);
        add(crearEtiqueta("Alto de plaza (m)"));
        add(spinnerAlto);

        add(Box.createVerticalStrut(30));

        // Botón Añadir Aparcamiento
        botonAñadir = new JButton("Añadir Aparcamiento");
        botonAñadir.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadir.setActionCommand(ComandoVentanaGestorEnum.CONFIRMAR_AÑADIR_APARCAMIENTO.name());
        add(botonAñadir);
    }

    // ================================
    // MÉTODOS DE VISTA MVC
    // ================================

    public void setControlador(ActionListener c) {
        botonAñadir.addActionListener(c);
    }

    public int getCapacidad() {
        return (Integer) spinnerCapacidad.getValue();
    }

    public int getLargo() {
        return (Integer) spinnerLargo.getValue();
    }

    public int getAncho() {
        return (Integer) spinnerAncho.getValue();
    }

    public int getAlto() {
        return (Integer) spinnerAlto.getValue();
    }

    public void limpiarCampos() {
        spinnerCapacidad.setValue(200);
        spinnerLargo.setValue(5);
        spinnerAncho.setValue(3);
        spinnerAlto.setValue(2);
    }

    // ================================
    // HELPERS
    // ================================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        spinner.setAlignmentX(Component.CENTER_ALIGNMENT);
        return spinner;
    }
}
