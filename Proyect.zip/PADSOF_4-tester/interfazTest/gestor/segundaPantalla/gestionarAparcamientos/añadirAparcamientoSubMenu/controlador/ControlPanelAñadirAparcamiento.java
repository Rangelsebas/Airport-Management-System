package interfazTest.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.vista.PanelAñadirAparcamiento;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelAñadirAparcamiento implements ActionListener {

    private PanelAñadirAparcamiento vista;
    private PantallaBase pantalla;

    public ControlPanelAñadirAparcamiento(PanelAñadirAparcamiento vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONFIRMAR_AÑADIR_APARCAMIENTO:
                procesarCreacionAparcamiento();
                break;

            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarCreacionAparcamiento() {
        int capacidad = vista.getCapacidad();
        int largo = vista.getLargo();
        int ancho = vista.getAncho();
        int alto = vista.getAlto();

        // Validaciones básicas
        if (capacidad <= 0 || largo <= 0 || ancho <= 0 || alto <= 0) {
            JOptionPane.showMessageDialog(vista, "Todos los valores deben ser mayores a cero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // TODO: Aquí deberías integrar la lógica real para registrar el nuevo aparcamiento en el sistema

        System.out.println("✅ Nuevo aparcamiento creado:");
        System.out.println("- Capacidad: " + capacidad);
        System.out.println("- Dimensiones de plaza: " + largo + "m x " + ancho + "m x " + alto + "m");

        JOptionPane.showMessageDialog(vista, "¡Aparcamiento creado exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        vista.limpiarCampos();
    }
}
