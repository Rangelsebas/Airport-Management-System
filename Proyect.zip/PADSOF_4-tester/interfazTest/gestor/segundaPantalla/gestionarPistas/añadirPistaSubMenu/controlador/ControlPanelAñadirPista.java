package interfazTest.gestor.segundaPantalla.gestionarPistas.añadirPistaSubMenu.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.segundaPantalla.gestionarPistas.añadirPistaSubMenu.vista.PanelAñadirPista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelAñadirPista implements ActionListener {

    private PanelAñadirPista vista;
    private PantallaBase pantalla;

    public ControlPanelAñadirPista(PanelAñadirPista vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONFIRMAR_AÑADIR_PISTA:
                procesarCreacionPista();
                break;
        
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarCreacionPista() {
        String nombre = vista.getNombre();
        int longitud = vista.getLongitud();
        String orientacion = vista.getOrientacion();
        String uso = vista.getUso();

        if (nombre.isEmpty() || nombre.equals("Nombre Pista")) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar un nombre de pista válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // TODO: Aquí deberías integrar la lógica real para registrar la nueva pista en el sistema

        System.out.println("✅ Nueva pista creada:");
        System.out.println("- Nombre: " + nombre);
        System.out.println("- Longitud: " + longitud + " metros");
        System.out.println("- Orientación: " + orientacion);
        System.out.println("- Uso: " + uso);

        JOptionPane.showMessageDialog(vista, "¡Pista creada exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        vista.limpiarCampos();
    }
}