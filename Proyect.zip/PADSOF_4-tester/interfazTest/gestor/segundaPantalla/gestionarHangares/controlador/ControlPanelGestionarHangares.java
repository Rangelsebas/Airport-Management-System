package interfazTest.gestor.segundaPantalla.gestionarHangares.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.segundaPantalla.gestionarHangares.añadirHangarSubMenu.controlador.ControlPanelAñadirHangar;
import interfazTest.gestor.segundaPantalla.gestionarHangares.añadirHangarSubMenu.vista.PanelAñadirHangar;
import interfazTest.gestor.segundaPantalla.gestionarHangares.vista.PanelGestionarHangares;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelGestionarHangares implements ActionListener {

    private PanelGestionarHangares vista;
    private PantallaBase pantalla;

    public ControlPanelGestionarHangares(PanelGestionarHangares vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        cargarHangaresDePrueba();
    }

    private void cargarHangaresDePrueba() {
        // Mock de hangares para visualizar
        vista.agregarHangar(50, 100, 80, 25, 12);
        vista.agregarHangar(70, 120, 90, 30, 18);
        vista.agregarHangar(40, 90, 70, 22, 9);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case AÑADIR_HANGAR:
                PanelAñadirHangar panelAñadirHangar = new PanelAñadirHangar();
                new ControlPanelAñadirHangar(panelAñadirHangar, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelAñadirHangar);
                break;

            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    
    }
}
