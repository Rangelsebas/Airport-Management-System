package interfazTest.gestor.segundaPantalla.gestionarHangares.añadirHangarSubMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelAñadirHangar extends JPanel {

    private JSpinner spinnerCapacidad;
    private JSpinner spinnerLargo;
    private JSpinner spinnerAncho;
    private JSpinner spinnerAlto;
    private JButton botonAñadir;

    public PanelAñadirHangar() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Márgenes generosos

        // Spinner Capacidad
        spinnerCapacidad = crearSpinner(50, 0, 500, 10);
        add(crearEtiqueta("Capacidad"));
        add(spinnerCapacidad);

        add(Box.createVerticalStrut(20));

        // Spinner Largo
        spinnerLargo = crearSpinner(100, 10, 300, 5);
        add(crearEtiqueta("Largo (m)"));
        add(spinnerLargo);

        add(Box.createVerticalStrut(20));

        // Spinner Ancho
        spinnerAncho = crearSpinner(80, 10, 300, 5);
        add(crearEtiqueta("Ancho (m)"));
        add(spinnerAncho);

        add(Box.createVerticalStrut(20));

        // Spinner Alto
        spinnerAlto = crearSpinner(25, 5, 100, 1);
        add(crearEtiqueta("Alto (m)"));
        add(spinnerAlto);

        add(Box.createVerticalStrut(30));

        // Botón Añadir Hangar
        botonAñadir = new JButton("Añadir Hangar");
        botonAñadir.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadir.setActionCommand(ComandoVentanaGestorEnum.CONFIRMAR_AÑADIR_HANGAR.name());
        add(botonAñadir);
    }

    // ================================
    // MÉTODOS DE VISTA MVC
    // ================================

    public void setControlador(ActionListener c) {
        botonAñadir.addActionListener(c);
    }

    public int getCapacidad() {
        return (Integer) spinnerCapacidad.getValue();
    }

    public int getLargo() {
        return (Integer) spinnerLargo.getValue();
    }

    public int getAncho() {
        return (Integer) spinnerAncho.getValue();
    }

    public int getAlto() {
        return (Integer) spinnerAlto.getValue();
    }

    public void limpiarCampos() {
        spinnerCapacidad.setValue(50);
        spinnerLargo.setValue(100);
        spinnerAncho.setValue(80);
        spinnerAlto.setValue(25);
    }

    // ================================
    // HELPERS
    // ================================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        spinner.setAlignmentX(Component.CENTER_ALIGNMENT);
        return spinner;
    }
}
