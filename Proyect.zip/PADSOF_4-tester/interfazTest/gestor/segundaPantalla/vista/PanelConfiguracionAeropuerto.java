package interfazTest.gestor.segundaPantalla.vista;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class PanelConfiguracionAeropuerto extends JPanel {

    private final PantallaBase pantallaBase;
    private final List<JButton> botones;

    public PanelConfiguracionAeropuerto(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        botones = List.of(
                crearBoton("Gestionar pistas", ComandoVentanaGestorEnum.GESTIONAR_PISTAS),
                crearBoton("Gestionar terminales", ComandoVentanaGestorEnum.GESTIONAR_TERMINALES),
                crearBoton("Gestionar hangares", ComandoVentanaGestorEnum.GESTIONAR_HANGARES),
                crearBoton("Gestionar aparcamientos", ComandoVentanaGestorEnum.GESTIONAR_APARCAMIENTOS)
        );

        JPanel contenedor = new JPanel();
        contenedor.setLayout(new BoxLayout(contenedor, BoxLayout.Y_AXIS));
        contenedor.setBackground(Color.WHITE);

        for (JButton boton : botones) {
            boton.setAlignmentX(Component.CENTER_ALIGNMENT);
            boton.setMaximumSize(new Dimension(230, 50));
            boton.setMinimumSize(new Dimension(230, 50));
            boton.setPreferredSize(new Dimension(230, 50));
            boton.setFont(new Font("SansSerif", Font.PLAIN, 14));
            boton.setFocusable(false);
            contenedor.add(Box.createVerticalStrut(12));
            contenedor.add(boton);
        }

        add(contenedor); // al centro
    }

    private JButton crearBoton(String texto, ComandoVentanaGestorEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        return boton;
    }

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void mostrarPanel(JPanel panel) {
        pantallaBase.mostrarContenidoEnPanelCentral(panel);
    }
}
