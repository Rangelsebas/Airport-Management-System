package interfazTest.gestor.segundaPantalla.gestionarTerminales.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.segundaPantalla.gestionarTerminales.añadirTerminalSubMenu.controlador.ControlPanelAñadirTerminal;
import interfazTest.gestor.segundaPantalla.gestionarTerminales.añadirTerminalSubMenu.vista.PanelAñadirTerminal;
import interfazTest.gestor.segundaPantalla.gestionarTerminales.vista.PanelGestionarTerminales;

public class ControlPanelGestionarTerminales implements ActionListener {

    private PanelGestionarTerminales vista;
    private PantallaBase pantalla;

    public ControlPanelGestionarTerminales(PanelGestionarTerminales vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        cargarTerminalesDePrueba();
    }

    private void cargarTerminalesDePrueba() {
        // Mock de terminales para pruebas visuales
        vista.agregarTerminal("Terminal 1", 5000, 10, 5, 3, 2);
        vista.agregarTerminal("Terminal 2", 4000, 8, 4, 2, 1);
        vista.agregarTerminal("Terminal 3", 6000, 12, 6, 4, 3);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case AÑADIR_TERMINAL:
                PanelAñadirTerminal panelAñadirTerminal = new PanelAñadirTerminal();
                new ControlPanelAñadirTerminal(panelAñadirTerminal, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelAñadirTerminal);
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }
}