package interfazTest.gestor.segundaPantalla.gestionarTerminales.añadirTerminalSubMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelAñadirTerminal extends JPanel {

    private JTextField campoNombre;
    private JSpinner spinnerCapacidad;
    private JSpinner spinnerPuertas;
    private JSpinner spinnerBuses;
    private JSpinner spinnerFingers;
    private JSpinner spinnerControladores;
    private JButton botonAñadir;

    public PanelAñadirTerminal() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Márgenes generosos

        // Campo Nombre
        campoNombre = new JTextField();
        campoNombre.setMaximumSize(new Dimension(300, 30));
        campoNombre.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoNombre, "Nombre Terminal");
        add(campoNombre);

        add(Box.createVerticalStrut(20));

        // Spinner Capacidad
        spinnerCapacidad = crearSpinner(5000, 0, 10000, 100);
        add(crearEtiqueta("Capacidad"));
        add(spinnerCapacidad);

        add(Box.createVerticalStrut(10));

        // Spinner Puertas
        spinnerPuertas = crearSpinner(10, 0, 50, 1);
        add(crearEtiqueta("Cantidad de Puertas"));
        add(spinnerPuertas);

        add(Box.createVerticalStrut(10));

        // Spinner Buses
        spinnerBuses = crearSpinner(5, 0, 20, 1);
        add(crearEtiqueta("Cantidad de Buses"));
        add(spinnerBuses);

        add(Box.createVerticalStrut(10));

        // Spinner Fingers
        spinnerFingers = crearSpinner(3, 0, 20, 1);
        add(crearEtiqueta("Cantidad de Fingers"));
        add(spinnerFingers);

        add(Box.createVerticalStrut(10));

        // Spinner Controladores
        spinnerControladores = crearSpinner(2, 0, 10, 1);
        add(crearEtiqueta("Cantidad de Controladores"));
        add(spinnerControladores);

        add(Box.createVerticalStrut(20));

        // Botón Añadir Terminal
        botonAñadir = new JButton("Añadir Terminal");
        botonAñadir.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadir.setActionCommand(ComandoVentanaGestorEnum.CONFIRMAR_AÑADIR_TERMINAL.name());
        add(botonAñadir);
    }

    // ================================
    // MÉTODOS DE VISTA MVC
    // ================================

    public void setControlador(ActionListener c) {
        botonAñadir.addActionListener(c);
    }

    public String getNombre() {
        return campoNombre.getText().trim();
    }

    public int getCapacidad() {
        return (Integer) spinnerCapacidad.getValue();
    }

    public int getCantidadPuertas() {
        return (Integer) spinnerPuertas.getValue();
    }

    public int getCantidadBuses() {
        return (Integer) spinnerBuses.getValue();
    }

    public int getCantidadFingers() {
        return (Integer) spinnerFingers.getValue();
    }

    public int getCantidadControladores() {
        return (Integer) spinnerControladores.getValue();
    }

    public void limpiarCampos() {
        campoNombre.setText("");
        restaurarPlaceholder(campoNombre, "Nombre Terminal");
        spinnerCapacidad.setValue(5000);
        spinnerPuertas.setValue(10);
        spinnerBuses.setValue(5);
        spinnerFingers.setValue(3);
        spinnerControladores.setValue(2);
    }

    // ================================
    // HELPERS
    // ================================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        spinner.setAlignmentX(Component.CENTER_ALIGNMENT);
        return spinner;
    }

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }

    private void restaurarPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);
    }
}
