package interfazTest.gestor.segundaPantalla.gestionarTerminales.añadirTerminalSubMenu.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.segundaPantalla.gestionarTerminales.añadirTerminalSubMenu.vista.PanelAñadirTerminal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelAñadirTerminal implements ActionListener {

    private PanelAñadirTerminal vista;
    private PantallaBase pantalla;

    public ControlPanelAñadirTerminal(PanelAñadirTerminal vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONFIRMAR_AÑADIR_TERMINAL:
                procesarCreacionTerminal();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarCreacionTerminal() {
        String nombre = vista.getNombre();
        int capacidad = vista.getCapacidad();
        int puertas = vista.getCantidadPuertas();
        int buses = vista.getCantidadBuses();
        int fingers = vista.getCantidadFingers();
        int controladores = vista.getCantidadControladores();

        if (nombre.isEmpty() || nombre.equals("Nombre Terminal")) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar un nombre de terminal válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // TODO: Aquí deberías integrar la lógica real para registrar la nueva terminal en el sistema

        System.out.println("✅ Nueva terminal creada:");
        System.out.println("- Nombre: " + nombre);
        System.out.println("- Capacidad: " + capacidad);
        System.out.println("- Puertas: " + puertas);
        System.out.println("- Buses: " + buses);
        System.out.println("- Fingers: " + fingers);
        System.out.println("- Controladores: " + controladores);

        JOptionPane.showMessageDialog(vista, "¡Terminal creada exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        vista.limpiarCampos();
    }
}
