package interfazTest.gestor.segundaPantalla.gestionarTerminales.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelGestionarTerminales extends JPanel {

    private JPanel panelListado;
    private JButton botonAñadirTerminal;

    public PanelGestionarTerminales() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Título
        JLabel titulo = new JLabel("Listado de Terminales", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Panel de listado
        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(900, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);

        // Botón "Añadir Terminal"
        botonAñadirTerminal = new JButton("Añadir Terminal");
        botonAñadirTerminal.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadirTerminal.setActionCommand(ComandoVentanaGestorEnum.AÑADIR_TERMINAL.name());

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(Color.WHITE);
        panelBoton.setBorder(new EmptyBorder(20, 0, 20, 0));
        panelBoton.add(botonAñadirTerminal);

        add(panelBoton, BorderLayout.SOUTH);
    }

    public void agregarTerminal(String nombre, int capacidad, int puertas, int buses, int fingers, int controladores) {
        JLabel terminalLabel = new JLabel(
            String.format(
                "Terminal: %s | Capacidad: %d | Puertas: %d | Buses: %d | Fingers: %d | Controladores: %d",
                nombre, capacidad, puertas, buses, fingers, controladores
            )
        );
        terminalLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        terminalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelTerminal = new JPanel();
        panelTerminal.setLayout(new BoxLayout(panelTerminal, BoxLayout.Y_AXIS));
        panelTerminal.setBackground(Color.WHITE);
        panelTerminal.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelTerminal.add(terminalLabel);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelTerminal);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void setControlador(ActionListener c) {
        botonAñadirTerminal.addActionListener(c);
    }
}
