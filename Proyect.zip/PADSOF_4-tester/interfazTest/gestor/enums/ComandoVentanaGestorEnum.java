package interfazTest.gestor.enums;

/**
 * Enum que representa las acciones disponibles en la ventana del Gestor de Aeropuerto.
 */
public enum ComandoVentanaGestorEnum {
    ADMINISTRAR_USUARIOS,
    CONFIGURACION_AEROPUERTO,
    PETICIONES_VUELOS,
    VER_FACTURAS_ESTADISTICAS,
    CERRAR_SESION,

    // Subcomandos de ADMINISTRAR_USUARIOS
    CREAR_USUARIO,
    ELIMINAR_USUARIO,
    VER_USUARIOS,

    // Subcomandos de CONFIGURACION_AEROPUERTO
    GESTIONAR_PISTAS,
    GESTIONAR_TERMINALES,
    GESTIONAR_HANGARES,
    GESTIONAR_APARCAMIENTOS,
    CARGAR_TIPOS_AVIONES,

    // Subcomandos de gestion de ELEMENTOS
    AÑADIR_PISTA,
    AÑADIR_TERMINAL,
    AÑADIR_HANGAR,
    AÑADIR_APARCAMIENTO,

    // Subcomandos de añadir ELEMENTOS
    CONFIRMAR_AÑADIR_TERMINAL,
    CONFIRMAR_AÑADIR_PISTA,
    CONFIRMAR_AÑADIR_HANGAR,
    CONFIRMAR_AÑADIR_APARCAMIENTO,

    // Subcomandos de gestion de APLICACION
    GUARDAR_APLICACION,
    CARGAR_APLICACION

}