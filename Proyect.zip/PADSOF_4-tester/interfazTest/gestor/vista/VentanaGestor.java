package interfazTest.gestor.vista;

//  import interfazTest.componentes.PantallaBase;
//  import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
//  import interfazTest.gestor.primeraPantalla.vista.PanelAdministrarUsuarios;
//  import interfazTest.gestor.segundaPantalla.vista.PanelConfiguracionAeropuerto;
//  import interfazTest.gestor.terceraPantalla.vista.PanelPeticionesVuelos;
//  import interfazTest.gestor.cuartaPantalla.vista.PanelFacturasEstadisticas;

import java.util.List;
import java.awt.event.ActionListener;
import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

public class VentanaGestor extends JFrame {
    private final String NOMBRE_USUARIO_GESTOR = "Gestor de Aeropuerto";
    private PantallaBase pantalla;
    private List<JButton> botones;
    private String nombreUsuario;

    // private PanelAdministrarUsuarios panelUsuarios;
    // private PanelConfiguracionAeropuerto panelConfiguracion;
    // private PanelPeticionesVuelos panelPeticiones;
    // private PanelFacturasEstadisticas panelFacturasEstadisticas;

    public VentanaGestor() {
        this.nombreUsuario = NOMBRE_USUARIO_GESTOR;
        setTitle("Sistema Aeropuerto - Gestor");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        botones = List.of(
            crearBotonMenu("Administrar usuarios", ComandoVentanaGestorEnum.ADMINISTRAR_USUARIOS),
            crearBotonMenu("Configuración del aeropuerto", ComandoVentanaGestorEnum.CONFIGURACION_AEROPUERTO),
            crearBotonMenu("Peticiones de vuelos", ComandoVentanaGestorEnum.PETICIONES_VUELOS),
            crearBotonMenu("Emitir o consultar facturas y estadísticas", ComandoVentanaGestorEnum.VER_FACTURAS_ESTADISTICAS),
            crearBotonMenu("Cargar aviones", ComandoVentanaGestorEnum.CARGAR_TIPOS_AVIONES),
            crearBotonMenu("Guardar aplicacion", ComandoVentanaGestorEnum.GUARDAR_APLICACION),
            crearBotonMenu("Cargar aplicacion", ComandoVentanaGestorEnum.CARGAR_APLICACION)
        );

        for (JButton boton : botones) {
            boton.setHorizontalAlignment(SwingConstants.CENTER);
        }

        List<String> notificaciones = List.of(
            "Vuelo #2452: Retrasado. Estado: En preparación.",
            "Vuelo #45323: En hora. Estado: Esperando pista."
        );

        pantalla = new PantallaBase(nombreUsuario, botones, notificaciones);
        add(pantalla);
    }

    /* Helper */
    private JButton crearBotonMenu(String texto, ComandoVentanaGestorEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        return boton;
    }

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
        pantalla.getCerrarSesionButton().setActionCommand(ComandoVentanaGestorEnum.CERRAR_SESION.name());
        pantalla.getCerrarSesionButton().addActionListener(c);
    }

    public PantallaBase getPantallaBase() {
        return pantalla;
    }

    public void mostrarPanel(JPanel panel) {
        pantalla.mostrarContenidoEnPanelCentral(panel);
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public JButton getBotonCerrarSesion() {
        return pantalla.getCerrarSesionButton();
    }

    public void update() {
        pantalla.mostrarContenidoEnPanelCentral(new JPanel());
    }

    // public PanelAdministrarUsuarios getPanelUsuarios() {
    //     if (panelUsuarios == null) {
    //         panelUsuarios = new PanelAdministrarUsuarios(pantalla);
    //     }
    //     return panelUsuarios;
    // }

    // public PanelConfiguracionAeropuerto getPanelConfiguracion() {
    //     if (panelConfiguracion == null) {
    //         panelConfiguracion = new PanelConfiguracionAeropuerto(pantalla);
    //     }
    //     return panelConfiguracion;
    // }

    // public PanelPeticionesVuelos getPanelPeticiones() {
    //     if (panelPeticiones == null) {
    //         panelPeticiones = new PanelPeticionesVuelos(pantalla);
    //     }
    //     return panelPeticiones;
    // }

    // public PanelFacturasEstadisticas getPanelFacturasEstadisticas() {
    //     if (panelFacturasEstadisticas == null) {
    //         panelFacturasEstadisticas = new PanelFacturasEstadisticas(pantalla);
    //     }
    //     return panelFacturasEstadisticas;
    // }
}
