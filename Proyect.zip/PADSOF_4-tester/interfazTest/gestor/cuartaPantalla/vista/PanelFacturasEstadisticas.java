package interfazTest.gestor.cuartaPantalla.vista;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;

import java.awt.*;

public class PanelFacturasEstadisticas extends JPanel {

    private PantallaBase pantallaBase;
    private JList<String> listaFacturas;
    private DefaultListModel<String> modeloFacturas;
    private JTextField campoDesde;
    private JTextField campoHasta;
    private JButton botonEmitirFactura;
    private JButton botonEstadisticas;

    public PanelFacturasEstadisticas(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // --- Título ---
        JLabel titulo = new JLabel("📑 Histórico de Facturas", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        add(titulo, BorderLayout.NORTH);

        // --- Centro: Lista de facturas ---
        modeloFacturas = new DefaultListModel<>();
        listaFacturas = new JList<>(modeloFacturas);
        listaFacturas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // ✅ Añadir para centrar
        listaFacturas.setFont(new Font("Monospaced", Font.PLAIN, 14));
        DefaultListCellRenderer renderer = new DefaultListCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.CENTER);
        listaFacturas.setCellRenderer(renderer);

        JScrollPane scrollFacturas = new JScrollPane(listaFacturas);
        scrollFacturas.setPreferredSize(new Dimension(600, 250));
        scrollFacturas.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        add(scrollFacturas, BorderLayout.CENTER);

        // --- Sur: Filtros y botones ---
        JPanel panelSur = new JPanel();
        panelSur.setLayout(new BoxLayout(panelSur, BoxLayout.Y_AXIS));
        panelSur.setBackground(Color.WHITE);

        JLabel filtroLabel = new JLabel("📆 Filtrar por fechas", SwingConstants.CENTER);
        filtroLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        filtroLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        panelSur.add(filtroLabel);
        panelSur.add(Box.createVerticalStrut(10));

        JPanel fechasPanel = new JPanel(new FlowLayout());
        fechasPanel.setBackground(Color.WHITE);
        campoDesde = new JTextField("02/12/2025", 10);
        campoHasta = new JTextField("02/12/2025", 10);
        fechasPanel.add(new JLabel("Desde:"));
        fechasPanel.add(campoDesde);
        fechasPanel.add(new JLabel("Hasta:"));
        fechasPanel.add(campoHasta);
        panelSur.add(fechasPanel);

        JPanel botonesPanel = new JPanel(new FlowLayout());
        botonesPanel.setBackground(Color.WHITE);
        botonEmitirFactura = new JButton("Emitir nueva factura");
        botonEstadisticas = new JButton("Estadísticas de uso");
        botonesPanel.add(botonEmitirFactura);
        botonesPanel.add(botonEstadisticas);
        panelSur.add(botonesPanel);

        add(panelSur, BorderLayout.SOUTH);

        mostrarFacturasEjemplo(); // Simulación temporal
    }

    private void mostrarFacturasEjemplo() {
        modeloFacturas.clear();
        for (int i = 1; i <= 9; i++) {
            modeloFacturas.addElement("Factura" + i + " - 2025-04-" + (10 + i));
        }
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public JList<String> getListaFacturas() {
        return listaFacturas;
    }

    public JTextField getCampoDesde() {
        return campoDesde;
    }

    public JTextField getCampoHasta() {
        return campoHasta;
    }

    public JButton getBotonEmitirFactura() {
        return botonEmitirFactura;
    }

    public JButton getBotonEstadisticas() {
        return botonEstadisticas;
    }
}
