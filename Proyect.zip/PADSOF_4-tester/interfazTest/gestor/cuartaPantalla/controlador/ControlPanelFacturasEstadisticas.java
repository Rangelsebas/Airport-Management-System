package interfazTest.gestor.cuartaPantalla.controlador;

import javax.swing.*;

import interfazTest.gestor.cuartaPantalla.vista.PanelFacturasEstadisticas;

import java.awt.event.*;

public class ControlPanelFacturasEstadisticas {

    private PanelFacturasEstadisticas vista;

    public ControlPanelFacturasEstadisticas(PanelFacturasEstadisticas vista) {
        this.vista = vista;

        configurarListeners();
    }

    private void configurarListeners() {
        // 🔹 Al hacer doble clic sobre una factura → simula descarga
        vista.getListaFacturas().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    JList<String> lista = vista.getListaFacturas();
                    int index = lista.locationToIndex(evt.getPoint());
                    if (index >= 0) {
                        String seleccionada = lista.getModel().getElementAt(index);
                        JOptionPane.showMessageDialog(null,
                            "💾 Descargando " + seleccionada,
                            "Descarga de factura",
                            JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });

        // 🔹 Botón "Emitir nueva factura"
        vista.getBotonEmitirFactura().addActionListener(e -> {
            JOptionPane.showMessageDialog(null,
                "🧾 Emitiendo nueva factura...",
                "Emisión",
                JOptionPane.INFORMATION_MESSAGE);
        });

        // 🔹 Botón "Estadísticas de uso"
        vista.getBotonEstadisticas().addActionListener(e -> {
            String desde = vista.getCampoDesde().getText();
            String hasta = vista.getCampoHasta().getText();
            JOptionPane.showMessageDialog(null,
                "📊 Mostrando estadísticas desde " + desde + " hasta " + hasta,
                "Estadísticas",
                JOptionPane.INFORMATION_MESSAGE);
        });
    }
}