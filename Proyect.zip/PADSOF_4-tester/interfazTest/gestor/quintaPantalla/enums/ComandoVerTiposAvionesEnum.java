package interfazTest.gestor.quintaPantalla.enums;

public enum ComandoVerTiposAvionesEnum {
    REFRESCAR_TIPOS_AVIONES
}
