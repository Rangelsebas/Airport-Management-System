package interfazTest.gestor.quintaPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import interfazTest.gestor.quintaPantalla.enums.ComandoVerTiposAvionesEnum;
import interfazTest.gestor.quintaPantalla.vista.PanelVerTiposAviones;

public class ControlPanelVerTiposAviones implements ActionListener {

    private final PanelVerTiposAviones vista;

    public ControlPanelVerTiposAviones(PanelVerTiposAviones vista) {
        this.vista = vista;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVerTiposAvionesEnum comando = ComandoVerTiposAvionesEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case REFRESCAR_TIPOS_AVIONES:
                System.out.println("🔄 Refrescando tipos de aviones...");

                // Simulación de carga de datos (puedes cambiar por ServicioAviones más adelante)
                Object[][] datosDummy = {
                    {"T001", "Boeing", "737", 189, "Sí", 39, 35, 12, "Mercancías"},
                    {"T002", "Airbus", "A320", 180, "Sí", 37, 34, 12, "Mercancías"},
                    {"T003", "Lockheed", "C-130", 92, "No", 30, 40, 11, "Pasajeros"},
                    {"T004", "Embraer", "E195", 132, "Sí", 38, 28, 10, "Mercancías"}
                };

                vista.actualizarTabla(datosDummy);

                //     private Object[] convertirTipoAvionATabla(TipoAvion avion) {
                //     return new Object[]{
                //         avion.getId(),
                //         avion.getMarca(),
                //         avion.getModelo(),
                //         avion.getCapacidad(),
                //         avion.getDimension().getLargo() + "m",
                //         avion.getDimension().getAncho() + "m",
                //         avion.getDimension().getAlto() + "m",
                //         avion.getCategoria().name(),
                //         (avion.getControlTemperatura() ? "Sí" : "No")
                //     };
                // }

                // Object[][] datos = new Object[ejemplos.length][];
                // for (int i = 0; i < ejemplos.length; i++) {
                //     datos[i] = convertirTipoAvionATabla(ejemplos[i]);
                // }

                // vista.actualizarTabla(datos);
                break;
        }
    }
}