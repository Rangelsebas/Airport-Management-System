package interfazTest.gestor.primeraPantalla.crearUsuario.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelCrearUsuario extends JPanel {

    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JButton botonCrear;

    public PanelCrearUsuario() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Márgenes generosos

        // Campo para nuevo usuario
        campoUsuario = new JTextField();
        campoUsuario.setMaximumSize(new Dimension(500, 30)); // Más largo
        campoUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoUsuario, "Nuevo Usuario");
        add(campoUsuario);

        add(Box.createVerticalStrut(20)); // Espacio

        // Campo para contraseña
        campoContrasena = new JPasswordField();
        campoContrasena.setMaximumSize(new Dimension(500, 30)); // Más largo
        campoContrasena.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoContrasena, "Contraseña");
        add(campoContrasena);

        add(Box.createVerticalStrut(20)); // Espacio

        // Botón Crear
        botonCrear = new JButton("Crear");
        botonCrear.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonCrear.setActionCommand(ComandoVentanaGestorEnum.CREAR_USUARIO.name());
        add(botonCrear);
    }

    // Métodos MVC

    public void setControlador(ActionListener c) {
        botonCrear.addActionListener(c);
    }

    public String getUsuario() {
        return campoUsuario.getText().trim();
    }

    public String getContrasena() {
        return new String(campoContrasena.getPassword()).trim();
    }

    public void limpiarCampos() {
        restaurarPlaceholder(campoUsuario, "Nuevo Usuario");
        restaurarPlaceholder(campoContrasena, "Contraseña");
    }

    private void restaurarPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);
    }

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }
}
