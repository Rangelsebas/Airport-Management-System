package interfazTest.gestor.primeraPantalla.crearUsuario.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.primeraPantalla.crearUsuario.vista.PanelCrearUsuario;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelCrearUsuario implements ActionListener {

    private PanelCrearUsuario vista;
    private PantallaBase pantalla;

    public ControlPanelCrearUsuario(PanelCrearUsuario vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CREAR_USUARIO:
                procesarCreacionUsuario();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarCreacionUsuario() {
        String usuario = vista.getUsuario();
        String contrasena = vista.getContrasena();

        // Validaciones
        if (usuario == null || contrasena == null) {
            JOptionPane.showMessageDialog(vista, "Error interno: Campos nulos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (usuario.isEmpty() && contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe completar ambos campos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (usuario.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar el nombre de usuario.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar la contraseña.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (usuario.equals("Nuevo Usuario")) {
            JOptionPane.showMessageDialog(vista, "El nombre de usuario no puede ser 'Nuevo Usuario'.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (contrasena.equals("Contraseña")) {
            JOptionPane.showMessageDialog(vista, "La contraseña no puede ser 'Contraseña'.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    

        // TODO: Aquí deberías conectar con la lógica real de creación de usuarios en el sistema

        System.out.println("✅ Usuario creado: " + usuario + " | Contraseña: " + contrasena);

        JOptionPane.showMessageDialog(vista, "¡Usuario creado exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        vista.limpiarCampos();
    }
}