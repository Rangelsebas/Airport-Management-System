package interfazTest.gestor.primeraPantalla.eliminarUsuario.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfazTest.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelEliminarUsuario extends JPanel {

    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JButton botonEliminar;

    public PanelEliminarUsuario() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Márgenes generosos

        // Campo para usuario
        campoUsuario = new JTextField();
        campoUsuario.setMaximumSize(new Dimension(500, 30)); // Más largo
        campoUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoUsuario, "Usuario a eliminar");
        add(campoUsuario);

        add(Box.createVerticalStrut(20)); // Espacio

        // Campo para contraseña
        campoContrasena = new JPasswordField();
        campoContrasena.setMaximumSize(new Dimension(500, 30)); // Más largo
        campoContrasena.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoContrasena, "Contraseña");
        add(campoContrasena);

        add(Box.createVerticalStrut(20)); // Espacio

        // Botón Eliminar
        botonEliminar = new JButton("Eliminar");
        botonEliminar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonEliminar.setActionCommand(ComandoVentanaGestorEnum.ELIMINAR_USUARIO.name());
        add(botonEliminar);
    }

    // Métodos MVC

    public void setControlador(ActionListener c) {
        botonEliminar.addActionListener(c);
    }

    public String getUsuario() {
        return campoUsuario.getText().trim();
    }

    public String getContrasena() {
        return new String(campoContrasena.getPassword()).trim();
    }

    public void limpiarCampos() {
        restaurarPlaceholder(campoUsuario, "Usuario a eliminar");
        restaurarPlaceholder(campoContrasena, "Contraseña");
    }

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }

    private void restaurarPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);
    }
}