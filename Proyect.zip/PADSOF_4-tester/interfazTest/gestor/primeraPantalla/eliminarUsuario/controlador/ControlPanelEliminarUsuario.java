package interfazTest.gestor.primeraPantalla.eliminarUsuario.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.primeraPantalla.eliminarUsuario.vista.PanelEliminarUsuario;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelEliminarUsuario implements ActionListener {

    private PanelEliminarUsuario vista;
    private PantallaBase pantalla;

    public ControlPanelEliminarUsuario(PanelEliminarUsuario vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case ELIMINAR_USUARIO:
                procesarEliminacionUsuario();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarEliminacionUsuario() {
        String usuario = vista.getUsuario();
        String contrasena = vista.getContrasena();

        // Validaciones
        if (usuario == null || contrasena == null) {
            JOptionPane.showMessageDialog(vista, "Error interno: Campos nulos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (usuario.isEmpty() && contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe completar ambos campos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (usuario.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar el nombre de usuario.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar la contraseña.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    

        // TODO: Aquí deberías conectar con la lógica real para verificar existencia del usuario

        boolean existeUsuario = mockVerificarUsuario(usuario, contrasena); // Simulado

        if (!existeUsuario) {
            JOptionPane.showMessageDialog(vista, "Usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Si pasa la validación
        System.out.println("🗑️ Usuario eliminado: " + usuario);
        JOptionPane.showMessageDialog(vista, "¡Usuario eliminado exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        vista.limpiarCampos();
    }

    // ================================
    // MÉTODO MOCK SIMULADO PARA PRUEBAS
    // ================================

    private boolean mockVerificarUsuario(String usuario, String contrasena) {
        // 🔥 Simulación:
        // En un futuro, deberías buscar el usuario real en la base de datos o sistema.
        // Ahora para pruebas, solo permitimos eliminar si es "admin" y "1234"

        return usuario.equals("gestor") && contrasena.equals("1234");
    }
}
