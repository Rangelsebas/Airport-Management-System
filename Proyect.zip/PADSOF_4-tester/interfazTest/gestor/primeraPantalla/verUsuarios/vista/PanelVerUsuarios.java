package interfazTest.gestor.primeraPantalla.verUsuarios.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PanelVerUsuarios extends JPanel {

    private JPanel panelListado;

    public PanelVerUsuarios() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Usuarios Registrados", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(600, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);
    }

    public void agregarUsuario(String nombreUsuario) {
        JLabel usuarioLabel = new JLabel(nombreUsuario);
        usuarioLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        usuarioLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelUsuario = new JPanel();
        panelUsuario.setLayout(new BoxLayout(panelUsuario, BoxLayout.Y_AXIS));
        panelUsuario.setBackground(Color.WHITE);
        panelUsuario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelUsuario.add(usuarioLabel);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelUsuario);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }
}
