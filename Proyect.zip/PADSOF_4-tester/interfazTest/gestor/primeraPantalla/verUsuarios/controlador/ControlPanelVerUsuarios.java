package interfazTest.gestor.primeraPantalla.verUsuarios.controlador;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.primeraPantalla.verUsuarios.vista.PanelVerUsuarios;

public class ControlPanelVerUsuarios {

    private PanelVerUsuarios vista;
    private PantallaBase pantalla;

    public ControlPanelVerUsuarios(PanelVerUsuarios vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        cargarUsuariosDePrueba();
    }

    private void cargarUsuariosDePrueba() {
        // Mock de usuarios para pruebas visuales

        vista.agregarUsuario("admin");
        vista.agregarUsuario("operador01");
        vista.agregarUsuario("gestorMain");
        vista.agregarUsuario("controladorVuelo1");
        vista.agregarUsuario("supervisorPistas");
    }
}
