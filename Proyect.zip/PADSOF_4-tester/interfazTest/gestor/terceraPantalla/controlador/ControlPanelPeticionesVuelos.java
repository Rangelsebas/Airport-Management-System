package interfazTest.gestor.terceraPantalla.controlador;

import java.awt.event.MouseAdapter;

import java.awt.event.MouseEvent;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.terceraPantalla.submenu.controlador.ControlPanelGestionSolicitud;
import interfazTest.gestor.terceraPantalla.submenu.vista.PanelGestionSolicitud;
import interfazTest.gestor.terceraPantalla.vista.PanelPeticionesVuelos;

public class ControlPanelPeticionesVuelos {

    private final PanelPeticionesVuelos vista;
    private final PantallaBase pantalla;
    //private final List<SolicitudVuelo> solicitudes;

    public ControlPanelPeticionesVuelos(PanelPeticionesVuelos vista/*, List<SolicitudVuelo> solicitudes */) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        //this.solicitudes = solicitudes;

        //vista.mostrarSolicitudes(solicitudes);
        vista.mostrarEjemplo();

        // vista.getListaSolicitudes().addMouseListener(new MouseAdapter() {
        //     @Override
        //     public void mouseClicked(MouseEvent evt) {
        //         if (evt.getClickCount() == 2) {
        //             int index = vista.getListaSolicitudes().locationToIndex(evt.getPoint());
        //             if (index >= 0 && index < solicitudes.size()) {
        //                 SolicitudVuelo seleccionada = solicitudes.get(index);

        //                 // Abrir subpanel de gestión
        //                 PanelGestionSolicitud panelGestion = new PanelGestionSolicitud(seleccionada, pantalla);
        //                 new ControlPanelGestionSolicitud(panelGestion); // conecta la lógica
        //                 pantalla.mostrarContenidoEnPanelCentral(panelGestion);
        //             }
        //         }
        //     }
        // });

        /*--------SIMULACION, ESTO SE QUITA DESPUES--------*/
        vista.getListaSolicitudes().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int index = vista.getListaSolicitudes().locationToIndex(evt.getPoint());
        
                    if (index >= 0) {
                        // Simulación visual simple
                        System.out.println("🖱️ Doble clic en solicitud #" + (index + 1));
        
                        // Puedes pasar valores falsos solo para testeo visual
                        PanelGestionSolicitud panelGestion = new PanelGestionSolicitud(
                            pantalla
                        );
                        new ControlPanelGestionSolicitud(panelGestion); // igual, lógica vacía
                        pantalla.mostrarContenidoEnPanelCentral(panelGestion);
                    }
                }
            }
        });
    }
}
