package interfazTest.gestor.terceraPantalla.vista;

import interfazTest.componentes.PantallaBase;

import javax.swing.*;
import java.awt.*;

public class PanelPeticionesVuelos extends JPanel {

    private final PantallaBase pantallaBase;
    private final DefaultListModel<String> modeloLista;
    private final JList<String> listaSolicitudes;
    //private List<SolicitudVuelo> solicitudesActuales;

    public PanelPeticionesVuelos(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        this.modeloLista = new DefaultListModel<>();
        this.listaSolicitudes = new JList<>(modeloLista);
        //this.solicitudesActuales = new ArrayList<>();

        listaSolicitudes.setFont(new Font("Monospaced", Font.PLAIN, 13));
        listaSolicitudes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // ✅ Centrado visual de cada elemento
        DefaultListCellRenderer renderer = new DefaultListCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.CENTER);
        listaSolicitudes.setCellRenderer(renderer);

        JScrollPane scroll = new JScrollPane(listaSolicitudes);

        scroll.setBorder(BorderFactory.createEmptyBorder()); // sin bordes visibles
        listaSolicitudes.setBorder(BorderFactory.createEmptyBorder()); // sin marco interno

        listaSolicitudes.setBackground(Color.WHITE);
        scroll.getViewport().setBackground(Color.WHITE);

        scroll.setPreferredSize(new Dimension(900, 500));
        add(scroll, BorderLayout.CENTER);
    }

    public void mostrarEjemplo() {
        modeloLista.clear(); // Limpia la lista visual
    
        for (int i = 1; i <= 10; i++) {
            String codigo = "SOL" + (1000 + i);
            String fecha = "2025-04-" + (i < 10 ? "0" + i : i);
            String texto = "✈️ " + codigo + " | Air Europa | " + fecha;
            modeloLista.addElement(texto);
        }
    }

    // public void mostrarSolicitudes(List<SolicitudVuelo> solicitudes) {
    //     this.solicitudesActuales = solicitudes;
    //     modeloLista.clear();

    //     if (solicitudes.isEmpty()) {
    //         modeloLista.addElement("No hay solicitudes de vuelo pendientes.");
    //         return;
    //     }

    //     for (SolicitudVuelo solicitud : solicitudes) {
    //         String texto = "✈️ " + solicitud.getCodigo()
    //                 + " | " + solicitud.getAerolinea()
    //                 + " | " + solicitud.getFecha();
    //         modeloLista.addElement(texto);
    //     }
    // }

    public JList<String> getListaSolicitudes() {
        return listaSolicitudes;
    }

    // public List<SolicitudVuelo> getSolicitudesActuales() {
    //     return solicitudesActuales;
    // }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}
