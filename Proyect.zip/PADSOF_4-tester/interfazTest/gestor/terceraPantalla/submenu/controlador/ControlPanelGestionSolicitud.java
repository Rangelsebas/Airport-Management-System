package interfazTest.gestor.terceraPantalla.submenu.controlador;

import javax.swing.*;

import interfazTest.gestor.terceraPantalla.submenu.vista.PanelGestionSolicitud;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelGestionSolicitud implements ActionListener {

    private final PanelGestionSolicitud vista;
    //private final SolicitudVuelo solicitud;

    public ControlPanelGestionSolicitud(PanelGestionSolicitud vista) {
        this.vista = vista;
        //this.solicitud = vista.getSolicitud();

        this.vista.getBtnAprobar().addActionListener(this);
        this.vista.getBtnRechazar().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnAprobar()) {
            String terminal = (String) vista.getComboTerminal().getSelectedItem();
            String controlador = (String) vista.getComboControlador().getSelectedItem();

            System.out.println("✅ Solicitud aprobada:");
            // System.out.println("→ Código: " + solicitud.getCodigo());
            System.out.println("→ Terminal asignado: " + terminal);
            System.out.println("→ Controlador asignado: " + controlador);

            JOptionPane.showMessageDialog(null, "Solicitud aprobada correctamente.");

        } else if (source == vista.getBtnRechazar()) {
            System.out.println("❌ Solicitud rechazada:");
            // System.out.println("→ Código: " + solicitud.getCodigo());

            JOptionPane.showMessageDialog(null, "Solicitud rechazada.");
        }
    }
}
