package interfazTest.gestor.controlador;

import interfazTest.componentes.PantallaBase;
import interfazTest.gestor.cuartaPantalla.controlador.ControlPanelFacturasEstadisticas;
import interfazTest.gestor.cuartaPantalla.vista.PanelFacturasEstadisticas;
import interfazTest.gestor.enums.ComandoVentanaGestorEnum;
import interfazTest.gestor.primeraPantalla.controlador.ControlPanelAdministrarUsuarios;
import interfazTest.gestor.primeraPantalla.vista.PanelAdministrarUsuarios;
import interfazTest.gestor.quintaPantalla.controlador.ControlPanelVerTiposAviones;
import interfazTest.gestor.quintaPantalla.vista.PanelVerTiposAviones;
import interfazTest.gestor.segundaPantalla.controlador.ControlPanelConfiguracionAeropuerto;
import interfazTest.gestor.segundaPantalla.vista.PanelConfiguracionAeropuerto;
import interfazTest.gestor.terceraPantalla.controlador.ControlPanelPeticionesVuelos;
import interfazTest.gestor.terceraPantalla.vista.PanelPeticionesVuelos;
import interfazTest.gestor.vista.VentanaGestor;
import interfazTest.login.controlador.ControlPanelLoginFrame;
import interfazTest.login.vista.PanelLoginFrame;

import java.awt.Component;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class ControlVentanaGestor implements ActionListener {

    private VentanaGestor vista;
    private PantallaBase pantalla;

    public ControlVentanaGestor(VentanaGestor vista) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case ADMINISTRAR_USUARIOS:
                PanelAdministrarUsuarios panelUsuarios = new PanelAdministrarUsuarios(pantalla);
                new ControlPanelAdministrarUsuarios(panelUsuarios, vista.getPantallaBase()); // conecta el controlador de la vista
                pantalla.mostrarContenidoEnPanelCentral(panelUsuarios);
                break;

            case CONFIGURACION_AEROPUERTO:
                PanelConfiguracionAeropuerto panelConfiguracion = new PanelConfiguracionAeropuerto(vista.getPantallaBase());
                new ControlPanelConfiguracionAeropuerto(panelConfiguracion, pantalla); // conecta el controlador de la vista
                vista.mostrarPanel(panelConfiguracion);
                break;

            case PETICIONES_VUELOS:
                //List<SolicitudVuelo> solicitudes = servicioVuelos.getSolicitudesPendientes(); // Simulado o real
                PanelPeticionesVuelos panelPeticiones = new PanelPeticionesVuelos(pantalla);
                new ControlPanelPeticionesVuelos(panelPeticiones/*, solicitudes */);
                pantalla.mostrarContenidoEnPanelCentral(panelPeticiones);
                break;

            case VER_FACTURAS_ESTADISTICAS:
                PanelFacturasEstadisticas panelFacturas = new PanelFacturasEstadisticas(vista.getPantallaBase());
                new ControlPanelFacturasEstadisticas(panelFacturas); // conectar lógica
                vista.mostrarPanel(panelFacturas);
                break;

            case CARGAR_TIPOS_AVIONES:
                PanelVerTiposAviones panelTipos = new PanelVerTiposAviones();
                new ControlPanelVerTiposAviones(panelTipos); // conecta el controlador
                vista.mostrarPanel(panelTipos);
                break;

            case GUARDAR_APLICACION:
                // Implementar lógica para guardar la aplicación
                JOptionPane.showMessageDialog(vista, "Aplicación guardada correctamente.", "Guardar Aplicación", JOptionPane.INFORMATION_MESSAGE);
                break;

            case CARGAR_APLICACION:
                // Implementar lógica para cargar la aplicación
                JOptionPane.showMessageDialog(vista, "Aplicación cargada correctamente.", "Cargar Aplicación", JOptionPane.INFORMATION_MESSAGE);
                break;

            case CERRAR_SESION:
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Estás seguro que deseas cerrar sesión?",
                        "Cerrar sesión", JOptionPane.YES_NO_OPTION);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.out.println("Sesión cerrada correctamente.");

                    // 🔥 Cerrar ventana actual
                    Window ventana = SwingUtilities.getWindowAncestor((Component) e.getSource());
                    if (ventana != null) {
                        ventana.dispose();
                    }

                    // 🔥 Volver al login
                    SwingUtilities.invokeLater(() -> {
                        PanelLoginFrame loginFrame = new PanelLoginFrame();
                        new ControlPanelLoginFrame(loginFrame); // conecta el controlador
                        loginFrame.setVisible(true);
                    });
                }
                break;
            default:
                break;
        }
    }
}
