package septimaPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import septimaPantalla.enums.ComandoNotificacionesEnum;
import septimaPantalla.vista.PanelNotificacionesHistorico;

import java.util.List;

public class ControlPanelNotificaciones implements ActionListener {

    private PanelNotificacionesHistorico vista;

    public ControlPanelNotificaciones(PanelNotificacionesHistorico vista) {
        this.vista = vista;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoNotificacionesEnum comando = ComandoNotificacionesEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case VER_NOTIFICACIONES:
                List<String> notificaciones = List.of(
                    "Vuelo #2452: Retrasado. Estado: En preparación.",
                    "Vuelo #45323: En hora. Estado: Esperando pista.",
                    "Vuelo #1178: Cancelado por condiciones climáticas."
                );
                vista.mostrarNotificaciones(notificaciones);
                break;
        }
    }
}