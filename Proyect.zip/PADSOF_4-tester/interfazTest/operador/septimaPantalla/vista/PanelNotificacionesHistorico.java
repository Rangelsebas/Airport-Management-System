package septimaPantalla.vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import interfazTest.componentes.PantallaBase;
import septimaPantalla.enums.ComandoNotificacionesEnum;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

public class PanelNotificacionesHistorico extends JPanel {

    private PantallaBase pantallaBase;
    private JButton botonVerNotificaciones;

    public PanelNotificacionesHistorico(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        botonVerNotificaciones = new JButton("Ver Notificaciones");
        botonVerNotificaciones.setActionCommand(ComandoNotificacionesEnum.VER_NOTIFICACIONES.name());

        // Estilo del botón
        Dimension buttonSize = new Dimension(240, 55);
        botonVerNotificaciones.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonVerNotificaciones.setMaximumSize(buttonSize);
        botonVerNotificaciones.setPreferredSize(buttonSize);
        botonVerNotificaciones.setHorizontalAlignment(SwingConstants.CENTER);
        botonVerNotificaciones.setVerticalAlignment(SwingConstants.CENTER);
        botonVerNotificaciones.setMargin(new Insets(10, 10, 10, 10));
        botonVerNotificaciones.setFocusable(false);

        add(Box.createVerticalStrut(20));
        add(botonVerNotificaciones);
    }

    public void setControlador(ActionListener c) {
        botonVerNotificaciones.addActionListener(c);
    }

    public void mostrarPanel(JPanel panel) {
        pantallaBase.mostrarContenidoEnPanelCentral(panel);
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    //TODO: la lista de las notificaciones esta en Aplicacion.java
    public void mostrarNotificaciones(List<String> notificaciones) {
        JPanel panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        for (String mensaje : notificaciones) {
            JLabel label = new JLabel("• " + mensaje);
            label.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            panelListado.add(label);
        }

        JScrollPane scrollPane = new JScrollPane(panelListado);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JPanel panelCentral = new JPanel();
        panelCentral.setLayout(new BorderLayout());
        panelCentral.add(scrollPane, BorderLayout.CENTER);

        mostrarPanel(panelCentral);
    }
}
