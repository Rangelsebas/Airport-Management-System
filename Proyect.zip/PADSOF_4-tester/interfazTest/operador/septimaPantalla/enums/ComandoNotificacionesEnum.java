package septimaPantalla.enums;

public enum ComandoNotificacionesEnum {
    VER_NOTIFICACIONES
}
