package terceraPantalla.historico.controlador;


import terceraPantalla.historico.vista.PanelVuelosHistorico;

public class ControlPanelVuelosHistorico {

    private final PanelVuelosHistorico vista;
    //private final ServicioVuelos servicio;

    public ControlPanelVuelosHistorico(PanelVuelosHistorico vista/*, ServicioVuelos servicio */) {
        this.vista = vista;
        //this.servicio = servicio;
        // No hay acciones, solo vista
    }
}