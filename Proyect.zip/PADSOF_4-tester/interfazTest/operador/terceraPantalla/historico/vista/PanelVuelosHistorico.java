package terceraPantalla.historico.vista;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;

import java.awt.*;

public class PanelVuelosHistorico extends JPanel {

    private final PantallaBase pantallaBase;
    private final JTextArea areaVuelos;

    public PanelVuelosHistorico(/*List<Vuelo> vuelos, */PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("📚 Histórico de Vuelos");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        add(titulo, BorderLayout.NORTH);

        areaVuelos = new JTextArea();
        areaVuelos.setEditable(false);
        areaVuelos.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaVuelos.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(areaVuelos);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scroll.setPreferredSize(new Dimension(900, 500)); 
        add(scroll, BorderLayout.CENTER);

        //mostrarVuelos(vuelos);
        areaVuelos.setText("""
        ✈️ Código: VH001 | Estado: FINALIZADO | Origen: Madrid | Destino: París | Aerolíneas: Iberia

        ✈️ Código: VH002 | Estado: CANCELADO | Origen: Londres | Destino: Berlín | Aerolíneas: British Airways

        ✈️ Código: VH003 | Estado: FINALIZADO | Origen: Roma | Destino: Atenas | Aerolíneas: Alitalia

        ✈️ Código: VH004 | Estado: FINALIZADO | Origen: Lisboa | Destino: Barcelona | Aerolíneas: TAP Air Portugal

        ✈️ Código: VH005 | Estado: CANCELADO | Origen: Ámsterdam | Destino: Praga | Aerolíneas: KLM

        ✈️ Código: VH006 | Estado: FINALIZADO | Origen: Estocolmo | Destino: Oslo | Aerolíneas: SAS

        ✈️ Código: VH007 | Estado: RECHAZADO | Origen: Bruselas | Destino: Viena | Aerolíneas: Brussels Airlines

        ✈️ Código: VH008 | Estado: FINALIZADO | Origen: Budapest | Destino: Zúrich | Aerolíneas: Wizz Air

        ✈️ Código: VH009 | Estado: CANCELADO | Origen: Dubái | Destino: Doha | Aerolíneas: Emirates

        ✈️ Código: VH010 | Estado: FINALIZADO | Origen: Nueva York | Destino: Los Ángeles | Aerolíneas: Delta

        ✈️ Código: VH011 | Estado: MODIFICADO | Origen: Chicago | Destino: Miami | Aerolíneas: United

        ✈️ Código: VH012 | Estado: FINALIZADO | Origen: Toronto | Destino: Vancouver | Aerolíneas: Air Canada

        ✈️ Código: VH013 | Estado: CANCELADO | Origen: Ciudad de México | Destino: Cancún | Aerolíneas: Aeroméxico

        ✈️ Código: VH014 | Estado: FINALIZADO | Origen: Bogotá | Destino: Lima | Aerolíneas: Avianca

        ✈️ Código: VH015 | Estado: FINALIZADO | Origen: Quito | Destino: Guayaquil | Aerolíneas: LATAM

        ✈️ Código: VH016 | Estado: CANCELADO | Origen: Montevideo | Destino: Buenos Aires | Aerolíneas: Sky Airline

        ✈️ Código: VH017 | Estado: RECHAZADO | Origen: Caracas | Destino: Panamá | Aerolíneas: Conviasa

        ✈️ Código: VH018 | Estado: FINALIZADO | Origen: Santiago | Destino: Sao Paulo | Aerolíneas: LATAM

        ✈️ Código: VH019 | Estado: FINALIZADO | Origen: San José | Destino: Managua | Aerolíneas: Volaris

        ✈️ Código: VH020 | Estado: FINALIZADO | Origen: Punta Cana | Destino: Santo Domingo | Aerolíneas: Arajet
        """);

    }

    // private void mostrarVuelos(List<Vuelo> vuelos) {
    //     if (vuelos.isEmpty()) {
    //         areaVuelos.setText("No hay vuelos registrados.");
    //         return;
    //     }

    //     StringBuilder texto = new StringBuilder();

    //     for (Vuelo v : vuelos) {
    //         texto.append("✈️ Código: ").append(v.getCodigoVuelo())
    //             .append(" | Estado: ").append(v.getEstado().name())
    //             .append(" | Origen: ").append(v.getOrigen())
    //             .append(" | Destino: ").append(v.getDestino())
    //             .append(" | Aerolíneas: ")
    //             .append(v.getAerolineas().stream()
    //                     .map(a -> a.getNombre())
    //                     .reduce((a1, a2) -> a1 + ", " + a2).orElse("Ninguna"))
    //             .append("\n\n");
    //     }

    //     areaVuelos.setText(texto.toString());
    // }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}
