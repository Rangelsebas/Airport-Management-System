package terceraPantalla.buscar.controlador;


//import interfazTest.operador.terceraPantalla.otro.ServicioVuelos;
import terceraPantalla.buscar.vista.PanelBuscarVuelo;
//import vuelo.EstadosVuelo;
//import vuelo.Vuelo;
//import vuelo.Vuelo;

public class ControlPanelBuscarVuelo {

    private final PanelBuscarVuelo vista;
    // private final ServicioVuelos servicio;
    // private final Vuelo vuelo;

    public ControlPanelBuscarVuelo(PanelBuscarVuelo vista/*, ServicioVuelos servicio, Vuelo vuelo */) {
        this.vista = vista;
        // this.servicio = servicio;
        // this.vuelo = vuelo;

        // Como es solo informativo, no hay listeners que conectar
        // El panel ya muestra la información directamente
    }
}









