package terceraPantalla.buscar.vista;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
//import vuelo.Vuelo;

import java.awt.*;

public class PanelBuscarVuelo extends JPanel {

    private final PantallaBase pantallaBase;
    //private final Vuelo vuelo;
    private final JLabel infoVueloLabel;

    public PanelBuscarVuelo(/*Vuelo vuelo, */PantallaBase pantallaBase) {
        //this.vuelo = vuelo;
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("🛫 Información del Vuelo");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createVerticalStrut(20));
        add(titulo);
        add(Box.createVerticalStrut(20));

        infoVueloLabel = new JLabel();
        infoVueloLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        infoVueloLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        infoVueloLabel.setHorizontalAlignment(SwingConstants.CENTER);

        add(infoVueloLabel);

        mostrarInformacionVuelo();
    }

    private void mostrarInformacionVuelo() {
        // String resumen = "<html><b>Código:</b> " + vuelo.getCodigoVuelo()
        //         + " | <b>Estado:</b> " + vuelo.getEstado().name()
        //         + " | <b>Origen:</b> " + vuelo.getOrigen()
        //         + " | <b>Destino:</b> " + vuelo.getDestino()
        //         + " | <b>Aerolíneas:</b> " + vuelo.getAerolineas().stream()
        //             .map(a -> a.getNombre())
        //             .reduce((a1, a2) -> a1 + ", " + a2).orElse("Ninguna")
        //         + "</html>";

        infoVueloLabel.setText("✈️ Código: VH001 | Estado: FINALIZADO | Origen: Madrid | Destino: París | Aerolíneas: Iberia");
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    // public Vuelo getVuelo() {
    //     return vuelo;
    // }
}