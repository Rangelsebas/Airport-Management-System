package interfazTest.operador.terceraPantalla.otro;


// import java.util.ArrayList;
// import java.util.List;
// import java.util.stream.Collectors;

// import aeropuerto.elementos.Pista;
// import vuelo.EstadosVuelo;
// import vuelo.Vuelo;

public class ServicioVuelos {

    // private List<Vuelo> vuelos;

    // public ServicioVuelos() {
    //     // Aquí deberías cargar los vuelos desde el sistema real o mockear algunos para pruebas
    //     this.vuelos = new ArrayList<>();
    // }

    // public void agregarVuelo(Vuelo vuelo) {
    //     vuelos.add(vuelo);
    // }

    // public Vuelo buscarVueloPorCodigo(String codigo) {
    //     for (Vuelo v : vuelos) {
    //         if (v.getCodigoVuelo().equals(codigo)) {
    //             return v;
    //         }
    //     }
    //     return null;
    // }

    // public List<Vuelo> obtenerVuelosEnCurso() {
    //     return vuelos.stream()
    //             .filter(v -> v.getEstado() == EstadosVuelo.EN_PREPARACION)
    //             .collect(Collectors.toList());
    // }
    
    // public List<Vuelo> obtenerVuelosPendientes() {
    //     return vuelos.stream()
    //             .filter(v -> v.getEstado() == EstadosVuelo.PENDIENTE)
    //             .collect(Collectors.toList());
    // }
    
    // public List<Vuelo> obtenerVuelosFinalizados() {
    //     return vuelos.stream()
    //             .filter(v -> v.getEstado() == EstadosVuelo.FINALIZADO)
    //             .collect(Collectors.toList());
    // }

    // public boolean cambiarEstadoVuelo(Vuelo vuelo, EstadosVuelo nuevoEstado) {
    //     if (vuelo.puedePasarA(nuevoEstado)) {
    //         vuelo.cambiarEstado(nuevoEstado);
    //         return true;
    //     }
    //     return false;
    // }

    // public List<Vuelo> getVuelosEnCurso() {
    //     return vuelos.stream()
    //             .filter(v -> {
    //                 EstadosVuelo estado = v.getEstado();
    //                 return estado == EstadosVuelo.ESPERANDO_PISTA_ATERRIZAJE
    //                     || estado == EstadosVuelo.ESPERANDO_ATERRIZAR
    //                     || estado == EstadosVuelo.ATERRIZADO
    //                     || estado == EstadosVuelo.DESCARGANDO
    //                     || estado == EstadosVuelo.DEBARANCANDO
    //                     || estado == EstadosVuelo.EMBARCANDO
    //                     || estado == EstadosVuelo.CARGANDO
    //                     || estado == EstadosVuelo.EN_PREPARACION
    //                     || estado == EstadosVuelo.ESPERANDO_PISTA_DESPEGUE
    //                     || estado == EstadosVuelo.ESPERANDO_DESPEGUE
    //                     || estado == EstadosVuelo.VOLANDO;
    //             })
    //             .toList();
    // }

    // public List<Vuelo> getVuelosPendientes() {
    //     return vuelos.stream()
    //             .filter(v -> v.getEstado() == EstadosVuelo.PENDIENTE)
    //             .toList();
    // }

    // public List<Vuelo> getTodosLosVuelos() {
    //     return vuelos;
    // }

    // // Ejemplos de acciones del flujo de estados
    // //TODO: Para cada metodo en Vuelo sobre el cambio de estado de un Vuelo, debo llamarlos aqui
    // public boolean asignarPistaALlegada(Vuelo vuelo, Pista pista) {
    //     try {
    //         return vuelo.asignarPistaCambioEstado(pista);
    //     } catch (Exception e) {
    //         return false;
    //     }
    // }

    // public boolean iniciarDesembarque(Vuelo vuelo) {
    //     try {
    //         vuelo.desembarcarPasajeros();
    //         return true;
    //     } catch (Exception e) {
    //         return false;
    //     }
    // }

    // public boolean iniciarDescarga(Vuelo vuelo) {
    //     try {
    //         vuelo.descargarMercancia();
    //         return true;
    //     } catch (Exception e) {
    //         return false;
    //     }
    // }

    // public boolean terminarLimpieza(Vuelo vuelo) {
    //     try {
    //         vuelo.finalizarLimpieza();
    //         return true;
    //     } catch (Exception e) {
    //         return false;
    //     }
    // }

    // public boolean completarRevisionTecnica(Vuelo vuelo) {
    //     try {
    //         vuelo.realizarRevisionTecnica();
    //         return true;
    //     } catch (Exception e) {
    //         return false;
    //     }
    // }

    // public boolean prepararProximaSalida(Vuelo vuelo) {
    //     try {
    //         vuelo.prepararParaSalida();
    //         return true;
    //     } catch (Exception e) {
    //         return false;
    //     }
    // }

    // public boolean asignarPistaDespegue(Vuelo vuelo) {
    //     try {
    //         vuelo.asignarPistaDespegue();
    //         return true;
    //     } catch (Exception e) {
    //         return false;
    //     }
    // }

    // public boolean aprobarSalida(Vuelo vuelo) {
    //     try {
    //         vuelo.aprobarSalida();
    //         return true;
    //     } catch (Exception e) {
    //         return false;
    //     }
    // }

    // public List<Vuelo> getTodosLosVuelos() {
    //     return vuelos;
    // }
}