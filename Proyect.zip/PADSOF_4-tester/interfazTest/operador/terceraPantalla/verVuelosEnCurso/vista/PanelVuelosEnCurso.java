package terceraPantalla.verVuelosEnCurso.vista;

import java.awt.*;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import interfazTest.componentes.PantallaBase;

public class PanelVuelosEnCurso extends JPanel {

    private final PantallaBase pantallaBase;
    private final JTextArea areaVuelos;

    public PanelVuelosEnCurso(/*List<Vuelo> vuelos, */PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("🛫 Vuelos en Curso");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        add(titulo, BorderLayout.NORTH);

        areaVuelos = new JTextArea();
        areaVuelos.setEditable(false);
        areaVuelos.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaVuelos.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(areaVuelos);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scroll.setPreferredSize(new java.awt.Dimension(900, 500)); 
        add(scroll, BorderLayout.CENTER);

        //mostrarVuelos(vuelos);
        areaVuelos.setText("""
        ✈️ Código: V1234 | Estado: EN_PREPARACION | Origen: Madrid | Destino: París | Aerolíneas: Iberia

        ✈️ Código: V2345 | Estado: DESCARGANDO | Origen: Frankfurt | Destino: Nueva York | Aerolíneas: Lufthansa

        ✈️ Código: V3456 | Estado: OPERATIVO | Origen: Bogotá | Destino: Lima | Aerolíneas: Avianca

        ✈️ Código: V4567 | Estado: CARGANDO | Origen: Toronto | Destino: Londres | Aerolíneas: Air Canada

        ✈️ Código: V5678 | Estado: EMBARCANDO | Origen: Roma | Destino: Berlín | Aerolíneas: Alitalia

        ✈️ Código: V6789 | Estado: ESPERANDO_DESPEGUE | Origen: Santiago | Destino: Buenos Aires | Aerolíneas: LATAM

        ✈️ Código: V7890 | Estado: VOLANDO | Origen: Miami | Destino: Ciudad de México | Aerolíneas: American Airlines

        ✈️ Código: V8901 | Estado: EN_PREPARACION | Origen: Chicago | Destino: Madrid | Aerolíneas: United

        ✈️ Código: V9012 | Estado: DESEMBARCANDO | Origen: São Paulo | Destino: Lima | Aerolíneas: Azul

        ✈️ Código: V0123 | Estado: ATERRIZADO | Origen: Amsterdam | Destino: Varsovia | Aerolíneas: KLM
        """);
    }

    // private void mostrarVuelos(List<Vuelo> vuelos) {
    //     if (vuelos.isEmpty()) {
    //         areaVuelos.setText("No hay vuelos en curso.");
    //         return;
    //     }

    //     StringBuilder texto = new StringBuilder();

    //     for (Vuelo v : vuelos) {
    //         texto.append("✈️ Código: ").append(v.getCodigoVuelo())
    //             .append(" | Estado: ").append(v.getEstado().name())
    //             .append(" | Origen: ").append(v.getOrigen())
    //             .append(" | Destino: ").append(v.getDestino())
    //             .append(" | Aerolíneas: ")
    //             .append(v.getAerolineas().stream()
    //                     .map(a -> a.getNombre())
    //                     .reduce((a1, a2) -> a1 + ", " + a2).orElse("Ninguna"))
    //             .append("\n\n");
    //     }

    //     areaVuelos.setText(texto.toString());
    // }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}