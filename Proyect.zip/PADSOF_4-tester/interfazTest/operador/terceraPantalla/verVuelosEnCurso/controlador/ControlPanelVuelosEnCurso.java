package terceraPantalla.verVuelosEnCurso.controlador;

import terceraPantalla.verVuelosEnCurso.vista.PanelVuelosEnCurso;

public class ControlPanelVuelosEnCurso {

    private final PanelVuelosEnCurso vista;
    //private final ServicioVuelos servicio;

    public ControlPanelVuelosEnCurso(PanelVuelosEnCurso vista/*, ServicioVuelos servicio */) {
        this.vista = vista;
        //this.servicio = servicio;

        // Solo muestra info al cargar, no hay acciones
        //List<Vuelo> vuelos = servicio.getVuelosEnCurso(); // debes tenerlo implementado
        // El panel ya lo muestra en el constructor (opcionalmente puedes refrescar aquí)
    }
}
