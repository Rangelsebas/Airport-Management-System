package terceraPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import interfazTest.componentes.PantallaBase;
import terceraPantalla.buscar.controlador.ControlPanelBuscarVuelo;
import terceraPantalla.buscar.vista.PanelBuscarVuelo;
import terceraPantalla.enums.ComandoEstadoVueloEnum;
import terceraPantalla.historico.controlador.ControlPanelVuelosHistorico;
import terceraPantalla.historico.vista.PanelVuelosHistorico;
import terceraPantalla.verVuelosEnCurso.controlador.ControlPanelVuelosEnCurso;
import terceraPantalla.verVuelosEnCurso.vista.PanelVuelosEnCurso;
import terceraPantalla.verVuelosPendientes.controlador.ControlPanelVuelosPendientes;
import terceraPantalla.verVuelosPendientes.vista.PanelVuelosPendientes;
import terceraPantalla.vista.PanelControlarEstadoVuelo;
//import vuelo.Vuelo;

import javax.swing.JOptionPane;

public class ControlPanelEstadoVuelo implements ActionListener {

    private PanelControlarEstadoVuelo vista;
    private PantallaBase pantalla;
    //private final ServicioVuelos servicioVuelos; 

    public ControlPanelEstadoVuelo(PanelControlarEstadoVuelo vista, PantallaBase pantalla/*, ServicioVuelos servicioVuelos */) {
        this.vista = vista;
        this.pantalla = pantalla;
        //this.servicioVuelos = servicioVuelos;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoEstadoVueloEnum comando = ComandoEstadoVueloEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case BUSCAR_VUELO:
                String codigo = vista.getCodigoVuelo();

                if (codigo.isBlank() || codigo.isEmpty() || codigo == null) {
                    JOptionPane.showMessageDialog(null, "❗ Ingresa un código de vuelo para buscar.", "Campo vacío", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                //Vuelo vuelo = servicioVuelos.buscarVueloPorCodigo(codigo);

                // if (vuelo == null) {
                //     JOptionPane.showMessageDialog(null, "❌ Vuelo no encontrado con ese código.", "No encontrado", JOptionPane.ERROR_MESSAGE);
                //     return;
                // }

                // Crear subpanel visual con la información del vuelo
                PanelBuscarVuelo panelBuscar = new PanelBuscarVuelo(/*vuelo, */pantalla);
                new ControlPanelBuscarVuelo(panelBuscar/* , servicioVuelos, vuelo*/); 
                pantalla.mostrarContenidoEnPanelCentral(panelBuscar);
                break;

            case VUELOS_EN_CURSO:
                //List<Vuelo> vuelosEnCurso = servicioVuelos.getVuelosEnCurso();

                PanelVuelosEnCurso panelVuelos = new PanelVuelosEnCurso(/*vuelosEnCurso, */pantalla);
                new ControlPanelVuelosEnCurso(panelVuelos/*, servicioVuelos */);

                pantalla.mostrarContenidoEnPanelCentral(panelVuelos);
                break;

            case VUELOS_PENDIENTES:
                //List<Vuelo> pendientes = servicioVuelos.getVuelosPendientes();

                PanelVuelosPendientes panelPendientes = new PanelVuelosPendientes(/*pendientes, */pantalla);
                new ControlPanelVuelosPendientes(panelPendientes/* , servicioVuelos*/);

                pantalla.mostrarContenidoEnPanelCentral(panelPendientes);
                break;

            case VUELOS_HISTORICO:
                //List<Vuelo> todos = servicioVuelos.getTodosLosVuelos();

                PanelVuelosHistorico panelHistorico = new PanelVuelosHistorico(/*todos, */pantalla);
                new ControlPanelVuelosHistorico(panelHistorico/*, servicioVuelos */);

                pantalla.mostrarContenidoEnPanelCentral(panelHistorico);
                break;
        }
    }
}
