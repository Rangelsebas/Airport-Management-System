package terceraPantalla.verVuelosPendientes.controlador;

import terceraPantalla.verVuelosPendientes.vista.PanelVuelosPendientes;

public class ControlPanelVuelosPendientes {

    private final PanelVuelosPendientes vista;
    //private final ServicioVuelos servicio;

    public ControlPanelVuelosPendientes(PanelVuelosPendientes vista/*, ServicioVuelos servicio */) {
        this.vista = vista;
        //this.servicio = servicio;
        // Sin acciones, solo mostrar info
    }
}
