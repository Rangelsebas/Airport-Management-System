package terceraPantalla.verVuelosPendientes.vista;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;

import java.awt.*;

public class PanelVuelosPendientes extends JPanel {

    private final PantallaBase pantallaBase;
    private final JTextArea areaVuelos;

    public PanelVuelosPendientes(/*List<Vuelo> vuelos, */PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("📋 Vuelos Pendientes");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        add(titulo, BorderLayout.NORTH);

        areaVuelos = new JTextArea();
        areaVuelos.setEditable(false);
        areaVuelos.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaVuelos.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(areaVuelos);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scroll.setPreferredSize(new Dimension(900, 500)); 
        add(scroll, BorderLayout.CENTER);

        //mostrarVuelos(vuelos);
        areaVuelos.setText("""
        ✈️ Código: VP001 | Estado: PENDIENTE | Origen: Quito | Destino: Lima | Aerolíneas: LATAM

        ✈️ Código: VP002 | Estado: PENDIENTE | Origen: Bogotá | Destino: Santiago | Aerolíneas: Avianca

        ✈️ Código: VP003 | Estado: PENDIENTE | Origen: Ciudad de México | Destino: Cancún | Aerolíneas: Aeroméxico

        ✈️ Código: VP004 | Estado: PENDIENTE | Origen: Buenos Aires | Destino: Montevideo | Aerolíneas: FlyBondi

        ✈️ Código: VP005 | Estado: PENDIENTE | Origen: Sao Paulo | Destino: Madrid | Aerolíneas: Iberia

        ✈️ Código: VP006 | Estado: PENDIENTE | Origen: Caracas | Destino: Miami | Aerolíneas: Conviasa

        ✈️ Código: VP007 | Estado: PENDIENTE | Origen: Panamá | Destino: Toronto | Aerolíneas: Copa Airlines

        ✈️ Código: VP008 | Estado: PENDIENTE | Origen: San Juan | Destino: Nueva York | Aerolíneas: JetBlue

        ✈️ Código: VP009 | Estado: PENDIENTE | Origen: Guadalajara | Destino: Dallas | Aerolíneas: Volaris

        ✈️ Código: VP010 | Estado: PENDIENTE | Origen: Medellín | Destino: Bogotá | Aerolíneas: Viva Air
        """);

    }

    // private void mostrarVuelos(List<Vuelo> vuelos) {
    //     if (vuelos.isEmpty()) {
    //         areaVuelos.setText("No hay vuelos pendientes.");
    //         return;
    //     }

    //     StringBuilder texto = new StringBuilder();

    //     for (Vuelo v : vuelos) {
    //         texto.append("✈️ Código: ").append(v.getCodigoVuelo())
    //             .append(" | Estado: ").append(v.getEstado().name())
    //             .append(" | Origen: ").append(v.getOrigen())
    //             .append(" | Destino: ").append(v.getDestino())
    //             .append(" | Aerolíneas: ")
    //             .append(v.getAerolineas().stream()
    //                     .map(a -> a.getNombre())
    //                     .reduce((a1, a2) -> a1 + ", " + a2).orElse("Ninguna"))
    //             .append("\n\n");
    //     }

    //     areaVuelos.setText(texto.toString());
    // }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}
