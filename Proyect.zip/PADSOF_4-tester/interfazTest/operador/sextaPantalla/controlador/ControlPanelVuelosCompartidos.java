package sextaPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import sextaPantalla.enums.ComandoVuelosCompartidosEnum;
import sextaPantalla.vista.PanelVuelosCompartidos;

public class ControlPanelVuelosCompartidos implements ActionListener {

    private PanelVuelosCompartidos vista;

    public ControlPanelVuelosCompartidos(PanelVuelosCompartidos vista) {
        this.vista = vista;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVuelosCompartidosEnum comando = ComandoVuelosCompartidosEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case VER_VUELOS_COMPARTIBLES:
                System.out.println("→ Mostrando vuelos disponibles para compartir...");
                break;

            case SOLICITAR_CODIGO:
                System.out.println("→ Solicitando código compartido...");
                break;
        }
    }
}
