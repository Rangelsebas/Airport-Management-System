package sextaPantalla.vista;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import sextaPantalla.enums.ComandoVuelosCompartidosEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class PanelVuelosCompartidos extends JPanel {

    private PantallaBase pantallaBase;
    private List<JButton> botones;

    public PanelVuelosCompartidos(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);

        botones = List.of(
            crearBoton("Ver Vuelos Compartidos", ComandoVuelosCompartidosEnum.VER_VUELOS_COMPARTIBLES),
            crearBoton("Solicitar Código Compartido", ComandoVuelosCompartidosEnum.SOLICITAR_CODIGO)
        );

        for (JButton btn : botones) {
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.setMaximumSize(new Dimension(250, 50));
            btn.setPreferredSize(new Dimension(250, 50));
            add(Box.createVerticalStrut(10));
            add(btn);
        }
    }

    private JButton crearBoton(String texto, ComandoVuelosCompartidosEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        return boton;
    }

    public void setControlador(ActionListener c) {
        for (JButton b : botones) {
            b.addActionListener(c);
        }
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void mostrarPanel(JPanel panel) {
        pantallaBase.mostrarContenidoEnPanelCentral(panel);
    }
}