package sextaPantalla.enums;

public enum ComandoVuelosCompartidosEnum {
    VER_VUELOS_COMPARTIBLES,
    SOLICITAR_CODIGO
}