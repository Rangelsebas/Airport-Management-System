package interfazTest.operador.vista;

import cuartaPantalla.vista.PanelRendimientoVuelo;
import interfazTest.componentes.PanelNotificaciones;
import interfazTest.componentes.PantallaBase;
import interfazTest.operador.controlador.ControlVentanaOperador;
import interfazTest.operador.enums.ComandoVentanaOperadorEnum;
import interfazTest.operador.primeraPantalla.vista.PanelGestionarFlota;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.*;
import quintaPantalla.vista.PanelFacturas;
import segundaPantalla.vista.PanelProponerVuelo;
import septimaPantalla.vista.PanelNotificacionesHistorico;
import sextaPantalla.vista.PanelVuelosCompartidos;
import terceraPantalla.vista.PanelControlarEstadoVuelo;

public class VentanaOperador extends JFrame {
    private final String NOMBRE_USUARIO_OPERADOR = "Operador de Aerolínea";
    private PantallaBase pantalla;
    private List<JButton> botones;
    private PanelGestionarFlota panelGestionarFlota;
    private String nombreUsuario;

    private PanelControlarEstadoVuelo panelEstadoVuelo;
    private PanelProponerVuelo panelProponerVuelo;
    private PanelRendimientoVuelo panelRendimiento;
    private PanelFacturas panelFacturas;
    private PanelVuelosCompartidos panelVuelosCompartidos;
    private PanelNotificacionesHistorico panelNotificacionesHistorico;


    public VentanaOperador() {
        this.nombreUsuario = NOMBRE_USUARIO_OPERADOR;
        setTitle("Sistema Aeropuerto - Operador");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        botones = List.of(
            crearBotonMenu("Gestionar Flota", ComandoVentanaOperadorEnum.GESTIONAR_FLOTA),
            crearBotonMenu("Proponer Vuelos", ComandoVentanaOperadorEnum.PROPONER_VUELOS),
            crearBotonMenu("Controlar el Estado de un Vuelo", ComandoVentanaOperadorEnum.CONTROLAR_ESTADO),
            crearBotonMenu("Ver el Rendimiento de los Vuelos", ComandoVentanaOperadorEnum.VER_RENDIMIENTO),
            crearBotonMenu("Ver facturas", ComandoVentanaOperadorEnum.VER_FACTURAS),
            crearBotonMenu("Vuelos compartidos", ComandoVentanaOperadorEnum.VUELOS_COMPARTIDOS),
            crearBotonMenu("Vuelos notificaciones", ComandoVentanaOperadorEnum.VER_NOTIFICACIONES),
            crearBotonMenu("Guardar aplicacion", ComandoVentanaOperadorEnum.GUARDAR_APLICACION),
            crearBotonMenu("Cargar aplicacion", ComandoVentanaOperadorEnum.CARGAR_APLICACION)
        );

        for (JButton boton : botones) {
            boton.setHorizontalAlignment(SwingConstants.CENTER);
        }

        List<String> notificaciones = List.of(
            "Vuelo #2452: Retrasado. Estado: En preparación.",
            "Vuelo #45323: En hora. Estado: Esperando pista."
        );

        pantalla = new PantallaBase("Operador de Aerolínea", botones, notificaciones);
        add(pantalla);
    }

    /* HELPER */
    private JButton crearBotonMenu(String texto, ComandoVentanaOperadorEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        boton.setHorizontalAlignment(SwingConstants.CENTER);
        return boton;
    }

    public PantallaBase getPantallaBase() {
        return pantalla;
    }

    public void mostrarPanel(JPanel panel) {
        pantalla.mostrarContenidoEnPanelCentral(panel);
    }

    public PanelGestionarFlota getPanelGestionarFlota() {
        if (panelGestionarFlota == null) {
            panelGestionarFlota = new PanelGestionarFlota(pantalla);
        }
        return panelGestionarFlota;
    }

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
        pantalla.getCerrarSesionButton().setActionCommand(ComandoVentanaOperadorEnum.CERRAR_SESION.name());
    }

    public String getNombreUsuario() {
        return this.nombreUsuario;
    }

    public PanelControlarEstadoVuelo getPanelEstadoVuelo() {
        if (panelEstadoVuelo == null) {
            panelEstadoVuelo = new PanelControlarEstadoVuelo(getPantallaBase());
        }
        return panelEstadoVuelo;
    }

    public PanelProponerVuelo getPanelProponerVuelo() {
        if (panelProponerVuelo == null) {
            panelProponerVuelo = new PanelProponerVuelo(getPantallaBase());
        }
        return panelProponerVuelo;
    }


    public PanelRendimientoVuelo getPanelRendimientoVuelo() {
        if (panelRendimiento == null) {
            panelRendimiento = new PanelRendimientoVuelo();
        }
        return panelRendimiento;
    }

    public PanelFacturas getPanelFacturas() {
        if (panelFacturas == null) {
            panelFacturas = new PanelFacturas(getPantallaBase());
        }
        return panelFacturas;
    }

    public PanelVuelosCompartidos getPanelVuelosCompartidos() {
        if (panelVuelosCompartidos == null) {
            panelVuelosCompartidos = new PanelVuelosCompartidos(getPantallaBase());
        }
        return panelVuelosCompartidos;
    }

    public PanelNotificacionesHistorico getPanelNotificacionesHistorico() {
        if (panelNotificacionesHistorico == null) {
            panelNotificacionesHistorico = new PanelNotificacionesHistorico(getPantallaBase());
        }
        return panelNotificacionesHistorico;
    }

    public JButton getBotonCerrarSesion() {
        return pantalla.getCerrarSesionButton();
    }

    public void update() {
        // Aquí puedes reiniciar el panel central, por ejemplo
        pantalla.mostrarContenidoEnPanelCentral(new JPanel());
    }
}

