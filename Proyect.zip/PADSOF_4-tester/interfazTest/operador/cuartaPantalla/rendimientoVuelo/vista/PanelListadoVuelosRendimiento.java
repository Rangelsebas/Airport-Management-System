package cuartaPantalla.rendimientoVuelo.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PanelListadoVuelosRendimiento extends JPanel {

    private JPanel panelListado;

    public PanelListadoVuelosRendimiento() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Listado de Vuelos", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        // 🛠️ Truco para que el scroll funcione perfecto
        panelListado.setAlignmentX(Component.CENTER_ALIGNMENT);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(800, 400)); 
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16); // Desplazamiento suave
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // No scroll horizontal

        panelListado.add(Box.createVerticalGlue());

        add(scroll, BorderLayout.CENTER);
    }

    public void agregarVuelo(String infoVuelo) {
        JButton botonVuelo = new JButton(infoVuelo);
        botonVuelo.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonVuelo.setMaximumSize(new Dimension(500, 40));
        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(botonVuelo);
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void agregarBotonVuelo(JButton boton) {
        boton.setMaximumSize(new Dimension(500, 40));
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelListado.add(Box.createVerticalStrut(10)); // Espacio entre botones
        panelListado.add(boton);
    }
}