package cuartaPantalla.rendimientoVuelo.vista;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;

import java.awt.*;

public class PanelRendimientoVuelos extends JPanel {

    private final PantallaBase pantallaBase;
    private final JTextArea areaResumen;

    public PanelRendimientoVuelos(String contenido, PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Rendimiento de Vuelos");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        add(titulo, BorderLayout.NORTH);

        areaResumen = new JTextArea();
        areaResumen.setEditable(false);
        areaResumen.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaResumen.setBackground(Color.WHITE);
        areaResumen.setMargin(new Insets(10, 10, 10, 10));
        areaResumen.setText(contenido);

        JScrollPane scroll = new JScrollPane(areaResumen);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(scroll, BorderLayout.CENTER);
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}