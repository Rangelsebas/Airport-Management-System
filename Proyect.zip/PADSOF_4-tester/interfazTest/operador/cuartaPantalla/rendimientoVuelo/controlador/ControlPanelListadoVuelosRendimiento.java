package cuartaPantalla.rendimientoVuelo.controlador;

import javax.swing.*;

import cuartaPantalla.detallesVuelosSubMenu.vista.PanelDetallesVueloRendimiento;
import cuartaPantalla.rendimientoVuelo.vista.PanelListadoVuelosRendimiento;
import interfazTest.componentes.PantallaBase;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class ControlPanelListadoVuelosRendimiento {

    private PanelListadoVuelosRendimiento vista;
    private Map<JButton, String> vuelosMap;
    /* FLUJO CON LOGICA DE NEGOCIO */
    //Map<JButton, Vuelo> vuelosMap;

    private PantallaBase pantalla;

    public ControlPanelListadoVuelosRendimiento(PanelListadoVuelosRendimiento vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vuelosMap = new HashMap<>();
    }

    public void agregarVuelo(String infoVuelo) {
        JButton botonVuelo = new JButton(infoVuelo);
        botonVuelo.setAlignmentX(JButton.CENTER_ALIGNMENT);
        botonVuelo.setMaximumSize(new java.awt.Dimension(500, 40));
        botonVuelo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vueloSeleccionado(infoVuelo);
            }
        });
        vuelosMap.put(botonVuelo, infoVuelo);
        // vuelosMap.put(botonVuelo, vuelo); // vuelo es tipo Vuelo, no String
        vista.agregarBotonVuelo(botonVuelo);
    }

    private void vueloSeleccionado(String infoVuelo) {
        System.out.println("✈️ Vuelo seleccionado: " + infoVuelo);

        // Instanciar el nuevo panel de detalles
        PanelDetallesVueloRendimiento panelDetalles = new PanelDetallesVueloRendimiento();
        // No es necesario controlador por ahora si solo mostramos info estática
        // Si más adelante quieres agregar lógica (editar, actualizar vuelo) sí haríamos ControlPanelDetallesVueloRendimiento

        // Simular carga de datos por ahora (después se pasará el objeto Vuelo real)
        panelDetalles.setCodigoVuelo("VH001");
        panelDetalles.setOrigen("Madrid");
        panelDetalles.setDestino("París");
        panelDetalles.setFecha("02/12/2025");
        panelDetalles.setHoraSalida("10:30");
        panelDetalles.setHoraLlegada("12:45");
        panelDetalles.setAvion("Airbus A320 - Matrícula N12345");
        panelDetalles.setCapacidadPasajeros(180);
        panelDetalles.setPuntualidad("En hora");

        // Mostrar en la pantalla principal
        pantalla.mostrarContenidoEnPanelCentral(panelDetalles);


        //TODO: Con la logica de negocio quedaria algo asi
        // Vuelo vuelo = vuelosMap.get(boton);

        // if (vuelo == null) {
        //     System.err.println("Error: Vuelo no encontrado.");
        //     return;
        // }

        // // Crear panel de detalles
        // PanelDetallesVueloRendimiento panelDetalles = new PanelDetallesVueloRendimiento();

        // // Cargar datos reales
        // panelDetalles.setCodigoVuelo(vuelo.getCodigoVuelo());
        // panelDetalles.setOrigen(vuelo.getOrigen());
        // panelDetalles.setDestino(vuelo.getDestino());
        // panelDetalles.setFecha(vuelo.getFecha().toString()); // LocalDate a String
        // panelDetalles.setHoraSalida(vuelo.getHoraSalida().toString());
        // panelDetalles.setHoraLlegada(vuelo.getHoraLlegada().toString());
        // panelDetalles.setAvion(vuelo.getAvion().getMarca() + " " + vuelo.getAvion().getModelo() + " - Matrícula " + vuelo.getAvion().getMatricula());
        // panelDetalles.setCapacidad(vuelo.getAvion().getTipoAvion().getCapacidad() + (vuelo.getAvion().getCategoria().toString().equals(\"PASAJEROS\") ? \" pasajeros\" : \" kg carga\"));
        // panelDetalles.setPuntualidad(vuelo.getEnTiempo() ? \"En hora\" : \"Con retraso\");

        // // Mostrar en pantalla
        // pantalla.mostrarContenidoEnPanelCentral(panelDetalles);
    }
}
