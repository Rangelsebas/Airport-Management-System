package cuartaPantalla.rendimientoVuelo.controlador;

import cuartaPantalla.rendimientoVuelo.vista.PanelRendimientoVuelos;
import interfazTest.componentes.PantallaBase;
import interfazTest.operador.terceraPantalla.otro.ServicioVuelos;

public class ControlPanelRendimientoVuelos {

    //private final ServicioVuelos servicio;
    private final PantallaBase pantalla;

    public ControlPanelRendimientoVuelos(PantallaBase pantalla/*, ServicioVuelos servicio */) {
        //this.servicio = servicio;
        this.pantalla = pantalla;

        String resumen = generarResumen();
        PanelRendimientoVuelos panel = new PanelRendimientoVuelos(resumen, pantalla);
        pantalla.mostrarContenidoEnPanelCentral(panel);
    }

    private String generarResumen() {
        //List<Vuelo> vuelos = servicio.getTodosLosVuelos();
        int total = 10;

        // int finalizados = contarPorEstado(vuelos, EstadosVuelo.FINALIZADO);
        // int cancelados = contarPorEstado(vuelos, EstadosVuelo.CANCELADO);
        // int enCurso = servicio.getVuelosEnCurso().size();
        // int pendientes = servicio.getVuelosPendientes().size();
        
        int finalizados = 3;
        int cancelados = 2;
        int enCurso = 4;
        int pendientes = 1;

        StringBuilder sb = new StringBuilder();
        sb.append("Resumen de Rendimiento de Vuelos\n\n")
          .append("Total de vuelos registrados: ").append(total).append("\n")
          .append("Finalizados: ").append(finalizados).append(" (").append(porc(finalizados, total)).append("%)\n")
          .append("Cancelados: ").append(cancelados).append(" (").append(porc(cancelados, total)).append("%)\n")
          .append("En curso: ").append(enCurso).append(" (").append(porc(enCurso, total)).append("%)\n")
          .append("Pendientes: ").append(pendientes).append(" (").append(porc(pendientes, total)).append("%)\n");

        return sb.toString();
    }

    // private int contarPorEstado(List<Vuelo> vuelos, EstadosVuelo estado) {
    //     return (int) vuelos.stream().filter(v -> v.getEstado() == estado).count();
    // }

    private int porc(int cantidad, int total) {
        if (total == 0) return 0;
        return (int) Math.round((cantidad * 100.0) / total);
    }
}
