package cuartaPantalla.enums;

public enum ComandoRendimientoEnum {
    CONSULTAR_RENDIMIENTO_VUELOS
}
