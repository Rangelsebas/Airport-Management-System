package cuartaPantalla.controlador;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JOptionPane;

import cuartaPantalla.enums.ComandoRendimientoEnum;
import cuartaPantalla.rendimientoVuelo.controlador.ControlPanelListadoVuelosRendimiento;
import cuartaPantalla.rendimientoVuelo.vista.PanelListadoVuelosRendimiento;
import cuartaPantalla.vista.PanelRendimientoVuelo;
import interfazTest.componentes.PantallaBase;

public class ControlPanelRendimientoVuelo implements ActionListener {

    private PanelRendimientoVuelo vista;
    private PantallaBase pantalla;

    public ControlPanelRendimientoVuelo(PanelRendimientoVuelo vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoRendimientoEnum comando = ComandoRendimientoEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONSULTAR_RENDIMIENTO_VUELOS:
                procesarConsulta();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarConsulta() {
        Date fechaDesde = vista.getFechaDesde();
        Date fechaHasta = vista.getFechaHasta();

        if (fechaDesde == null || fechaHasta == null) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar ambas fechas.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (fechaDesde.after(fechaHasta)) {
            JOptionPane.showMessageDialog(vista, "La fecha 'Desde' no puede ser posterior a la fecha 'Hasta'.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // TODO: Aquí se debería llamar a la lógica que busque vuelos entre esas fechas
        System.out.println("🔍 Consultando vuelos desde: " + fechaDesde + " hasta: " + fechaHasta);

        // Instanciamos el nuevo panel
        PanelListadoVuelosRendimiento panelListado = new PanelListadoVuelosRendimiento();
        ControlPanelListadoVuelosRendimiento controlListado = new ControlPanelListadoVuelosRendimiento(panelListado, pantalla);

        // Mock de vuelos (esto luego será reemplazado por la búsqueda real)
        controlListado.agregarVuelo("✈️ Código: VH001 - Madrid → París - 02/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH002 - Barcelona → Roma - 03/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH001 - Madrid → París - 02/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH002 - Barcelona → Roma - 03/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH001 - Madrid → París - 02/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH002 - Barcelona → Roma - 03/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");
        controlListado.agregarVuelo("✈️ Código: VH003 - Valencia → Berlín - 04/12/2025");

        // Mostrar el nuevo panel
        // Aquí depende de cómo manejes tu cambio de vista (quizá tienes un método vistaPrincipal.mostrarPanel(panelListado))
        pantalla.mostrarContenidoEnPanelCentral(panelListado);
    }
}
