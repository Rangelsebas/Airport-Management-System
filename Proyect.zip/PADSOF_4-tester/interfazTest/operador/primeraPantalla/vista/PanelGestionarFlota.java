package interfazTest.operador.primeraPantalla.vista;

import interfazTest.componentes.PantallaBase;
import interfazTest.operador.primeraPantalla.enums.ComandoFlotaEnum;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;

public class PanelGestionarFlota extends JPanel {

    private PantallaBase pantallaBase;
    private List<JButton> botones;

    public PanelGestionarFlota(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        // Crear los botones con comando asociado
        botones = List.of(
            crearBotonMenu("Ver Flota", ComandoFlotaEnum.VER_FLOTA),
            crearBotonMenu("Editar un Avión", ComandoFlotaEnum.EDITAR_AVION),
            crearBotonMenu("Añadir un Avión", ComandoFlotaEnum.AÑADIR_AVION)
        );

        for (JButton boton : botones) {
            boton.setAlignmentX(Component.CENTER_ALIGNMENT);
            boton.setMaximumSize(new Dimension(200, 40));
            boton.setPreferredSize(new Dimension(200, 40));
            boton.setMinimumSize(new Dimension(200, 40));
            add(Box.createVerticalStrut(10));
            add(boton);
        }
    }

    private JButton crearBotonMenu(String texto, ComandoFlotaEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        return boton;
    }

    public void setControlador(ActionListener controlador) {
        for (JButton boton : botones) {
            boton.addActionListener(controlador);
        }
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void mostrarPanel(JPanel panel) {
        pantallaBase.mostrarContenidoEnPanelCentral(panel);
    }

    public void update() {
        // en caso de que necesites reiniciar cosas en el futuro
    }
}
