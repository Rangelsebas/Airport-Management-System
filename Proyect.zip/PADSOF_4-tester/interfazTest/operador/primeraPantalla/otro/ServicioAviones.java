package primeraPantalla.otro;

public class ServicioAviones {

    // private final List<Avion> aviones;

    // public ServicioAviones() {
    //     this.aviones = new ArrayList<>();
    // }

    // // Añadir un nuevo avión
    // public boolean agregarAvion(Avion avion) {
    //     if (avion == null || buscarPorMatricula(avion.getMatricula()) != null) {
    //         return false; // Ya existe uno con esa matrícula o es nulo
    //     }
    //     return aviones.add(avion);
    // }

    // // Buscar por matrícula exacta
    // public Avion buscarPorMatricula(String matricula) {
    //     if (matricula == null) return null;

    //     for (Avion a : aviones) {
    //         if (a.getMatricula().equalsIgnoreCase(matricula)) {
    //             return a;
    //         }
    //     }
    //     return null;
    // }

    // // Actualizar avión existente
    // public boolean actualizarAvion(Avion avionModificado) {
    //     if (avionModificado == null) return false;

    //     for (int i = 0; i < aviones.size(); i++) {
    //         if (aviones.get(i).getMatricula().equalsIgnoreCase(avionModificado.getMatricula())) {
    //             aviones.set(i, avionModificado);
    //             return true;
    //         }
    //     }
    //     return false;
    // }

    // // Eliminar por matrícula
    // public boolean eliminarPorMatricula(String matricula) {
    //     if (matricula == null) return false;

    //     return aviones.removeIf(a -> a.getMatricula().equalsIgnoreCase(matricula));
    // }

    // // Obtener todos
    // public List<Avion> getAviones() {
    //     return new ArrayList<>(aviones); // Retornar copia para proteger la lista original
    // }
}