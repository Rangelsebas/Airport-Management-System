package primeraPantalla.enums;

public enum ComandoProponerVueloEnum {
    PROPONER_VUELO,
    SOLICITAR_COMPARTIR,
    VER_SOLICITUDES
}
