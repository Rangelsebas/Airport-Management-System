package primeraPantalla.verFlota.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;

// import aerolinea.Avion;
// import aerolinea.AvionMercancias;
// import aerolinea.TipoAvion;
import interfazTest.componentes.PantallaBase;
//import primeraPantalla.otro.ServicioAviones;
import primeraPantalla.verFlota.enums.ComandoVerFlotaEnum;
import primeraPantalla.verFlota.vista.PanelVerFlota;

public class ControlPanelVerFlota implements ActionListener {
    private final PanelVerFlota vista;
    private final PantallaBase pantalla;
    //private final ServicioAviones servicio;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public ControlPanelVerFlota(PanelVerFlota vista, PantallaBase pantalla/*, ServicioAviones servicio */) {
        this.vista = vista;
        this.pantalla = pantalla;
        //this.servicio = servicio;

        this.vista.setControlador(this);
        cargarTabla(); // al iniciar, carga la tabla
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVerFlotaEnum comando = ComandoVerFlotaEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case REFRESCAR_TABLA:
                System.out.println("Refrescando tabla de aviones...");


                Object[][] datosDummy = {
                    {"MAT001", "T001", "Boeing", "737", 189, "Sí", 39, 35, 12, "Mercancías", "2022-05-15", "2024-01-20", "Disponible", "Sí"},
                    {"MAT002", "T002", "Airbus", "A320", 180, "Sí", 37, 34, 12, "Mercancías", "2021-08-10", "2023-11-05", "No disponible", "No"},
                    {"MAT003", "T003", "Lockheed", "C-130", 92, "No", 30, 40, 11, "Pasajeros", "2020-03-22", "2023-10-01", "Disponible", "No"},
                    {"MAT004", "T004", "Embraer", "E195", 132, "Sí", 38, 28, 10, "Mercancías", "2023-02-12", "2024-03-15", "Disponible", "Sí"}
                };

                vista.actualizarTabla(datosDummy);
                break;
        }
    }

    private void cargarTabla() {
        
        // List<Avion> lista = servicio.getAviones();
        // Object[][] datos = new Object[lista.size()][8];

        // for (int i = 0; i < lista.size(); i++) {
        //     Avion a = lista.get(i);
        //     TipoAvion t = a.getTipo();

        //     datos[i][0] = a.getMatricula();
        //     datos[i][1] = t.getId();
        //     datos[i][2] = t.getMarca();
        //     datos[i][3] = t.getModelo();
        //     datos[i][4] = t.getCapacidad();
        //TODO: cambiar esto de abajo por eso 👉 datos[i][5] = a.getTipoGeneral().toString(); // sin instanceof
        //     datos[i][5] = (a instanceof AvionMercancias) ? "Mercancías" : "Pasajeros";
        //     datos[i][6] = a.getFechaCompra().format(formatter);
        //     datos[i][7] = a.getFechaUltimaRevision().format(formatter);
        // }
    }
}
