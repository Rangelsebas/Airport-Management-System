package primeraPantalla.editarAvion.enums;

public enum ComandoEditarAvionEnum {
    BUSCAR_AVION,
    GUARDAR_CAMBIOS_AVION
}
