package primeraPantalla.editarAvion.controlador;

import interfazTest.componentes.PantallaBase;
import interfazTest.operador.primeraPantalla.añadirAvion.enums.TipoAvionGeneralEnum;
import primeraPantalla.editarAvion.enums.ComandoEditarAvionEnum;
import primeraPantalla.editarAvion.vista.PanelEditarAvion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JOptionPane;

public class ControlPanelEditarAvion implements ActionListener {
    private final PanelEditarAvion vista;
    private final PantallaBase pantalla;
    //private final ServicioAviones servicio;

    //private Avion avionOriginal; // el que estamos editando

    public ControlPanelEditarAvion(PanelEditarAvion vista, PantallaBase pantalla/*, ServicioAviones servicio */) {
        this.vista = vista;
        this.pantalla = pantalla;
        //this.servicio = servicio;

        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoEditarAvionEnum comando = ComandoEditarAvionEnum.valueOf(e.getActionCommand());

        switch (comando) {

            case BUSCAR_AVION:
                try {
                    /* === MOCK === */
                    String matriculaBuscada = vista.getMatriculaBuscada();

                    if (matriculaBuscada == null || matriculaBuscada.strip().isEmpty() || matriculaBuscada.equalsIgnoreCase("Matrícula")) {
                        JOptionPane.showMessageDialog(null, "Debes ingresar la matrícula del avión para buscar.", "Campo vacío", JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                    // 🔥 Mock de aviones registrados
                    String[][] avionesMock = {
                        {"MAT001", "T001", "Boeing", "737", "189", "No", "39", "35", "12", "Mercancías", "2022-05-15", "2024-01-20", "Disponible", "Sí"},
                        {"MAT002", "T002", "Airbus", "A320", "180", "No", "38", "34", "12", "Pasajeros", "2021-03-10", "2023-11-05", "Disponible", "No"}
                    };

                    boolean encontrado = false;

                    for (String[] avion : avionesMock) {
                        if (avion[0].equalsIgnoreCase(matriculaBuscada.trim())) {
                            encontrado = true;

                            // 🔥 Llenamos el formulario
                            vista.mostrarAvionMock(avion); // Vamos a crear este método auxiliar rápido ahora
                            break;
                        }
                    }

                    if (!encontrado) {
                        JOptionPane.showMessageDialog(null, "No se encontró ningún avión con esa matrícula.", "No encontrado", JOptionPane.ERROR_MESSAGE);
                        vista.update(); // Limpiar formulario
                    }

                    //TODO: Lógica real
                    // try {
                    //     String matriculaBuscada = vista.getMatriculaBuscada();

                    //     if (matriculaBuscada == null || matriculaBuscada.strip().isEmpty() || matriculaBuscada.equalsIgnoreCase("Matrícula")) {
                    //         JOptionPane.showMessageDialog(null, "Debes ingresar la matrícula del avión para buscar.", "Campo vacío", JOptionPane.WARNING_MESSAGE);
                    //         return;
                    //     }

                    //     Avion encontrado = servicio.buscarPorMatricula(matriculaBuscada.trim());

                    //     if (encontrado == null) {
                    //         JOptionPane.showMessageDialog(null, "❌ No se encontró ningún avión con la matrícula ingresada.", "No encontrado", JOptionPane.ERROR_MESSAGE);
                    //         vista.update();
                    //         return;
                    //     }

                    //     avionOriginal = encontrado;
                    //     vista.mostrarAvion(encontrado);

                    // } catch (Exception ex) {
                    //     ex.printStackTrace();
                    //     JOptionPane.showMessageDialog(null, "Ocurrió un error inesperado al buscar el avión.", "Error", JOptionPane.ERROR_MESSAGE);
                    // }
                    // break;
            
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Ocurrió un error inesperado al buscar el avión. Inténtalo de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                break;
                
            case GUARDAR_CAMBIOS_AVION:
                // TODO: en el futuro: verificar si avionOriginal == null para lógica real


                try {
                // Recoger datos del formulario
                String matricula = vista.getMatricula();
                String tipoId = vista.getTipoId();
                String marca = vista.getMarca();
                String modelo = vista.getModelo();
                int capacidad = vista.getCapacidad();
                int largo = vista.getLargo();
                int ancho = vista.getAncho();
                int alto = vista.getAlto();
                TipoAvionGeneralEnum categoria = vista.getCategoria();
                boolean controlTemperatura = vista.isControlTemperatura();
                boolean materialPeligroso = vista.isMaterialPeligroso();
                Date fechaCompra = vista.getFechaCompra();
                Date fechaRevision = vista.getFechaUltimaRevision();

                // Validaciones de campos de texto + placeholder
                if (matricula.isBlank() || matricula.equalsIgnoreCase("Matrícula")
                    || tipoId.isBlank() || tipoId.equalsIgnoreCase("Tipo (ID)")
                    || marca.isBlank() || marca.equalsIgnoreCase("Marca")
                    || modelo.isBlank() || modelo.equalsIgnoreCase("Modelo")) {
                    
                    JOptionPane.showMessageDialog(null, "Todos los campos de texto deben estar correctamente completados.", "Campos vacíos o inválidos", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Validaciones básicas
                if (matricula.isBlank() || tipoId.isBlank() || marca.isBlank() || modelo.isBlank()) {
                    JOptionPane.showMessageDialog(null, "Todos los campos de texto deben estar completos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                if (capacidad <= 0 || largo <= 0 || ancho <= 0 || alto <= 0) {
                    JOptionPane.showMessageDialog(null, "Los valores numéricos deben ser mayores a cero.", "Valores inválidos", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                if (categoria == null) {
                    JOptionPane.showMessageDialog(null, "Debe seleccionar un tipo de avión válido.", "Tipo no seleccionado", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Simular guardado exitoso
                System.out.println("Datos del avión editados:");
                System.out.println("- Matrícula: " + matricula);
                System.out.println("- Tipo ID: " + tipoId);
                System.out.println("- Marca: " + marca);
                System.out.println("- Modelo: " + modelo);
                System.out.println("- Capacidad: " + capacidad);
                System.out.println("- Dimensiones: " + largo + "m x " + ancho + "m x " + alto + "m");
                System.out.println("- Categoría: " + categoria);
                System.out.println("- Control de temperatura: " + (controlTemperatura ? "Sí" : "No"));
                System.out.println("- Material peligroso: " + (materialPeligroso ? "Sí" : "No"));
                System.out.println("- Fecha compra: " + fechaCompra);
                System.out.println("- Fecha revisión: " + fechaRevision);

                JOptionPane.showMessageDialog(null, "Los cambios han sido guardados correctamente (mock).", "Éxito", JOptionPane.INFORMATION_MESSAGE);


                //TODO: Lógica real
                // Validación 1: Matrícula no modificada
                // if (!avionEditado.getMatricula().equalsIgnoreCase(avionOriginal.getMatricula())) {
                //     JOptionPane.showMessageDialog(null, "No puedes cambiar la matrícula del avión.", "Dato bloqueado", JOptionPane.ERROR_MESSAGE);
                //     return;
                // }

                // // Validación 2: Campos de texto
                // String id = avionEditado.getTipo().getId();
                // String marca = avionEditado.getTipo().getMarca();
                // String modelo = avionEditado.getTipo().getModelo();
                // String matricula = avionEditado.getMatricula();

                // if (id.isBlank() || marca.isBlank() || modelo.isBlank() || matricula.isBlank()) {
                //     JOptionPane.showMessageDialog(null, "Todos los campos de texto deben estar completos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
                //     return;
                // }

                // // Validación 3: Valores numéricos
                // int capacidad = avionEditado.getTipo().getCapacidad();
                // int largo = avionEditado.getTipo().getLargo();
                // int ancho = avionEditado.getTipo().getAncho();
                // int alto = avionEditado.getTipo().getAlto();

                // if (capacidad <= 0 || largo <= 0 || ancho <= 0 || alto <= 0) {
                //     JOptionPane.showMessageDialog(null, "Todos los valores numéricos deben ser mayores a cero.", "Valores inválidos", JOptionPane.WARNING_MESSAGE);
                //     return;
                // }

                // // Validación 4: Tipo seleccionado
                // if (avionEditado.getTipoGeneral() == null) {
                //     JOptionPane.showMessageDialog(null, "Debes seleccionar un tipo de avión válido.", "Tipo no seleccionado", JOptionPane.WARNING_MESSAGE);
                //     return;
                // }

                // // Guardar cambios
                // boolean actualizado = servicio.actualizarAvion(avionEditado);

                // if (actualizado) {
                //     JOptionPane.showMessageDialog(null, "Los cambios han sido guardados correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                // } else {
                //     JOptionPane.showMessageDialog(null, "No se pudo actualizar el avión.", "Error", JOptionPane.WARNING_MESSAGE);
                // }

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error inesperado al guardar los cambios.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            break;
        }
    }
}
