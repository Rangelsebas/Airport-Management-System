package primeraPantalla.editarAvion.vista;

import interfazTest.operador.primeraPantalla.añadirAvion.enums.TipoAvionGeneralEnum;
import java.awt.*;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import primeraPantalla.editarAvion.enums.ComandoEditarAvionEnum;

public class PanelEditarAvion extends JPanel {

    // --- Parte de búsqueda ---
    private JTextField campoMatriculaBuscar;
    private JButton botonBuscar;

    // --- Campos editables ---
    private JTextField campoMatricula;
    private JTextField campoTipoId;
    private JTextField campoMarca;
    private JTextField campoModelo;
    private JSpinner spinnerCapacidad;
    private JSpinner spinnerLargo;
    private JSpinner spinnerAncho;
    private JSpinner spinnerAlto;
    private JComboBox<TipoAvionGeneralEnum> comboCategoria;
    private JSpinner spinnerFechaCompra;
    private JSpinner spinnerFechaRevision;
    
    private JPanel panelOpcionesMercancia;
    private JCheckBox checkTemperatura;
    private JCheckBox checkMaterialPeligroso;

    private JButton botonGuardar;

    public PanelEditarAvion() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        // --- Búsqueda ---
        add(crearEtiqueta("Buscar por matrícula:"));
        campoMatriculaBuscar = crearCampoTexto("");
        añadirPlaceholder(campoMatriculaBuscar, "Matrícula");
        botonBuscar = new JButton("Buscar");
        JPanel buscarPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buscarPanel.setBackground(Color.WHITE);
        buscarPanel.add(campoMatriculaBuscar);
        buscarPanel.add(botonBuscar);
        add(buscarPanel);

        add(Box.createVerticalStrut(20));

        // --- Formulario de edición ---
        campoMatricula = crearCampoTexto("");
        añadirPlaceholder(campoMatricula, "Matrícula");
        add(campoMatricula);

        campoTipoId = crearCampoTexto("");
        añadirPlaceholder(campoTipoId, "Tipo (ID)");
        add(campoTipoId);

        campoMarca = crearCampoTexto("");
        añadirPlaceholder(campoMarca, "Marca");
        add(campoMarca);

        campoModelo = crearCampoTexto("");
        añadirPlaceholder(campoModelo, "Modelo");
        add(campoModelo);

        add(crearEtiqueta("Capacidad:"));
        spinnerCapacidad = crearSpinner(150, 0, 1000, 10);
        add(spinnerCapacidad);

        add(crearEtiqueta("Dimensiones (LxAxH):"));
        JPanel dimPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        dimPanel.setBackground(Color.WHITE);
        spinnerLargo = crearSpinner(100, 10, 500, 10);
        spinnerAncho = crearSpinner(150, 10, 500, 10);
        spinnerAlto = crearSpinner(15, 1, 100, 1);
        dimPanel.add(spinnerLargo);
        dimPanel.add(spinnerAncho);
        dimPanel.add(spinnerAlto);
        add(dimPanel);

        add(crearEtiqueta("Categoría:"));
        comboCategoria = new JComboBox<>(TipoAvionGeneralEnum.values());
        comboCategoria.setSelectedItem(null);
        comboCategoria.setMaximumSize(new Dimension(200, 30));
        comboCategoria.addActionListener(e -> actualizarOpcionesPorTipo());
        add(comboCategoria);

        // Panel opciones mercancía
        panelOpcionesMercancia = new JPanel();
        panelOpcionesMercancia.setLayout(new BoxLayout(panelOpcionesMercancia, BoxLayout.Y_AXIS));
        panelOpcionesMercancia.setBackground(Color.WHITE);

        checkTemperatura = new JCheckBox("¿Control de Temperatura?");
        checkTemperatura.setBackground(Color.WHITE);

        checkMaterialPeligroso = new JCheckBox("¿Transporta Material Peligroso?");
        checkMaterialPeligroso.setBackground(Color.WHITE);

        panelOpcionesMercancia.add(checkTemperatura);
        panelOpcionesMercancia.add(checkMaterialPeligroso);
        panelOpcionesMercancia.setVisible(false);
        add(panelOpcionesMercancia);

        add(crearEtiqueta("Fecha de compra:"));
        spinnerFechaCompra = new JSpinner(new SpinnerDateModel());
        spinnerFechaCompra.setEditor(new JSpinner.DateEditor(spinnerFechaCompra, "dd/MM/yyyy"));
        spinnerFechaCompra.setMaximumSize(new Dimension(200, 30));
        add(spinnerFechaCompra);

        add(crearEtiqueta("Fecha de última revisión:"));
        spinnerFechaRevision = new JSpinner(new SpinnerDateModel());
        spinnerFechaRevision.setEditor(new JSpinner.DateEditor(spinnerFechaRevision, "dd/MM/yyyy"));
        spinnerFechaRevision.setMaximumSize(new Dimension(200, 30));
        add(spinnerFechaRevision);

        botonGuardar = new JButton("Guardar cambios");
        botonGuardar.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalStrut(15));
        add(botonGuardar);
    }

    // ========== GETTERS ==========

    public String getMatriculaBuscada() {
        return campoMatriculaBuscar.getText();
    }

    public String getMatricula() {
        return campoMatricula.getText();
    }

    public String getTipoId() {
        return campoTipoId.getText();
    }

    public String getMarca() {
        return campoMarca.getText();
    }

    public String getModelo() {
        return campoModelo.getText();
    }

    public int getCapacidad() {
        return (Integer) spinnerCapacidad.getValue();
    }

    public int getLargo() {
        return (Integer) spinnerLargo.getValue();
    }

    public int getAncho() {
        return (Integer) spinnerAncho.getValue();
    }

    public int getAlto() {
        return (Integer) spinnerAlto.getValue();
    }

    public TipoAvionGeneralEnum getCategoria() {
        return (TipoAvionGeneralEnum) comboCategoria.getSelectedItem();
    }

    public boolean isControlTemperatura() {
        return checkTemperatura.isSelected();
    }

    public boolean isMaterialPeligroso() {
        return checkMaterialPeligroso.isSelected();
    }

    public Date getFechaCompra() {
        return (Date) spinnerFechaCompra.getValue();
    }

    public Date getFechaUltimaRevision() {
        return (Date) spinnerFechaRevision.getValue();
    }

    public void update() {
        campoMatricula.setText("Matrícula");
        campoMatricula.setForeground(Color.GRAY);

        campoTipoId.setText("Tipo (ID)");
        campoTipoId.setForeground(Color.GRAY);

        campoMarca.setText("Marca");
        campoMarca.setForeground(Color.GRAY);

        campoModelo.setText("Modelo");
        campoModelo.setForeground(Color.GRAY);

        spinnerCapacidad.setValue(150);
        spinnerLargo.setValue(100);
        spinnerAncho.setValue(150);
        spinnerAlto.setValue(15);

        comboCategoria.setSelectedItem(null);

        checkTemperatura.setSelected(false);
        checkMaterialPeligroso.setSelected(false);
        panelOpcionesMercancia.setVisible(false);

        spinnerFechaCompra.setValue(new Date());
        spinnerFechaRevision.setValue(new Date());
    }

    // ========== HELPERS ==========

    private JTextField crearCampoTexto(String placeholder) {
        JTextField campo = new JTextField();
        campo.setMaximumSize(new Dimension(200, 30));
        campo.setToolTipText(placeholder);
        return campo;
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        return spinner;
    }

    private void actualizarOpcionesPorTipo() {
        TipoAvionGeneralEnum categoriaSeleccionada = (TipoAvionGeneralEnum) comboCategoria.getSelectedItem();

        if (categoriaSeleccionada == TipoAvionGeneralEnum.AVION_MERCANCIAS) {
            panelOpcionesMercancia.setVisible(true);
        } else {
            panelOpcionesMercancia.setVisible(false);
            checkTemperatura.setSelected(false);
            checkMaterialPeligroso.setSelected(false);
        }

        revalidate();
        repaint();
    }

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }

    public void setControlador(ActionListener c) {
        botonBuscar.setActionCommand(ComandoEditarAvionEnum.BUSCAR_AVION.name());
        botonBuscar.addActionListener(c);

        botonGuardar.setActionCommand(ComandoEditarAvionEnum.GUARDAR_CAMBIOS_AVION.name());
        botonGuardar.addActionListener(c);
    }

    /*==== MOCK ===== */
    public void mostrarAvionMock(String[] datos) {
        campoMatricula.setText(datos[0]);
        campoTipoId.setText(datos[1]);
        campoMarca.setText(datos[2]);
        campoModelo.setText(datos[3]);
        spinnerCapacidad.setValue(Integer.parseInt(datos[4]));
        checkTemperatura.setSelected(datos[5].equalsIgnoreCase("Sí"));
        spinnerLargo.setValue(Integer.parseInt(datos[6]));
        spinnerAncho.setValue(Integer.parseInt(datos[7]));
        spinnerAlto.setValue(Integer.parseInt(datos[8]));
    
        // Seleccionar categoría correctamente
        String categoriaNormalizada = datos[9].toUpperCase().replace("Í", "I").replace("É", "E").replace("Á", "A").replace("Ó", "O").replace("Ú", "U");
        comboCategoria.setSelectedItem(TipoAvionGeneralEnum.valueOf("AVION_" + categoriaNormalizada));
    
        // Fechas
        spinnerFechaCompra.setValue(java.sql.Date.valueOf(datos[10]));
        spinnerFechaRevision.setValue(java.sql.Date.valueOf(datos[11]));
    
        // Mostrar o no opciones de mercancía
        if (comboCategoria.getSelectedItem() == TipoAvionGeneralEnum.AVION_MERCANCIAS) {
            panelOpcionesMercancia.setVisible(true);
            checkMaterialPeligroso.setSelected(datos[13].equalsIgnoreCase("Sí"));
        } else {
            panelOpcionesMercancia.setVisible(false);
            checkMaterialPeligroso.setSelected(false);
        }
    }


    /*========================== */
    /*======LOGICA NEGOCIO====== */
    /*========================== */

    // public void mostrarAvion(Avion avion) {
    //     TipoAvion tipo = avion.getTipo();
    //     TipoAvionGeneralEnum tipoGeneral = avion.getTipoGeneral();

    //     campoMatricula.setText(avion.getMatricula());
    //     campoTipoId.setText(tipo.getId());
    //     campoMarca.setText(tipo.getMarca());
    //     campoModelo.setText(tipo.getModelo());
    //     spinnerCapacidad.setValue(tipo.getCapacidad());
    //     spinnerLargo.setValue(tipo.getLargo());
    //     spinnerAncho.setValue(tipo.getAncho());
    //     spinnerAlto.setValue(tipo.getAlto());
    //     checkTemperatura.setSelected(tipo.isControlTemperatura());
    //     comboCategoria.setSelectedItem(tipoGeneral);

    //     spinnerFechaCompra.setValue(java.sql.Date.valueOf(avion.getFechaCompra()));
    //     spinnerFechaRevision.setValue(java.sql.Date.valueOf(avion.getFechaUltimaRevision()));

    //     if (tipoGeneral == TipoAvionGeneralEnum.AVION_MERCANCIAS) {
    //         panelOpcionesMercancia.setVisible(true);

    //         if (avion instanceof AvionMercancias merc) {
    //             checkMaterialPeligroso.setSelected(merc.tieneMaterialPeligroso());
    //         }
    //     } else {
    //         panelOpcionesMercancia.setVisible(false);
    //         checkMaterialPeligroso.setSelected(false);
    //     }
    // }

    // public Avion getAvionEditado() {
    //     String id = campoTipoId.getText();
    //     String marca = campoMarca.getText();
    //     String modelo = campoModelo.getText();
    //     int capacidad = (Integer) spinnerCapacidad.getValue();
    //     int largo = (Integer) spinnerLargo.getValue();
    //     int ancho = (Integer) spinnerAncho.getValue();
    //     int alto = (Integer) spinnerAlto.getValue();
    //     boolean temperatura = checkTemperatura.isSelected();

    //     LocalDate fechaCompra = ((Date) spinnerFechaCompra.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    //     LocalDate fechaRevision = ((Date) spinnerFechaRevision.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

    //     TipoAvion tipo = new TipoAvion(id, marca, modelo, capacidad, temperatura, largo, alto, ancho);
    //     TipoAvionGeneralEnum tipoGeneral = (TipoAvionGeneralEnum) comboCategoria.getSelectedItem();

    //     String matricula = campoMatricula.getText();

    //     if (tipoGeneral == TipoAvionGeneralEnum.AVION_MERCANCIAS) {
    //         boolean materialPeligroso = checkMaterialPeligroso.isSelected();
    //         return new AvionMercancias(fechaCompra, fechaRevision, tipo, matricula, materialPeligroso);
    //     } else {
    //         return new AvionPasajeros(fechaCompra, fechaRevision, tipo, matricula);
    //     }
    // }
    
}


//TODO: añadir esto a Avion, AvionMercancias y AvionPasajeros

    //Avion.java
    // public abstract class Avion {
    //     // ... tus atributos y métodos comunes ...
    
    //     public abstract TipoAvionGeneralEnum getTipoGeneral();
    // }

    // AvionPasajeros.java
    // @Override
    // public TipoAvionGeneralEnum getTipoGeneral() {
    //     return TipoAvionGeneralEnum.AVION_PASAJEROS;
    // }

    // AvionMercancias.java
    // @Override
    // public TipoAvionGeneralEnum getTipoGeneral() {
    //     return TipoAvionGeneralEnum.AVION_MERCANCIAS;
    // }

    // public void mostrarAvion(Avion avion) {
    //     TipoAvion tipo = avion.getTipo();
    //     TipoAvionGeneralEnum tipoGeneral = avion.getTipoGeneral();

    //     // Llenar campos comunes
    //     campoMarca.setText(tipo.getMarca());
    //     campoModelo.setText(tipo.getModelo());
    //     spinnerCapacidad.setValue(tipo.getCapacidad());
    //     spinnerLargo.setValue(tipo.getLargo());
    //     spinnerAncho.setValue(tipo.getAncho());
    //     spinnerAlto.setValue(tipo.getAlto());
    //     checkTemperatura.setSelected(tipo.isControlTemperatura());

    //     comboTipo.setSelectedItem(tipoGeneral);

    //     spinnerFechaCompra.setValue(java.sql.Date.valueOf(avion.getFechaCompra()));
    //     spinnerFechaRevision.setValue(java.sql.Date.valueOf(avion.getFechaUltimaRevision()));

    //     // Mostrar checkboxes especiales solo si es de tipo mercancías
    //     if (tipoGeneral == TipoAvionGeneralEnum.AVION_MERCANCIAS) {
    //         panelOpcionesMercancia.setVisible(true);

    //         // Acceso seguro: el controlador ya sabe que este avión fue creado como AvionMercancias
    //         if (avion instanceof AvionMercancias merc) {
    //             checkMaterialPeligroso.setSelected(merc.tieneMaterialPeligroso());
    //         }

    //TODO: añadir esta vaina a Avion y AvionMercancias
    // public boolean tieneMaterialPeligroso() {
    //     return false;
    // } 
    // Y luego sobreescribirlo solo en AvionMercancias.

    //     } else {
    //         checkMaterialPeligroso.setSelected(false);
    //         panelOpcionesMercancia.setVisible(false);
    //     }
    // }


    // public Avion getAvionEditado() {
    //     // Recoge los campos actualizados
    //     String marca = campoMarca.getText();
    //     String modelo = campoModelo.getText();
    //     int capacidad = (Integer) spinnerCapacidad.getValue();
    //     int largo = (Integer) spinnerLargo.getValue();
    //     int ancho = (Integer) spinnerAncho.getValue();
    //     int alto = (Integer) spinnerAlto.getValue();
    //     boolean temperatura = checkTemperatura.isSelected();

    //     LocalDate fechaCompra = ((Date) spinnerFechaCompra.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    //     LocalDate fechaRevision = ((Date) spinnerFechaRevision.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

    //     TipoAvion tipo = new TipoAvion(id, marca, modelo, capacidad, temperatura, largo, alto, ancho);
    //     TipoAvionGeneralEnum tipoGeneral = (TipoAvionGeneralEnum) comboTipo.getSelectedItem();

    //     if (tipoGeneral == TipoAvionGeneralEnum.AVION_MERCANCIAS) {
    //         boolean materialPeligroso = checkMaterialPeligroso.isSelected();
    //         return new AvionMercancias(fechaCompra, fechaRevision, tipo, matricula, materialPeligroso);
    //     } else {
    //         return new AvionPasajeros(fechaCompra, fechaRevision, tipo, matricula);
    //     }
    // }
