package interfazTest.operador.primeraPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import interfazTest.componentes.PantallaBase;
import interfazTest.operador.primeraPantalla.añadirAvion.controlador.ControlPanelAñadirAvion;
import interfazTest.operador.primeraPantalla.añadirAvion.vista.PanelAñadirAvion;
import interfazTest.operador.primeraPantalla.enums.ComandoFlotaEnum;
import interfazTest.operador.primeraPantalla.vista.PanelGestionarFlota;
import primeraPantalla.editarAvion.controlador.ControlPanelEditarAvion;
import primeraPantalla.editarAvion.vista.PanelEditarAvion;
//import primeraPantalla.otro.ServicioAviones;
import primeraPantalla.verFlota.controlador.ControlPanelVerFlota;
import primeraPantalla.verFlota.vista.PanelVerFlota;

public class ControlPanelGestionarFlota implements ActionListener {

    private PanelGestionarFlota vista;
    private PantallaBase pantalla;
    //private final ServicioAviones servicioAviones;

    public ControlPanelGestionarFlota(PanelGestionarFlota vista, PantallaBase pantalla/*, ServicioAviones servicioAviones */) {
        this.vista = vista;
        this.pantalla = pantalla;
        //this.servicioAviones = servicioAviones;
        this.vista.setControlador(this); 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoFlotaEnum comando = ComandoFlotaEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case VER_FLOTA:
                PanelVerFlota panel = new PanelVerFlota();
                new ControlPanelVerFlota(panel, pantalla/*, servicio */);
                pantalla.mostrarContenidoEnPanelCentral(panel);
                break;
            case EDITAR_AVION:
                System.out.println("→ Editando avión");
                PanelEditarAvion panelEditar = new PanelEditarAvion();
                new ControlPanelEditarAvion(panelEditar, pantalla/*, servicio */);
                pantalla.mostrarContenidoEnPanelCentral(panelEditar);
                break;
            case AÑADIR_AVION:
                System.out.println("→ Añadiendo avión");
                PanelAñadirAvion panelAñadir = new PanelAñadirAvion();
                new ControlPanelAñadirAvion(panelAñadir, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelAñadir);
                break;
        }
    }
    
}
