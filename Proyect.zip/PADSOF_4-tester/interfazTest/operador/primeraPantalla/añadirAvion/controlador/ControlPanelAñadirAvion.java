package interfazTest.operador.primeraPantalla.añadirAvion.controlador;

import interfazTest.componentes.PantallaBase;
import interfazTest.operador.primeraPantalla.añadirAvion.enums.ComandoAñadirAvionEnum;
import interfazTest.operador.primeraPantalla.añadirAvion.enums.TipoAvionGeneralEnum;
import interfazTest.operador.primeraPantalla.añadirAvion.vista.PanelAñadirAvion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;

import javax.swing.JOptionPane;

// import funcionalidad.aerolinea.AvionMercancias;
// import funcionalidad.aerolinea.AvionPasajeros;
// import funcionalidad.aerolinea.CategoriaAvion;
// import funcionalidad.aerolinea.TipoAvion;

public class ControlPanelAñadirAvion implements ActionListener {

    private PanelAñadirAvion vista;
    private PantallaBase pantalla;

    public ControlPanelAñadirAvion(PanelAñadirAvion vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoAñadirAvionEnum comando = ComandoAñadirAvionEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case AÑADIR_AVION_CONFIRMADO:
                try {
                    String matricula = vista.getMatricula();
                    String tipoId = vista.getTipoId();
                    String marca = vista.getMarca();
                    String modelo = vista.getModelo();
                    int capacidad = vista.getCapacidad();
                    boolean tempControl = vista.isControlTemperatura();
                    boolean materialPeligroso = vista.isMaterialPeligroso();
                    int largo = vista.getLargo();
                    int ancho = vista.getAncho();
                    int alto = vista.getAlto();
                    TipoAvionGeneralEnum categoria = vista.getCategoria();
        
                    LocalDate fechaCompra = vista.getFechaCompra().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    LocalDate fechaRevision = vista.getFechaUltimaRevision().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        
                    // === Validaciones importantes ===
        
                    if (matricula == null || matricula.isBlank() || matricula.equals("Matrícula")) {
                        JOptionPane.showMessageDialog(null, "Por favor, ingresa una matrícula válida.", "Campo obligatorio", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
        
                    if (tipoId == null || tipoId.isBlank() || tipoId.equals("Tipo (ID)")) {
                        JOptionPane.showMessageDialog(null, "Por favor, ingresa un Tipo (ID) válido.", "Campo obligatorio", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
        
                    if (marca.isBlank() || marca.equals("Marca") || modelo.isBlank() || modelo.equals("Modelo")) {
                        JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos de Marca y Modelo.", "Campos obligatorios", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
        
                    if (capacidad <= 0 || largo <= 0 || ancho <= 0 || alto <= 0) {
                        JOptionPane.showMessageDialog(null, "Todos los valores numéricos deben ser mayores a cero.", "Datos inválidos", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
        
                    if (categoria == null) {
                        JOptionPane.showMessageDialog(null, "Selecciona una categoría (Mercancías o Pasajeros).", "Categoría faltante", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
        
                    if (fechaCompra.isAfter(LocalDate.now())) {
                        JOptionPane.showMessageDialog(null, "La fecha de compra no puede ser futura.", "Fecha inválida", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
        
                    if (fechaRevision.isBefore(fechaCompra)) {
                        JOptionPane.showMessageDialog(null, "La fecha de revisión no puede ser anterior a la fecha de compra.", "Fecha inválida", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
        
                    // === Creación del avión según categoría ===
                    if (categoria == TipoAvionGeneralEnum.AVION_MERCANCIAS) {
                        // Lógica para avión de mercancías
                    } else {
                        // Lógica para avión de pasajeros
                    }
        
                    // TODO: servicioAviones.agregarAvion(avion);
        
                    JOptionPane.showMessageDialog(null, "Avión añadido con éxito.", "Operación exitosa", JOptionPane.INFORMATION_MESSAGE);
                    vista.update(); // Limpiar campos
        
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Ocurrió un error al procesar el avión. Inténtalo de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                break;
        }
    }
}
