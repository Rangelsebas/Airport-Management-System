package interfazTest.operador.primeraPantalla.añadirAvion.enums;


public enum ComandoAñadirAvionEnum {
    AÑADIR_AVION_CONFIRMADO
}
