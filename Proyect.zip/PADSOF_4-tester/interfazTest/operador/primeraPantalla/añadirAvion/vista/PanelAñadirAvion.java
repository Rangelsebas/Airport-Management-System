package interfazTest.operador.primeraPantalla.añadirAvion.vista;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import interfazTest.operador.primeraPantalla.añadirAvion.enums.ComandoAñadirAvionEnum;
import interfazTest.operador.primeraPantalla.añadirAvion.enums.TipoAvionGeneralEnum;

public class PanelAñadirAvion extends JPanel {

    private JTextField campoMatricula;
    private JTextField campoTipoId;
    private JTextField campoMarca;
    private JTextField campoModelo;
    private JSpinner spinnerCapacidad;
    private JSpinner spinnerLargo;
    private JSpinner spinnerAncho;
    private JSpinner spinnerAlto;
    private JComboBox<TipoAvionGeneralEnum> comboCategoria;
    private JSpinner spinnerFechaCompra;
    private JSpinner spinnerFechaRevision;

    private JPanel panelOpcionesMercancia;
    private JCheckBox checkTemperatura;
    private JCheckBox checkMaterialPeligroso;

    private JButton botonAceptar;

    public PanelAñadirAvion() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        // Matrícula
        campoMatricula = crearCampoTexto("");
        añadirPlaceholder(campoMatricula, "Matrícula");
        add(campoMatricula);

        // Tipo (ID)
        campoTipoId = crearCampoTexto("");
        añadirPlaceholder(campoTipoId, "Tipo (ID)");
        add(campoTipoId);

        // Marca
        campoMarca = crearCampoTexto("");
        añadirPlaceholder(campoMarca, "Marca");
        add(campoMarca);

        // Modelo
        campoModelo = crearCampoTexto("");
        añadirPlaceholder(campoModelo, "Modelo");
        add(campoModelo);

        // Capacidad
        add(crearEtiqueta("Capacidad:"));
        spinnerCapacidad = crearSpinner(150, 0, 1000, 10);
        add(spinnerCapacidad);

        // Dimensiones (Largo, Ancho, Alto)
        add(crearEtiqueta("Dimensiones (LxAxH):"));
        JPanel panelDimensiones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panelDimensiones.setBackground(Color.WHITE);
        spinnerLargo = crearSpinner(100, 10, 500, 10);
        spinnerAncho = crearSpinner(150, 10, 500, 10);
        spinnerAlto = crearSpinner(15, 1, 100, 1);
        panelDimensiones.add(spinnerLargo);
        panelDimensiones.add(spinnerAncho);
        panelDimensiones.add(spinnerAlto);
        add(panelDimensiones);

        // Categoría
        comboCategoria = new JComboBox<>(TipoAvionGeneralEnum.values());
        comboCategoria.setSelectedItem(null);
        comboCategoria.setMaximumSize(new Dimension(200, 30));
        comboCategoria.addActionListener(e -> actualizarOpcionesPorTipo());
        add(comboCategoria);

        // Panel Opciones Mercancía (checkboxes juntos)
        panelOpcionesMercancia = new JPanel();
        panelOpcionesMercancia.setLayout(new BoxLayout(panelOpcionesMercancia, BoxLayout.Y_AXIS));
        panelOpcionesMercancia.setBackground(Color.WHITE);

        checkTemperatura = new JCheckBox("¿Control de Temperatura?");
        checkTemperatura.setBackground(Color.WHITE);

        checkMaterialPeligroso = new JCheckBox("¿Transporta Material Peligroso?");
        checkMaterialPeligroso.setBackground(Color.WHITE);

        panelOpcionesMercancia.add(checkTemperatura);
        panelOpcionesMercancia.add(checkMaterialPeligroso);
        panelOpcionesMercancia.setVisible(false); // Inicia oculto
        add(panelOpcionesMercancia);

        // Fecha Compra
        add(crearEtiqueta("Fecha de compra:"));
        spinnerFechaCompra = new JSpinner(new SpinnerDateModel());
        spinnerFechaCompra.setEditor(new JSpinner.DateEditor(spinnerFechaCompra, "dd/MM/yyyy"));
        spinnerFechaCompra.setMaximumSize(new Dimension(200, 30));
        add(spinnerFechaCompra);

        // Última Revisión
        add(crearEtiqueta("Fecha de última revisión:"));
        spinnerFechaRevision = new JSpinner(new SpinnerDateModel());
        spinnerFechaRevision.setEditor(new JSpinner.DateEditor(spinnerFechaRevision, "dd/MM/yyyy"));
        spinnerFechaRevision.setMaximumSize(new Dimension(200, 30));
        add(spinnerFechaRevision);

        // Botón
        botonAceptar = new JButton("Añadir avión");
        botonAceptar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAceptar.setActionCommand(ComandoAñadirAvionEnum.AÑADIR_AVION_CONFIRMADO.name());
        add(Box.createVerticalStrut(15));
        add(botonAceptar);
    }

    // ========== MÉTODOS DE VISTA MVC ==========

    public void setControlador(ActionListener c) {
        botonAceptar.addActionListener(c);
    }

    public String getMatricula() {
        return campoMatricula.getText();
    }

    public String getTipoId() {
        return campoTipoId.getText();
    }

    public String getMarca() {
        return campoMarca.getText();
    }

    public String getModelo() {
        return campoModelo.getText();
    }

    public int getCapacidad() {
        return (Integer) spinnerCapacidad.getValue();
    }

    public int getLargo() {
        return (Integer) spinnerLargo.getValue();
    }

    public int getAncho() {
        return (Integer) spinnerAncho.getValue();
    }

    public int getAlto() {
        return (Integer) spinnerAlto.getValue();
    }

    public TipoAvionGeneralEnum getCategoria() {
    return (TipoAvionGeneralEnum) comboCategoria.getSelectedItem();
}

    public boolean isControlTemperatura() {
        return checkTemperatura.isSelected();
    }

    public boolean isMaterialPeligroso() {
        return checkMaterialPeligroso.isSelected();
    }

    public Date getFechaCompra() {
        return (Date) spinnerFechaCompra.getValue();
    }

    public Date getFechaUltimaRevision() {
        return (Date) spinnerFechaRevision.getValue();
    }

    public void update() {
        campoMatricula.setText("Matrícula");
        campoMatricula.setForeground(Color.GRAY);

        campoTipoId.setText("Tipo (ID)");
        campoTipoId.setForeground(Color.GRAY);

        campoMarca.setText("Marca");
        campoMarca.setForeground(Color.GRAY);

        campoModelo.setText("Modelo");
        campoModelo.setForeground(Color.GRAY);

        spinnerCapacidad.setValue(150);
        spinnerLargo.setValue(100);
        spinnerAncho.setValue(150);
        spinnerAlto.setValue(15);

        comboCategoria.setSelectedItem(null);

        checkTemperatura.setSelected(false);
        checkMaterialPeligroso.setSelected(false);
        panelOpcionesMercancia.setVisible(false);

        spinnerFechaCompra.setValue(new Date());
        spinnerFechaRevision.setValue(new Date());
    }

    // ========== HELPERS ==========

    private JTextField crearCampoTexto(String placeholder) {
        JTextField campo = new JTextField();
        campo.setMaximumSize(new Dimension(200, 30));
        campo.setToolTipText(placeholder);
        return campo;
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        return spinner;
    }

    private void actualizarOpcionesPorTipo() {
        TipoAvionGeneralEnum categoriaSeleccionada = (TipoAvionGeneralEnum) comboCategoria.getSelectedItem();
    
        if (categoriaSeleccionada == TipoAvionGeneralEnum.AVION_MERCANCIAS) {
            panelOpcionesMercancia.setVisible(true);
        } else {
            panelOpcionesMercancia.setVisible(false);
            checkTemperatura.setSelected(false);
            checkMaterialPeligroso.setSelected(false);
        }
    
        revalidate();
        repaint();
    }

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }
}
