package segundaPantalla.vista;

import interfazTest.componentes.PantallaBase;
import primeraPantalla.enums.ComandoProponerVueloEnum;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

public class PanelProponerVuelo extends JPanel {

    private PantallaBase pantallaBase;

    private List<JButton> botones;

    public PanelProponerVuelo(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        this.botones = new ArrayList<>();

        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        JPanel contenedor = new JPanel();
        contenedor.setLayout(new BoxLayout(contenedor, BoxLayout.Y_AXIS));
        contenedor.setBackground(Color.WHITE);

        // Crear y añadir botones
        botones = List.of(
            crearBoton("Proponer Vuelo", ComandoProponerVueloEnum.PROPONER_VUELO),
            crearBoton("Solicitar Compartir Vuelo", ComandoProponerVueloEnum.SOLICITAR_COMPARTIR),
            crearBoton("<html><center>Ver Solicitudes<br>de Compartir Vuelo</center></html>", ComandoProponerVueloEnum.VER_SOLICITUDES)
        );

        Dimension buttonSize = new Dimension(240, 55);
        for (JButton btn : botones) {
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.setMaximumSize(buttonSize);
            btn.setPreferredSize(buttonSize);
            btn.setHorizontalAlignment(SwingConstants.CENTER);
            btn.setVerticalAlignment(SwingConstants.CENTER);
            btn.setMargin(new Insets(10, 10, 10, 10));
            btn.setFocusable(false);
            contenedor.add(Box.createVerticalStrut(10));
            contenedor.add(btn);
        }

        add(contenedor); // Añadir al centro
    }

    private JButton crearBoton(String texto, ComandoProponerVueloEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        return boton;
    }

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void mostrarPanel(JPanel panel) {
        pantallaBase.mostrarContenidoEnPanelCentral(panel);
    }
}
