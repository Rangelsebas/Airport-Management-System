package segundaPantalla.solicitarCompartir.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import segundaPantalla.solicitarCompartir.enums.ComandoSolicitarCompartirVueloEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelSolicitarCompartirVuelo extends JPanel {

    private JComboBox<String> comboVuelos;
    private JLabel labelCantidad;
    private JSpinner spinnerCantidad;
    private JButton botonSolicitarCompartir;

    public PanelSolicitarCompartirVuelo() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        // ComboBox para seleccionar vuelo compartible
        add(crearEtiqueta("Seleccionar vuelo:"));
        comboVuelos = new JComboBox<>();
        comboVuelos.setMaximumSize(new Dimension(200, 30));

        // Añadir vuelos de prueba
        comboVuelos.addItem("✈️ Código: VH001 | Estado: FINALIZADO | Origen: Madrid | Destino: París | Aerolíneas: Iberia");
        comboVuelos.addItem("✈️ Código: VH002 | Estado: FINALIZADO | Origen: Barcelona | Destino: Roma | Aerolíneas: Vueling");
        comboVuelos.addItem("✈️ Código: VH003 | Estado: FINALIZADO | Origen: Valencia | Destino: Berlín | Aerolíneas: Lufthansa");

        add(comboVuelos);

        add(Box.createVerticalStrut(10));

        // Cantidad de pasajeros o carga
        labelCantidad = crearEtiqueta("Cantidad a aportar:");
        add(labelCantidad);

        spinnerCantidad = crearSpinner(0, 0, 1000, 1);
        add(spinnerCantidad);

        add(Box.createVerticalStrut(15));

        // Botón para solicitar compartir
        botonSolicitarCompartir = new JButton("Solicitar Compartir");
        botonSolicitarCompartir.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonSolicitarCompartir.setActionCommand(ComandoSolicitarCompartirVueloEnum.SOLICITAR_COMPARTIR_CONFIRMADO.name());
        add(botonSolicitarCompartir);
    }

    // =============================
    // MÉTODOS VISTA MVC
    // =============================

    public void setControlador(ActionListener c) {
        botonSolicitarCompartir.addActionListener(c);
    }

    public String getVueloSeleccionado() {
        return (String) comboVuelos.getSelectedItem();
    }

    public int getCantidad() {
        return (Integer) spinnerCantidad.getValue();
    }

    public void setListaVuelos(String[] vuelos) {
        comboVuelos.removeAllItems();
        comboVuelos.addItem("Seleccionar vuelo");
        for (String vuelo : vuelos) {
            comboVuelos.addItem(vuelo);
        }
    }

    public void reset() {
        comboVuelos.setSelectedIndex(0);
        spinnerCantidad.setValue(0);
    }

    // =============================
    // HELPERS
    // =============================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        return spinner;
    }
}
