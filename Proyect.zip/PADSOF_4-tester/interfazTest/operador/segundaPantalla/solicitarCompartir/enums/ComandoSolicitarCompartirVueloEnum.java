package segundaPantalla.solicitarCompartir.enums;

public enum ComandoSolicitarCompartirVueloEnum {
    SOLICITAR_COMPARTIR_CONFIRMADO
}
