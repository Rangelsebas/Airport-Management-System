package segundaPantalla.solicitarCompartir.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import segundaPantalla.solicitarCompartir.enums.ComandoSolicitarCompartirVueloEnum;
import segundaPantalla.solicitarCompartir.vista.PanelSolicitarCompartirVuelo;

public class ControlPanelSolicitarCompartirVuelo implements ActionListener {

    private PanelSolicitarCompartirVuelo vista;

    public ControlPanelSolicitarCompartirVuelo(PanelSolicitarCompartirVuelo vista) {
        this.vista = vista;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();

        if (comando.equals(ComandoSolicitarCompartirVueloEnum.SOLICITAR_COMPARTIR_CONFIRMADO.name())) {
            procesarSolicitudCompartir();
        }
    }

    private void procesarSolicitudCompartir() {
        String vueloSeleccionado = vista.getVueloSeleccionado();
        int cantidad = vista.getCantidad();
    
        if (vueloSeleccionado == null || vueloSeleccionado.equals("Seleccionar vuelo")) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar un vuelo válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(vista, "Debe indicar una cantidad mayor a cero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        int capacidadDisponible = obtenerCapacidadDisponibleDelVuelo(vueloSeleccionado);
    
        if (cantidad > capacidadDisponible) {
            JOptionPane.showMessageDialog(vista, "La cantidad solicitada excede la capacidad disponible para compartir.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        // Lógica simulada
        System.out.println("✈️ Solicitud de compartir vuelo:");
        System.out.println("Vuelo seleccionado: " + vueloSeleccionado);
        System.out.println("Cantidad a aportar: " + cantidad);
    
        // Después de procesar: limpiar formulario
        vista.reset();
    }

    private int obtenerCapacidadDisponibleDelVuelo(String vueloSeleccionado) {
        // MOCK para simular capacidades
        if (vueloSeleccionado.contains("VH001")) {
            return 80; // 80 pasajeros disponibles
        } else if (vueloSeleccionado.contains("VH002")) {
            return 50; // 50 pasajeros disponibles
        } else if (vueloSeleccionado.contains("VH003")) {
            return 30; // 30 pasajeros disponibles
        } else {
            return 0; // No disponible
        }
    }
}



// TODO: Esto es lo que implementaremos cuando integremos la lógica de negocio

/*
package interfazTest.operador.primeraPantalla.proponerVuelos.controlador;

import interfazTest.operador.primeraPantalla.proponerVuelos.vista.PanelSolicitarCompartirVuelo;
import interfazTest.operador.primeraPantalla.proponerVuelos.enums.ComandoSolicitarCompartirVueloEnum;
import funcionalidad.vuelo.Vuelo;
import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

public class ControlPanelSolicitarCompartirVuelo implements ActionListener {

    private PanelSolicitarCompartirVuelo vista;
    private Map<String, Vuelo> mapaVuelos;

    public ControlPanelSolicitarCompartirVuelo(PanelSolicitarCompartirVuelo vista) {
        this.vista = vista;
        this.vista.setControlador(this);
        this.mapaVuelos = new HashMap<>();
        cargarVuelosDePrueba();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();

        if (comando.equals(ComandoSolicitarCompartirVueloEnum.SOLICITAR_COMPARTIR_CONFIRMADO.name())) {
            procesarSolicitudCompartir();
        }
    }

    private void procesarSolicitudCompartir() {
        String vueloSeleccionadoTexto = vista.getVueloSeleccionado();
        int cantidad = vista.getCantidad();

        if (vueloSeleccionadoTexto == null || vueloSeleccionadoTexto.equals("Seleccionar vuelo")) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar un vuelo válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Vuelo vuelo = obtenerVueloSeleccionado(vueloSeleccionadoTexto);
        if (vuelo == null) {
            JOptionPane.showMessageDialog(vista, "Error interno: vuelo no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Simular la capacidad disponible
        int capacidadDisponible = obtenerCapacidadDisponibleDelVuelo(vuelo);

        if (cantidad > capacidadDisponible) {
            JOptionPane.showMessageDialog(vista, "La cantidad solicitada excede la capacidad disponible para compartir.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Simulamos llamada real
        System.out.println("✈️ Solicitud de compartir vuelo enviada:");
        System.out.println("- Código de vuelo: " + vuelo.getCodigoVuelo());
        System.out.println("- Origen: " + vuelo.getOrigen());
        System.out.println("- Destino: " + vuelo.getDestino());
        System.out.println("- Cantidad solicitada: " + cantidad);

        // En futuro real sería algo como:
        // vuelo.solicitarVueloCompartido(cantidad, aerolineaSolicitante);

        vista.reset();
    }

    private Vuelo obtenerVueloSeleccionado(String vueloTexto) {
        return mapaVuelos.get(vueloTexto);
    }

    private int obtenerCapacidadDisponibleDelVuelo(Vuelo vuelo) {
        // Simulación: el 50% de la capacidad total del avión disponible para compartir
        int total = vuelo.getCantidadCarga(); // Para pasajeros o carga
        return total / 2;
    }

    private void cargarVuelosDePrueba() {
        // Simular creación de vuelos de prueba
        Avion avion1 = new Avion("Boeing", "737", CategoriaAvion.PASAJEROS, 160);
        Avion avion2 = new Avion("Airbus", "A320", CategoriaAvion.PASAJEROS, 150);
        Avion avion3 = new Avion("Cargolux", "747F", CategoriaAvion.MERCANIAS, 30000);

        Aerolinea iberia = new Aerolinea("Iberia", "IBE");
        Aerolinea vueling = new Aerolinea("Vueling", "VLG");
        Aerolinea cargolux = new Aerolinea("Cargolux", "CLX");

        Vuelo vuelo1 = new Vuelo("Madrid", "París", LocalTime.of(10, 30), LocalTime.of(12, 45), LocalDate.now(), iberia, avion1);
        Vuelo vuelo2 = new Vuelo("Barcelona", "Roma", LocalTime.of(14, 15), LocalTime.of(16, 30), LocalDate.now(), vueling, avion2);
        Vuelo vuelo3 = new Vuelo("Valencia", "Berlín", LocalTime.of(9, 0), LocalTime.of(11, 20), LocalDate.now(), cargolux, avion3);

        String textoVuelo1 = "✈️ Código: " + vuelo1.getCodigoVuelo() + " | Estado: FINALIZADO | Origen: " + vuelo1.getOrigen() + " | Destino: " + vuelo1.getDestino() + " | Aerolínea: Iberia";
        String textoVuelo2 = "✈️ Código: " + vuelo2.getCodigoVuelo() + " | Estado: FINALIZADO | Origen: " + vuelo2.getOrigen() + " | Destino: " + vuelo2.getDestino() + " | Aerolínea: Vueling";
        String textoVuelo3 = "✈️ Código: " + vuelo3.getCodigoVuelo() + " | Estado: FINALIZADO | Origen: " + vuelo3.getOrigen() + " | Destino: " + vuelo3.getDestino() + " | Aerolínea: Cargolux";

        // Cargar en el mapa
        mapaVuelos.put(textoVuelo1, vuelo1);
        mapaVuelos.put(textoVuelo2, vuelo2);
        mapaVuelos.put(textoVuelo3, vuelo3);

        // Cargar en la vista
        vista.setListaVuelos(new String[] { textoVuelo1, textoVuelo2, textoVuelo3 });
    }
}
 */
