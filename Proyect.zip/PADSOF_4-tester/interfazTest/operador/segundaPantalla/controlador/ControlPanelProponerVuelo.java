package segundaPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import interfazTest.componentes.PantallaBase;
import primeraPantalla.enums.ComandoProponerVueloEnum;
import segundaPantalla.proponerVuelo.controlador.ControlPanelProponerVueloMenu;
import segundaPantalla.proponerVuelo.vista.PanelProponerVueloMenu;
import segundaPantalla.solicitarCompartir.controlador.ControlPanelSolicitarCompartirVuelo;
import segundaPantalla.solicitarCompartir.vista.PanelSolicitarCompartirVuelo;
import segundaPantalla.verSolicitudesDeCompartir.controlador.ControlPanelVerSolicitudesCompartirVuelo;
import segundaPantalla.verSolicitudesDeCompartir.vista.PanelVerSolicitudesCompartirVuelo;
import segundaPantalla.vista.PanelProponerVuelo;

public class ControlPanelProponerVuelo implements ActionListener {

    private final PanelProponerVuelo vista;
    private final PantallaBase pantalla;

    public ControlPanelProponerVuelo(PanelProponerVuelo vista) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoProponerVueloEnum comando = ComandoProponerVueloEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case PROPONER_VUELO:
                PanelProponerVueloMenu panel = new PanelProponerVueloMenu();
                new ControlPanelProponerVueloMenu(panel);
                vista.mostrarPanel(panel);
                break;

            case SOLICITAR_COMPARTIR:
                PanelSolicitarCompartirVuelo panelSolicitar = new PanelSolicitarCompartirVuelo();
                new ControlPanelSolicitarCompartirVuelo(panelSolicitar);
                vista.mostrarPanel(panelSolicitar);
                break;

            case VER_SOLICITUDES:
                PanelVerSolicitudesCompartirVuelo panelVerSolicitudes = new PanelVerSolicitudesCompartirVuelo();
                new ControlPanelVerSolicitudesCompartirVuelo(panelVerSolicitudes);
                vista.mostrarPanel(panelVerSolicitudes);
                break;
        }
    }
}
