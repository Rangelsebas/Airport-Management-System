package segundaPantalla.proponerVuelo.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import segundaPantalla.proponerVuelo.enums.ComandoPanelProponerVueloMenu;
import segundaPantalla.proponerVuelo.enums.ComandoTipoVueloEnum;
import segundaPantalla.proponerVuelo.vista.PanelProponerVueloMenu;

public class ControlPanelProponerVueloMenu implements ActionListener {
    private PanelProponerVueloMenu vista;

    public ControlPanelProponerVueloMenu(PanelProponerVueloMenu vista) {
        this.vista = vista;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoPanelProponerVueloMenu comando = ComandoPanelProponerVueloMenu.valueOf(e.getActionCommand());

        switch (comando) {
            case PROPONER_VUELO_CONFIRMADO:
                procesarPropuestaVuelo();
                break;
            default:
                break;
        }
    }

    private void procesarPropuestaVuelo() {
        ComandoTipoVueloEnum tipo = vista.getTipo();
        java.util.Date fecha = vista.getFecha();
        int hora = vista.getHora();
        int minuto = vista.getMinuto();
        int cantidad = vista.getCantidad();
        String avion = vista.getAvion();

        // Validación mínima: que no elijan "Avión" por defecto
        if (avion == null || avion.equals("Avión") || avion.isBlank()) {
            JOptionPane.showMessageDialog(vista, "Por favor seleccione un avión válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Lógica ejemplo: podrías enviar esto a tu modelo aquí
        System.out.println("🛫 Propuesta de vuelo realizada:");
        System.out.println("Tipo de vuelo: " + tipo);
        System.out.println("Fecha: " + fecha);
        System.out.println("Hora: " + hora + ":" + minuto);
        if (tipo == ComandoTipoVueloEnum.PASAJEROS) {
            System.out.println("Número de pasajeros: " + cantidad);
        } else {
            System.out.println("Carga (kg): " + cantidad);
        }
        System.out.println("Avión seleccionado: " + avion);

        //TODO: Aquí podrías agregar lógica real: mandar a modelo, confirmar alta, etc.

        // Luego de procesar: limpiar formulario
        vista.reset();
    }
}
