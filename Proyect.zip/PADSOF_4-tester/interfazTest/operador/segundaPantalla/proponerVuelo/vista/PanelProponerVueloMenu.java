package segundaPantalla.proponerVuelo.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import segundaPantalla.proponerVuelo.enums.ComandoPanelProponerVueloMenu;
import segundaPantalla.proponerVuelo.enums.ComandoTipoVueloEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Date;

public class PanelProponerVueloMenu extends JPanel {


    private JComboBox<ComandoTipoVueloEnum> comboTipo;
    private JSpinner spinnerFecha;
    private JSpinner spinnerHora;
    private JSpinner spinnerMinuto;
    private JSpinner spinnerCantidad;
    private JComboBox<String> comboAvion;
    private JButton botonHacerPropuesta;
    private JLabel labelCantidad;

    public PanelProponerVueloMenu() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        // Combo tipo
        comboTipo = new JComboBox<>(ComandoTipoVueloEnum.values());
        comboTipo.setMaximumSize(new Dimension(200, 30));
        comboTipo.addItemListener(e -> actualizarLabelCantidad());
        add(comboTipo);

        add(Box.createVerticalStrut(10));
        
        // Fecha
        add(crearEtiqueta("Fecha:"));
        spinnerFecha = new JSpinner(new SpinnerDateModel());
        spinnerFecha.setEditor(new JSpinner.DateEditor(spinnerFecha, "dd/MM/yyyy"));
        spinnerFecha.setMaximumSize(new Dimension(200, 30));
        add(spinnerFecha);

        add(Box.createVerticalStrut(10));

        // Hora
        add(crearEtiqueta("Hora:"));
        JPanel panelHora = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0)); // <-- Cambio aquí
        panelHora.setBackground(Color.WHITE);
        spinnerHora = crearSpinner(12, 0, 23, 1);
        spinnerMinuto = crearSpinner(0, 0, 59, 1);
        panelHora.add(spinnerHora);
        panelHora.add(new JLabel(":"));
        panelHora.add(spinnerMinuto);
        add(panelHora);

        add(Box.createVerticalStrut(10));

        // Pasajeros / Carga
        labelCantidad = crearEtiqueta("Número de pasajeros:");
        add(labelCantidad);

        spinnerCantidad = crearSpinner(100, 0, 10000, 10); // Ahora 10.000 por si la carga en kg es más grande
        add(spinnerCantidad);

        add(Box.createVerticalStrut(10));

        // Combo avión
        comboAvion = new JComboBox<>();
        comboAvion.setMaximumSize(new Dimension(200, 30));
        comboAvion.addItem("Avión"); // Primera opción por defecto

        comboAvion.addItem("🛫 Boeing 737-800 | Matrícula: EC-ILA | 189 pasajeros");
        comboAvion.addItem("🛫 Airbus A320neo | Matrícula: N12345 | 180 pasajeros");
        comboAvion.addItem("🛫 Embraer E195-E2 | Matrícula: PT-XYZ | 132 pasajeros");
        comboAvion.addItem("🛫 Boeing 747-8F | Matrícula: CLX-987 | 140000 kg carga");
        comboAvion.addItem("🛫 ATR 72-600 | Matrícula: F-WWEK | 70 pasajeros");
        comboAvion.addItem("🛫 Airbus BelugaXL | Matrícula: F-GXLH | 51000 kg carga");
        comboAvion.addItem("🛫 Cessna 208 Caravan | Matrícula: XA-ULI | 14 pasajeros");
        add(comboAvion);

        /* TODO: flujo cuando integremos la logica de negocio */
        // List<Avion> flotaDisponible = operador.getFlotaDisponible();

        // for (Avion avion : flotaDisponible) {
        //     String tipo = avion.getCategoria() == CategoriaAvion.PASAJEROS ? 
        //                 avion.getTipoAvion().getCapacidad() + " pasajeros" :
        //                 avion.getTipoAvion().getCapacidad() + " kg carga";

        //     String descripcion = "🛫 " + avion.getMarca() + " " + avion.getModelo() +
        //                         " | Matrícula: " + avion.getMatricula() +
        //                         " | " + tipo;
        //     comboAvion.addItem(descripcion);
        // }

        add(Box.createVerticalStrut(15));

        // Botón
        botonHacerPropuesta = new JButton("Hacer propuesta");
        botonHacerPropuesta.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonHacerPropuesta.setActionCommand(ComandoPanelProponerVueloMenu.PROPONER_VUELO_CONFIRMADO.name());
        add(botonHacerPropuesta);
    }

    // ================================
    // MÉTODOS DE VISTA MVC
    // ================================

    public void setControlador(ActionListener c) {
        botonHacerPropuesta.addActionListener(c);
    }

    public ComandoTipoVueloEnum getTipo() {
        return (ComandoTipoVueloEnum) comboTipo.getSelectedItem();
    }

    public Date getFecha() {
        return (Date) spinnerFecha.getValue();
    }

    public int getHora() {
        return (Integer) spinnerHora.getValue();
    }

    public int getMinuto() {
        return (Integer) spinnerMinuto.getValue();
    }

    public int getCantidad() {
        return (Integer) spinnerCantidad.getValue();
    }

    public String getAvion() {
        return (String) comboAvion.getSelectedItem();
    }

    public void setListaAviones(String[] aviones) {
        comboAvion.removeAllItems();
        comboAvion.addItem("Avión"); // Siempre la primera opción
        for (String avion : aviones) {
            comboAvion.addItem(avion);
        }
    }

    public void reset() {
        comboTipo.setSelectedIndex(0);
        spinnerFecha.setValue(new Date());
        spinnerHora.setValue(12);
        spinnerMinuto.setValue(0);
        spinnerCantidad.setValue(100);
        comboAvion.setSelectedIndex(0);
    }

    // ================================
    // HELPERS
    // ================================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(60, 30));
        return spinner;
    }

    private void actualizarLabelCantidad() {
        if (comboTipo.getSelectedItem() == ComandoTipoVueloEnum.MERCANCIA) {
            labelCantidad.setText("Carga (kg):");
        } else {
            labelCantidad.setText("Número de pasajeros:");
        }
    }
}
