package segundaPantalla.proponerVuelo.enums;

public enum ComandoTipoVueloEnum {
    PASAJEROS("Pasajeros"),
    MERCANCIA("Mercancía");

    private final String nombre;

    ComandoTipoVueloEnum(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
