package segundaPantalla.verSolicitudesDeCompartir.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PanelVerSolicitudesCompartirVuelo extends JPanel {

    private JPanel panelSolicitudes;

    public PanelVerSolicitudesCompartirVuelo() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Solicitudes de Compartir Vuelos", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        /* Scroll */
        panelSolicitudes = new JPanel();
        panelSolicitudes.setLayout(new BoxLayout(panelSolicitudes, BoxLayout.Y_AXIS));
        panelSolicitudes.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelSolicitudes);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(400, 400)); // Ancho fijo, altura variable
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16); // para un scroll más suave
        add(scroll, BorderLayout.CENTER);
    }

    public void agregarSolicitud(String vueloInfo, String solicitante, int porcentaje, String estado) {
        JPanel solicitudPanel = new JPanel();
        solicitudPanel.setLayout(new BoxLayout(solicitudPanel, BoxLayout.Y_AXIS));
        solicitudPanel.setBackground(Color.WHITE);
        solicitudPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        JLabel vueloLabel = new JLabel("\u2708\ufe0f " + vueloInfo);
        vueloLabel.setFont(new Font("Arial", Font.BOLD, 14));
        JLabel solicitanteLabel = new JLabel("Solicitante: " + solicitante);
        JLabel porcentajeLabel = new JLabel("Porcentaje solicitado: " + porcentaje + "%");
        JLabel estadoLabel = new JLabel("Estado: " + estado);

        solicitudPanel.add(vueloLabel);
        solicitudPanel.add(solicitanteLabel);
        solicitudPanel.add(porcentajeLabel);
        solicitudPanel.add(estadoLabel);

        panelSolicitudes.add(Box.createVerticalStrut(10));
        panelSolicitudes.add(solicitudPanel);
    }

    public void reset() {
        panelSolicitudes.removeAll();
        panelSolicitudes.revalidate();
        panelSolicitudes.repaint();
    }
}