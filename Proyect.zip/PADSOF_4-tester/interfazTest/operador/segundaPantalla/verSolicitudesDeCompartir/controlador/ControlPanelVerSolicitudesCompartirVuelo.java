package segundaPantalla.verSolicitudesDeCompartir.controlador;

import segundaPantalla.verSolicitudesDeCompartir.vista.PanelVerSolicitudesCompartirVuelo;

public class ControlPanelVerSolicitudesCompartirVuelo {

    private PanelVerSolicitudesCompartirVuelo vista;

    public ControlPanelVerSolicitudesCompartirVuelo(PanelVerSolicitudesCompartirVuelo vista) {
        this.vista = vista;
        cargarSolicitudesMockup();
    }

    private void cargarSolicitudesMockup() {
        // Simular solicitudes fijas para probar la parte visual

        vista.agregarSolicitud("Código: VH001 - Madrid → París", "Iberia", 30, "PENDIENTE");
        vista.agregarSolicitud("Código: VH002 - Barcelona → Roma", "Vueling", 20, "APROBADA");
        vista.agregarSolicitud("Código: VH003 - Valencia → Berlín", "Cargolux", 40, "RECHAZADA");
        vista.agregarSolicitud("Código: VH004 - Madrid → Londres", "Iberia", 50, "PENDIENTE");
        vista.agregarSolicitud("Código: VH005 - Barcelona → Nueva York", "Vueling", 10, "APROBADA");
    }
}



// TODO: Esto es lo que implementaremos cuando integremos la lógica de negocio

/*
public class ControlPanelVerSolicitudesCompartirVuelo {

    private PanelVerSolicitudesCompartirVuelo vista;

    public ControlPanelVerSolicitudesCompartirVuelo(PanelVerSolicitudesCompartirVuelo vista) {
        this.vista = vista;
        cargarSolicitudesDePrueba();
    }

    private void cargarSolicitudesDePrueba() {
        // Crear vuelos y ocupaciones de prueba
        List<Vuelo> vuelos = crearVuelosMock();

        for (Vuelo vuelo : vuelos) {
            for (Ocupacion ocupacion : vuelo.getOcupaciones()) {
                String vueloInfo = "Código: " + vuelo.getCodigoVuelo() +
                                   " - " + vuelo.getOrigen() + " → " + vuelo.getDestino();
                String solicitante = ocupacion.getAerolineaSolicitante().getNombre();
                int porcentaje = ocupacion.getPorcentajeAsientos();
                String estado = ocupacion.getEstado().toString();
                vista.agregarSolicitud(vueloInfo, solicitante, porcentaje, estado);
            }
        }
    }

    private List<Vuelo> crearVuelosMock() {
        List<Vuelo> vuelos = new ArrayList<>();

        // Aviones
        Avion avion1 = new Avion("Boeing", "737", CategoriaAvion.PASAJEROS, 160);
        Avion avion2 = new Avion("Airbus", "A320", CategoriaAvion.PASAJEROS, 150);

        // Aerolíneas
        Aerolinea iberia = new Aerolinea("Iberia", "IBE");
        Aerolinea vueling = new Aerolinea("Vueling", "VLG");
        Aerolinea latam = new Aerolinea("LATAM", "LAM");

        // Vuelos
        Vuelo vuelo1 = new Vuelo("Madrid", "París", LocalTime.of(10, 30), LocalTime.of(12, 45), LocalDate.now(), iberia, avion1);
        Vuelo vuelo2 = new Vuelo("Barcelona", "Roma", LocalTime.of(14, 15), LocalTime.of(16, 30), LocalDate.now(), vueling, avion2);

        // Ocupaciones simuladas
        vuelo1.getOcupaciones().clear();
        vuelo1.getOcupaciones().add(new Ocupacion(latam, 30, EstadoSolicitud.PENDIENTE));

        vuelo2.getOcupaciones().clear();
        vuelo2.getOcupaciones().add(new Ocupacion(iberia, 20, EstadoSolicitud.APROBADA));

        vuelos.add(vuelo1);
        vuelos.add(vuelo2);

        return vuelos;
    }
}
 */
