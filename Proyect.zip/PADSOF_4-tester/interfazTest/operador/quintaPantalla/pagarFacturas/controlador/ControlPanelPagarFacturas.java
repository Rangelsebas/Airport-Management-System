package quintaPantalla.pagarFacturas.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import quintaPantalla.pagarFacturas.enums.ComandoPagarFacturasEnum;
import quintaPantalla.pagarFacturas.vista.PanelPagarFacturas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ControlPanelPagarFacturas implements ActionListener {

    private PanelPagarFacturas vista;
    private PantallaBase pantalla;

    public ControlPanelPagarFacturas(PanelPagarFacturas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        cargarFacturasPendientes();
    }

    private void cargarFacturasPendientes() {
        // Aquí cargamos facturas simuladas de prueba

        vista.agregarFactura("#F101 | Fecha: 10/12/2025 | Monto: $700");
        vista.agregarFactura("#F102 | Fecha: 11/12/2025 | Monto: $450");
        vista.agregarFactura("#F103 | Fecha: 12/12/2025 | Monto: $600");
        vista.agregarFactura("#F104 | Fecha: 13/12/2025 | Monto: $520");
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoPagarFacturasEnum comando = ComandoPagarFacturasEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case PAGAR_FACTURAS:
                procesarPagoFacturas();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarPagoFacturas() {
        List<JCheckBox> checkboxes = vista.getCheckboxes();
        boolean algunaSeleccionada = false;

        for (JCheckBox checkbox : checkboxes) {
            if (checkbox.isSelected() && checkbox.isEnabled()) {
                algunaSeleccionada = true;
                System.out.println("💵 Factura pagada: " + checkbox.getText());

                checkbox.setSelected(false); // Desmarcarla
                checkbox.setEnabled(false);  // Desactivarla (gris)
            }
        }

        if (!algunaSeleccionada) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar al menos una factura para pagar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(vista, "¡Pago realizado con éxito!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        // Opcional: podrías eliminar las facturas pagadas del panel
        // o refrescar la lista si quieres
    }
}
