package quintaPantalla.pagarFacturas.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import quintaPantalla.pagarFacturas.enums.ComandoPagarFacturasEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class PanelPagarFacturas extends JPanel {

    private JPanel panelListado;
    private JButton botonPagar;
    private List<JCheckBox> listaCheckboxes;

    public PanelPagarFacturas() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Pagar Facturas", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        listaCheckboxes = new ArrayList<>();

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(500, 300));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);

        botonPagar = new JButton("Pagar Seleccionadas");
        botonPagar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonPagar.setActionCommand(ComandoPagarFacturasEnum.PAGAR_FACTURAS.name());

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(Color.WHITE);
        panelBoton.setBorder(new EmptyBorder(20, 0, 20, 0));
        panelBoton.add(botonPagar);

        add(panelBoton, BorderLayout.SOUTH);
    }

    public void agregarFactura(String infoFactura) {
        JCheckBox checkbox = new JCheckBox(infoFactura);
        checkbox.setFont(new Font("Arial", Font.PLAIN, 16));
        checkbox.setBackground(Color.WHITE);
        checkbox.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelFactura = new JPanel();
        panelFactura.setLayout(new BoxLayout(panelFactura, BoxLayout.Y_AXIS));
        panelFactura.setBackground(Color.WHITE);
        panelFactura.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelFactura.add(checkbox);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelFactura);

        listaCheckboxes.add(checkbox);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public List<JCheckBox> getCheckboxes() {
        return listaCheckboxes;
    }

    public void setControlador(ActionListener c) {
        botonPagar.addActionListener(c);
    }

    public void reset() {
        panelListado.removeAll();
        listaCheckboxes.clear();
        panelListado.revalidate();
        panelListado.repaint();
    }
}
