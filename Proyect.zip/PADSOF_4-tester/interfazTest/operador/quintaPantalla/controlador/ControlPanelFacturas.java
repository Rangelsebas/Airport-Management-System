package quintaPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import interfazTest.componentes.PantallaBase;
import quintaPantalla.enums.ComandoFacturaEnum;
import quintaPantalla.historicoFacturas.controlador.ControlPanelConsultarHistoricoFacturas;
import quintaPantalla.historicoFacturas.vista.PanelConsultarHistoricoFacturas;
import quintaPantalla.pagarFacturas.controlador.ControlPanelPagarFacturas;
import quintaPantalla.pagarFacturas.vista.PanelPagarFacturas;
import quintaPantalla.vista.PanelFacturas;

public class ControlPanelFacturas implements ActionListener {

    private PanelFacturas vista;
    private PantallaBase pantalla;

    public ControlPanelFacturas(PanelFacturas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoFacturaEnum comando = ComandoFacturaEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case HISTORICO_FACTURAS:
                PanelConsultarHistoricoFacturas panelConsultarFacturas = new PanelConsultarHistoricoFacturas();
                new ControlPanelConsultarHistoricoFacturas(panelConsultarFacturas, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelConsultarFacturas);
                break;

            case PAGAR_FACTURA:
                PanelPagarFacturas panelPagar = new PanelPagarFacturas();
                new ControlPanelPagarFacturas(panelPagar, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelPagar);
                break;
        }
    }
}
