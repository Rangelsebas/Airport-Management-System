package quintaPantalla.historicoFacturas.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JOptionPane;

import interfazTest.componentes.PantallaBase;
import quintaPantalla.historicoFacturas.enums.ComandoHistoricoFacturasEnum;
import quintaPantalla.historicoFacturas.vista.PanelConsultarHistoricoFacturas;
import quintaPantalla.listadoFacturasSubMenu.controlador.ControlPanelListadoFacturas;
import quintaPantalla.listadoFacturasSubMenu.vista.PanelListadoFacturas;

public class ControlPanelConsultarHistoricoFacturas implements ActionListener {

    private PanelConsultarHistoricoFacturas vista;
    private PantallaBase pantalla;

    public ControlPanelConsultarHistoricoFacturas(PanelConsultarHistoricoFacturas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoHistoricoFacturasEnum comando = ComandoHistoricoFacturasEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONSULTAR_HISTORICO_FACTURAS:
                procesarConsulta();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarConsulta() {
        Date fechaDesde = vista.getFechaDesde();
        Date fechaHasta = vista.getFechaHasta();

        if (fechaDesde == null || fechaHasta == null) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar ambas fechas.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (fechaDesde.after(fechaHasta)) {
            JOptionPane.showMessageDialog(vista, "La fecha 'Desde' no puede ser posterior a la fecha 'Hasta'.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        System.out.println("🔍 Consultando facturas desde: " + fechaDesde + " hasta: " + fechaHasta);

        // Instanciar el nuevo panel de listado de facturas
        PanelListadoFacturas panelListadoFacturas = new PanelListadoFacturas();
        new ControlPanelListadoFacturas(panelListadoFacturas, pantalla);

        // Aquí deberías agregar facturas mock para probar
        // Por ejemplo: controlListadoFacturas.agregarFactura(...);

        pantalla.mostrarContenidoEnPanelCentral(panelListadoFacturas);
    }
}