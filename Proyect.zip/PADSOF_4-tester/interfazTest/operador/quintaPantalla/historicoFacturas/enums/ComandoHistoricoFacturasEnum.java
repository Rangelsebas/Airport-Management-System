package quintaPantalla.historicoFacturas.enums;

public enum ComandoHistoricoFacturasEnum {
    CONSULTAR_HISTORICO_FACTURAS
}
