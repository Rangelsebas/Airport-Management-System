package quintaPantalla.listadoFacturasSubMenu.controlador;

import interfazTest.componentes.PantallaBase;
import quintaPantalla.listadoFacturasSubMenu.vista.PanelListadoFacturas;

public class ControlPanelListadoFacturas {

    private PanelListadoFacturas vista;
    private PantallaBase pantalla;

    public ControlPanelListadoFacturas(PanelListadoFacturas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        cargarFacturasDePrueba();
    }

    private void cargarFacturasDePrueba() {
        // Simulamos facturas de prueba para visualizar

        vista.agregarFactura("#F001 | Fecha: 01/12/2025 | Estado: Pagada | Monto: $500");
        vista.agregarFactura("#F002 | Fecha: 02/12/2025 | Estado: No Pagada | Monto: $300");
        vista.agregarFactura("#F003 | Fecha: 03/12/2025 | Estado: Pagada | Monto: $450");
        vista.agregarFactura("#F004 | Fecha: 04/12/2025 | Estado: No Pagada | Monto: $600");
        vista.agregarFactura("#F005 | Fecha: 05/12/2025 | Estado: Pagada | Monto: $700");
        
    }
}
