package interfazTest.operador.controlador;


import java.awt.Component;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import cuartaPantalla.controlador.ControlPanelRendimientoVuelo;
import cuartaPantalla.vista.PanelRendimientoVuelo;
import interfazTest.componentes.PanelNotificaciones;
import interfazTest.login.controlador.ControlPanelLoginFrame;
import interfazTest.login.vista.PanelLoginFrame;
import interfazTest.operador.enums.ComandoVentanaOperadorEnum;
import interfazTest.operador.primeraPantalla.controlador.ControlPanelGestionarFlota;
import interfazTest.operador.primeraPantalla.vista.PanelGestionarFlota;
import interfazTest.operador.vista.VentanaOperador;
import quintaPantalla.controlador.ControlPanelFacturas;
import quintaPantalla.vista.PanelFacturas;
import segundaPantalla.controlador.ControlPanelProponerVuelo;
import segundaPantalla.vista.PanelProponerVuelo;
import septimaPantalla.controlador.ControlPanelNotificaciones;
import septimaPantalla.vista.PanelNotificacionesHistorico;
import sextaPantalla.controlador.ControlPanelVuelosCompartidos;
import sextaPantalla.vista.PanelVuelosCompartidos;
import terceraPantalla.controlador.ControlPanelEstadoVuelo;
import terceraPantalla.vista.PanelControlarEstadoVuelo;

public class ControlVentanaOperador implements ActionListener {
    private VentanaOperador vista;

    public ControlVentanaOperador(VentanaOperador vista) {
        this.vista = vista;
        this.vista.setControlador(this); 

        vista.getBotonCerrarSesion().setActionCommand(ComandoVentanaOperadorEnum.CERRAR_SESION.name());
        vista.getBotonCerrarSesion().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            ComandoVentanaOperadorEnum comando = ComandoVentanaOperadorEnum.valueOf(e.getActionCommand());

            switch (comando) {
                case GESTIONAR_FLOTA:
                    PanelGestionarFlota panelFlota = vista.getPanelGestionarFlota();
                    new ControlPanelGestionarFlota(panelFlota, vista.getPantallaBase()); 
                    vista.mostrarPanel(panelFlota);
                    break;

                case PROPONER_VUELOS:
                    PanelProponerVuelo panelProponer = vista.getPanelProponerVuelo();
                    new ControlPanelProponerVuelo(panelProponer); 
                    vista.mostrarPanel(panelProponer);
                    break;

                case CONTROLAR_ESTADO:
                    PanelControlarEstadoVuelo panelEstado = vista.getPanelEstadoVuelo(); // ← Carga desde el getter
                    new ControlPanelEstadoVuelo(panelEstado, vista.getPantallaBase()); // ← Conecta el controlador
                    vista.mostrarPanel(panelEstado); // ← Muestra en pantalla
                    break;

                case VER_RENDIMIENTO:
                    PanelRendimientoVuelo panelRendimiento = vista.getPanelRendimientoVuelo();
                    new ControlPanelRendimientoVuelo(panelRendimiento, vista.getPantallaBase());
                    vista.mostrarPanel(panelRendimiento);
                    break;

                case VER_FACTURAS:
                    PanelFacturas panelFacturas = vista.getPanelFacturas();
                    new ControlPanelFacturas(panelFacturas, vista.getPantallaBase());
                    vista.mostrarPanel(panelFacturas);
                    break;

                case VUELOS_COMPARTIDOS:
                    PanelVuelosCompartidos panelCompartidos = vista.getPanelVuelosCompartidos();
                    new ControlPanelVuelosCompartidos(panelCompartidos);
                    vista.mostrarPanel(panelCompartidos);
                    break;

                case VER_NOTIFICACIONES:
                    PanelNotificacionesHistorico PanelNotificaciones = vista.getPanelNotificacionesHistorico();
                    new ControlPanelNotificaciones(PanelNotificaciones);
                    vista.mostrarPanel(PanelNotificaciones);
                    break;
                case GUARDAR_APLICACION:
                    // Implementar la lógica para guardar el estado de la aplicación
                    JOptionPane.showMessageDialog(vista, "Estado de la aplicación guardado correctamente.");
                    break;
                case CARGAR_APLICACION:
                    // Implementar la lógica para cargar el estado de la aplicación
                    JOptionPane.showMessageDialog(vista, "Estado de la aplicación cargado correctamente.");
                    break;

                case CERRAR_SESION:
                    int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Estás seguro que deseas cerrar sesión?",
                        "Cerrar sesión", JOptionPane.YES_NO_OPTION);

                    if (respuesta == JOptionPane.YES_OPTION) {
                        System.out.println("Sesión cerrada correctamente.");

                        // 🔥 Cerrar ventana actual
                        Window ventana = SwingUtilities.getWindowAncestor((Component) e.getSource());
                        if (ventana != null) {
                            ventana.dispose();
                        }

                        // 🔥 Volver al login
                        SwingUtilities.invokeLater(() -> {
                            PanelLoginFrame loginFrame = new PanelLoginFrame();
                            new ControlPanelLoginFrame(loginFrame); // conecta el controlador
                            loginFrame.setVisible(true);
                        });
                    }
                    break;
            }

        } catch (IllegalArgumentException ex) {
            System.err.println("Comando no reconocido: " + e.getActionCommand());
        }
}

}
