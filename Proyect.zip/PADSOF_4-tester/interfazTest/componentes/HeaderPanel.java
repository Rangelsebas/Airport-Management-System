package interfazTest.componentes;

import java.awt.*;
import javax.swing.*;

public class HeaderPanel extends JPanel {
    public JLabel usuarioLabel;
    public JButton cerrarSesionButton;

    public HeaderPanel(String nombreUsuario) {
        setLayout(new BorderLayout());

        usuarioLabel = new JLabel("< Usuario > : " + nombreUsuario);
        usuarioLabel.setFont(new Font("Arial", Font.BOLD, 14));

        cerrarSesionButton = new JButton("Cerrar Sesión");

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        derecha.add(cerrarSesionButton);

        setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(usuarioLabel, BorderLayout.WEST);
        add(derecha, BorderLayout.EAST);
    }

    public JButton getCerrarSesionButton() {
        return cerrarSesionButton;
    }
}
