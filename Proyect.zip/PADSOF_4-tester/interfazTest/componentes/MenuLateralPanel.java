package interfazTest.componentes;

import java.awt.*;
import java.util.List;
import javax.swing.*;

public class MenuLateralPanel extends JPanel {
    public MenuLateralPanel(List<JButton> botonesMenu) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        for (JButton b : botonesMenu) {
            b.setAlignmentX(Component.CENTER_ALIGNMENT);
            b.setMaximumSize(new Dimension(300, 60));
            b.setFont(new Font("Arial", Font.BOLD, 16));
            b.setText("<html>" + b.getText() + "</html>");
            b.setHorizontalAlignment(SwingConstants.CENTER);
            b.setVerticalAlignment(SwingConstants.CENTER);
            add(Box.createVerticalStrut(10));
            add(b);
        }

        int alturaEstimativa = botonesMenu.size() * 80;
        setPreferredSize(new Dimension(300, alturaEstimativa));
    }
}
