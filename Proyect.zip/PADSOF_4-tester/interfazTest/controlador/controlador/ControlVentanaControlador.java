package interfazTest.controlador.controlador;

import java.awt.Component;
import java.awt.Panel;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import interfazTest.controlador.cuartaPantalla.controlador.ControlPanelVerCola;
import interfazTest.controlador.cuartaPantalla.vista.PanelVerCola;
import interfazTest.controlador.enums.ComandoVentanaControladorEnum;
import interfazTest.controlador.primeraPantalla.controlador.ControlPanelControlarAterrizajes;
import interfazTest.controlador.primeraPantalla.vista.PanelControlarAterrizajes;
import interfazTest.controlador.segundaPantalla.controlador.ControlPanelControlarDespegues;
import interfazTest.controlador.segundaPantalla.vista.PanelControlarDespegues;
import interfazTest.controlador.terceraPantalla.controlador.ControlPanelControlarEstadoVuelo;
import interfazTest.controlador.terceraPantalla.vista.PanelControlarEstadoVuelo;
import interfazTest.controlador.vista.VentanaControlador;
import interfazTest.login.controlador.ControlPanelLoginFrame;
import interfazTest.login.vista.PanelLoginFrame;

public class ControlVentanaControlador implements ActionListener {

    private VentanaControlador vista;

    public ControlVentanaControlador(VentanaControlador vista) {
        this.vista = vista;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaControladorEnum comando = ComandoVentanaControladorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONTROLAR_ATERRIZAJES:
                PanelControlarAterrizajes panelControlarAterrizajes = vista.getPanelControlarAterrizajes();
                new ControlPanelControlarAterrizajes(panelControlarAterrizajes, vista.getPantallaBase());
                vista.mostrarPanel(panelControlarAterrizajes);
                break;

            case CONTROLAR_DESPEGUES:
                PanelControlarDespegues panelControlarDespegues = vista.getPanelControlarDespegues();
                new ControlPanelControlarDespegues(panelControlarDespegues, vista.getPantallaBase());
                vista.mostrarPanel(panelControlarDespegues);
                break;

            case CONTROLAR_ESTADO_VUELO:
                PanelControlarEstadoVuelo panelControlarEstadoVuelo = vista.getPanelControlarEstadoVuelo();
                new ControlPanelControlarEstadoVuelo(panelControlarEstadoVuelo, vista.getPantallaBase());
                vista.mostrarPanel(panelControlarEstadoVuelo);
                break;

            case VER_COLA:
                PanelVerCola panelVerCola = vista.getPanelVerCola();
                new ControlPanelVerCola(panelVerCola, vista.getPantallaBase());
                vista.mostrarPanel(panelVerCola);
                break;

            case CERRAR_SESION:
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Estás seguro que deseas cerrar sesión?",
                        "Cerrar sesión", JOptionPane.YES_NO_OPTION);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.out.println("Sesión cerrada correctamente.");

                    // 🔥 Cerrar ventana actual
                    Window ventana = SwingUtilities.getWindowAncestor((Component) e.getSource());
                    if (ventana != null) {
                        ventana.dispose();
                    }

                    // 🔥 Volver al login
                    SwingUtilities.invokeLater(() -> {
                        PanelLoginFrame loginFrame = new PanelLoginFrame();
                        new ControlPanelLoginFrame(loginFrame); // conecta el controlador
                        loginFrame.setVisible(true);
                    });
                }
                break;

            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }
}