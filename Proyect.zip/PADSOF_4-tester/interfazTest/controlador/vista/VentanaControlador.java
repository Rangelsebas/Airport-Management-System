/* javac -d bin src/interfaz/controlador/VentanaControlador.java src/interfaz/componentes/PantallaBase.java  src/interfaz/controlador/ControlarAterrizaje.java 
 * java -cp bin interfazTest.controlador.VentanaControlador
 * 
 */

package interfazTest.controlador.vista;

import interfazTest.componentes.PantallaBase;
import interfazTest.controlador.cuartaPantalla.vista.PanelVerCola;
import interfazTest.controlador.enums.ComandoVentanaControladorEnum;
import interfazTest.controlador.primeraPantalla.vista.PanelControlarAterrizajes;
import interfazTest.controlador.segundaPantalla.vista.PanelControlarDespegues;
import interfazTest.controlador.terceraPantalla.vista.PanelControlarEstadoVuelo;

import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.*;

public class VentanaControlador extends JFrame {
    
    private final String NOMBRE_USUARIO_CONTROLADOR = "Controlador Aéreo";
    private PantallaBase pantalla;
    private List<JButton> botones;
    private String nombreUsuario;

    // Subpaneles
    private PanelControlarAterrizajes panelAterrizajes;
    private PanelControlarDespegues panelDespegues;
    private PanelControlarEstadoVuelo panelEstadoVuelo;
    private PanelVerCola panelVerCola;

    public VentanaControlador() {
        this.nombreUsuario = NOMBRE_USUARIO_CONTROLADOR;
        setTitle("Sistema Aeropuerto - Controlador");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        botones = List.of(
            crearBotonMenu("Controlar Aterrizajes", ComandoVentanaControladorEnum.CONTROLAR_ATERRIZAJES),
            crearBotonMenu("Controlar Despegues", ComandoVentanaControladorEnum.CONTROLAR_DESPEGUES),
            crearBotonMenu("Controlar el Estado de un Vuelo", ComandoVentanaControladorEnum.CONTROLAR_ESTADO_VUELO),
            crearBotonMenu("Ver Cola", ComandoVentanaControladorEnum.VER_COLA)
        );

        for (JButton boton : botones) {
            boton.setHorizontalAlignment(SwingConstants.CENTER);
        }

        List<String> notificaciones = List.of(
            "Vuelo #2452: Retrasado. Estado: Esperando aterrizaje.",
            "Vuelo #45323: En hora. Estado: Esperando pista."
        );

        pantalla = new PantallaBase(nombreUsuario, botones, notificaciones);
        add(pantalla);
    }

    /* HELPER */
    private JButton crearBotonMenu(String texto, ComandoVentanaControladorEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        boton.setHorizontalAlignment(SwingConstants.CENTER);
        return boton;
    }

    public PantallaBase getPantallaBase() {
        return pantalla;
    }

    public void mostrarPanel(JPanel panel) {
        pantalla.mostrarContenidoEnPanelCentral(panel);
    }

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
        pantalla.getCerrarSesionButton().setActionCommand(ComandoVentanaControladorEnum.CERRAR_SESION.name());
        pantalla.getCerrarSesionButton().addActionListener(c);
    }

    public String getNombreUsuario() {
        return this.nombreUsuario;
    }

    public PanelControlarAterrizajes getPanelControlarAterrizajes() {
        if (panelAterrizajes == null) {
            panelAterrizajes = new PanelControlarAterrizajes();
        }
        return panelAterrizajes;
    }

    public PanelControlarDespegues getPanelControlarDespegues() {
        if (panelDespegues == null) {
            panelDespegues = new PanelControlarDespegues();
        }
        return panelDespegues;
    }

    public PanelControlarEstadoVuelo getPanelControlarEstadoVuelo() {
        if (panelEstadoVuelo == null) {
            panelEstadoVuelo = new PanelControlarEstadoVuelo();
        }
        return panelEstadoVuelo;
    }

    public PanelVerCola getPanelVerCola() {
        if (panelVerCola == null) {
            panelVerCola = new PanelVerCola();
        }
        return panelVerCola;
    }

    public JButton getBotonCerrarSesion() {
        return pantalla.getCerrarSesionButton();
    }

    public void update() {
        pantalla.mostrarContenidoEnPanelCentral(new JPanel());
    }
}
