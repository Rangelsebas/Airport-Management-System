package interfazTest.controlador.segundaPantalla.subMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class PanelAsignarRecursosDespegue extends JPanel {

    private JLabel labelEstado;
    private JLabel labelAerolinea;
    private JLabel labelCodigo;
    private JLabel labelFecha;

    private JComboBox<String> comboPistas;
    //private JComboBox<String> comboPuertas;
    private JButton botonAccion;

    public PanelAsignarRecursosDespegue(String estadoVuelo, String aerolinea, String codigo, String fecha,
                                        List<String> pistasDisponibles, List<String> puertasDisponibles,
                                        ActionListener listenerAccion) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50));

        // Info del vuelo
        labelEstado = crearEtiqueta(estadoVuelo);
        labelAerolinea = crearEtiqueta("Aerolínea: " + aerolinea);
        labelCodigo = crearEtiqueta("Código: " + codigo);
        labelFecha = crearEtiqueta("Fecha: " + fecha);

        add(labelEstado);
        add(labelAerolinea);
        add(labelCodigo);
        add(labelFecha);

        add(Box.createVerticalStrut(30));

        // Según el estado, mostrar recursos a asignar
        if (estadoVuelo.equalsIgnoreCase("Esperando pista para despegue")) {
            // Mostrar Pistas y Puertas
            add(crearEtiqueta("Asignar Pista:"));
            comboPistas = new JComboBox<>(pistasDisponibles.toArray(new String[0]));
            comboPistas.setMaximumSize(new Dimension(300, 30));
            add(comboPistas);

            // add(Box.createVerticalStrut(20));

            // add(crearEtiqueta("Asignar Puerta:"));
            // comboPuertas = new JComboBox<>(puertasDisponibles.toArray(new String[0]));
            // comboPuertas.setMaximumSize(new Dimension(300, 30));
            // add(comboPuertas);

        } else if (estadoVuelo.equalsIgnoreCase("Esperando despegue")) {
            // Solo autorización para despegar
            JLabel labelInfo = new JLabel("Esperando autorización para despegar...");
            labelInfo.setFont(new Font("Arial", Font.PLAIN, 16));
            labelInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
            add(labelInfo);

        } else if (estadoVuelo.equalsIgnoreCase("Esperando pista")) {
            // Solo pista (sin puerta)
            add(crearEtiqueta("Asignar Pista:"));
            comboPistas = new JComboBox<>(pistasDisponibles.toArray(new String[0]));
            comboPistas.setMaximumSize(new Dimension(300, 30));
            add(comboPistas);
        }

        add(Box.createVerticalStrut(30));

        // Botón acción final (Asignar o Autorizar)
        botonAccion = new JButton("Asignar");
        botonAccion.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAccion.addActionListener(listenerAccion);
        add(botonAccion);
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public void setControlador(ActionListener c) {
        botonAccion.addActionListener(c);
    }

    // Métodos GET para que el controlador pueda acceder a los valores seleccionados
    public String getPistaSeleccionada() {
        return comboPistas != null ? (String) comboPistas.getSelectedItem() : null;
    }

    // public String getPuertaSeleccionada() {
    //     return comboPuertas != null ? (String) comboPuertas.getSelectedItem() : null;
    // }
}
