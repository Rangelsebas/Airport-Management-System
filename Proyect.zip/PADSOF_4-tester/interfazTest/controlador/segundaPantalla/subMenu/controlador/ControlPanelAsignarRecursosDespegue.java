package interfazTest.controlador.segundaPantalla.subMenu.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import interfazTest.componentes.PantallaBase;
import interfazTest.controlador.segundaPantalla.subMenu.vista.PanelAsignarRecursosDespegue;
import interfazTest.controlador.segundaPantalla.vista.PanelControlarDespegues;

public class ControlPanelAsignarRecursosDespegue implements ActionListener {

    private PanelAsignarRecursosDespegue vista;
    private PantallaBase pantallaBase;
    private String estadoVuelo;
    private PanelControlarDespegues panelAnterior;

    //TODO: Con la logica de negocio, le pasariamos un Vuelo vuelo al constructor, en vez de: String estadoVuelo
    public ControlPanelAsignarRecursosDespegue(PanelAsignarRecursosDespegue vista, PantallaBase pantallaBase, String estadoVuelo, PanelControlarDespegues panelAnterior) {
        this.vista = vista;
        this.pantallaBase = pantallaBase;
        this.estadoVuelo = estadoVuelo;
        this.panelAnterior = panelAnterior;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        procesarAsignacion();
    }

    private void procesarAsignacion() {
        String pistaSeleccionada = vista.getPistaSeleccionada();

        if (estadoVuelo.equalsIgnoreCase("Esperando pista para despegue")) {
            if (pistaSeleccionada == null) {
                JOptionPane.showMessageDialog(vista, "Debes seleccionar una pista para despegue.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JOptionPane.showMessageDialog(vista, "Pista asignada correctamente para despegue:\nPista: " + pistaSeleccionada, "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } else if (estadoVuelo.equalsIgnoreCase("Esperando despegue")) {
            JOptionPane.showMessageDialog(vista, "Despegue autorizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } else if (estadoVuelo.equalsIgnoreCase("Esperando pista")) {
            if (pistaSeleccionada == null) {
                JOptionPane.showMessageDialog(vista, "Debes seleccionar una pista para despegue.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JOptionPane.showMessageDialog(vista, "Pista asignada para despegue: " + pistaSeleccionada, "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(vista, "Estado de vuelo desconocido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Volver correctamente al panel de vuelos
        pantallaBase.mostrarContenidoEnPanelCentral(panelAnterior);
    }
}