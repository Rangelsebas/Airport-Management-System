package interfazTest.controlador.segundaPantalla.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.controlador.segundaPantalla.subMenu.controlador.ControlPanelAsignarRecursosDespegue;
import interfazTest.controlador.segundaPantalla.subMenu.vista.PanelAsignarRecursosDespegue;
import interfazTest.controlador.segundaPantalla.vista.PanelControlarDespegues;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ControlPanelControlarDespegues implements ActionListener {

    private PanelControlarDespegues vista;
    private PantallaBase pantalla;
    private Map<JButton, VueloInfo> vuelosMapeados = new HashMap<>();

    public ControlPanelControlarDespegues(PanelControlarDespegues vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        
        cargarVuelosDePrueba();
    }

    private void cargarVuelosDePrueba() {
        agregarVuelo("Esperando pista para despegue", "Delta Airlines", "DL123", "28/04/2025");
        agregarVuelo("Esperando despegue", "American Airlines", "AA456", "28/04/2025");
        agregarVuelo("Esperando pista", "United Airlines", "UA789", "28/04/2025");
    }

    private void agregarVuelo(String estado, String aerolinea, String codigo, String fecha) {
        JButton botonSeleccionar = vista.agregarVuelo(estado, aerolinea, codigo, fecha, this);
        vuelosMapeados.put(botonSeleccionar, new VueloInfo(estado, aerolinea, codigo, fecha));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton boton = (JButton) e.getSource();
        VueloInfo info = vuelosMapeados.get(boton);

        if (info != null) {
            abrirAsignacionRecursos(info);
        }
    }

    private void abrirAsignacionRecursos(VueloInfo vueloInfo) {
        List<String> pistasMock = List.of("Pista 4", "Pista 5", "Pista 6");
        List<String> puertasMock = List.of("Puerta D", "Puerta E", "Puerta F");

        PanelAsignarRecursosDespegue panelAsignar = new PanelAsignarRecursosDespegue(
            vueloInfo.estado,
            vueloInfo.aerolinea,
            vueloInfo.codigo,
            vueloInfo.fecha,
            pistasMock,
            puertasMock,
            null // el controlador lo añade
        );

        new ControlPanelAsignarRecursosDespegue(panelAsignar, pantalla, vueloInfo.estado, vista);
        pantalla.mostrarContenidoEnPanelCentral(panelAsignar);
    }

    private static class VueloInfo {
        String estado;
        String aerolinea;
        String codigo;
        String fecha;

        VueloInfo(String estado, String aerolinea, String codigo, String fecha) {
            this.estado = estado;
            this.aerolinea = aerolinea;
            this.codigo = codigo;
            this.fecha = fecha;
        }
    }
}

//TODO: Con la logica de negocio, quedaria así:
// public class ControlPanelControlarDespegues implements ActionListener {

//     private PanelControlarDespegues vista;
//     private PantallaBase pantalla;
//     private Map<JButton, Vuelo> vuelosMapeados = new HashMap<>(); // Mapeo: botón -> vuelo

//     public ControlPanelControlarDespegues(PanelControlarDespegues vista, PantallaBase pantalla) {
//         this.vista = vista;
//         this.pantalla = pantalla;

//         cargarVuelosDePrueba();
//     }

//     private void cargarVuelosDePrueba() {
//         // 🔥 Simulación de vuelos esperando despegue
//         Aerolinea aerolinea1 = new Aerolinea("Iberia");
//         Vuelo vuelo1 = new Vuelo("VH1001", aerolinea1, EstadoVuelo.ESPERANDO_PISTA_DESPEGUE, "28/04/2025");

//         Aerolinea aerolinea2 = new Aerolinea("Vueling");
//         Vuelo vuelo2 = new Vuelo("VH1002", aerolinea2, EstadoVuelo.ESPERANDO_PISTA_DESPEGUE, "28/04/2025");

//         Aerolinea aerolinea3 = new Aerolinea("Air France");
//         Vuelo vuelo3 = new Vuelo("VH1003", aerolinea3, EstadoVuelo.ESPERANDO_PISTA_DESPEGUE, "28/04/2025");

//         agregarVuelo(vuelo1);
//         agregarVuelo(vuelo2);
//         agregarVuelo(vuelo3);
//     }

//     private void agregarVuelo(Vuelo vuelo) {
//         String estadoVisual = traducirEstado(vuelo.getEstadoVuelo());

//         JButton botonSeleccionar = vista.agregarVuelo(
//             estadoVisual,
//             vuelo.getAerolinea().getNombreAerolinea(),
//             vuelo.getCodigoVuelo(),
//             vuelo.getFechaVuelo(),
//             this
//         );

//         vuelosMapeados.put(botonSeleccionar, vuelo);
//     }

//     private String traducirEstado(EstadoVuelo estado) {
//         return switch (estado) {
//             case ESPERANDO_PISTA_DESPEGUE -> "Esperando pista para despegue";
//             default -> "Estado desconocido";
//         };
//     }

//     @Override
//     public void actionPerformed(ActionEvent e) {
//         JButton boton = (JButton) e.getSource();
//         Vuelo vueloSeleccionado = vuelosMapeados.get(boton);

//         if (vueloSeleccionado != null) {
//             abrirAsignarRecursos(vueloSeleccionado);
//         }
//     }

//     private void abrirAsignarRecursos(Vuelo vuelo) {
//         List<String> pistasMock = List.of("Pista 1", "Pista 2", "Pista 3");

//         // NOTA: Lista de puertas vacía ya que en despegue no se asigna puerta
//         List<String> puertasMock = List.of(); 

//         PanelAsignarRecursosVuelo panelAsignar = new PanelAsignarRecursosVuelo(
//             vuelo.getEstadoVuelo(),
//             vuelo.getAerolinea().getNombreAerolinea(),
//             vuelo.getCodigoVuelo(),
//             vuelo.getFechaVuelo(),
//             pistasMock,
//             puertasMock
//         );

//         new ControlPanelAsignarRecursosVuelo(panelAsignar, pantalla, vuelo);

//         pantalla.mostrarContenidoEnPanelCentral(panelAsignar);
//     }
// }
