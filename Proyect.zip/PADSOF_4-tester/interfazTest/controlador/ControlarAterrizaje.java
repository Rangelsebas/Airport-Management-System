package interfazTest.controlador;

import java.awt.*;
import java.util.List;
import javax.swing.*;

public class ControlarAterrizaje extends JPanel {
    public ControlarAterrizaje() {
        // Configuración básica del panel
        setLayout(new BorderLayout());
        
        // Etiqueta principal
        JLabel etiqueta = new JLabel("Panel de Control de Aterrizaje", SwingConstants.CENTER);
        add(etiqueta, BorderLayout.NORTH);
        
        // Botones de control
        List<JButton> botones = List.of(
            new JButton("Controlar Aterrizajes"),
            new JButton("Controlar Despegues"),
            new JButton("Controlar el Estado de un Vuelo"),
            new JButton("Ver Cola")
        );
        
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(botones.size(), 1));
        
        for (JButton boton : botones) {
            panelBotones.add(boton);
        }

        add(panelBotones, BorderLayout.CENTER);
    }
}
