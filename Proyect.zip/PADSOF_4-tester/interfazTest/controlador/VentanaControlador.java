/* javac -d bin src/interfaz/controlador/VentanaControlador.java src/interfaz/componentes/PantallaBase.java  src/interfaz/controlador/ControlarAterrizaje.java 
 * java -cp bin interfazTest.controlador.VentanaControlador
 * 
 */

package interfazTest.controlador;

import interfazTest.componentes.PantallaBase;
import java.util.List;
import javax.swing.*;

public class VentanaControlador extends JFrame {
    public VentanaControlador() {
        setTitle("Sistema Aeropuerto - Controlador");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Botones del menú lateral
        List<JButton> botones = List.of(
            new JButton("Controlar Aterrizajes"),
            new JButton("Controlar Despegues"),
            new JButton("Controlar el Estado de un Vuelo"),
            new JButton("Ver Cola")
        );

        // Notificaciones iniciales
        List<String> notificaciones = List.of(
            "Vuelo #2452: Retrasado. Estado: En preparación.",
            "Vuelo #45323: En hora. Estado: Esperando pista."
        );

        PantallaBase pantalla = new PantallaBase("Controlador Aereo", botones, notificaciones);

        // Aquí puedes añadir listeners a los botones
        botones.get(0).addActionListener(e -> {
            // Obtén el panel central de la pantalla
            JPanel panelCentral = pantalla.getPanelCentral();
            // Limpia el contenido actual
            panelCentral.removeAll();
            // Agrega la nueva instancia de ControlarAterrizaje
            panelCentral.add(new ControlarAterrizaje());
            // Actualiza la interfaz
            panelCentral.revalidate();
            panelCentral.repaint();
        });
        botones.get(1).addActionListener(e -> System.out.println("Ir a Propor Vuelos"));
        botones.get(2).addActionListener(e -> System.out.println("Ir a Controlar el Estado de un Vuelo"));
        botones.get(3).addActionListener(e -> System.out.println("Ir a Consultar el Rendimiento de los Vuelos y Facturas"));

        add(pantalla);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VentanaControlador::new);
    }
}
