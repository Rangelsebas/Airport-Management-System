package interfazTest.controlador.enums;

public enum ComandoVentanaControladorEnum {
    CONTROLAR_ATERRIZAJES,
    CONTROLAR_DESPEGUES,
    CONTROLAR_ESTADO_VUELO,
    VER_COLA,
    CERRAR_SESION
}