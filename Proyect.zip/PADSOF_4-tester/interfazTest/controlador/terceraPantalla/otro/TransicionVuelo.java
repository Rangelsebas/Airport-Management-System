package interfazTest.controlador.terceraPantalla.otro;

/*
 * Esta clase representará una acción disponible para un vuelo en un estado específico
 * TODO: pensar si esta clase debe ser parte de la lógica de negocio o de la interfazTest. ¿Asi?
 * src/
    └── dominio/          ← lógica de negocio
        └── transiciones/
            ├── GestorTransicionesVuelo.java  
            └── TransicionVuelo.java
 */
public class TransicionVuelo {
    private final String nombreVisual;
    private final String actionCommand;

    public TransicionVuelo(String nombreVisual, String actionCommand) {
        this.nombreVisual = nombreVisual;
        this.actionCommand = actionCommand;
    }

    public String getNombreVisual() {
        return nombreVisual;
    }

    public String getActionCommand() {
        return actionCommand;
    }
}
