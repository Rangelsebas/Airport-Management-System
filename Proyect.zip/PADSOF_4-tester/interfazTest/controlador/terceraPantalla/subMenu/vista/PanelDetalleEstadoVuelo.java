package interfazTest.controlador.terceraPantalla.subMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfazTest.controlador.terceraPantalla.otro.TransicionVuelo;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelDetalleEstadoVuelo extends JPanel {

    private JLabel labelEstado;
    private JLabel labelAerolinea;
    private JLabel labelCodigo;
    private JLabel labelFecha;

    public JButton botonPasarHangar;
    public JButton botonDejarOperativo;
    public JButton botonCancelar;

    public PanelDetalleEstadoVuelo(String estadoVuelo, String aerolinea, String codigo, String fecha) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50));
    
        // Info del vuelo
        labelEstado = crearEtiqueta(estadoVuelo);
        labelAerolinea = crearEtiqueta("Aerolínea: " + aerolinea);
        labelCodigo = crearEtiqueta("Código: " + codigo);
        labelFecha = crearEtiqueta("Fecha: " + fecha);
    
        add(labelEstado);
        add(labelAerolinea);
        add(labelCodigo);
        add(labelFecha);
    
        add(Box.createVerticalStrut(30));
    
        // Botones (sin listener todavía)
        botonPasarHangar = crearBotonMenu("Pasar al Hangar", "PASAR_HANGAR");
        add(botonPasarHangar);
    
        add(Box.createVerticalStrut(10));
    
        botonDejarOperativo = crearBotonMenu("Dejar Operativo", "DEJAR_OPERATIVO");
        add(botonDejarOperativo);
    
        add(Box.createVerticalStrut(20));
    
        botonCancelar = crearBotonMenu("Cancelar", "CANCELAR");
        add(botonCancelar);

         // TODO: Faltan más botones que se agregarán dependiendo de los estados.

    }
   
    public void setControlador(ActionListener c) {
        botonPasarHangar.addActionListener(c);
        botonDejarOperativo.addActionListener(c);
        botonCancelar.addActionListener(c);
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private JButton crearBotonMenu(String texto, String comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando);
        boton.setHorizontalAlignment(SwingConstants.CENTER);
        boton.setFocusPainted(false);
        boton.setMaximumSize(new Dimension(200, 40));
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        return boton;
    }

    //TODO: Con la logica de negocio, quedaria algo asi:
    // public void agregarBotonesDinamicos(List<TransicionVuelo> acciones, ActionListener listener) {
    //     for (TransicionVuelo accion : acciones) {
    //         JButton boton = new JButton(accion.getNombreVisual());
    //         boton.setActionCommand(accion.getActionCommand());
    //         boton.addActionListener(listener);
    //         boton.setAlignmentX(Component.CENTER_ALIGNMENT);
    //         boton.setMaximumSize(new Dimension(200, 40));
    //         add(Box.createVerticalStrut(10));
    //         add(boton);
    //     }
    //     revalidate();
    //     repaint();
    // }

    // Métodos para ocultar botones dinámicamente si en algún estado no corresponde mostrarlos
    public void ocultarBotonPasarHangar() {
        botonPasarHangar.setVisible(false);
    }

    public void ocultarBotonDejarOperativo() {
        botonDejarOperativo.setVisible(false);
    }
}
