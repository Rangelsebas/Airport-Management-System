package interfazTest.controlador.terceraPantalla.subMenu.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.controlador.terceraPantalla.subMenu.vista.PanelDetalleEstadoVuelo;
import interfazTest.controlador.terceraPantalla.vista.PanelControlarEstadoVuelo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelDetalleEstadoVuelo implements ActionListener {

    private PanelDetalleEstadoVuelo vista;
    private PantallaBase pantallaBase;
    private String estadoVuelo;
    private PanelControlarEstadoVuelo panelAnterior; 

    public ControlPanelDetalleEstadoVuelo(PanelDetalleEstadoVuelo vista, PantallaBase pantallaBase, String estadoVuelo, PanelControlarEstadoVuelo panelAnterior) {
        this.vista = vista;
        this.pantallaBase = pantallaBase;
        this.estadoVuelo = estadoVuelo;
        this.panelAnterior = panelAnterior;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();

        switch (comando) {
            case "PASAR_HANGAR" -> procesarPasarHangar();
            case "DEJAR_OPERATIVO" -> procesarDejarOperativo();
            case "CANCELAR" -> pantallaBase.mostrarContenidoEnPanelCentral(panelAnterior);
            default -> JOptionPane.showMessageDialog(vista, "Acción desconocida.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //TODO: Con la logica de negocio, quedaria algo asi:
    // @Override
    // public void actionPerformed(ActionEvent e) {
    //     switch (e.getActionCommand()) {
    //         case "PASAR_HANGAR" -> vuelo.guardarAvionEnHangar(...);
    //         case "DEJAR_OPERATIVO" -> vuelo.mantenerAvionOperativo();
    //         case "SACAR_HANGAR" -> vuelo.sacarAvionHangar();
    //         case "PASAR_PREPARACION" -> vuelo.pasarAPreparacionCambioEstado();
    //         case "INICIAR_EMBARQUE" -> vuelo.iniciarEmbarqueCambioEstado(...);
    //         case "INICIAR_CARGA" -> vuelo.iniciarCargaCambioEstado();
    //         case "FINALIZAR_EMBARQUE" -> vuelo.embarqueFinalizadoCambioEstado();
    //         case "CANCELAR" -> pantallaBase.mostrarContenidoEnPanelCentral(panelAnterior);
    //         default -> JOptionPane.showMessageDialog(vista, "Acción desconocida.", "Error", JOptionPane.ERROR_MESSAGE);
    //     }

    //     pantallaBase.mostrarContenidoEnPanelCentral(panelAnterior);
    // }

    private void procesarPasarHangar() {
        JOptionPane.showMessageDialog(vista, "Avión enviado al hangar.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        pantallaBase.mostrarContenidoEnPanelCentral(panelAnterior);
    }

    private void procesarDejarOperativo() {
        JOptionPane.showMessageDialog(vista, "Avión dejado operativo.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        pantallaBase.mostrarContenidoEnPanelCentral(panelAnterior);
    }
}
