package interfazTest.controlador.terceraPantalla.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.controlador.terceraPantalla.subMenu.controlador.ControlPanelDetalleEstadoVuelo;
import interfazTest.controlador.terceraPantalla.subMenu.vista.PanelDetalleEstadoVuelo;
import interfazTest.controlador.terceraPantalla.vista.PanelControlarEstadoVuelo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class ControlPanelControlarEstadoVuelo implements ActionListener {

    private PanelControlarEstadoVuelo vista;
    private PantallaBase pantallaBase;
    private Map<JButton, VueloInfoMock> vuelosMapeados = new HashMap<>();

    public ControlPanelControlarEstadoVuelo(PanelControlarEstadoVuelo vista, PantallaBase pantallaBase) {
        this.vista = vista;
        this.pantallaBase = pantallaBase;

        cargarVuelosMock();
    }

    private void cargarVuelosMock() {
        agregarVueloMock("Vuelo terminado", "LATAM", "LA001", "28/04/2025");
        agregarVueloMock("Vuelo empieza pronto", "Avianca", "AV002", "28/04/2025");
        agregarVueloMock("Vuelo en espera", "Iberia", "IB003", "28/04/2025");
        agregarVueloMock("Vuelo en despegue", "Air France", "AF004", "28/04/2025");
    }

    private void agregarVueloMock(String estado, String aerolinea, String codigo, String fecha) {
        JButton botonSeleccionar = vista.agregarVuelo(estado, aerolinea, codigo, fecha, this);
        vuelosMapeados.put(botonSeleccionar, new VueloInfoMock(estado, aerolinea, codigo, fecha));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton boton = (JButton) e.getSource();
        VueloInfoMock vuelo = vuelosMapeados.get(boton);

        if (vuelo != null) {
            abrirSubmenu(vuelo);
        }
    }

    private void abrirSubmenu(VueloInfoMock vuelo) {
        PanelDetalleEstadoVuelo panelDetalle = new PanelDetalleEstadoVuelo(
            vuelo.estado,
            vuelo.aerolinea,
            vuelo.codigo,
            vuelo.fecha
        );
    
        new ControlPanelDetalleEstadoVuelo(panelDetalle, pantallaBase, vuelo.estado, vista);
    
        pantallaBase.mostrarContenidoEnPanelCentral(panelDetalle);
    }

    //TODO: Con la logica de negocio, quedaria algo asi:
    // private void abrirSubmenu(Vuelo vuelo) {
    //     // 1. Crear panel
    //     PanelDetalleEstadoVuelo panelDetalle = new PanelDetalleEstadoVuelo(
    //         vuelo.getEstado().toString(),
    //         vuelo.getAerolineaOperadora().getNombre(),
    //         vuelo.getCodigoVuelo(),
    //         vuelo.getFecha().toString()
    //     );

    //     // 2. Crear controlador del submenú
    //     ControlPanelDetalleEstadoVuelo controladorDetalle = new ControlPanelDetalleEstadoVuelo(panelDetalle, pantallaBase, vuelo, vista);

    //     // 3. Obtener transiciones disponibles desde la lógica de negocio
    //     List<TransicionVuelo> acciones = GestorTransicionesVuelo.obtenerTransicionesDisponibles(vuelo);

    //     // 4. Cargar botones dinámicos al panel con el listener del submenú
    //     panelDetalle.agregarBotonesDinamicos(acciones, controladorDetalle);

    //     // 5. Mostrar panel
    //     pantallaBase.mostrarContenidoEnPanelCentral(panelDetalle);
    // }

    // Clase interna mock para la info de vuelo
    private static class VueloInfoMock {
        String estado;
        String aerolinea;
        String codigo;
        String fecha;

        VueloInfoMock(String estado, String aerolinea, String codigo, String fecha) {
            this.estado = estado;
            this.aerolinea = aerolinea;
            this.codigo = codigo;
            this.fecha = fecha;
        }
    }
}

//TODO: Con la logica de negocio, quedaria algo asi:
// public class ControlPanelControlarEstadoVuelo implements ActionListener {

//     private PanelControlarEstadoVuelo vista;
//     private PantallaBase pantallaBase;
//     private Map<JButton, Vuelo> vuelosMapeados = new HashMap<>();

//     public ControlPanelControlarEstadoVuelo(PanelControlarEstadoVuelo vista, PantallaBase pantallaBase) {
//         this.vista = vista;
//         this.pantallaBase = pantallaBase;

//         cargarVuelosDePrueba(); // TODO: aquí deberías conectar tu servicio real luego
//     }

//     private void cargarVuelosDePrueba() {
//         // 🔥 Mock temporal: en real conectarías vuelos vivos
//         Vuelo vuelo1 = crearMockVuelo("Vuelo terminado", "LATAM", "LA001", "28/04/2025");
//         Vuelo vuelo2 = crearMockVuelo("Vuelo empieza pronto", "Avianca", "AV002", "28/04/2025");

//         agregarVuelo(vuelo1);
//         agregarVuelo(vuelo2);
//     }

//     private Vuelo crearMockVuelo(String estadoDescripcion, String aerolinea, String codigo, String fecha) {
//         // Aquí puedes crear instancias de Vuelo reales o mockearlas.
//         return null; // TODO: Mock temporal
//     }

//     private void agregarVuelo(Vuelo vuelo) {
//         JButton botonSeleccionar = vista.agregarVuelo(
//             traducirEstado(vuelo.getEstado()),
//             vuelo.getAerolineaOperadora().getNombre(),
//             vuelo.getCodigoVuelo(),
//             vuelo.getFecha().toString(),
//             this
//         );

//         vuelosMapeados.put(botonSeleccionar, vuelo);
//     }

//     @Override
//     public void actionPerformed(ActionEvent e) {
//         JButton boton = (JButton) e.getSource();
//         Vuelo vueloSeleccionado = vuelosMapeados.get(boton);

//         if (vueloSeleccionado != null) {
//             abrirSubmenuEstadoVuelo(vueloSeleccionado);
//         }
//     }

//     private void abrirSubmenuEstadoVuelo(Vuelo vuelo) {
//         EstadosVuelo estadoActual = vuelo.getEstado();

//         JPanel panelOpciones = new JPanel();
//         panelOpciones.setLayout(new BoxLayout(panelOpciones, BoxLayout.Y_AXIS));

//         JLabel titulo = new JLabel("Acciones disponibles para el vuelo " + vuelo.getCodigoVuelo());
//         titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
//         panelOpciones.add(titulo);

//         switch (estadoActual) {
//             case OPERATIVO -> {
//                 JButton btnHangar = new JButton("Pasar a Hangar");
//                 btnHangar.addActionListener(a -> {
//                     // TODO: Seleccionar hangar antes de ejecutar
//                     boolean cambio = vuelo.guardarAvionEnHangar(null);
//                     confirmarCambio(cambio, "Avión enviado a hangar.");
//                 });
//                 panelOpciones.add(btnHangar);

//                 JButton btnOperativo = new JButton("Dejar Operativo");
//                 btnOperativo.addActionListener(a -> {
//                     boolean cambio = vuelo.mantenerAvionOperativo();
//                     confirmarCambio(cambio, "Avión dejado operativo.");
//                 });
//                 panelOpciones.add(btnOperativo);
//             }
//             case EN_HANGAR -> {
//                 JButton btnSacarHangar = new JButton("Sacar de Hangar");
//                 btnSacarHangar.addActionListener(a -> {
//                     boolean cambio = vuelo.sacarAvionHangar();
//                     confirmarCambio(cambio, "Avión sacado del hangar.");
//                 });
//                 panelOpciones.add(btnSacarHangar);
//             }
//             case EN_APARCAMIENTO -> {
//                 JButton btnPreparar = new JButton("Pasar a Preparación");
//                 btnPreparar.addActionListener(a -> {
//                     boolean cambio = vuelo.pasarAPreparacionCambioEstado();
//                     confirmarCambio(cambio, "Vuelo pasado a preparación.");
//                 });
//                 panelOpciones.add(btnPreparar);
//             }
//             case EN_PREPARACION -> {
//                 JButton btnEmbarque = new JButton("Iniciar Embarque / Carga");
//                 btnEmbarque.addActionListener(a -> {
//                     // TODO: Decidir entre iniciar carga o embarque según categoría del avión
//                     boolean cambio = vuelo.iniciarEmbarqueCambioEstado(null); // puerta = null de momento
//                     confirmarCambio(cambio, "Embarque iniciado.");
//                 });
//                 panelOpciones.add(btnEmbarque);
//             }
//             default -> {
//                 JLabel labelInfo = new JLabel("Sin acciones disponibles para este estado.");
//                 labelInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
//                 panelOpciones.add(labelInfo);
//             }
//         }

//         JButton btnCancelar = new JButton("Cancelar");
//         btnCancelar.setAlignmentX(Component.CENTER_ALIGNMENT);
//         btnCancelar.addActionListener(a -> pantallaBase.mostrarContenidoEnPanelCentral(vista));
//         panelOpciones.add(Box.createVerticalStrut(20));
//         panelOpciones.add(btnCancelar);

//         pantallaBase.mostrarContenidoEnPanelCentral(panelOpciones);
//     }

//     private void confirmarCambio(boolean cambioExitoso, String mensaje) {
//         if (cambioExitoso) {
//             JOptionPane.showMessageDialog(vista, "✅ " + mensaje, "Éxito", JOptionPane.INFORMATION_MESSAGE);
//         } else {
//             JOptionPane.showMessageDialog(vista, "⚠️ No se pudo realizar la acción.", "Error", JOptionPane.ERROR_MESSAGE);
//         }
//         pantallaBase.mostrarContenidoEnPanelCentral(vista);
//     }

//     private String traducirEstado(EstadosVuelo estado) {
//         return switch (estado) {
//             case FINALIZADO -> "Vuelo terminado";
//             case APROBADO, PENDIENTE, MODIFICADO, EN_PREPARACION -> "Vuelo empieza pronto";
//             default -> "Otro estado";
//         };
//     }
// }
