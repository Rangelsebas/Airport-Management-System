package interfazTest.controlador.cuartaPantalla.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelVerCola extends JPanel {

    private JPanel panelListado;

    public PanelVerCola() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Cola de Vuelos para Despegue", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(500, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);
    }

    public JButton agregarVuelo(String numeroCola, String aerolinea, String codigo, String hora, String pista, ActionListener listener) {
        JPanel panelVuelo = new JPanel();
        panelVuelo.setLayout(new BoxLayout(panelVuelo, BoxLayout.Y_AXIS));
        panelVuelo.setBackground(Color.WHITE);
        panelVuelo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
            new EmptyBorder(10, 10, 10, 10)
        ));

        JLabel labelNumero = new JLabel("Vuelo esperando despegue #" + numeroCola);
        labelNumero.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel labelAerolinea = new JLabel("Aerolínea: " + aerolinea);
        JLabel labelCodigo = new JLabel("Código: " + codigo);
        JLabel labelHora = new JLabel("Hora: " + hora);
        JLabel labelPista = new JLabel("Pista: " + pista);

        JButton botonSeleccionar = new JButton("Seleccionar");
        botonSeleccionar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonSeleccionar.setFocusPainted(false);
        botonSeleccionar.addActionListener(listener);

        panelVuelo.add(labelNumero);
        panelVuelo.add(labelAerolinea);
        panelVuelo.add(labelCodigo);
        panelVuelo.add(labelHora);
        panelVuelo.add(labelPista);
        panelVuelo.add(Box.createVerticalStrut(10));
        panelVuelo.add(botonSeleccionar);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelVuelo);
        panelListado.revalidate();
        panelListado.repaint();

        return botonSeleccionar;
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }
}