package interfazTest.controlador.cuartaPantalla.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.controlador.cuartaPantalla.vista.PanelVerCola;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class ControlPanelVerCola implements ActionListener {

    private PanelVerCola vista;
    private PantallaBase pantallaBase;
    private Map<JButton, VueloColaInfo> vuelosMapeados = new HashMap<>();

    public ControlPanelVerCola(PanelVerCola vista, PantallaBase pantallaBase) {
        this.vista = vista;
        this.pantallaBase = pantallaBase;

        cargarVuelosMock();
    }

    private void cargarVuelosMock() {
        agregarVueloMock("1", "LATAM", "LA001", "10:30", "Pista 1");
        agregarVueloMock("2", "Delta Airlines", "DL456", "10:45", "Pista 1");
        agregarVueloMock("1", "American Airlines", "AA789", "10:35", "Pista 2");
        agregarVueloMock("2", "United Airlines", "UA101", "10:50", "Pista 2");
        agregarVueloMock("1", "Iberia", "IB202", "10:40", "Pista 3");
    }

    private void agregarVueloMock(String numeroCola, String aerolinea, String codigo, String hora, String pista) {
        JButton botonSeleccionar = vista.agregarVuelo(numeroCola, aerolinea, codigo, hora, pista, this);
        vuelosMapeados.put(botonSeleccionar, new VueloColaInfo(numeroCola, aerolinea, codigo, hora, pista));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton boton = (JButton) e.getSource();
        VueloColaInfo vuelo = vuelosMapeados.get(boton);

        if (vuelo != null) {
            abrirDetallesMock(vuelo);
        }
    }

    private void abrirDetallesMock(VueloColaInfo vuelo) {
        JOptionPane.showMessageDialog(
            vista,
            "Detalles del Vuelo:\n" +
            "Aerolínea: " + vuelo.aerolinea + "\n" +
            "Código: " + vuelo.codigo + "\n" +
            "Hora: " + vuelo.hora + "\n" +
            "Pista: " + vuelo.pista,
            "Detalle de Vuelo",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    // Clase interna mock para guardar info de vuelos
    private static class VueloColaInfo {
        String numeroCola;
        String aerolinea;
        String codigo;
        String hora;
        String pista;

        VueloColaInfo(String numeroCola, String aerolinea, String codigo, String hora, String pista) {
            this.numeroCola = numeroCola;
            this.aerolinea = aerolinea;
            this.codigo = codigo;
            this.hora = hora;
            this.pista = pista;
        }
    }
}
