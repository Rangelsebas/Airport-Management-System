package interfazTest.controlador.primeraPantalla.subMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class PanelAsignarRecursosAterrizaje extends JPanel {

    private JLabel labelEstado;
    private JLabel labelAerolinea;
    private JLabel labelCodigo;
    private JLabel labelFecha;

    private JComboBox<String> comboPistas;
    private JComboBox<String> comboPuertas;
    private JButton botonAccion;

    public PanelAsignarRecursosAterrizaje(String estadoVuelo, String aerolinea, String codigo, String fecha,
                                     List<String> pistasDisponibles, List<String> puertasDisponibles,
                                     ActionListener listenerAccion) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50));

        // Info del vuelo
        labelEstado = crearEtiqueta(estadoVuelo);
        labelAerolinea = crearEtiqueta("Aerolínea: " + aerolinea);
        labelCodigo = crearEtiqueta("Código: " + codigo);
        labelFecha = crearEtiqueta("Fecha: " + fecha);

        add(labelEstado);
        add(labelAerolinea);
        add(labelCodigo);
        add(labelFecha);

        add(Box.createVerticalStrut(30));

        // Según el estado, mostrar recursos a asignar
        if (estadoVuelo.equalsIgnoreCase("Esperando pista de aterrizaje")) {
            // Mostrar Pistas
            add(crearEtiqueta("Asignar Pista:"));
            comboPistas = new JComboBox<>(pistasDisponibles.toArray(new String[0]));
            comboPistas.setMaximumSize(new Dimension(300, 30));
            add(comboPistas);

            add(Box.createVerticalStrut(20));

            // Mostrar Puertas
            add(crearEtiqueta("Asignar Puerta:"));
            comboPuertas = new JComboBox<>(puertasDisponibles.toArray(new String[0]));
            comboPuertas.setMaximumSize(new Dimension(300, 30));
            add(comboPuertas);

        } else if (estadoVuelo.equalsIgnoreCase("Esperando aterrizaje")) {
            // Solo autorización para aterrizar
            JLabel labelInfo = new JLabel("Esperando autorización para aterrizar...");
            labelInfo.setFont(new Font("Arial", Font.PLAIN, 16));
            labelInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
            add(labelInfo);

        } else if (estadoVuelo.equalsIgnoreCase("Esperando pista")) {
            // Sólo pista para despegue
            add(crearEtiqueta("Asignar Pista:"));
            comboPistas = new JComboBox<>(pistasDisponibles.toArray(new String[0]));
            comboPistas.setMaximumSize(new Dimension(300, 30));
            add(comboPistas);
        }

        add(Box.createVerticalStrut(30));

        // Botón acción final (Asignar o Autorizar)
        botonAccion = new JButton("Asignar");
        botonAccion.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAccion.addActionListener(listenerAccion);
        add(botonAccion);
    }

    public void setControlador(ActionListener c) {
        botonAccion.addActionListener(c);
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    // Métodos GET para que el controlador pueda acceder a los combos seleccionados
    public String getPistaSeleccionada() {
        return comboPistas != null ? (String) comboPistas.getSelectedItem() : null;
    }

    public String getPuertaSeleccionada() {
        return comboPuertas != null ? (String) comboPuertas.getSelectedItem() : null;
    }
}


//TODO: Con al logica de negocio, quedaria así:

// public class PanelAsignarRecursosVuelo extends JPanel {

//     private JLabel labelEstado;
//     private JLabel labelAerolinea;
//     private JLabel labelCodigo;
//     private JLabel labelFecha;

//     private JComboBox<String> comboPistas;
//     private JComboBox<String> comboPuertas;
//     private JButton botonAccion;

//     private EstadoVuelo estadoVuelo; // Guardamos el estado recibido

//     public PanelAsignarRecursosVuelo(EstadoVuelo estadoVuelo, String aerolinea, String codigo, String fecha,
//                                      List<String> pistasDisponibles, List<String> puertasDisponibles) {
//         this.estadoVuelo = estadoVuelo;

//         setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
//         setBackground(Color.WHITE);
//         setBorder(new EmptyBorder(20, 50, 20, 50));

//         // Info del vuelo
//         labelEstado = crearEtiqueta("Estado: " + traducirEstado(estadoVuelo));
//         labelAerolinea = crearEtiqueta("Aerolínea: " + aerolinea);
//         labelCodigo = crearEtiqueta("Código: " + codigo);
//         labelFecha = crearEtiqueta("Fecha: " + fecha);

//         add(labelEstado);
//         add(labelAerolinea);
//         add(labelCodigo);
//         add(labelFecha);

//         add(Box.createVerticalStrut(30));

//         // Según el estado, mostrar recursos a asignar
//         if (estadoVuelo == EstadoVuelo.ESPERANDO_PISTA_ATERRIZAJE) {
//             add(crearEtiqueta("Asignar Pista:"));
//             comboPistas = new JComboBox<>(pistasDisponibles.toArray(new String[0]));
//             comboPistas.setMaximumSize(new Dimension(300, 30));
//             add(comboPistas);

//             add(Box.createVerticalStrut(20));

//             add(crearEtiqueta("Asignar Puerta:"));
//             comboPuertas = new JComboBox<>(puertasDisponibles.toArray(new String[0]));
//             comboPuertas.setMaximumSize(new Dimension(300, 30));
//             add(comboPuertas);

//         } else if (estadoVuelo == EstadoVuelo.ESPERANDO_ATERRIZAJE) {
//             JLabel labelInfo = new JLabel("Esperando autorización para aterrizar...");
//             labelInfo.setFont(new Font("Arial", Font.PLAIN, 16));
//             labelInfo.setAlignmentX(Component.CENTER_ALIGNMENT);
//             add(labelInfo);

//         } else if (estadoVuelo == EstadoVuelo.ESPERANDO_PISTA_DESPEGUE) {
//             add(crearEtiqueta("Asignar Pista:"));
//             comboPistas = new JComboBox<>(pistasDisponibles.toArray(new String[0]));
//             comboPistas.setMaximumSize(new Dimension(300, 30));
//             add(comboPistas);
//         }

//         add(Box.createVerticalStrut(30));

//         // Botón de acción
//         botonAccion = new JButton("Asignar");
//         botonAccion.setAlignmentX(Component.CENTER_ALIGNMENT);
//         add(botonAccion);
//     }

//     public void setControlador(ActionListener c) {
//         botonAccion.addActionListener(c);
//     }

//     private JLabel crearEtiqueta(String texto) {
//         JLabel label = new JLabel(texto);
//         label.setFont(new Font("Arial", Font.BOLD, 16));
//         label.setAlignmentX(Component.CENTER_ALIGNMENT);
//         return label;
//     }

//     private String traducirEstado(EstadoVuelo estado) {
//         return switch (estado) {
//             case ESPERANDO_PISTA_ATERRIZAJE -> "Esperando pista de aterrizaje";
//             case ESPERANDO_ATERRIZAJE -> "Esperando aterrizaje";
//             case ESPERANDO_PISTA_DESPEGUE -> "Esperando pista para despegue";
//             default -> "Estado desconocido";
//         };
//     }

//     // Métodos GET para que el controlador pueda acceder a los combos seleccionados
//     public String getPistaSeleccionada() {
//         return comboPistas != null ? (String) comboPistas.getSelectedItem() : null;
//     }

//     public String getPuertaSeleccionada() {
//         return comboPuertas != null ? (String) comboPuertas.getSelectedItem() : null;
//     }

//     public EstadoVuelo getEstadoVuelo() {
//         return estadoVuelo;
//     }
// }
