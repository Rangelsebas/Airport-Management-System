package interfazTest.controlador.primeraPantalla.subMenu.controlador;

import javax.swing.*;

import interfazTest.componentes.PantallaBase;
import interfazTest.controlador.primeraPantalla.subMenu.vista.PanelAsignarRecursosAterrizaje;
import interfazTest.controlador.primeraPantalla.vista.PanelControlarAterrizajes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelAsignarRecursosAterrizaje implements ActionListener {

    private PanelAsignarRecursosAterrizaje vista;
    private PantallaBase pantallaBase;
    private String estadoVuelo;
    private PanelControlarAterrizajes panelAnterior; 

    //TODO: Con la logica de negocio, le pasariamos un Vuelo vuelo al constructor, en vez de: String estadoVuelo
    public ControlPanelAsignarRecursosAterrizaje(PanelAsignarRecursosAterrizaje vista, PantallaBase pantallaBase, String estadoVuelo, PanelControlarAterrizajes panelAnterior) {
        this.vista = vista;
        this.pantallaBase = pantallaBase;
        this.estadoVuelo = estadoVuelo;
        this.panelAnterior = panelAnterior;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        procesarAsignacion();
    }

    private void procesarAsignacion() {
        String pistaSeleccionada = vista.getPistaSeleccionada();
        String puertaSeleccionada = vista.getPuertaSeleccionada();
        //TODO: Aqui despues de añadiran mas elementos del aeropuerto si es necesario. Por ejemplo:
        // Si hay un vuelo de despegue que necesita un hangar, se haria algo como:
        // String hangarSeleccionado = vista.getHangarSeleccionado();

        if (estadoVuelo.equalsIgnoreCase("Esperando pista de aterrizaje")) {
            if (pistaSeleccionada == null || puertaSeleccionada == null) {
                JOptionPane.showMessageDialog(vista, "Debes seleccionar una pista y una puerta.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JOptionPane.showMessageDialog(vista, "✅ Asignación completada:\nPista: " + pistaSeleccionada + "\nPuerta: " + puertaSeleccionada, "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } else if (estadoVuelo.equalsIgnoreCase("Esperando aterrizaje")) {
            JOptionPane.showMessageDialog(vista, "✅ Aterrizaje autorizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } else if (estadoVuelo.equalsIgnoreCase("Esperando pista")) {
            if (pistaSeleccionada == null) {
                JOptionPane.showMessageDialog(vista, "Debes seleccionar una pista para despegar.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JOptionPane.showMessageDialog(vista, "✅ Pista asignada para despegue: " + pistaSeleccionada, "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(vista, "Estado de vuelo desconocido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 🔥 Después de asignar, volver al panel principal de vuelos
        pantallaBase.mostrarContenidoEnPanelCentral(panelAnterior);
    }
}




//TODO: Con la logica de negocio, quedaria así:

// public class ControlPanelAsignarRecursosVuelo implements ActionListener {

//     private PanelAsignarRecursosVuelo vista;
//     private PantallaBase pantallaBase;
//     private Vuelo vuelo; // Vuelo real

//     public ControlPanelAsignarRecursosVuelo(PanelAsignarRecursosVuelo vista, PantallaBase pantallaBase, Vuelo vuelo) {
//         this.vista = vista;
//         this.pantallaBase = pantallaBase;
//         this.vuelo = vuelo;
//         this.vista.setControlador(this);
//     }

//     @Override
//     public void actionPerformed(ActionEvent e) {
//         procesarAsignacion();
//     }

//     private void procesarAsignacion() {
//         String pistaSeleccionada = vista.getPistaSeleccionada();
//         String puertaSeleccionada = vista.getPuertaSeleccionada();

//         EstadoVuelo estadoActual = vuelo.getEstadoVuelo();

//         switch (estadoActual) {
//             case ESPERANDO_PISTA_ATERRIZAJE:
//                 if (pistaSeleccionada == null || puertaSeleccionada == null) {
//                     JOptionPane.showMessageDialog(vista, "Debes seleccionar una pista y una puerta.", "Error", JOptionPane.WARNING_MESSAGE);
//                     return;
//                 }

//                 // Aquí actualizas el vuelo si quieres: vuelo.asignarPista(pistaSeleccionada), vuelo.asignarPuerta(puertaSeleccionada);
//                 JOptionPane.showMessageDialog(vista, "✅ Asignación completada:\nPista: " + pistaSeleccionada + "\nPuerta: " + puertaSeleccionada, "Éxito", JOptionPane.INFORMATION_MESSAGE);

//                 break;

//             case ESPERANDO_ATERRIZAJE:
//                 // Solo autorizar aterrizaje
//                 JOptionPane.showMessageDialog(vista, "✅ Aterrizaje autorizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

//                 // Aquí podrías actualizar su estado a "Aterrizado" o algo similar
//                 break;

//             case ESPERANDO_PISTA_DESPEGUE:
//                 if (pistaSeleccionada == null) {
//                     JOptionPane.showMessageDialog(vista, "Debes seleccionar una pista para despegar.", "Error", JOptionPane.WARNING_MESSAGE);
//                     return;
//                 }
//                 JOptionPane.showMessageDialog(vista, "✅ Pista asignada para despegue: " + pistaSeleccionada, "Éxito", JOptionPane.INFORMATION_MESSAGE);

//                 break;

//             default:
//                 JOptionPane.showMessageDialog(vista, "Estado de vuelo no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
//                 return;
//         }

//         // Después de asignar, volver al menú principal
//         pantallaBase.mostrarContenidoEnPanelCentral(new JPanel());
//     }
// }
