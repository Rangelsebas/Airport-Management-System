package interfazTest.controlador.primeraPantalla.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelControlarAterrizajes extends JPanel {

    private JPanel panelListado;

    public PanelControlarAterrizajes() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Vuelos esperando aterrizaje", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(500, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);
    }

    public JButton agregarVuelo(String estado, String aerolinea, String codigo, String fecha, ActionListener c) {
        JPanel panelVuelo = new JPanel();
        panelVuelo.setLayout(new BoxLayout(panelVuelo, BoxLayout.Y_AXIS));
        panelVuelo.setBackground(Color.WHITE);
        panelVuelo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
            new EmptyBorder(10, 10, 10, 10)
        ));
    
        JLabel labelEstado = new JLabel(estado);
        labelEstado.setFont(new Font("Arial", Font.BOLD, 16));
    
        JLabel labelAerolinea = new JLabel("Aerolínea: " + aerolinea);
        JLabel labelCodigo = new JLabel("Código: " + codigo);
        JLabel labelFecha = new JLabel("Fecha: " + fecha);
    
        JButton botonSeleccionar = new JButton("Seleccionar");
        botonSeleccionar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonSeleccionar.setFocusPainted(false);
        botonSeleccionar.addActionListener(c);
    
        panelVuelo.add(labelEstado);
        panelVuelo.add(labelAerolinea);
        panelVuelo.add(labelCodigo);
        panelVuelo.add(labelFecha);
        panelVuelo.add(Box.createVerticalStrut(10));
        panelVuelo.add(botonSeleccionar);
    
        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelVuelo);
        panelListado.revalidate();
        panelListado.repaint();
    
        return botonSeleccionar;
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }
}