package pruebas.anas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import funcionalidad.aplicacion.Notificacion;
import funcionalidad.usuarios.GestorAeropuerto;

public class GestorAeropuertoTest {
    private GestorAeropuerto gestor;

    @Before
    public void setUp() {
        gestor = GestorAeropuerto.init("gestor1", "12345678A", "Juan Perez", "juan.perez@example.com", "password123");
    }

    @Test
    public void testSingletonInstance() {
        GestorAeropuerto anotherGestor = GestorAeropuerto.init("gestor2", "87654321B", "Ana Lopez", "ana.lopez@example.com", "password456");
        assertSame(gestor, anotherGestor);
    }

    @Test
    public void testCheckRol() {
        assertTrue(gestor.checkRol(funcionalidad.usuarios.Rol.GESTORAEROPUERTO));
        assertFalse(gestor.checkRol(funcionalidad.usuarios.Rol.OPERADORAEROLINEA));
    }

    @Test
    public void testCambiarContrasena() {
        assertTrue(gestor.cambiarContrasena("password123", "newpassword123"));
        assertFalse(gestor.cambiarContrasena("wrongpassword", "newpassword123"));
    }

    @Test
    public void testComprobarContrasena() {
        // Debugging information
        System.out.println("Expected password: password123");
        System.out.println("Actual password: " + gestor.comprobarContrasena("password123"));

        assertTrue(gestor.comprobarContrasena("newpassword123"));
    }

    @Test
    public void testAñadirNotificacion() {
        Notificacion notificacion = new Notificacion("Test notification");
        assertTrue(gestor.añadirNotificacion(notificacion));
        assertEquals(1, gestor.getNotificacion().size());
    }

    @Test
    public void testGetNotificacionNoLeidas() {
        Notificacion notificacion1 = new Notificacion("Test notification 1");
        Notificacion notificacion2 = new Notificacion("Test notification 2");
        notificacion1.marcarComoLeida();
        gestor.añadirNotificacion(notificacion1);
        gestor.añadirNotificacion(notificacion2);

        // Debugging information
        System.out.println("Total notifications: " + gestor.getNotificacion().size());
        System.out.println("Unread notifications: " + gestor.getNotificacionNoLeidas().size());

        assertEquals(2, gestor.getNotificacionNoLeidas().size());
    }
}
