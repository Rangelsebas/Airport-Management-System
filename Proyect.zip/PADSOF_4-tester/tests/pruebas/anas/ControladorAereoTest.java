package pruebas.anas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import funcionalidad.aerolinea.*;
import funcionalidad.aplicacion.Notificacion;
import funcionalidad.usuarios.ControladorAereo;
import funcionalidad.vuelo.Vuelo;

import java.time.LocalDate;
import java.time.LocalTime;

public class ControladorAereoTest {
    private ControladorAereo controlador;
    private Vuelo vuelo;
    private Aerolinea aerolinea;
    private Avion avion;

    @Before
    public void setUp() {
        controlador = new ControladorAereo("controlador1", "12345678A", "Juan Perez", "juan.perez@example.com", "password123");
        aerolinea = new Aerolinea("Aerolinea X");
        TipoAvion tipoAvion = new TipoAvion("Tipo 1", "Boeing", "737", 100, true, 30, 10, 10);
        avion = new Avion(LocalDate.now(), LocalDate.now(), tipoAvion, "ABC123") {
            @Override
            public Boolean comprobarMantenimiento() {
                return true;
            }

            @Override
            public CategoriaAvion getCategoria() {
                return CategoriaAvion.PASAJEROS;
            }
        };
        vuelo = new Vuelo("Origen", "Destino", LocalTime.of(10, 0), LocalTime.of(12, 0), LocalDate.now(), aerolinea, avion);
    }

    @Test
    public void testCheckRol() {
        assertTrue(controlador.checkRol(funcionalidad.usuarios.Rol.CONTROLADORAEREO));
        assertFalse(controlador.checkRol(funcionalidad.usuarios.Rol.GESTORAEROPUERTO));
    }

    @Test
    public void testCambiarContrasena() {
        assertTrue(controlador.cambiarContrasena("password123", "newpassword123"));
        assertFalse(controlador.cambiarContrasena("wrongpassword", "newpassword123"));
    }

    @Test
    public void testComprobarContrasena() {
        assertTrue(controlador.comprobarContrasena("password123"));
        assertFalse(controlador.comprobarContrasena("wrongpassword"));
    }

    @Test
    public void testAñadirNotificacion() {
        Notificacion notificacion = new Notificacion("Test notification");
        assertTrue(controlador.añadirNotificacion(notificacion));
        assertEquals(1, controlador.getNotificacion().size());
    }

    @Test
    public void testGetNotificacionNoLeidas() {
        Notificacion notificacion1 = new Notificacion("Test notification 1");
        Notificacion notificacion2 = new Notificacion("Test notification 2");
        notificacion1.marcarComoLeida();
        controlador.añadirNotificacion(notificacion1);
        controlador.añadirNotificacion(notificacion2);
        assertEquals(1, controlador.getNotificacionNoLeidas().size());
    }
}
