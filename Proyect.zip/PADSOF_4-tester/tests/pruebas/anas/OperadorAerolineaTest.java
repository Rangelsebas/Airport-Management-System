package pruebas.anas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Notificacion;
import funcionalidad.usuarios.OperadorAerolinea;

public class OperadorAerolineaTest {
    private OperadorAerolinea operador;
    private Aerolinea aerolinea;

    @Before
    public void setUp() {
        operador = new OperadorAerolinea("operador1", "12345678A", "Juan Perez", "juan.perez@example.com", "password123");
        aerolinea = new Aerolinea("Aerolinea X");
    }

    @Test
    public void testAsignarAerolinea() {
        operador.asignarAerolinea(aerolinea);
        assertNotNull(aerolinea); // Verifica que la aerolínea no sea nula
        assertNotNull(operador); // Verifica que el operador no sea nulo
    }

    @Test
    public void testCheckRol() {
        assertTrue(operador.checkRol(funcionalidad.usuarios.Rol.OPERADORAEROLINEA));
        assertFalse(operador.checkRol(funcionalidad.usuarios.Rol.GESTORAEROPUERTO));
    }

    @Test
    public void testCambiarContrasena() {
        assertTrue(operador.cambiarContrasena("password123", "newpassword123"));
        assertFalse(operador.cambiarContrasena("wrongpassword", "newpassword123"));
    }

    @Test
    public void testComprobarContrasena() {
        assertTrue(operador.comprobarContrasena("password123"));
        assertFalse(operador.comprobarContrasena("wrongpassword"));
    }

    @Test
    public void testAñadirNotificacion() {
        Notificacion notificacion = new Notificacion("Test notification");
        assertTrue(operador.añadirNotificacion(notificacion));
        assertEquals(1, operador.getNotificacion().size());
    }

    @Test
    public void testGetNotificacionNoLeidas() {
        Notificacion notificacion1 = new Notificacion("Test notification 1");
        Notificacion notificacion2 = new Notificacion("Test notification 2");
        notificacion1.marcarComoLeida();
        operador.añadirNotificacion(notificacion1);
        operador.añadirNotificacion(notificacion2);
        assertEquals(1, operador.getNotificacionNoLeidas().size());
    }
}
