package pruebas.anas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import funcionalidad.aplicacion.Notificacion;
import funcionalidad.usuarios.*;

public class UsuarioTest {

    private Usuario usuario;
    private Rol rol;

    // Configuración inicial antes de cada prueba
    @Before
    public void setUp() {
        rol = Rol.GESTORAEROPUERTO; // Inicializa el rol
        usuario = new Usuario("user1", "12345678A", "John Doe", "john@example.com", "password", rol); // Crea un nuevo usuario
    }

    // Prueba para verificar el rol del usuario
    @Test
    public void testCheckRol() {
        assertTrue(usuario.checkRol(rol)); // Verifica que el rol es correcto
        assertFalse(usuario.checkRol(Rol.OPERADORAEROLINEA)); // Verifica que un rol incorrecto no es aceptado
    }

    // Prueba para cambiar la contraseña del usuario
    @Test
    public void testCambiarContrasena() {
        assertTrue(usuario.cambiarContrasena("password", "newpassword")); // Verifica que la contraseña se cambia correctamente
        assertFalse(usuario.cambiarContrasena("wrongpassword", "newpassword")); // Verifica que una contraseña incorrecta no permite el cambio
        assertTrue(usuario.comprobarContrasena("newpassword")); // Verifica que la nueva contraseña es correcta
    }

    // Prueba para comprobar la contraseña del usuario
    @Test
    public void testComprobarContrasena() {
        assertTrue(usuario.comprobarContrasena("password")); // Verifica que la contraseña es correcta
        assertFalse(usuario.comprobarContrasena("wrongpassword")); // Verifica que una contraseña incorrecta no es aceptada
    }

    // Prueba para añadir una notificación al usuario
    @Test
    public void testAñadirNotificacion() {
        Notificacion notificacion = new Notificacion("Test notification"); // Crea una nueva notificación
        assertTrue(usuario.añadirNotificacion(notificacion)); // Verifica que la notificación se añade correctamente
        assertEquals(1, usuario.getNotificacion().size()); // Verifica que la lista de notificaciones tiene un elemento
        assertEquals("Test notification", usuario.getNotificacion().get(0).getMensaje()); // Verifica que el mensaje de la notificación es correcto
    }

    // Prueba para obtener notificaciones no leídas
    @Test
    public void testGetNotificacionNoLeidas() {
        Notificacion notificacion1 = new Notificacion("Test notification 1"); // Crea una nueva notificación
        Notificacion notificacion2 = new Notificacion("Test notification 2"); // Crea otra notificación
        notificacion2.marcarComoLeida(); // Marca la segunda notificación como leída
        usuario.añadirNotificacion(notificacion1); // Añade la primera notificación
        usuario.añadirNotificacion(notificacion2); // Añade la segunda notificación
        assertEquals(1, usuario.getNotificacionNoLeidas().size()); // Verifica que solo hay una notificación no leída
        assertEquals("Test notification 1", usuario.getNotificacionNoLeidas().get(0).getMensaje()); // Verifica que el mensaje de la notificación no leída es correcto
    }

    // Prueba para obtener el nombre de usuario
    @Test
    public void testGetNombreUsuario() {
        assertEquals("user1", usuario.getNombreUsuario()); // Verifica que el nombre de usuario es correcto
    }
}
