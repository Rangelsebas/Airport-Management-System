package pruebas.angel;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aerolinea.TipoAvion;
import funcionalidad.aeropuerto.AeropuertoPropio;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.Factura;
import funcionalidad.otro.Orientacion;
import funcionalidad.otro.Uso;
import funcionalidad.vuelo.Vuelo;

public class FacturaPDFTest {
    private Aplicacion app;
    private Boolean st = false;
    @BeforeEach
    void setUp(){

    }

    @Test
    public void generarPDFTest(){
        app = Aplicacion.init("AENA");
        assertNotNull(app);
        assertTrue(app.crearGestor("GestorAngel", "1234", "55242141M", "Angel Dal", "angel.dal@estudiante.uam.es"));
        assertTrue(app.iniciarSesion("GestorAngel", "1234"));
        assertTrue(app.crearAeropuertoPropio("Adolfo Suarez de Barajas", 2000, "Madrid", 10, "Barajas, Madrid", "MAD", LocalTime.of(6, 0), LocalTime.of(23, 0)));
        app.cargarAeropuertosExternos("aeropuertosExternos.txt");
        AeropuertoPropio airport = app.getAeropuertoPropio();
        airport.añadirPista("Pista 1", 4000, Orientacion.ESTE, Uso.ATERRIZAJE);
        airport.añadirTerminal("T1", 20);
        airport.añadirHangar("H1", 20, 500, 80, 80, 35);
        airport.añadirAparcamiento("A1", 200, 150, 40, 40);
        app.cargarTiposDeAviones("tiposAviones.txt");
        TipoAvion avion = app.getTipoAvion("BO777X1");
        app.añadirAerolinea("Iberia");
        app.registrarOperador("IberiaOperador", "111111Z", "Cristiano Ronaldo", "cirs@uam.es", "1234");
        app.asignarAerolineaOperador("IberiaOperador", "Iberia");
        app.registrarControlador("Controlador1", "222222A", "Fernando Alonso", "nuestropadre@uam.es", "1234");
        app.cerrarSesion();
        app.iniciarSesion("IberiaOperador", "1234");
        Aerolinea iberia = app.getAerolinea("Iberia");
        TipoAvion nuevoAvion = avion;
        iberia.anadirAvion(CategoriaAvion.PASAJEROS, nuevoAvion, LocalDate.of(2020, 5, 25), LocalDate.of(2024, 5, 25));
        Avion avionVuelo = iberia.getAviones().getFirst();
        app.solicitarNuevoVuelo("Pamplona", "Adolfo Suarez de Barajas", app.getRealTime().plusDays(1).toLocalDate(), LocalTime.of(12, 0), LocalTime.of(14, 0), iberia, avionVuelo);
        app.cerrarSesion();
        app.iniciarSesion("GestorAngel", "1234");
        airport.añadirPuertasTerminal("T1", 100, 30, 10, 30, 20);

        /* A ver la notificacion */
        app.verNotificacionesNoLeidas();
        /* Intentamos aprobar el vuelo */
        assertTrue(app.aprobarSolicitudVuelo("V1", "T1", "Controlador1"));
        app.verNotificacionesNoLeidas();
        app.setRealTime(LocalDateTime.of(app.getRealTime().getYear(),app.getRealTime().getMonth(),app.getRealTime().getDayOfMonth() + 1,11,0));
        System.out.println(app.getVuelosDelDia());
        app.avanzarUnaHora();
        app.avanzarUnaHora();
        app.avanzarUnaHora();
        app.actualizar();
        System.out.println("\nAvanzamos unas horas son las: " + app.getRealTime().toLocalTime() +"\n");
        System.out.println(app.getVuelosDelDia());
        Vuelo miVuelo = app.getVueloxCodigo("V1");
        app.cerrarSesion();
        app.iniciarSesion("Controlador1", "1234");
        st = miVuelo.asignarPistaCambioEstado(airport.getPista("Pista 1"));
        assertTrue(st);
        st = miVuelo.autorizarAterrizajeCambioEstado(airport.getAparcamiento("A1"), airport.getTerminal("T1").getPuerta("A01"));
        assertTrue(st);
        app.verNotificacionesNoLeidas();
        app.cerrarSesion();
        st = app.iniciarSesion("IberiaOperador", "1234");
        assertTrue(st);
        app.avanzarCincoMinutos();
        st = miVuelo.iniciarDescargaCambioEstado();
        assertTrue(st);
        app.verNotificacionesNoLeidas();
        st = miVuelo.descargaFinalizadaCambioEstado();
        app.avanzarCincoMinutos();
        app.avanzarCincoMinutos();
        app.avanzarCincoMinutos();
        assertTrue(st);
        app.cerrarSesion();
        app.iniciarSesion("Controlador1", "1234");
        assertTrue(st);
        app.avanzarUnaHora();
        st = miVuelo.guardarAvionEnHangar(airport.getHangar("H1"));
        assertTrue(st);
        /* Vuelo terminado */
        System.out.println(miVuelo);
        app.cerrarSesion();
        app.iniciarSesion("GestorAngel", "1234");
        st = app.emitirFactura(iberia, app.getRealTime().toLocalDate());
        assertTrue(st);
        Factura fac = iberia.getFacturas().getFirst();
        assertNotNull(fac);
        fac.añadirVueloACobro(miVuelo);
        System.out.println("Tu factura:\n"+ fac);
        st = app.generarPDFFactura(fac);
        assertTrue(st);
    }
}
