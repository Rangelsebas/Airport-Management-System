package pruebas.angel;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aerolinea.TipoAvion;
import funcionalidad.aplicacion.Aplicacion;

import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class AplicacionTest {

    private Aplicacion aplicacion;

    @BeforeEach
    void setUp() {
        // Inicializar la aplicación y crear un usuario para pruebas
        aplicacion = Aplicacion.init("Test Aeropuerto");
        
        // Crear un usuario gestor para pruebas de creación de aeropuerto
        aplicacion.crearGestor("gestor", "gestor123", "1234", "Angel Dal", "gestor@aeropuerto.com");
        
        // Simular login del usuario gestor
        aplicacion.iniciarSesion("gestor", "gestor123");
    }

    @Test
    void testCrearAeropuertoPropioExitoso() {
        // Configurar los datos necesarios
        String nombre = "Aeropuerto Central";
        String ciudadMasCercana = "Madrid";
        int distanciaCiudad = 15;
        String direccion = "Calle Aeropuerto 123";
        String codigo = "MAD";
        LocalTime horaApertura = LocalTime.of(6, 0);
        LocalTime horaCierre = LocalTime.of(23, 0);

        // Ejecutar el método
        Boolean resultado = aplicacion.crearAeropuertoPropio(nombre, 2000, ciudadMasCercana, distanciaCiudad, direccion, codigo, horaApertura, horaCierre);

        // Verificar que la creación fue exitosa
        assertTrue(resultado, "El aeropuerto propio debería crearse correctamente.");
    }

    @Test
    void testCrearAeropuertoPropioSinLogin() {
        // Cerrar sesión del usuario para simular un intento sin login
        aplicacion.cerrarSesion();

        String nombre = "Aeropuerto Internacional";
        String ciudadMasCercana = "Barcelona";
        int distanciaCiudad = 25;
        String direccion = "Calle Aeropuerto Internacional 1";
        String codigo = "BCN";
        LocalTime horaApertura = LocalTime.of(6, 0);
        LocalTime horaCierre = LocalTime.of(23, 0);

        // Intentar crear el aeropuerto sin estar logueado
        Boolean resultado = aplicacion.crearAeropuertoPropio(nombre, 2000, ciudadMasCercana, distanciaCiudad, direccion, codigo, horaApertura, horaCierre);

        // Verificar que no se crea el aeropuerto
        assertFalse(resultado, "El aeropuerto no debería poder crearse sin un usuario logueado.");
    }

    @Test
    void testCrearAeropuertoPropioSinAlgunDato() {
        String nombre = "Aeropuerto Internacional";
        String ciudadMasCercana = "Barcelona";
        int distanciaCiudad = 25;
        String direccion = "Calle Aeropuerto Internacional 1";
        String codigo = null;
        LocalTime horaApertura = LocalTime.of(6, 0);
        LocalTime horaCierre = LocalTime.of(23, 0);

        // Intentar crear el aeropuerto sin codigo
        Boolean resultado = aplicacion.crearAeropuertoPropio(nombre, 2000, ciudadMasCercana, distanciaCiudad, direccion, codigo, horaApertura, horaCierre);

        // Verificar que no se crea el aeropuerto
        assertFalse(resultado, "El aeropuerto no debería poder crearse sin un dato.");
    }

    @Test
    void testCerrarSesion() {
        // Comprobar si el usuario está logueado
        assertNotNull(aplicacion.getUsuarioLogueado(), "El usuario debería estar logueado.");

        // Cerrar sesión
        aplicacion.cerrarSesion();

        // Verificar que el usuario se ha desconectado
        assertNull(aplicacion.getUsuarioLogueado(), "El usuario debería estar desconectado.");
    }

    @Test
    void testIniciarSesionUsuarioNoExistente() {
        //primero cerramos sesion
        aplicacion.cerrarSesion();
        // Intentar iniciar sesión con un usuario que no existe
        Boolean resultado = aplicacion.iniciarSesion("inexistente", "contraseñaIncorrecta");

        // Verificar que la sesión no se inicia
        assertFalse(resultado, "La sesión no debería iniciarse con un usuario que no existe.");
    }

    @Test
    void testIniciarSesionConContraseñaIncorrecta() {
        //primero cerramos sesion
        aplicacion.cerrarSesion();
        // Intentar iniciar sesión con una contraseña incorrecta
        Boolean resultado = aplicacion.iniciarSesion("gestor", "contraseñaIncorrecta");

        // Verificar que la sesión no se inicia
        assertFalse(resultado, "La sesión no debería iniciarse con una contraseña incorrecta.");
    }

    @Test
    void testCrearGestorSinExitos() {
        // Crear un nuevo gestor
        Boolean resultado = aplicacion.crearGestor("nuevoGestor", "contraseña", "12345678A", "Nuevo Gestor", "nuevo@aeropuerto.com");

        // Verificar que el gestor no se haya creado
        assertFalse(resultado, "Ya existe un gestor, muy bien");
    }

    @Test
    void testRegistrarControlador() {
        // Intentar registrar un controlador con un usuario logueado como gestor
        Boolean resultado = aplicacion.registrarControlador("controlador1", "87654321B", "Controlador Uno", "controlador1@aero.com", "controlador123");

        // Verificar que se haya registrado correctamente
        assertTrue(resultado, "El controlador debería registrarse correctamente.");
    }

    @Test
    void testRegistrarOperador() {
        // Intentar registrar un operador con un usuario logueado como gestor
        Boolean resultado = aplicacion.registrarOperador("operador1", "11223344C", "Operador Uno", "operador1@aero.com", "operador123");

        // Verificar que se haya registrado correctamente
        assertTrue(resultado, "El operador debería registrarse correctamente.");
    }

    @Test
    void testRegistrarUsuarioExistente() {
        // Registrar un operador con un usuario logueado como gestor
        aplicacion.registrarOperador("operador1", "11223344C", "Operador Uno", "operador1@aero.com", "operador123");

        Boolean resultado = aplicacion.registrarOperador("operador1", "11223344C", "Operador Uno", "operador1@aero.com", "operador123");

        // Verificar que se no haya registrado
        assertFalse(resultado, "El sistema debería detectar que existe ese usuario.");
    }

    @Test
    void testEliminarUsuario() {
        // Añadir el ususario a eliminar
        int usuarios = aplicacion.listarUsuarios().size();
        Boolean resultado = aplicacion.registrarOperador("operador2", "11223344Z", "Operador Uno", "operador1@aero.com", "operador123");
        assertTrue(resultado, "Usuario registrado");
        assertEquals(aplicacion.listarUsuarios().size(), usuarios + 1, "Lista actualizada");


        resultado = aplicacion.eliminarUsuario("operador2");
        usuarios = aplicacion.listarUsuarios().size();

        assertTrue(resultado, "Usuario eliminado");
        assertEquals(aplicacion.listarUsuarios().size(), usuarios, "Lista actualizada");
    }

    @Test
    void testEliminarUsuarioNoGestor() {
        // Añadir el ususario a eliminar
        int usuarios = aplicacion.listarUsuarios().size();
        Boolean resultado = aplicacion.registrarOperador("operador3", "11223344Y", "Operador Uno", "operador1@aero.com", "operador123");
        assertTrue(resultado, "Usuario registrado");
        // Añadir usuario que lo intentará
        resultado = aplicacion.registrarOperador("operador4", "11223344X", "Operador Dos", "operador1@aero.com", "operador123");
        assertTrue(resultado, "Usuario registrado");
        // Cerrar sesion de gestor
        aplicacion.cerrarSesion();
        aplicacion.iniciarSesion("operador4", "operador123");

        // Tratar de eliminar
        resultado = aplicacion.eliminarUsuario("operador3");

        assertFalse(resultado, "Usuario no eliminado");
        assertEquals(usuarios + 2, aplicacion.listarUsuarios().size(), "Lista no modificada");
    }

    @Nested
    public class notificacionesTest {
        @BeforeEach
        void setUp(){
            aplicacion.crearAeropuertoPropio("Adolfo Suarez de Barajas", 2000, "Madrid", 10, "Calle en barajas", "MAD", LocalTime.of(04, 0), LocalTime.of(23, 0));
        }
        @Test
        void notificarNuevoVueloTest(){
            aplicacion.registrarOperador("OperadorTestNoti", "1111111Z", "Cristiano Ronaldo Jr", "cr7jr@gmail.com", "1234");
            aplicacion.añadirAeropuertoExterno("Aeropuerto Simon Bolivar", "Caracas", 20, "Calle algo", "VEN123", LocalTime.of(6, 0), LocalTime.of(23, 0), 6);
            aplicacion.añadirAerolinea("Iberia");
            Aerolinea aerolinea = aplicacion.getAerolinea("Iberia");
            aerolinea.asignarOperador(aplicacion.getUsuario("OperadorTestNoti"));
            aplicacion.verNotificacionesNoLeidas();
            aplicacion.cerrarSesion();
            aplicacion.iniciarSesion("OperadorTestNoti", "1234");
            assertTrue(aplicacion.añadirTipoAvion("B737v2","Boeing", "737", 100, false, 20, 30, 10));
            TipoAvion nuevoTipo = aplicacion.getTipoAvion("B737v2");
            assertNotNull(nuevoTipo);
            assertTrue(aerolinea.anadirAvion(CategoriaAvion.PASAJEROS, nuevoTipo, LocalDate.of(2024, 5, 20), LocalDate.of(2025, 1, 1)), "Añadido el avion");
            Aerolinea aerolineaTest = aplicacion.getAerolinea("Iberia");
            Avion avion = aerolineaTest.getAviones().getFirst();
            aplicacion.solicitarNuevoVuelo("Adolfo Suarez de Barajas", "Aeropuerto Simon Bolivar", LocalDate.of(2025, 10, 10), LocalTime.of(12, 0), LocalTime.of(20, 0), aerolineaTest, avion);
            aplicacion.cerrarSesion();
            aplicacion.iniciarSesion("gestor", "gestor123");
            aplicacion.verNotificacionesNoLeidas();
        }
    }

    @Nested
    public class guardarYCargarTest {
        @Test
        @Order(1)
        void salvarAppTest(){
            assertTrue(aplicacion.salvarAplicacion("aplicacion.dat"), "Correctamente salvado");
        }

        @Test
        @Order(2)
        void cargarAplicacion(){
            aplicacion.crearAeropuertoPropio("Adolfo Suarez de Barajas", 2000, "Madird", 10, "Calle del aeropuerto", 
            "BR2020", LocalTime.of(4, 0), LocalTime.of(23, 0));
            System.out.println(aplicacion);
            aplicacion.salvarAplicacion("aplicacion.dat");
            assertTrue(aplicacion.cargarAplicacion("aplicacion.ser"), "Aplicacion cargada correctamente");
            System.out.println(aplicacion);
        }
    }

    @Nested
    public class operadorAerolineaTest {
        @BeforeEach
        void setUp(){
            aplicacion.registrarOperador("operador1", "11223344C", "Operador Uno", "operador1@aero.com", "operador123");

            aplicacion.cerrarSesion();

            aplicacion.iniciarSesion("operador1", "operador123");
        }

        @Test
        void testAñadirTipoAvionConExito(){
            Boolean resultado = aplicacion.añadirTipoAvion("B737V1", "Boeing", "737", 270, false, 20, 30, 5);

            resultado = resultado && aplicacion.listarTiposDeAviones().getLast().getMarca().equals("Boeing");

            assertTrue(resultado, "Se ha agregado el tipo de avión a la app");
        }

        @Test
        void testAñadirTipoAvionSinExito() {
            int tamaño = aplicacion.listarTiposDeAviones().size();

            assertThrows(IllegalArgumentException.class, () -> {
                aplicacion.añadirTipoAvion("B737V2", "Boeing", null, 270, false, 20, 30, 5);
            }, "Debe lanzar una excepción si los datos del avión son inválidos");
        
            assertEquals(tamaño, aplicacion.listarTiposDeAviones().size(), "Sigue habiendo la misma cantidad que antes");
        }
    }
}
