package pruebas.sebas;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import funcionalidad.aerolinea.*;
import funcionalidad.aplicacion.Aplicacion;

public class AvionMercanciasTest {

    private AvionMercancias avion;
    private TipoAvion tipoAvionMock;
    private Aplicacion app;

    @BeforeEach
    void setUp() {
        // Inicializar la aplicación y crear un usuario para pruebas
        app = Aplicacion.init("acceder");
        
        // Crear un usuario gestor para pruebas de creación de aeropuerto
        app.crearGestor("gestor", "gestor123", "1234", "Angel Dal", "gestor@aeropuerto.com");
        
        // Simular login del usuario gestor
        app.iniciarSesion("gestor", "gestor123");

        tipoAvionMock = new TipoAvion("C-81", "Boeing", "747-8F", 50000, true, 76, 19, 68);

        LocalDate fechaCompra = LocalDate.now().minusYears(3);
        LocalDate fechaRevision = LocalDate.now().minusMonths(7); // Debería requerir mantenimiento
        String matricula = tipoAvionMock.getMarca() + "-" + tipoAvionMock.getModelo() + "-" + tipoAvionMock.getCapacidad();

        avion = new AvionMercancias(fechaCompra, fechaRevision, tipoAvionMock, matricula, true, true);
    }

    @AfterEach
    void cleanUp() {
        app.cerrarSesion();
    }

    @Test
    void testComprobarMantenimientoNecesario() {
        assertTrue(avion.comprobarMantenimiento(), "El avión debería requerir mantenimiento.");
    }

    @Test
    void testCargarMercanciaExitosa() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");

        avion.setDisponible(true);

        boolean resultado = avion.cargar(20000);
        assertTrue(resultado, "La carga debería ser exitosa si el avión está disponible y dentro del límite.");
    }


    /* TESTS NEGATIVOS */

    @Test
    void testCargarMercanciaExcedeCapacidad() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        System.out.println("Usuario registrado: " + usuarioUnico);
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");

        boolean resultado = avion.cargar(60000); // Capacidad es 50000
        assertFalse(resultado, "No debería permitir cargar más peso del permitido.");
    }

    @Test
    void testCargarMercanciaConEstadoNoDisponible() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");

        System.out.println(app.getUsuarioLogueado());

        avion.setDisponible(false);

        boolean resultado = avion.cargar(100);
        assertFalse(resultado, "No debería permitir cargar si el avión no está disponible.");
    }

    @Test
    void testCrearAvionMercanciasConTipoAvionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new AvionMercancias(LocalDate.now(), LocalDate.now(), null, "BOEING-TEST-50000", true, true);
        }, "Se esperaba una IllegalArgumentException al crear un AvionMercancias con TipoAvion null.");
    }

    @Test
    void testCrearAvionMercanciasConTodoNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new AvionMercancias(null, null, null, null, true, true);
        }, "Se esperaba una IllegalArgumentException al crear un AvionMercancias con valores nulos.");
    }
}
