package pruebas.sebas;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalTime;

import funcionalidad.aerolinea.*;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.ControladorAereo;
import funcionalidad.usuarios.Usuario;
import funcionalidad.vuelo.Vuelo;

public class VueloTest {
    private Aplicacion app;
    private Aerolinea aerolinea;
    private AvionPasajeros avion;
    private Vuelo vuelo;
    private Usuario controlador;

    @BeforeEach
    void setUp() {
        app = Aplicacion.init("acceder");
        app.crearGestor("gestor", "gestor123", "1234", "Nombre Gestor", "gestor@aeropuerto.com");
        app.iniciarSesion("gestor", "gestor123");

        TipoAvion tipo1 = new TipoAvion("A-71", "Airbus", "A320", 180, false, 37, 11, 34);
        avion = new AvionPasajeros(LocalDate.now(), LocalDate.now(), tipo1, "A320-Test");

        aerolinea = new Aerolinea("AirTest");

        app.registrarControlador("controlador1", "87654321B", "Controlador Uno", "ctrl1@test.com", "clave123");
        app.registrarOperador("operador1", "87654321B", "Operador Uno", "ctrl1@test.com", "clave123");

        TipoAvion tipo2 = new TipoAvion("A-71", "Airbus", "A320", 180, false, 37, 11, 34);
        avion = new AvionPasajeros(LocalDate.now(), LocalDate.now(), tipo2, "A320-Test");

        vuelo = new Vuelo("Madrid", "Paris", LocalTime.of(8, 0), LocalTime.of(10, 0), LocalDate.now(), aerolinea, avion);

        app.cerrarSesion();
    }

    @AfterEach
    void cleanUp() {
        app.cerrarSesion();
    }

    /*----CONSTRUCTOR----*/

    @Test
    void testConstructorValido() {
        Vuelo vuelo = new Vuelo("Madrid", "Barcelona", LocalTime.of(10, 0), LocalTime.of(12, 0), LocalDate.now(), aerolinea, avion);
        assertEquals("Madrid", vuelo.getOrigen());
        assertEquals("Barcelona", vuelo.getDestino());
        assertEquals(LocalTime.of(10, 0), vuelo.getHoraSalida());
        assertEquals(LocalTime.of(12, 0), vuelo.getHoraLlegada());
        assertTrue(vuelo.getEnTiempo());
        assertEquals(aerolinea, vuelo.getAerolineaOperadora());
        assertEquals(avion, vuelo.getAvion());
    }

    @Test
    void testConstructorHoraLlegadaAntesQueSalida() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Vuelo("Madrid", "Barcelona", LocalTime.of(15, 0), LocalTime.of(10, 0), LocalDate.now(), aerolinea, avion);
        });
    }

    @Test
    void testConstructorParametrosNulos() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Vuelo(null, "Destino", LocalTime.of(10, 0), LocalTime.of(12, 0), LocalDate.now(), aerolinea, avion);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Vuelo("Origen", null, LocalTime.of(10, 0), LocalTime.of(12, 0), LocalDate.now(), aerolinea, avion);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Vuelo("Origen", "Destino", null, LocalTime.of(12, 0), LocalDate.now(), aerolinea, avion);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Vuelo("Origen", "Destino", LocalTime.of(10, 0), null, LocalDate.now(), aerolinea, avion);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Vuelo("Origen", "Destino", LocalTime.of(10, 0), LocalTime.of(12, 0), null, aerolinea, avion);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Vuelo("Origen", "Destino", LocalTime.of(10, 0), LocalTime.of(12, 0), LocalDate.now(), null, avion);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Vuelo("Origen", "Destino", LocalTime.of(10, 0), LocalTime.of(12, 0), LocalDate.now(), aerolinea, null);
        });
    }


    /*----RELACIONES----*/
    @Test
    void testVincularAerolineaConRolValido() {
        Aerolinea nueva = new Aerolinea("NuevaAir");
        
        app.cerrarSesion();
        app.iniciarSesion("operador1", "clave123");

        System.out.println(app.getUsuarioLogueado());

        boolean resultado = vuelo.vincularAerolinea(nueva);
        assertTrue(resultado);
        assertTrue(vuelo.getAerolineas().contains(nueva));
    }

    @Test
    void testVincularAerolineaSinRol() {
        app.iniciarSesion("gestor", "gestor123");
        Aerolinea otra = new Aerolinea("OtraAir");

        boolean resultado = vuelo.vincularAerolinea(otra);
        assertFalse(resultado);
    }

    @Test
    void testDesvincularAerolineaConRolValido() {
        app.iniciarSesion("operador1", "clave123");
        Boolean desvinculado = vuelo.desvincularAerolinea(aerolinea);
        assertTrue(desvinculado);
        assertFalse(vuelo.getAerolineas().contains(aerolinea));
    }

    @Test
    void testDesvincularAerolineaSinRol() {
        app.iniciarSesion("gestor", "gestor123");
        Boolean resultado = vuelo.desvincularAerolinea(aerolinea);
        assertFalse(resultado);
    }

    @Test
    void testVincularControladorConPermiso() {
        app.cerrarSesion();
        app.iniciarSesion("gestor", "gestor123");

        System.out.println(app.getUsuarioLogueado());

        controlador = new ControladorAereo("controlador bellako", "12345624N", "Neymar Jr.", "elbicho@gmail.com", "elpapadeloshelados123");

        Boolean vinculado = vuelo.vincularControlador(controlador);
        assertTrue(vinculado);
        assertEquals(controlador, vuelo.getControladorAereo());
    }

    @Test
    void testDesvincularControladorSinPermiso() {
        app.iniciarSesion("gestor", "gestor123");
        vuelo.vincularControlador(controlador);
        app.cerrarSesion();

        app.iniciarSesion("operador1", "clave123");
        Boolean resultado = vuelo.desvincularControlador();
        assertFalse(resultado);
    }

    @Test
    void testVueloCobradoConRolValido() {
        app.iniciarSesion("gestor", "gestor123");
        Boolean cobrado = vuelo.vueloCobrado();
        assertTrue(cobrado);
        assertTrue(vuelo.askCobrado());
    }

    @Test
    void testVueloCobradoSinPermiso() {
        app.iniciarSesion("operador1", "clave123");
        Boolean resultado = vuelo.vueloCobrado();
        assertFalse(resultado);
    }


}
