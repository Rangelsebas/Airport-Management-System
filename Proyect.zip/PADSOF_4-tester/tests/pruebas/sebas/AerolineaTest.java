package pruebas.sebas;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalTime;

import funcionalidad.aerolinea.*;
import funcionalidad.aeropuerto.elementos.Hangar;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.Factura;
import funcionalidad.otro.Dimension;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.vuelo.*;

// Hay que ejecutarlos uno por uno, no desde aqui
public class AerolineaTest {
    private Aplicacion app;
    private Aerolinea aerolinea;
    private TipoAvion tipoAvionMock;
    private Avion avionMock;
    private Factura facturaMock;
    private OperadorAerolinea operadorMock;
    private Vuelo vueloMock;

    // Hay que ejecutarlos uno por uno
    @BeforeEach
    void setUp() {
        app = Aplicacion.init("acceder");
        app.crearGestor("gestor", "gestor123", "1234", "Juan Gestor", "gestor@aeropuerto.com");
        app.iniciarSesion("gestor", "gestor123");
        
        Boolean construido = app.crearAeropuertoPropio("Barajas", 100, "Teruel", 30, "Calle Puente 25", "21056", LocalTime.of(6, 0), LocalTime.of(22, 0));
        assertTrue(construido);

        operadorMock = new OperadorAerolinea("operador1", "11223344X", "Laura Operadora", "laura@aero.com", "clave123");

        aerolinea = new Aerolinea("LATAM");
        tipoAvionMock = new TipoAvion("C-77", "Boeing", "737", 180, true, 40, 12, 35);
        avionMock = new AvionPasajeros(LocalDate.of(2024, 3, 1), LocalDate.of(2024, 1, 1), tipoAvionMock, "BOEING-737-180");
        facturaMock = new Factura(LocalDate.of(2024, 3, 1), aerolinea);
        vueloMock = new Vuelo("CDG", "MEX", LocalTime.of(9, 30), LocalTime.of(12, 30), LocalDate.of(2024, 3, 20), aerolinea, avionMock);
    }

    @AfterEach
    void cleanUp() {
        app.cerrarSesion();
    }

    @Test
    void testCrearAerolinea() {
        assertEquals("LATAM", aerolinea.getNombre());
        assertTrue(aerolinea.getVuelos().isEmpty());
        assertTrue(aerolinea.getFacturas().isEmpty());
        assertTrue(aerolinea.getAviones().isEmpty());
    }

    @Test
    void testvincularOperadorCorrectamente() {
        String usuarioUnico = "operador" + System.currentTimeMillis();
        app.registrarOperador(usuarioUnico, "11223344Z", "Operador Uno", "operador@aero.com", "operador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "operador123");

        boolean resultado = aerolinea.asignarOperador(operadorMock);
        assertTrue(resultado);
        assertEquals(operadorMock, aerolinea.getOperadorAerolinea());
    }

    @Test
    void testVincularYDesvincularVuelo() {
        String usuarioUnico = "operador" + System.currentTimeMillis();
        app.registrarOperador(usuarioUnico, "11223344Z", "Operador Uno", "operador@aero.com", "operador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "operador123");

        System.out.println(app.getUsuarioLogueado());

        assertTrue(aerolinea.vincularVuelo(vueloMock));
        assertTrue(aerolinea.getVuelos().contains(vueloMock));
        aerolinea.desvincularVuelo(vueloMock);
        assertFalse(aerolinea.getVuelos().contains(vueloMock));
    }

    @Test
    void testVincularYDesvincularFactura() {
        String usuarioUnico = "operador" + System.currentTimeMillis();
        app.registrarOperador(usuarioUnico, "11223344Z", "Operador Uno", "operador@aero.com", "operador123");
        app.cerrarSesion();

        app.iniciarSesion("gestor", "gestor123");

        assertTrue(aerolinea.vincularFactura(facturaMock));
        assertTrue(aerolinea.getFacturas().contains(facturaMock));
        aerolinea.desvincularFactura(facturaMock);
        assertFalse(aerolinea.getFacturas().contains(facturaMock));
    }

    @Test
    void testAnadirAvion() {
        String usuarioUnico = "operador" + System.currentTimeMillis();
        app.registrarOperador(usuarioUnico, "11223344Z", "Operador Uno", "operador@aero.com", "operador123");

        app.cerrarSesion();
        app.iniciarSesion("gestor", "gestor123");

        Dimension dimension = new Dimension(10, 10, 10);
        Hangar hangar = new Hangar("Hangar 1", 100, 100, dimension);

        app.getAeropuertoPropio().añadirHangar(hangar.getNombre(), 100, 30, 100, 100, 100);

        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "operador123");

        assertTrue(aerolinea.anadirAvion(CategoriaAvion.PASAJEROS, tipoAvionMock, avionMock.getFechaCompra(), avionMock.getFechaUltimaRevision()));
        assertEquals(1, aerolinea.getAviones().size());
    }

    @Test
    void testvincularOperadorNull_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> {
            aerolinea.asignarOperador(null);
        });
    }
}
