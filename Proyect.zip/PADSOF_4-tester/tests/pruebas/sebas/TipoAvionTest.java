package pruebas.sebas;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import funcionalidad.aerolinea.TipoAvion;
import funcionalidad.otro.Dimension;

import static org.junit.jupiter.api.Assertions.*;

public class TipoAvionTest {

    private TipoAvion tipoAvion;

    @BeforeEach
    void setUp() {
        tipoAvion = new TipoAvion("B-65", "ABC123", "Boeing", 180, true, 40, 12, 35);
    }

    @Test
    void testConstructorInicializaCorrectamente() {
        assertEquals("ABC123", tipoAvion.getMarca());
        assertEquals("Boeing", tipoAvion.getModelo());
        assertEquals(180, tipoAvion.getCapacidad());
        assertTrue(tipoAvion.getControlTemperatura());
        assertEquals(new Dimension(40, 35, 12), tipoAvion.getDimension());
    }

    @Test
    void testToStringContieneDatosClave() {
        String output = tipoAvion.toString();
        assertTrue(output.contains("ABC123"));
        assertTrue(output.contains("Boeing"));
        assertTrue(output.contains("180"));
        assertTrue(output.contains("true"));
    }

    @Test
    void testCrearTipoAvionConCapacidadNegativa() {
        assertThrows(IllegalArgumentException.class, () -> {
            new TipoAvion("D-90", "DEF456", "Airbus", -50, false, 30, 10, 25);
        }, "Se esperaba una IllegalArgumentException al crear un TipoAvion con capacidad negativa.");
    }
}
