package pruebas.sebas;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import funcionalidad.aerolinea.*;
import funcionalidad.aplicacion.Aplicacion;

public class AvionTest {
    private TipoAvion tipoAvionMockPasajeros;
    private TipoAvion tipoAvionMockMercancias;
    private AvionPasajeros avionPasajeros;
    private AvionMercancias avionMercancias;
    private Aplicacion app;


    @BeforeEach
    void setUp() {
        // Inicializar la aplicación y crear un usuario para pruebas
        app = Aplicacion.init("acceder");
        
        // Crear un usuario gestor para pruebas de creación de aeropuerto
        app.crearGestor("gestor", "gestor123", "1234", "Angel Dal", "gestor@aeropuerto.com");
        
        // Simular login del usuario gestor
        app.iniciarSesion("gestor", "gestor123");


        tipoAvionMockPasajeros = new TipoAvion("A-71", "Airbus", "A320", 180, false, 37, 11, 34);
        tipoAvionMockMercancias = new TipoAvion("A-21", "Boeing", "747F", 50000, true, 70, 19, 64);

        LocalDate fechaCompra = LocalDate.of(2024, 3, 19);
        LocalDate fechaRevision = LocalDate.of(2024, 1, 1);

        avionPasajeros = new AvionPasajeros(fechaCompra, fechaRevision, tipoAvionMockPasajeros, "Boeing-737 MAX-180");
        avionMercancias = new AvionMercancias(fechaCompra, fechaRevision, tipoAvionMockMercancias, "Boeing-747F-50000", true, true);

    }

    @AfterEach
    void cleanUp() {
        app.cerrarSesion();
    }

    @Test
    void testComprobarMantenimientoPasajeros() {
        assertTrue(avionPasajeros.comprobarMantenimiento(), "El avión de pasajeros debería requerir mantenimiento.");
    }

    @Test
    void testComprobarMantenimientoMercancias() {
        assertTrue(avionMercancias.comprobarMantenimiento(), "El avión de mercancías debería requerir mantenimiento.");
    }

    @Test
    void testCargarPasajerosCuandoDisponible() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");

        avionPasajeros.setDisponible(true);

        boolean resultado = avionPasajeros.cargar(100);
        assertTrue(resultado, "El embarque debería ser aceptado si el avión está disponible.");
    }

    @Test
    void testCargarMercanciaCuandoDisponible() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");

        avionMercancias.setDisponible(true);

        boolean resultado = avionMercancias.cargar(15000);
        assertTrue(resultado, "La carga debería ser aceptada si el avión está disponible.");
    }



    /* TESTS NEGATIVOS */
    @Test
    void testCargarPasajerosExcedeCapacidad() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");


        boolean resultado = avionPasajeros.cargar(999); // Muy por encima de 180
        assertFalse(resultado, "No debería permitir embarcar más pasajeros de los permitidos.");
    }

    @Test
    void testCargarMercanciaExcedeCapacidad() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");


        boolean resultado = avionMercancias.cargar(100000); // Muy por encima de 50000
        assertFalse(resultado, "No debería permitir cargar más peso del permitido.");
    }

}
