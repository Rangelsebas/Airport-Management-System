package pruebas.sebas;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.EstadoSolicitud;
import funcionalidad.vuelo.Ocupacion;

public class OcupacionTest {

    private Aerolinea aerolineaMock;
    private Ocupacion ocupacion;
    private Aplicacion app;

    @BeforeEach
    void setUp() {
        // Inicializar la aplicación y crear un usuario para pruebas
        app = Aplicacion.init("acceder");
        
        // Crear un usuario gestor para pruebas de creación de aeropuerto
        app.crearGestor("gestor", "gestor123", "1234", "Angel Dal", "gestor@aeropuerto.com");
         
      // Simular login del usuario gestor
        app.iniciarSesion("gestor", "gestor123");


        aerolineaMock = new Aerolinea("Delta Airlines");
        ocupacion = new Ocupacion(aerolineaMock, 40, EstadoSolicitud.PENDIENTE);
    }

    @Test
    void testConstructorInicializaCorrectamente() {
        assertEquals(aerolineaMock, ocupacion.getAerolineaSolicitante(), "La aerolínea no se asignó correctamente.");
        assertEquals(40, ocupacion.getPorcentajeAsientos(), "El porcentaje de asientos no es correcto.");
        assertEquals(EstadoSolicitud.PENDIENTE, ocupacion.getEstado(), "El estado inicial debe ser PENDIENTE.");
    }

    @Test
    void testAprobarCambiaEstado() {
        ocupacion.aprobar();
        assertEquals(EstadoSolicitud.APROBADA, ocupacion.getEstado(), "El estado debería cambiar a APROBADA.");
    }

    @Test
    void testRechazarCambiaEstado() {
        ocupacion.rechazar();
        assertEquals(EstadoSolicitud.RECHAZADA, ocupacion.getEstado(), "El estado debería cambiar a RECHAZADA.");
    }

    @Test
    void testToStringContieneDatosClave() {
        String output = ocupacion.toString();
        assertTrue(output.contains("Delta Airlines"), "toString debería contener el nombre de la aerolínea.");
        assertTrue(output.contains("40"), "toString debería contener el porcentaje de asientos.");
        assertTrue(output.contains("PENDIENTE"), "toString debería reflejar el estado actual.");
    }

    /* TESTS NEGATIVOS */

    @Test
    void testPorcentajeNegativo() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Ocupacion(aerolineaMock, -10, EstadoSolicitud.PENDIENTE);
        }, "Se esperaba una IllegalArgumentException al pasar un porcentaje negativo.");
    }

    @Test
    void testPorcentajeMayorA100() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Ocupacion(aerolineaMock, 150, EstadoSolicitud.PENDIENTE);
        }, "Se esperaba una IllegalArgumentException al pasar un porcentaje mayor a 100.");
    }

    @Test
    void testAerolineaNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Ocupacion(null, 50, EstadoSolicitud.PENDIENTE);
        }, "Se esperaba una IllegalArgumentException al pasar una aerolínea null.");
    }

    @Test
    void testEstadoNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Ocupacion(aerolineaMock, 50, null);
        }, "Se esperaba una IllegalArgumentException al pasar estado null.");
    }


}
