package pruebas.sebas;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import funcionalidad.aerolinea.*;
import funcionalidad.aplicacion.Aplicacion;

public class AvionPasajerosTest {

    private AvionPasajeros avion;
    private TipoAvion tipoAvionMock;
    private Aplicacion app;

    @BeforeEach
    void setUp() {
        // Inicializar la aplicación y crear un usuario para pruebas
        app = Aplicacion.init("acceder");
        
        // Crear un usuario gestor para pruebas de creación de aeropuerto
        app.crearGestor("gestor", "gestor123", "1234", "Angel Dal", "gestor@aeropuerto.com");
         
      // Simular login del usuario gestor
        app.iniciarSesion("gestor", "gestor123");

        tipoAvionMock = new TipoAvion("Y-45", "Airbus", "A320", 180, true, 37, 11, 34);

        LocalDate fechaCompra = LocalDate.now().minusYears(2);
        LocalDate fechaRevision = LocalDate.now().minusMonths(7);
        String matricula = tipoAvionMock.getMarca() + "-" + tipoAvionMock.getModelo() + "-" + tipoAvionMock.getCapacidad();

        avion = new AvionPasajeros(fechaCompra, fechaRevision, tipoAvionMock, matricula);
    }

    @AfterEach
    void cleanUp() {
        app.cerrarSesion();
    }

    @Test
    void testComprobarMantenimientoNecesario() {
        assertTrue(avion.comprobarMantenimiento(), "El avión debería requerir mantenimiento.");
    }

    @Test
    void testComprobarDisponibilidad() {
        assertFalse(avion.isDisponible(), "El avión no debería estar disponible.");
    }

    @Test
    void testCargarPasajerosCuandoDisponible() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");

        avion.setDisponible(true);

        boolean resultado = avion.cargar(100);
        assertTrue(resultado, "El embarque debería ser aceptado si el avión está disponible.");
    }


    /* TESTS NEGATIVOS */

    @Test
    void testCargarPasajerosExcedeCapacidad() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");

        boolean resultado = avion.cargar(200); // Capacidad es 180
        assertFalse(resultado, "No debería permitir embarcar más pasajeros de los permitidos.");
        //assertNotEquals(EstadosVuelo.EMBARCANDO, avion.getEstado(), "El estado no debería cambiar.");
    }

    @Test
    void testCargarPasajerosNoDisponible() {
        String usuarioUnico = "controlador" + System.currentTimeMillis();
        app.registrarControlador(usuarioUnico, "11223344Z", "Controlador Uno", "controlador@aero.com", "controlador123");
        app.cerrarSesion();
        app.iniciarSesion(usuarioUnico, "controlador123");

        avion.setDisponible(false);

        boolean resultado = avion.cargar(50);
        assertFalse(resultado, "No debería permitir embarcar si el avión no está disponible.");
    }


    @Test
    void testCrearAvionPasajerosConTipoAvionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new AvionPasajeros(LocalDate.now(), LocalDate.now(), null, "TEST-MAT");
        }, "Se esperaba una IllegalArgumentException al crear un AvionPasajeros con TipoAvion null.");
    }

    @Test
    void testCrearAvionPasajerosConTodoNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new AvionPasajeros(null, null, null, null);
        }, "Se esperaba una IllegalArgumentException al crear un AvionPasajeros con valores nulos.");
    }
}
