package pruebas.facturaTest;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aeropuerto.elementos.ElementoFacturable;
import funcionalidad.facturacion.EstadoPago;
import funcionalidad.facturacion.Factura;
import funcionalidad.vuelo.Vuelo;

// Clases dummy para simular las dependencias

// Dummy para Aerolinea
class DummyAerolinea extends Aerolinea {
    public DummyAerolinea(String nombre) {
        super(nombre); // Llama al constructor de Aerolinea que recibe un nombre
    }

    @Override
    public String getNombre() {
        return super.getNombre(); // Devuelve el nombre de la aerolínea
    }

    @Override
    public Boolean vincularFactura(Factura factura) {
        // Simula la vinculación
        return true;
    }

    @Override
    public Boolean desvincularFactura(Factura factura) {
        // Simula la desvinculación
        return true;
    }
}

// Dummy para Vuelo
class DummyVuelo extends Vuelo {
    private List<ElementoFacturable> elementos = new ArrayList<>();
    private boolean cobrado = false;
    
    @Override
    public void vueloCobrado() {
        cobrado = true;
    }
    
    @Override
    public List<ElementoFacturable> getAllElementosFacturable() {
        return elementos;
    }
    
    public boolean isCobrado() {
        return cobrado;
    }
    
    // Puedes agregar métodos para añadir elementos si lo deseas.
}

public class FacturacionTest {
    private Factura factura;
    private LocalDate fechaEmision;
    private DummyAerolinea dummyAerolinea;

    @BeforeEach
    public void setUp() {
        fechaEmision = LocalDate.now();
        dummyAerolinea = new DummyAerolinea("Aerolínea Dummy");
        factura = new Factura(fechaEmision, dummyAerolinea);
    }

    @Test
    public void testConstructor() {
        // Verifica que la fecha de emisión se establezca correctamente
        assertEquals(fechaEmision, factura.verFechaEmision(), "La fecha de emisión debe ser la asignada");
        // Verifica que el estado inicial sea PENDIENTE
        assertEquals(EstadoPago.PENDIENTE, factura.getEstadoPago(), "El estado inicial debe ser PENDIENTE");
        // Verifica que la factura tenga un identificador formateado correctamente
        assertTrue(factura.getInvoiceIdentifier().startsWith("F-"), "El identificador de factura debe empezar con 'F-'");
        // Verifica que inicialmente no existan vuelos cobrados
        assertTrue(factura.getVuelosCobrados().isEmpty(), "No debe haber vuelos cobrados inicialmente");
    }

    @Test
    public void testAgregarYDesvincularAerolinea() {
        // Crea una factura sin aerolínea
        Factura facturaSinAero = new Factura(fechaEmision, null);
        // Agregar la aerolínea
        facturaSinAero.agregarAerolinea(dummyAerolinea);
        // Como en la prueba dummy el método vincularFactura no hace nada, se asume que se ha asignado la aerolínea
        assertEquals("Aerolínea Dummy", facturaSinAero.getAirline(), "La aerolínea debería haberse agregado");

        // Desvincular la aerolínea
        facturaSinAero.desvincularAerolinea(dummyAerolinea);
        // Tras la desvinculación, si se implementa correctamente, el valor debería ser null
        // Dado que getAirline() utiliza la aerolínea, se puede verificar con toString o comprobando internamente
        // Para efectos de la prueba, se puede comprobar que toString no contenga el nombre de la aerolínea.
        assertFalse(facturaSinAero.toString().contains("Aerolínea Dummy"), "La aerolínea no debe estar vinculada tras la desvinculación");
    }

    @Test
    public void testAñadirVueloACobro() {
        DummyVuelo dummyVuelo = new DummyVuelo();
        factura.añadirVueloACobro(dummyVuelo);
        // Verifica que el vuelo se haya añadido a la lista
        List<Vuelo> vuelosCobrados = factura.getVuelosCobrados();
        assertEquals(1, vuelosCobrados.size(), "Debe haber 1 vuelo cobrado");
        // Verifica que el método vueloCobrado se haya llamado (la bandera dummy cambia a true)
        assertTrue(dummyVuelo.isCobrado(), "El vuelo debe estar marcado como cobrado");
    }

    @Test
    public void testFacturaPagadaSinUsuarioLogueado() {
        // Suponiendo que Aplicacion.init("acceso").getUsuarioLogueado() devuelva null en el entorno de pruebas
        // Al invocar facturaPagada no se debe cambiar el estado de la factura
        factura.facturaPagada();
        assertEquals(EstadoPago.PENDIENTE, factura.getEstadoPago(), "Si no hay usuario logueado, la factura debe seguir PENDIENTE");
    }
    
    // Puedes agregar más tests, por ejemplo, para los métodos getBasePrice, getCompanyName, getPrice, etc.
    // Considera utilizar frameworks como Mockito para simular el comportamiento de Aplicacion y sus dependencias.
}
