package interfaz.menuInicio.enums;

public enum ComandoInicioEnum {
    NUEVA_APLICACION,
    CARGAR_APLICACION,

    //Menu 'Nueva Aplicacion'
    AUTORRELLENAR,
    CONFIRMAR,
    CANCELAR
}
