package interfaz.menuInicio.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.InicioAplicacionFrame;
import interfaz.login.controlador.ControlPanelLoginFrame;
import interfaz.login.vista.PanelLoginFrame;
import interfaz.menuInicio.enums.ComandoInicioEnum;
import interfaz.menuInicio.menuNuevaAplicacion.controlador.ControlPanelNuevaAplicacion;
import interfaz.menuInicio.menuNuevaAplicacion.vista.PanelNuevaAplicacion;
import interfaz.menuInicio.vista.PanelInicioAplicacion;

public class ControlPanelInicioAplicacion implements ActionListener {

    private PanelInicioAplicacion vista;
    private InicioAplicacionFrame inicioFrame;

    public ControlPanelInicioAplicacion(PanelInicioAplicacion vista, InicioAplicacionFrame frame) {
        this.vista = vista;
        this.inicioFrame = frame;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoInicioEnum comando = ComandoInicioEnum.valueOf(e.getActionCommand());

        // Procesar el comando
        switch (comando) {
            case NUEVA_APLICACION:
                PanelNuevaAplicacion panelNueva = new PanelNuevaAplicacion();
                new ControlPanelNuevaAplicacion(panelNueva, inicioFrame); 

                inicioFrame.mostrarContenido(panelNueva); 
                break;
            case CARGAR_APLICACION:
                //JOptionPane.showMessageDialog(vista, "Funcionalidad para cargar aplicación aún no implementada.", "Cargar Aplicación", JOptionPane.INFORMATION_MESSAGE);

                if(!Aplicacion.init("").cargarAplicacion("aeropuerto.txt")){
                    panelNueva = new PanelNuevaAplicacion();
                    new ControlPanelNuevaAplicacion(panelNueva, inicioFrame); 

                    inicioFrame.mostrarContenido(panelNueva); 
                    break;
                }

                PanelLoginFrame loginFrame = new PanelLoginFrame();
                new ControlPanelLoginFrame(loginFrame); // conecta el controlador
                loginFrame.setVisible(true);

                inicioFrame.dispose(); // Cierra el frame de inicio
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Acción desconocida.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
