/*
 * Compilar
 * 
 * 1. javac -d bin -sourcepath src -cp "lib/*" $(find src -name "*.java")
 * 2. java -cp "bin:lib/*" interfaz.menuInicio.vista.PanelInicioAplicacion
 */

package interfaz.menuInicio.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;

import interfaz.componentes.InicioAplicacionFrame;
import interfaz.menuInicio.controlador.ControlPanelInicioAplicacion;
import interfaz.menuInicio.enums.ComandoInicioEnum;

public class PanelInicioAplicacion extends JPanel {

    private JButton botonNuevaAplicacion;
    private JButton botonCargarAplicacion;

    public PanelInicioAplicacion() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(100, 50, 100, 50));

        JLabel titulo = new JLabel("🛫 Sistema de Gestión Aeroportuaria");
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(titulo);

        add(Box.createVerticalStrut(50));

        botonNuevaAplicacion = crearBotonMenu("NUEVA APLICACIÓN", ComandoInicioEnum.NUEVA_APLICACION.name());
        add(botonNuevaAplicacion);

        add(Box.createVerticalStrut(20));

        botonCargarAplicacion = crearBotonMenu("CARGAR APLICACIÓN", ComandoInicioEnum.CARGAR_APLICACION.name());
        add(botonCargarAplicacion);
    }

    private JButton crearBotonMenu(String texto, String comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando);
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        boton.setMaximumSize(new Dimension(400, 50));
        boton.setFont(new Font("Arial", Font.PLAIN, 18));
        return boton;
    }

    public void setControlador(ActionListener c) {
        botonNuevaAplicacion.addActionListener(c);
        botonCargarAplicacion.addActionListener(c);
    }

    // TODO: Poner el main en un main de verdad y no en la vista.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InicioAplicacionFrame frame = new InicioAplicacionFrame();

            PanelInicioAplicacion panelInicio = new PanelInicioAplicacion();
            new ControlPanelInicioAplicacion(panelInicio, frame); // Conecta controlador

            frame.mostrarContenido(panelInicio);
            frame.setVisible(true);
        });
    }
}
