package interfaz.menuInicio.menuNuevaAplicacion.controlador;

import javax.swing.*;

import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.InicioAplicacionFrame;
import interfaz.login.controlador.ControlPanelLoginFrame;
import interfaz.login.vista.PanelLoginFrame;
import interfaz.menuInicio.controlador.ControlPanelInicioAplicacion;
import interfaz.menuInicio.enums.ComandoInicioEnum;
import interfaz.menuInicio.menuNuevaAplicacion.vista.PanelNuevaAplicacion;
import interfaz.menuInicio.vista.PanelInicioAplicacion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelNuevaAplicacion implements ActionListener {

    private PanelNuevaAplicacion vista;
    private InicioAplicacionFrame frameInicio;

    public ControlPanelNuevaAplicacion(PanelNuevaAplicacion vista, InicioAplicacionFrame frameInicio) {
        this.vista = vista;
        this.frameInicio = frameInicio;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoInicioEnum comando = ComandoInicioEnum.valueOf(e.getActionCommand());

        // Procesar el comando
        switch (comando) {
            case AUTORRELLENAR:
                vista.autorrellenarCampos();
                break;
            case CONFIRMAR:
            System.out.println("Confirmar");
                procesarCreacion();
                break;
            case CANCELAR:
                System.out.println("Cancelar");
                PanelInicioAplicacion panelInicio = new PanelInicioAplicacion();
                new ControlPanelInicioAplicacion(panelInicio, frameInicio);
                frameInicio.mostrarContenido(panelInicio);
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Acción desconocida.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void procesarCreacion() {
        try {
            // 1. Validación y creación del gestor
            Aplicacion app = Aplicacion.init("aeropuerto");
        
            boolean gestorCreado = app.crearGestor(
                vista.getUsuario(),
                vista.getContrasena(),
                vista.getDNI(),
                vista.getNombreGestor(),
                vista.getEmail()
            );
        
            if (!gestorCreado) {
                JOptionPane.showMessageDialog(vista, "No se pudo crear el gestor. Revisa los datos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        
            // 2. Creación del aeropuerto
            boolean aeropuertoCreado = app.crearAeropuertoPropio(
                vista.getNombreAeropuerto(),
                vista.getPrecioBase(),
                vista.getCiudad(),
                vista.getDistancia(),
                vista.getDireccion(),
                vista.getCodigo(),
                vista.getHoraApertura(),
                vista.getHoraCierre(),
                vista.getUsuario()
            );
        
            if (!aeropuertoCreado) {
                JOptionPane.showMessageDialog(vista, "No se pudo crear el aeropuerto. Revisa los datos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        
            // 3. Éxito
            JOptionPane.showMessageDialog(vista, "Aplicación inicializada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(app);
        
            // Ir a pantalla de login
            PanelLoginFrame login = new PanelLoginFrame();
            new ControlPanelLoginFrame(login);
            login.setVisible(true);

            // Cerrar la ventana actual si es necesario
            frameInicio.dispose();
        
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(vista, "" + ex.getMessage(), "Campo inválido", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(vista, "Error inesperado. Verifica los campos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
