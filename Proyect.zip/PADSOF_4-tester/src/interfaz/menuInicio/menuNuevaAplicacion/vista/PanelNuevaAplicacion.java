package interfaz.menuInicio.menuNuevaAplicacion.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfaz.menuInicio.enums.ComandoInicioEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.util.Calendar;

public class PanelNuevaAplicacion extends JPanel {

    // Gestor
    private JTextField campoNombreGestor;
    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JTextField campoDNI;
    private JTextField campoEmail;

    // Aeropuerto
    private JTextField campoNombreAeropuerto;
    private JSpinner campoPrecioBase;
    private JTextField campoCiudad;
    private JSpinner campoDistancia;
    private JTextField campoDireccion;
    private JTextField campoCodigo;
    private JSpinner spinnerHoraApertura;
    private JSpinner spinnerHoraCierre;

    // Botones
    private JButton botonAutorellenar;
    private JButton botonConfirmar;
    private JButton botonCancelar;

    public PanelNuevaAplicacion() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50));

        // Gestor
        add(crearTitulo("Crear Gestor Principal"));
        campoNombreGestor = crearCampo("Nombre del Gestor");
        add(campoNombreGestor);

        campoUsuario = crearCampo("Usuario");
        add(campoUsuario);

        campoContrasena = new JPasswordField();
        campoContrasena.setMaximumSize(new Dimension(400, 30));
        campoContrasena.setAlignmentX(Component.CENTER_ALIGNMENT);
        campoContrasena.setToolTipText("Contraseña");
        añadirPlaceholder(campoContrasena, "Contraseña");
        add(Box.createVerticalStrut(10));
        add(campoContrasena);

        campoDNI = crearCampo("DNI");
        add(campoDNI);

        campoEmail = crearCampo("Email");
        add(campoEmail);

        // Aeropuerto
        add(Box.createVerticalStrut(30));
        add(crearTitulo("Crear Aeropuerto"));

        campoNombreAeropuerto = crearCampo("Nombre del Aeropuerto");
        add(campoNombreAeropuerto);

        campoCiudad = crearCampo("Ciudad más cercana");
        add(campoCiudad);

        campoDireccion = crearCampo("Dirección");
        add(campoDireccion);

        campoCodigo = crearCampo("Código IATA");
        add(campoCodigo);

        campoPrecioBase = crearSpinnerDouble(1000, 0, 100000, 100);
        add(crearEtiqueta("Precio base"));
        add(campoPrecioBase);
        add(Box.createVerticalStrut(10));

        campoDistancia = crearSpinner(0, 0, 500, 1);
        add(crearEtiqueta("Distancia a ciudad (km)"));
        add(campoDistancia);
        add(Box.createVerticalStrut(10));

        add(Box.createVerticalStrut(20));

        // Hora apertura
        spinnerHoraApertura = new JSpinner(new SpinnerDateModel());
        spinnerHoraApertura.setEditor(new JSpinner.DateEditor(spinnerHoraApertura, "HH:mm"));
        spinnerHoraApertura.setMaximumSize(new Dimension(400, 30));
        add(new JLabel("Hora de apertura"));
        add(spinnerHoraApertura);

        spinnerHoraCierre = new JSpinner(new SpinnerDateModel());
        spinnerHoraCierre.setEditor(new JSpinner.DateEditor(spinnerHoraCierre, "HH:mm"));
        spinnerHoraCierre.setMaximumSize(new Dimension(400, 30));
        add(new JLabel("Hora de cierre"));
        add(spinnerHoraCierre);

        add(Box.createVerticalStrut(20));

        // Panel de botones final
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.setBackground(Color.WHITE);

        botonAutorellenar = new JButton("Autorrellenar");
        botonAutorellenar.setActionCommand(ComandoInicioEnum.AUTORRELLENAR.name());

        botonConfirmar = new JButton("Confirmar");
        botonConfirmar.setActionCommand(ComandoInicioEnum.CONFIRMAR.name());

        botonCancelar = new JButton("Cancelar");
        botonCancelar.setActionCommand(ComandoInicioEnum.CANCELAR.name());

        panelBotones.add(botonAutorellenar);
        panelBotones.add(botonConfirmar);
        panelBotones.add(botonCancelar);

        add(panelBotones);
    }

    private JLabel crearTitulo(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalStrut(10));
        return label;
    }

    private JTextField crearCampo(String placeholder) {
        JTextField campo = new JTextField();
        campo.setMaximumSize(new Dimension(400, 30));
        campo.setAlignmentX(Component.CENTER_ALIGNMENT);
        campo.setToolTipText(placeholder);
        añadirPlaceholder(campo, placeholder);
        return campo;
    }

    // ========================
    // MÉTODOS MVC
    // ========================

    public void setControlador(ActionListener c) {
        botonAutorellenar.addActionListener(c);
        botonConfirmar.addActionListener(c);
        botonCancelar.addActionListener(c);
    }


    /**
     * Autorrellena todos los campos con datos de ejemplo.
     */
    public void autorrellenarCampos() {
        // Gestor
        campoNombreGestor.setText("Angel Dal");
        campoUsuario.setText("angel");
        campoContrasena.setText("123");
        campoDNI.setText("55242141M");
        campoEmail.setText("angel.dal@estudiante.uam.es");

        // Aeropuerto
        campoNombreAeropuerto.setText("Adolfo Suárez Madrid-Barajas");
        campoCiudad.setText("Madrid");
        campoDireccion.setText("Barajas, 28042 Madrid");
        campoCodigo.setText("MAD");
        campoPrecioBase.setValue(2500.0);
        campoDistancia.setValue(5);

        // Horarios
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 4);
        cal.set(Calendar.MINUTE, 0);
        spinnerHoraApertura.setValue(cal.getTime());

        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 30);
        spinnerHoraCierre.setValue(cal.getTime());
    }

    // Gestor
    public String getNombreGestor() {
        return validarCampo(campoNombreGestor, "Nombre del Gestor");
    }

    public String getUsuario() {
        return validarCampo(campoUsuario, "Usuario");
    }

    public String getContrasena() {
        String texto = new String(campoContrasena.getPassword()).trim();
        if (texto.isEmpty()) throw new IllegalArgumentException("Contraseña no puede estar vacía.");
        return texto;
    }

    public String getDNI() {
        return validarCampo(campoDNI, "DNI");
    }

    public String getEmail() {
        return validarCampo(campoEmail, "Email");
    }

     // AEROPUERTO
     public String getNombreAeropuerto() {
        return validarCampo(campoNombreAeropuerto, "Nombre del Aeropuerto");
    }

    public double getPrecioBase() {
        return (double) campoPrecioBase.getValue();
    }

    public String getCiudad() {
        return validarCampo(campoCiudad, "Ciudad más cercana");
    }

    public int getDistancia() {
        return (int) campoDistancia.getValue();
    }

    public String getDireccion() {
        return validarCampo(campoDireccion, "Dirección");
    }

    public String getCodigo() {
        return validarCampo(campoCodigo, "Código IATA");
    }

    public LocalTime getHoraApertura() {
        return LocalTime.parse(new java.text.SimpleDateFormat("HH:mm").format(spinnerHoraApertura.getValue()));
    }

    public LocalTime getHoraCierre() {
        return LocalTime.parse(new java.text.SimpleDateFormat("HH:mm").format(spinnerHoraCierre.getValue()));
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private String validarCampo(JTextField campo, String placeholder) {
        String texto = campo.getText().trim();
        if (texto.isEmpty() || texto.equals(placeholder)) {
            throw new IllegalArgumentException("El campo '" + placeholder + "' no puede estar vacío.");
        }
        return texto;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        spinner.setAlignmentX(Component.CENTER_ALIGNMENT);
        return spinner;
    }

    private JSpinner crearSpinnerDouble(double value, double min, double max, double step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        spinner.setAlignmentX(Component.CENTER_ALIGNMENT);
        return spinner;
    }

    private void añadirPlaceholder(JTextField campo, String placeholder) {
        campo.setForeground(Color.GRAY);
        campo.setText(placeholder);
    
        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(placeholder)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }
    
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(placeholder);
                }
            }
        });
    }
}
