package interfaz.controlador.primeraPantalla.aterrizarAvion.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;

import funcionalidad.aeropuerto.elementos.Aparcamiento;
import funcionalidad.aeropuerto.elementos.Puerta;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.ControladorAereo;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.primeraPantalla.aterrizarAvion.vista.PanelAterrizarAvion;
import interfaz.controlador.primeraPantalla.controlador.ControlPanelControlarAterrizajes;
import interfaz.controlador.primeraPantalla.vista.PanelControlarAterrizajes;

public class ControlPanelAterrizarAvion implements ActionListener {
    private final PanelAterrizarAvion vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelAterrizarAvion(PanelAterrizarAvion vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("");
        this.vista.getBtnAprobar().addActionListener(this);
        actualizarDatos();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnAprobar()) {
            Vuelo v = aplicacion.buscarVueloxCodigo(codigo);
            Aparcamiento aparcamiento = aplicacion.getAeropuertoPropio().getAparcamiento((String) vista.getComboAparcamiento().getSelectedItem());
            Puerta puerta = ((ControladorAereo) aplicacion.getUsuarioLogueado()).getTerminal().getPuerta((String) vista.getComboPuerta().getSelectedItem());

            if (aparcamiento == null || puerta == null) {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione un aparcamiento y una puerta.");
                return;
            }

            if (v == null) {
                JOptionPane.showMessageDialog(null, "Error inesperado.");
                return;
            }

            // Asignar el aparcamiento y la puerta al vuelo
            try {
                v.autorizarAterrizajeCambioEstado(aparcamiento, puerta);
                JOptionPane.showMessageDialog(null, "Asignación exitosa");
                System.out.println("→ Aparcamiento asignado: " + aparcamiento.getNombre());
                System.out.println("→ Puerta asignada: " + puerta.getNombre());
                volver();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error al asignar el aparcamiento y la puerta: " + ex.getMessage());
            }
        }
    }

    private void actualizarDatos() {
        List<Aparcamiento> aparcamientos = aplicacion.getAeropuertoPropio().getAparcamientosApropiado(aplicacion.buscarVueloxCodigo(codigo).getAvion());
        List<Puerta> puertas = ((ControladorAereo) aplicacion.getUsuarioLogueado()).getTerminal().getPuertas();

        for (Aparcamiento aparcamiento : aparcamientos) {
            vista.añadirAparcamiento(aparcamiento.getNombre());
        }

        for (Puerta puerta : puertas) {
            vista.añadirPuerta(puerta.getNombre());
        }
    }

    private void volver(){
        // Volver a la pantala de aterrizajes
        PanelControlarAterrizajes panelControlarAterrizajes = new PanelControlarAterrizajes(pantalla);
        new ControlPanelControlarAterrizajes(panelControlarAterrizajes);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarAterrizajes);
    }
}
