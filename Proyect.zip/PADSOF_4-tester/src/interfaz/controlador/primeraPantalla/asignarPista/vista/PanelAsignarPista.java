package interfaz.controlador.primeraPantalla.asignarPista.vista;

import javax.swing.*;

import interfaz.componentes.PantallaBase;

import java.awt.*;

public class PanelAsignarPista extends JPanel {
    private PantallaBase pantallaBase;

    private JComboBox<String> comboPista;
    private JButton btnAprobar;

    public PanelAsignarPista(PantallaBase pantallaBase, String codigo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("✈️ Vuelo con codigo: " + codigo + " pendiente de asignar pista.", Font.BOLD, 18));
        add(Box.createVerticalStrut(10));

        add(Box.createVerticalStrut(20));

        // Combo de pistas
        comboPista = new JComboBox<>(new String[]{"Seleccionar Pista"});
        comboPista.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(new JLabel("Selecciona Pista:"));
        add(comboPista);

        add(Box.createVerticalStrut(10));

        add(Box.createVerticalStrut(20));

        // Botones
        btnAprobar = new JButton("Asignar Pista");

        btnAprobar.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(btnAprobar);
        add(Box.createVerticalStrut(10));
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public JComboBox<String> getComboPista() {
        return comboPista;
    }

    public JButton getBtnAprobar() {
        return btnAprobar;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void añadirPista(String pista) {
        comboPista.addItem(pista);
    }    
}
