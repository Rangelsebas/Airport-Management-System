package interfaz.controlador.primeraPantalla.pasarHangarOperativo.enums;

public enum ComandoPasarHangarOperativo {
    DEJAR_OPERATIVO,
    METER_EN_HANGAR
}
