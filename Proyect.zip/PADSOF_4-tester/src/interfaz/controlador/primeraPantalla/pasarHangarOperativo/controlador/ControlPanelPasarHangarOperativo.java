package interfaz.controlador.primeraPantalla.pasarHangarOperativo.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.aeropuerto.elementos.Hangar;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.primeraPantalla.controlador.ControlPanelControlarAterrizajes;
import interfaz.controlador.primeraPantalla.pasarHangarOperativo.enums.ComandoPasarHangarOperativo;
import interfaz.controlador.primeraPantalla.pasarHangarOperativo.vista.PanelPasarHangarOperativo;
import interfaz.controlador.primeraPantalla.vista.PanelControlarAterrizajes;

public class ControlPanelPasarHangarOperativo implements ActionListener {
    private final PanelPasarHangarOperativo vista;
    private final PantallaBase pantalla;
    private final Vuelo vuelo;
    private Aplicacion aplicacion;

    public ControlPanelPasarHangarOperativo(PanelPasarHangarOperativo vista, PantallaBase pantalla, Vuelo vuelo) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vuelo = vuelo;
        this.aplicacion = Aplicacion.init("acceder");
        this.vista.setControlador(this);
        actualizarDatos();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoPasarHangarOperativo comando = ComandoPasarHangarOperativo.valueOf(e.getActionCommand());

        switch (comando) {
            case DEJAR_OPERATIVO:
                dejarOperrativo();
                volver();
                break;
            case METER_EN_HANGAR:
                meterEnHangar();
                volver();
                break;
        }
    }

    private void dejarOperrativo() {
        if (vuelo == null) {
            JOptionPane.showMessageDialog(vista, "No hay vuelo seleccionado para dejar operativo.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (vuelo.mantenerAvionOperativo()) {
            JOptionPane.showMessageDialog(vista, "Avión dejado operativo exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo dejar el avión operativo.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void meterEnHangar() {
        if (vuelo == null) {
            JOptionPane.showMessageDialog(vista, "No hay vuelo seleccionado para meter en hangar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Hangar hangar = aplicacion.getAeropuertoPropio().getHangar((String) vista.getComboHangares().getSelectedItem());

        if (hangar == null) {
            JOptionPane.showMessageDialog(vista, "Hangar no válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (vuelo.guardarAvionEnHangar(hangar)) {
            JOptionPane.showMessageDialog(vista, "Avión metido en hangar exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo meter el avión en hangar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarDatos() {
        // Actualizar la lista de hangares
        vista.getComboHangares().removeAllItems();
        for (Hangar hangar : aplicacion.getAeropuertoPropio().getHangaresApropiados(vuelo.getAvion())) {
            vista.getComboHangares().addItem(hangar.getNombre());
        }
    }

    private void volver() {
        // Volver a la primera pantalla
        PanelControlarAterrizajes panelControlarEstadoVuelo = new PanelControlarAterrizajes(pantalla);
        new ControlPanelControlarAterrizajes(panelControlarEstadoVuelo);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarEstadoVuelo);
    }
}
