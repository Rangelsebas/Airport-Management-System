package interfaz.controlador.primeraPantalla.pasarHangarOperativo.vista;

import javax.swing.*;

import interfaz.componentes.PantallaBase;
import interfaz.controlador.primeraPantalla.pasarHangarOperativo.enums.ComandoPasarHangarOperativo;
import funcionalidad.vuelo.Vuelo;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelPasarHangarOperativo extends JPanel {

    private PantallaBase pantallaBase;
    private JLabel infoVueloLabel;
    private JButton botonDejarOperativo;
    private JButton botonMeterEnHangar;
    private JComboBox<String> comboHangares;

    public PanelPasarHangarOperativo(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Información del Vuelo");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createVerticalStrut(20));
        add(titulo);
        add(Box.createVerticalStrut(20));

        infoVueloLabel = new JLabel();
        infoVueloLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        infoVueloLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        infoVueloLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(infoVueloLabel);

        add(Box.createVerticalStrut(30));

        botonDejarOperativo = new JButton("Dejar avión operativo");
        botonMeterEnHangar = new JButton("Meter avión en hangar");

        botonDejarOperativo.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonMeterEnHangar.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Combo de hangares
        comboHangares = new JComboBox<>(new String[]{"Seleccionar Hangar"});
        comboHangares.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(new JLabel("Selecciona hangar:"));
        add(comboHangares);

        add(Box.createVerticalStrut(10));

        add(botonDejarOperativo);
        add(Box.createVerticalStrut(10));
        add(botonMeterEnHangar);
    }

    public void mostrarInformacionVuelo(Vuelo vuelo) {
        if (vuelo == null) {
            infoVueloLabel.setText("No se encontró un vuelo con ese código.");
            botonDejarOperativo.setVisible(false);
            botonMeterEnHangar.setVisible(false);
            return;
        }

        String resumen = "<html><b>Código:</b> " + vuelo.getCodigoVuelo()
                + " | <b>Estado:</b> " + vuelo.getEstado().name()
                + " | <b>Origen:</b> " + vuelo.getOrigen().getNombre()
                + " | <b>Destino:</b> " + vuelo.getDestino().getNombre()
                + " | <b>Aerolíneas:</b> " + vuelo.getAerolineaOperadora().getNombre()
                + "</html>";

        infoVueloLabel.setText(resumen);
    }

    public void setControlador(ActionListener c) {
        botonDejarOperativo.setActionCommand(ComandoPasarHangarOperativo.DEJAR_OPERATIVO.name());
        botonMeterEnHangar.setActionCommand(ComandoPasarHangarOperativo.METER_EN_HANGAR.name());

        botonDejarOperativo.addActionListener(c);
        botonMeterEnHangar.addActionListener(c);
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public JButton getBotonDejarOperativo() {
        return botonDejarOperativo;
    }

    public JButton getBotonMeterEnHangar() {
        return botonMeterEnHangar;
    }

    public JComboBox<String> getComboHangares() {
        return comboHangares;
    }

    public void añadirHangar(String hangar) {
        comboHangares.addItem(hangar);
    }

}
