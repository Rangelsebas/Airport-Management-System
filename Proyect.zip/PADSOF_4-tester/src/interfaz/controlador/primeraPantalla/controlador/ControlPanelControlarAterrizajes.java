package interfaz.controlador.primeraPantalla.controlador;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.ControladorAereo;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.primeraPantalla.asignarPista.controlador.ControlPanelAsignarPista;
import interfaz.controlador.primeraPantalla.asignarPista.vista.PanelAsignarPista;
import interfaz.controlador.primeraPantalla.aterrizarAvion.controlador.ControlPanelAterrizarAvion;
import interfaz.controlador.primeraPantalla.aterrizarAvion.vista.PanelAterrizarAvion;
import interfaz.controlador.primeraPantalla.pasarHangarOperativo.controlador.ControlPanelPasarHangarOperativo;
import interfaz.controlador.primeraPantalla.pasarHangarOperativo.vista.PanelPasarHangarOperativo;
import interfaz.controlador.primeraPantalla.vista.PanelControlarAterrizajes;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.format.DateTimeFormatter;

public class ControlPanelControlarAterrizajes {

    private final PanelControlarAterrizajes vista;
    private final PantallaBase pantalla;
    private ControladorAereo ca;

    public ControlPanelControlarAterrizajes(PanelControlarAterrizajes vista/*, List<SolicitudVuelo> solicitudes */) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.ca = (ControladorAereo) Aplicacion.init("").getUsuarioLogueado();

        if (ca.getVuelosPendientesAterrizar().isEmpty()) {
            vista.añadirSolicitud("No hay vuelos que atender");
        } else {
            for (Vuelo vuelo : ca.getVuelosPendientesAterrizar()) {
                String texto = "Codigo del vuelo: " + vuelo.getCodigoVuelo() + " | Aerolinea: " + vuelo.getAerolineaOperadora().getNombre() + " | Fecha: " + vuelo.getFecha() + 
                " | " + vuelo.getHoraSalida().format(DateTimeFormatter.ofPattern("HH:mm")) + " - " + vuelo.getHoraLlegada().format(DateTimeFormatter.ofPattern("HH:mm")) + 
                " | " + vuelo.getOrigen().getNombre() + " - " + vuelo.getDestino().getNombre() + " | Estado : " + vuelo.getEstado() + " | Retraso: " + (vuelo.getEnTiempo()? "No" : "Si") + "\n";
                vista.añadirSolicitud(texto);
            }
            
            vista.getListaSolicitudes().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent evt) {
                    if (evt.getClickCount() == 2) {
                        int index = vista.getListaSolicitudes().locationToIndex(evt.getPoint());
                        
                        if (index >= 0) {
                            String texto = vista.getListaSolicitudes().getModel().getElementAt(index);
                            String codigo = getCodigo(texto);

                            Vuelo vuelo = Aplicacion.init("").buscarVueloxCodigo(codigo);
                            
                            switch (vuelo.getEstado()) {
                                case ESPERANDO_PISTA_ATERRIZAJE:
                                    PanelAsignarPista panelAsignarPista = new PanelAsignarPista(pantalla, codigo);
                                    new ControlPanelAsignarPista(panelAsignarPista, codigo, pantalla);
                                    pantalla.mostrarContenidoEnPanelCentral(panelAsignarPista);
                                    break;
                                        
                                case ESPERANDO_ATERRIZAR:
                                    PanelAterrizarAvion panelAterrizarAvion = new PanelAterrizarAvion(pantalla, codigo);
                                    new ControlPanelAterrizarAvion(panelAterrizarAvion, codigo, pantalla);
                                    pantalla.mostrarContenidoEnPanelCentral(panelAterrizarAvion);
                                    break;

                                case OPERATIVO:
                                    PanelPasarHangarOperativo panelPasarHangarOperativo = new PanelPasarHangarOperativo(pantalla);
                                    new ControlPanelPasarHangarOperativo(panelPasarHangarOperativo, pantalla, vuelo);
                                    pantalla.mostrarContenidoEnPanelCentral(panelPasarHangarOperativo);
                                    break;
                            
                                default:
                                    break;
                            }
                        }
                    }
                }
            });
        }
    }
    
    private String getCodigo(String texto){
        String clave = "Codigo del vuelo:";
        int pos = texto.indexOf(clave);
        String codigo = "";

        if (pos != -1) {
            // comenzamos justo tras la clave
            int start = pos + clave.length();
            // buscamos el siguiente separador " |"
            int end = texto.indexOf("|", start);
            if (end == -1) {
                // si no hay barra, cogemos hasta el cierre del div
                end = texto.indexOf("<", start);
            }
            codigo = texto.substring(start, end).trim();
        }

        return codigo;
    }
}
