package interfaz.controlador.cuartaPantalla.vista;

import javax.swing.*;

import interfaz.componentes.PantallaBase;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelVerCola extends JPanel {

    private PantallaBase pantallaBase;
    private JComboBox<String> comboPistas;
    private JButton botonVerCola;

    public PanelVerCola(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("Selecciona una pista para ver la cola de vuelos.", Font.BOLD, 18));
        add(Box.createVerticalStrut(10));

        add(Box.createVerticalStrut(20));

        // Combo de pistas
        comboPistas = new JComboBox<>(new String[]{"Seleccionar Pista"});
        comboPistas.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(new JLabel("Selecciona Pista:"));
        add(comboPistas);

        add(Box.createVerticalStrut(10));

        add(Box.createVerticalStrut(20));

        // Botones
        botonVerCola = new JButton("Ver la cola de la pista");

        botonVerCola.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(botonVerCola);
        add(Box.createVerticalStrut(10));
    }

    public void setActionListener(ActionListener a) {
        botonVerCola.addActionListener(a);
    }

    public void añadirPista(String pista) {
        comboPistas.addItem(pista);
    }

    public JComboBox<String> getComboPistas() {
        return comboPistas;
    }

    public JButton getBotonVerCola() {
        return botonVerCola;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }
}