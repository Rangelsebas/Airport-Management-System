package interfaz.controlador.cuartaPantalla.verColaPista.controlador;

import java.util.Deque;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.controlador.cuartaPantalla.verColaPista.vista.PanelVerColaPista;

public class ControlPanelVerColaPista {
    private PanelVerColaPista vista;
    private Aplicacion aplicacion;
    private String nombrePista;

    public ControlPanelVerColaPista(PanelVerColaPista vista, String nombrePista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("");
        this.nombrePista = nombrePista;
        actualizarCola();
    }

    private void actualizarCola() {
        vista.reset();
        Deque<Vuelo> cola = aplicacion.getAeropuertoPropio().getPista(nombrePista).verCola();
        int contador = 1;
        System.out.println("Cola de la pista " + nombrePista + ":\n" + cola + "\n");
        if (cola.isEmpty()) {
            vista.agregarVuelo("No hay vuelos en cola para la pista " + nombrePista);
        } else {
            for (Vuelo vuelo : cola) {
                vista.agregarVuelo("Posicion en la cola: " + contador + " vuelo con codigo " + vuelo.getCodigoVuelo() + " con destino " + vuelo.getDestino().getNombre() + " y origen " + vuelo.getOrigen().getNombre()
                + " con estado " + vuelo.getEstado() + " con fecha de salida " + vuelo.getFecha() + " hora de salida " + vuelo.getHoraSalida() + "." 
                + " hora de llegada " + vuelo.getHoraLlegada() + "." + " Avion " + vuelo.getAvion().getMatricula() + "."
                );
                contador++;
            }
        }
    }
}
