package interfaz.controlador.cuartaPantalla.verColaPista.vista;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class PanelVerColaPista extends JPanel {
    
    private JPanel panelListado;

    public PanelVerColaPista() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Título
        JLabel titulo = new JLabel("Cola", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Panel de listado
        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(900, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);
    }

    public void agregarVuelo(String vuelo) {
        String texto = "<html><div style='text-align: center; width:500px;'>" + vuelo + "</div></html>";
        JLabel vueloLabel = new JLabel(texto);
        vueloLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        vueloLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelvuelo = new JPanel();
        panelvuelo.setLayout(new BoxLayout(panelvuelo, BoxLayout.Y_AXIS));
        panelvuelo.setBackground(Color.WHITE);
        panelvuelo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelvuelo.add(vueloLabel);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelvuelo);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }
}
