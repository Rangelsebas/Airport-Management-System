package interfaz.controlador.cuartaPantalla.controlador;

import funcionalidad.aeropuerto.elementos.Pista;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.cuartaPantalla.verColaPista.controlador.ControlPanelVerColaPista;
import interfaz.controlador.cuartaPantalla.verColaPista.vista.PanelVerColaPista;
import interfaz.controlador.cuartaPantalla.vista.PanelVerCola;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class ControlPanelVerCola implements ActionListener {

    private PanelVerCola vista;
    private PantallaBase pantallaBase;
    private Aplicacion aplicacion;

    public ControlPanelVerCola(PanelVerCola vista, PantallaBase pantallaBase) {
        this.vista = vista;
        this.pantallaBase = pantallaBase;
        this.aplicacion = Aplicacion.init("");
        this.vista.setActionListener(this); 
        actualizarPistas();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBotonVerCola()) {
            String nombrePista = (String) vista.getComboPistas().getSelectedItem();
            PanelVerColaPista panelVerColaPista = new PanelVerColaPista();
            new ControlPanelVerColaPista(panelVerColaPista, nombrePista);
            pantallaBase.mostrarContenidoEnPanelCentral(panelVerColaPista);
        }
    }

    private void actualizarPistas() {
        List<Pista> pistas = aplicacion.getAeropuertoPropio().getPistas();
        for (Pista pista : pistas) {
            vista.añadirPista(pista.getNombre());
        }
    }

}
