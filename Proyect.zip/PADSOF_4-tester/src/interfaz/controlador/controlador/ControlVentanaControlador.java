package interfaz.controlador.controlador;

import java.awt.Component;
import java.awt.Panel;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.comunNotificaciones.controlador.ControlPanelVerNotificaciones;
import interfaz.comunNotificaciones.vista.PanelVerNotificaciones;
import interfaz.controlador.cuartaPantalla.controlador.ControlPanelVerCola;
import interfaz.controlador.cuartaPantalla.vista.PanelVerCola;
import interfaz.controlador.enums.ComandoVentanaControladorEnum;
import interfaz.controlador.primeraPantalla.controlador.ControlPanelControlarAterrizajes;
import interfaz.controlador.primeraPantalla.vista.PanelControlarAterrizajes;
import interfaz.controlador.segundaPantalla.controlador.ControlPanelControlarDespegues;
import interfaz.controlador.segundaPantalla.vista.PanelControlarDespegues;
import interfaz.controlador.terceraPantalla.controlador.ControlPanelEstadoVuelo;
import interfaz.controlador.terceraPantalla.vista.PanelControlarEstadoVuelo;
import interfaz.controlador.vista.VentanaControlador;
import interfaz.login.controlador.ControlPanelLoginFrame;
import interfaz.login.vista.PanelLoginFrame;

public class ControlVentanaControlador implements ActionListener {

    private VentanaControlador vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;  

    public ControlVentanaControlador(VentanaControlador vista) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
        actualizarFechaYHora();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaControladorEnum comando = ComandoVentanaControladorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONTROLAR_ATERRIZAJES:
                PanelControlarAterrizajes panelControlarAterrizajes = new PanelControlarAterrizajes(pantalla);
                new ControlPanelControlarAterrizajes(panelControlarAterrizajes);
                vista.mostrarPanel(panelControlarAterrizajes);
                break;

            case CONTROLAR_DESPEGUES:
                PanelControlarDespegues panelControlarDespegues = new PanelControlarDespegues(pantalla);
                new ControlPanelControlarDespegues(panelControlarDespegues);
                vista.mostrarPanel(panelControlarDespegues);
                break;

            case CONTROLAR_ESTADO_VUELO:
                PanelControlarEstadoVuelo panelControlarEstadoVuelo = new PanelControlarEstadoVuelo(pantalla);
                new ControlPanelEstadoVuelo(panelControlarEstadoVuelo, vista.getPantallaBase());
                vista.mostrarPanel(panelControlarEstadoVuelo);
                break;

            case VER_COLA:
                PanelVerCola panelVerCola = new PanelVerCola(pantalla);
                new ControlPanelVerCola(panelVerCola, vista.getPantallaBase());
                vista.mostrarPanel(panelVerCola);
                break;
            
            case VER_NOTIFICACIONES:
                PanelVerNotificaciones panelNotificaciones = new PanelVerNotificaciones(vista.getPantallaBase());
                new ControlPanelVerNotificaciones(panelNotificaciones); // conecta el controlador
                vista.mostrarPanel(panelNotificaciones);
                break;

            case GUARDAR_APLICACION:
                if(aplicacion.salvarAplicacion("aeropuerto.txt")) {
                    JOptionPane.showMessageDialog(vista, "Aplicación guardada correctamente.", "Guardar Aplicación", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(vista, "Error al guardar la aplicación.", "Guardar Aplicación", JOptionPane.ERROR_MESSAGE);
                }
                break;

            case CARGAR_APLICACION:
                if(aplicacion.cargarAplicacion("aeropuerto.txt")) {
                    JOptionPane.showMessageDialog(vista, "Aplicación cargada correctamente.", "Cargar Aplicación", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(vista, "Error al cargar la aplicación.", "Cargar Aplicación", JOptionPane.ERROR_MESSAGE);
                }

                // 🔥 Cerrar ventana actual
                Window ventana = SwingUtilities.getWindowAncestor((Component) e.getSource());
                cerrarSesionIrALogin(ventana);

                break;

            case CERRAR_SESION:
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Estás seguro que deseas cerrar sesión?",
                        "Cerrar sesión", JOptionPane.YES_NO_OPTION);

                if (respuesta == JOptionPane.YES_OPTION) {
                    // Cerrar sesión
                    cerrarSesionIrALogin(SwingUtilities.getWindowAncestor((Component) e.getSource()));
                } else {
                    System.out.println("No se ha cerrado la sesión.");
                }
                break;
            
            case AVANZAR_5M:
                aplicacion.avanzarCincoMinutos();
                JOptionPane.showMessageDialog(vista, "Tiempo avanzado 5 minutos.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Tiempo avanzado 5 minutos. Tiempo actual: " + aplicacion.getRealTime());
                actualizarFechaYHora();
                break;

            case AVANZAR_30M:
                aplicacion.avanzarTreintaMinutos();
                JOptionPane.showMessageDialog(vista, "Tiempo avanzado 30 minutos.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Tiempo avanzado 30 minutos. Tiempo actual: " + aplicacion.getRealTime());
                actualizarFechaYHora();
                break;

            case AVANZAR_1H:
                aplicacion.avanzarUnaHora();
                JOptionPane.showMessageDialog(vista, "Tiempo avanzado 1 hora.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Tiempo avanzado 1 hora. Tiempo actual: " + aplicacion.getRealTime());
                actualizarFechaYHora();
                break;

            case AVANZAR_1D:
                aplicacion.avanzarUnDia();
                JOptionPane.showMessageDialog(vista, "Tiempo avanzado 1 día.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Tiempo avanzado 1 día. Tiempo actual: " + aplicacion.getRealTime());
                actualizarFechaYHora();
                break;

            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void actualizarFechaYHora() {
        String fechaHora = aplicacion.getRealTime().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        pantalla.setFechaHora(fechaHora);
    }

    private void cerrarSesionIrALogin(Window ventana) {
        // Cerrar sesión
        aplicacion.cerrarSesion();
        System.out.println("Sesión cerrada correctamente.");

        // Cerrar ventana actual
        if (ventana != null) {
            ventana.dispose();
        }

        // Volver al login
        SwingUtilities.invokeLater(() -> {
            PanelLoginFrame loginFrame = new PanelLoginFrame();
            new ControlPanelLoginFrame(loginFrame); // conecta el controlador
            loginFrame.setVisible(true);
        });
    }
}