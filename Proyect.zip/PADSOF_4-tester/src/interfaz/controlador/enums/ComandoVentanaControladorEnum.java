package interfaz.controlador.enums;

public enum ComandoVentanaControladorEnum {
    CONTROLAR_ATERRIZAJES,
    CONTROLAR_DESPEGUES,
    CONTROLAR_ESTADO_VUELO,
    VER_COLA,
    VER_NOTIFICACIONES,
    GUARDAR_APLICACION,
    CARGAR_APLICACION,
    CERRAR_SESION,
        
    // Subcomandos de control de tiempo
    AVANZAR_5M,
    AVANZAR_30M,
    AVANZAR_1H,
    AVANZAR_1D
}