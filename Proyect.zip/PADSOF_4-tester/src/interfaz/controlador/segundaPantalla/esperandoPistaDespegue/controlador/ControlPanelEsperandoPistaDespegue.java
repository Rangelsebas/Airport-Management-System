package interfaz.controlador.segundaPantalla.esperandoPistaDespegue.controlador;

import java.util.List;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import funcionalidad.aeropuerto.elementos.Pista;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Uso;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.segundaPantalla.controlador.ControlPanelControlarDespegues;
import interfaz.controlador.segundaPantalla.esperandoPistaDespegue.vista.PanelEsperandoPistaDespegue;
import interfaz.controlador.segundaPantalla.vista.PanelControlarDespegues;

public class ControlPanelEsperandoPistaDespegue implements ActionListener {
    private final PanelEsperandoPistaDespegue vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelEsperandoPistaDespegue(PanelEsperandoPistaDespegue vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("");
        this.vista.getBtnAprobar().addActionListener(this);
        actualizarDatos();
    }

    private void actualizarDatos() {
        List<Pista> pistas = aplicacion.getAeropuertoPropio().getPistas();
        
        for (Pista pista : pistas) {
            if (pista.getUso() == Uso.DESPEGUE) {
                vista.añadirPista(pista.getNombre());
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnAprobar()) {
            String pista = (String) vista.getComboPista().getSelectedItem();

            if (pista == null) {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione una pista.");
                return;
            }

            Vuelo v = aplicacion.buscarVueloxCodigo(codigo);
            Pista pistaSeleccionada = aplicacion.getAeropuertoPropio().getPista(pista);

            if (v == null || pistaSeleccionada == null) {
                JOptionPane.showMessageDialog(null, "Error inesperado.");
                return;
            }

            try {
                if (v.asignarPistaDespegueCambioEstado(pistaSeleccionada)){
                    System.out.println("✅ Pista asignada:");
                    System.out.println("→ Pista asignada: " + pista);
                    JOptionPane.showMessageDialog(null, "Pista asignada correctamente.");
                    volver();
                }
            } catch (Exception x) {
                JOptionPane.showMessageDialog(null, "Error al asignar la pista: " + x.getMessage());
            }
        } 
    }

    private void volver(){
        // Volver a la pantala de aterrizajes
        PanelControlarDespegues panelControlarDespegues = new PanelControlarDespegues(pantalla);
        new ControlPanelControlarDespegues(panelControlarDespegues);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDespegues);
    }
}
