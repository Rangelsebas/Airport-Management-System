package interfaz.controlador.segundaPantalla.vista;

import javax.swing.*;

import interfaz.componentes.PantallaBase;

import java.awt.*;
import java.util.List;

public class PanelControlarDespegues extends JPanel {

    //TODO cambiar nombre de solicitudes a vuelos
    private final PantallaBase pantallaBase;
    private final DefaultListModel<String> modeloLista;
    private final JList<String> listaSolicitudes;
    private List<String> solicitudesActuales;

    public PanelControlarDespegues(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        this.modeloLista = new DefaultListModel<>();
        this.listaSolicitudes = new JList<>(modeloLista);
        //this.solicitudesActuales = new ArrayList<>();

        listaSolicitudes.setFont(new Font("Monospaced", Font.PLAIN, 13));
        listaSolicitudes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // ✅ Centrado visual de cada elemento
        DefaultListCellRenderer renderer = new DefaultListCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.CENTER);
        listaSolicitudes.setCellRenderer(renderer);

        JScrollPane scroll = new JScrollPane(listaSolicitudes);

        scroll.setBorder(BorderFactory.createEmptyBorder()); // sin bordes visibles
        listaSolicitudes.setBorder(BorderFactory.createEmptyBorder()); // sin marco interno

        listaSolicitudes.setBackground(Color.WHITE);
        scroll.getViewport().setBackground(Color.WHITE);

        scroll.setPreferredSize(new Dimension(900, 500));
        add(scroll, BorderLayout.CENTER);
    }

    public void añadirSolicitud(String solicitud) {
        String texto = "<html><div style='text-align: center; width:500px;'>" + "✈️ " + solicitud + "</div></html>";
        modeloLista.addElement(texto);
    }

    public JList<String> getListaSolicitudes() {
        return listaSolicitudes;
    }

    public List<String> getSolicitudesActuales() {
        return solicitudesActuales;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}