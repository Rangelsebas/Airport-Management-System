package interfaz.controlador.segundaPantalla.despegarAvion.vista;

import javax.swing.*;
import java.awt.*;

import interfaz.componentes.PantallaBase;

public class PanelDespegarAvion extends JPanel {
    private PantallaBase pantallaBase;
    private JButton btnAprobar;
    private JButton btnVolver;

    public PanelDespegarAvion(PantallaBase pantallaBase, String codigo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("✈️ Vuelo con codigo: " + codigo + " esperando orden para despegar.", Font.BOLD, 18));

        add(Box.createVerticalStrut(20));

        // Botones
        btnAprobar = new JButton("Autorizar despegue");

        btnAprobar.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(btnAprobar);
        add(Box.createVerticalStrut(10));
        btnVolver = new JButton("Volver");
        btnVolver.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(btnVolver);
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public JButton getBtnAprobar() {
        return btnAprobar;
    }

    public JButton getBtnVolver() {
        return btnVolver;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

}
