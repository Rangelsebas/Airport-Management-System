package interfaz.controlador.segundaPantalla.despegarAvion.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.segundaPantalla.controlador.ControlPanelControlarDespegues;
import interfaz.controlador.segundaPantalla.despegarAvion.vista.PanelDespegarAvion;
import interfaz.controlador.segundaPantalla.vista.PanelControlarDespegues;

public class ControlPanelDespegarAvion implements ActionListener{
    private final PanelDespegarAvion vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelDespegarAvion(PanelDespegarAvion vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("");
        this.vista.getBtnAprobar().addActionListener(this);
        this.vista.getBtnVolver().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnAprobar()) {
            Vuelo v = aplicacion.buscarVueloxCodigo(codigo);

            if (v == null) {
                JOptionPane.showMessageDialog(null, "Error inesperado.");
                return;
            }

            try {
                v.autorizarDespegueCambioEstado();
                JOptionPane.showMessageDialog(null, "Despegue autorizado. Avión en el aire.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error al autorizar el despegue: " + ex.getMessage());
            } finally {
                volver();
            }   
        }

        if (source == vista.getBtnVolver()) {
            volver();
        }
    }

    private void volver(){
        // Volver a la pantala de despegue
        PanelControlarDespegues panelControlarDespegues = new PanelControlarDespegues(pantalla);
        new ControlPanelControlarDespegues(panelControlarDespegues);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDespegues);
    }
}
