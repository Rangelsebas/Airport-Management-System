package interfaz.controlador.segundaPantalla.sacarDeCola.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.segundaPantalla.controlador.ControlPanelControlarDespegues;
import interfaz.controlador.segundaPantalla.sacarDeCola.enums.SacarDeColaComando;
import interfaz.controlador.segundaPantalla.sacarDeCola.vista.PanelSacarDeCola;
import interfaz.controlador.segundaPantalla.vista.PanelControlarDespegues;

public class ControlPanelSacarDeCola implements ActionListener{
    private final PanelSacarDeCola vista;
    private final PantallaBase pantalla;
    private final Vuelo vuelo;

    public ControlPanelSacarDeCola(PanelSacarDeCola vista, PantallaBase pantalla, Vuelo vuelo) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vuelo = vuelo;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        SacarDeColaComando comando = SacarDeColaComando.valueOf(e.getActionCommand());

        switch (comando) {
            case SACAR_DE_COLA:
                sacarAvion();
                volver();
                break;
            case VOLVER:
                volver();
                break;
        }
    }

    private void sacarAvion() {
        if (vuelo == null) {
            JOptionPane.showMessageDialog(vista, "No hay vuelo seleccionado para sacar de la cola.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            if(vuelo.sacarPrimeroDeCola()){
                JOptionPane.showMessageDialog(vista, "Avión puesto a la espera de autorización de despegue.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo sacar el avión de la cola.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "No se pudo sacar de la cola. Motivo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void volver() {
        // Volver a la tercera pantalla
        PanelControlarDespegues panelControlarDespegues = new PanelControlarDespegues(pantalla);
        new ControlPanelControlarDespegues(panelControlarDespegues);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDespegues);
    }
}
