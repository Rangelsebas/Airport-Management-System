package interfaz.controlador.segundaPantalla.sacarDeCola.enums;

public enum SacarDeColaComando {
    SACAR_DE_COLA,
    VOLVER
}
