package interfaz.controlador.segundaPantalla.controlador;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.ControladorAereo;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.segundaPantalla.despegarAvion.controlador.ControlPanelDespegarAvion;
import interfaz.controlador.segundaPantalla.despegarAvion.vista.PanelDespegarAvion;
import interfaz.controlador.segundaPantalla.esperandoPistaDespegue.controlador.ControlPanelEsperandoPistaDespegue;
import interfaz.controlador.segundaPantalla.esperandoPistaDespegue.vista.PanelEsperandoPistaDespegue;
import interfaz.controlador.segundaPantalla.moverAAparcamiento.controlador.ControlPanelMoverAAparcamiento;
import interfaz.controlador.segundaPantalla.moverAAparcamiento.vista.PanelMoverAAparcamiento;
import interfaz.controlador.segundaPantalla.sacarAvionHangar.controlador.ControlPanelSacarAvion;
import interfaz.controlador.segundaPantalla.sacarAvionHangar.vista.PanelSacarAvion;
import interfaz.controlador.segundaPantalla.sacarDeCola.controlador.ControlPanelSacarDeCola;
import interfaz.controlador.segundaPantalla.sacarDeCola.vista.PanelSacarDeCola;
import interfaz.controlador.segundaPantalla.vista.PanelControlarDespegues;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.format.DateTimeFormatter;

public class ControlPanelControlarDespegues {

    private final PanelControlarDespegues vista;
    private final PantallaBase pantalla;
    private ControladorAereo ca;

    public ControlPanelControlarDespegues(PanelControlarDespegues vista) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.ca = (ControladorAereo) Aplicacion.init("").getUsuarioLogueado();

        if (ca.getVuelosPendientesDespegar().isEmpty()) {
            vista.añadirSolicitud("No hay vuelos que atender");
        } else {
            for (Vuelo vuelo : ca.getVuelosPendientesDespegar()) {
                String texto = "Codigo del vuelo: " + vuelo.getCodigoVuelo() + " | Aerolinea: " + vuelo.getAerolineaOperadora().getNombre() + " | Fecha: " + vuelo.getFecha() + 
                " | " + vuelo.getHoraSalida().format(DateTimeFormatter.ofPattern("HH:mm")) + " - " + vuelo.getHoraLlegada().format(DateTimeFormatter.ofPattern("HH:mm")) + 
                " | " + vuelo.getOrigen().getNombre() + " - " + vuelo.getDestino().getNombre() + " | Estado : " + vuelo.getEstado() + " | Retraso: " + (vuelo.getEnTiempo()? "No" : "Si") + "\n";
                vista.añadirSolicitud(texto);
            }
            
            vista.getListaSolicitudes().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent evt) {
                    if (evt.getClickCount() == 2) {
                        int index = vista.getListaSolicitudes().locationToIndex(evt.getPoint());
                        
                        if (index >= 0) {
                            String texto = vista.getListaSolicitudes().getModel().getElementAt(index);
                            String codigo = getCodigo(texto);

                            Vuelo vuelo = Aplicacion.init("").buscarVueloxCodigo(codigo);
                            
                            switch (vuelo.getEstado()) {
                                case APROBADO:
                                case EN_HANGAR:
                                    PanelSacarAvion panelSacarAvion = new PanelSacarAvion(pantalla, vuelo.getCodigoVuelo());
                                    new ControlPanelSacarAvion(panelSacarAvion, pantalla, vuelo);
                                    pantalla.mostrarContenidoEnPanelCentral(panelSacarAvion);
                                    break;
                                
                                case OPERATIVO:
                                    PanelMoverAAparcamiento panelMoverAAparcamiento = new PanelMoverAAparcamiento(pantalla, codigo);
                                    new ControlPanelMoverAAparcamiento(panelMoverAAparcamiento, vuelo, pantalla);
                                    pantalla.mostrarContenidoEnPanelCentral(panelMoverAAparcamiento);  
                                    break;

                                case ESPERANDO_PISTA_DESPEGUE:
                                    PanelEsperandoPistaDespegue panelEsperandoPistaDespegue = new PanelEsperandoPistaDespegue(pantalla, codigo);
                                    new ControlPanelEsperandoPistaDespegue(panelEsperandoPistaDespegue, codigo, pantalla);
                                    pantalla.mostrarContenidoEnPanelCentral(panelEsperandoPistaDespegue);
                                    break;

                                case EN_COLA:
                                    PanelSacarDeCola panelSacarDeCola = new PanelSacarDeCola(pantalla, codigo);
                                    new ControlPanelSacarDeCola(panelSacarDeCola, pantalla, vuelo);
                                    pantalla.mostrarContenidoEnPanelCentral(panelSacarDeCola);
                                    break;

                                case ESPERANDO_DESPEGUE:
                                    PanelDespegarAvion panelDespegarAvion = new PanelDespegarAvion(pantalla, codigo);
                                    new ControlPanelDespegarAvion(panelDespegarAvion, codigo, pantalla);
                                    pantalla.mostrarContenidoEnPanelCentral(panelDespegarAvion);
                                    break;
                            
                                default:
                                    break;
                            }
                        }
                    }
                }
            });
        }
    }
    
    private String getCodigo(String texto){
        String clave = "Codigo del vuelo:";
        int pos = texto.indexOf(clave);
        String codigo = "";

        if (pos != -1) {
            // comenzamos justo tras la clave
            int start = pos + clave.length();
            // buscamos el siguiente separador " |"
            int end = texto.indexOf("|", start);
            if (end == -1) {
                // si no hay barra, cogemos hasta el cierre del div
                end = texto.indexOf("<", start);
            }
            codigo = texto.substring(start, end).trim();
        }

        return codigo;
    }
}
