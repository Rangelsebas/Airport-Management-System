package interfaz.controlador.segundaPantalla.moverAAparcamiento.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;

import funcionalidad.aeropuerto.elementos.Aparcamiento;
import funcionalidad.aeropuerto.elementos.Puerta;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.ControladorAereo;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.segundaPantalla.controlador.ControlPanelControlarDespegues;
import interfaz.controlador.segundaPantalla.moverAAparcamiento.vista.PanelMoverAAparcamiento;
import interfaz.controlador.segundaPantalla.vista.PanelControlarDespegues;

public class ControlPanelMoverAAparcamiento implements ActionListener {
    private final PanelMoverAAparcamiento vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private Vuelo vuelo;

    public ControlPanelMoverAAparcamiento(PanelMoverAAparcamiento vista, Vuelo vuelo, PantallaBase pantalla) {
        this.vista = vista;
        this.vuelo = vuelo;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("");
        this.vista.getBtnAprobar().addActionListener(this);
        actualizarDatos();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnAprobar()) {
            Aparcamiento aparcamiento = aplicacion.getAeropuertoPropio().getAparcamiento((String) vista.getComboAparcamiento().getSelectedItem());
            Puerta puerta = ((ControladorAereo) aplicacion.getUsuarioLogueado()).getTerminal().getPuerta((String) vista.getComboPuerta().getSelectedItem());

            if (aparcamiento == null || puerta == null) {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione un aparcamiento y una puerta.");
                return;
            }

            if (vuelo == null) {
                JOptionPane.showMessageDialog(null, "Error inesperado.");
                return;
            }

            // Asignar el aparcamiento y la puerta al vuelo
            try {
                if (!vuelo.moverAvionAAparcamiento(aparcamiento, puerta)){
                    JOptionPane.showMessageDialog(null, "Error al asignar el aparcamiento y la puerta.");
                    return;
                } else {
                    JOptionPane.showMessageDialog(null, "Asignación exitosa");
                    System.out.println("→ Aparcamiento asignado: " + aparcamiento.getNombre());
                    System.out.println("→ Puerta asignada: " + puerta.getNombre());
                    volver(); 
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error al asignar el aparcamiento y la puerta. Motivo: " + ex.getMessage());
                return;
            }     
        }
    }

    private void actualizarDatos() {
        List<Aparcamiento> aparcamientos = aplicacion.getAeropuertoPropio().getAparcamientosApropiado(vuelo.getAvion());
        List<Puerta> puertas = ((ControladorAereo) aplicacion.getUsuarioLogueado()).getTerminal().getPuertas();

        for (Aparcamiento aparcamiento : aparcamientos) {
            vista.añadirAparcamiento(aparcamiento.getNombre());
        }

        for (Puerta puerta : puertas) {
            vista.añadirPuerta(puerta.getNombre());
        }
    }

    private void volver(){
        // Volver a la pantala de despegues
        PanelControlarDespegues panelControlarDespegues = new PanelControlarDespegues(pantalla);
        new ControlPanelControlarDespegues(panelControlarDespegues);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDespegues);
    }
}
