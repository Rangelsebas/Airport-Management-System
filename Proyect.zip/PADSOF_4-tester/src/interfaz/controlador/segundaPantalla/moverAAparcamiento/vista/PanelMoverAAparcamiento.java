package interfaz.controlador.segundaPantalla.moverAAparcamiento.vista;

import java.awt.*;
import javax.swing.*;

import interfaz.componentes.PantallaBase;

public class PanelMoverAAparcamiento extends JPanel {
    private PantallaBase pantallaBase;
    private JComboBox<String> comboAparcamiento;
    private JComboBox<String> comboPuerta;
    private JButton btnAprobar;

    public PanelMoverAAparcamiento(PantallaBase pantallaBase, String codigo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("✈️ Vuelo con codigo: " + codigo + " esperando un aparcamiento y puerta.", Font.BOLD, 18));
        add(Box.createVerticalStrut(10));

        add(Box.createVerticalStrut(20));

        // Combo de aparcamientos
        comboAparcamiento = new JComboBox<>(new String[]{"Seleccionar Aparcamiento"});
        comboAparcamiento.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(new JLabel("Selecciona Aparcamiento:"));
        add(comboAparcamiento);

        add(Box.createVerticalStrut(10));

        // Combo de puertas
        comboPuerta = new JComboBox<>(new String[]{"Seleccionar Puerta"});
        comboPuerta.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(new JLabel("Selecciona Puerta:"));
        add(comboPuerta);

        add(Box.createVerticalStrut(20));

        // Botones
        btnAprobar = new JButton("Asignar");

        btnAprobar.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(btnAprobar);
        add(Box.createVerticalStrut(10));
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public JComboBox<String> getComboAparcamiento() {
        return comboAparcamiento;
    }

    public JComboBox<String> getComboPuerta() {
        return comboPuerta;
    }

    public JButton getBtnAprobar() {
        return btnAprobar;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void añadirAparcamiento(String aparcamiento) {
        comboAparcamiento.addItem(aparcamiento);
    }

    public void añadirPuerta(String puerta) {
        comboPuerta.addItem(puerta);
    }
}
