package interfaz.controlador.segundaPantalla.sacarAvionHangar.vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;

public class PanelSacarAvion extends JPanel {
    private PantallaBase pantallaBase;
    private JLabel infoVueloLabel;
    private JButton botonSacar;
    private JButton botonVolver;

    public PanelSacarAvion(PantallaBase pantallaBase, String codigoVuelo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Información del Vuelo");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createVerticalStrut(20));
        add(titulo);
        add(Box.createVerticalStrut(20));

        add(crearLabel("✈️ Vuelo con codigo: " + codigoVuelo + ". Su avión se encuentra en el hangar.", Font.BOLD, 18));
        add(Box.createVerticalStrut(10));

        infoVueloLabel = new JLabel();
        infoVueloLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        infoVueloLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        infoVueloLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(infoVueloLabel);

        add(Box.createVerticalStrut(30));

        botonSacar = new JButton("Sacar avión del hangar");
        botonVolver = new JButton("Volver");

        botonSacar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonVolver.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createVerticalStrut(10));
        add(botonSacar);
        add(Box.createVerticalStrut(10));   
        add(botonVolver);
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public void mostrarInformacionVuelo(Vuelo vuelo) {
        if (vuelo == null) {
            infoVueloLabel.setText("No se encontró un vuelo con ese código.");
            botonSacar.setVisible(false);
            return;
        }

        String resumen = "<html><b>Código:</b> " + vuelo.getCodigoVuelo()
                + " | <b>Estado:</b> " + vuelo.getEstado().name()
                + " | <b>Origen:</b> " + vuelo.getOrigen().getNombre()
                + " | <b>Destino:</b> " + vuelo.getDestino().getNombre()
                + " | <b>Aerolíneas:</b> " + vuelo.getAerolineaOperadora().getNombre()
                + "</html>";

        infoVueloLabel.setText(resumen);
    }

    public void setControlador(ActionListener c) {
        botonSacar.setActionCommand("SACAR_AVION_HANGAR");
        botonSacar.addActionListener(c);
        botonVolver.setActionCommand("VOLVER");
        botonVolver.addActionListener(c);
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public JButton getBotonSacar() {
        return botonSacar;
    }

}
