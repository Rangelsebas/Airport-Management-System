package interfaz.controlador.segundaPantalla.sacarAvionHangar.enums;

public enum ComandoSacarAvion {
    SACAR_AVION_HANGAR,
    VOLVER
}
