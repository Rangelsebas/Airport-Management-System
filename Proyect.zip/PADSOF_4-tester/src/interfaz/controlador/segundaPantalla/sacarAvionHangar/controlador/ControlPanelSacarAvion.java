package interfaz.controlador.segundaPantalla.sacarAvionHangar.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.controlador.segundaPantalla.controlador.ControlPanelControlarDespegues;
import interfaz.controlador.segundaPantalla.sacarAvionHangar.enums.ComandoSacarAvion;
import interfaz.controlador.segundaPantalla.sacarAvionHangar.vista.PanelSacarAvion;
import interfaz.controlador.segundaPantalla.vista.PanelControlarDespegues;

public class ControlPanelSacarAvion implements ActionListener {
    private final PanelSacarAvion vista;
    private final PantallaBase pantalla;
    private final Vuelo vuelo;

    public ControlPanelSacarAvion(PanelSacarAvion vista, PantallaBase pantalla, Vuelo vuelo) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vuelo = vuelo;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoSacarAvion comando = ComandoSacarAvion.valueOf(e.getActionCommand());

        switch (comando) {
            case SACAR_AVION_HANGAR:
                sacarAvion();
                volver();
                break;
            case VOLVER:
                volver();
                break;
        }
    }

    private void sacarAvion() {
        if (vuelo == null) {
            JOptionPane.showMessageDialog(vista, "No hay vuelo seleccionado para sacar del hangar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (vuelo.sacarAvionHangar()) {
            JOptionPane.showMessageDialog(vista, "Avión sacado del hangar exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo sacar el avión del hangar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void volver() {
        // Volver a la tercera pantalla
        PanelControlarDespegues panelControlarDespegues = new PanelControlarDespegues(pantalla);
        new ControlPanelControlarDespegues(panelControlarDespegues);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDespegues);
    }
}
