/* javac -d bin src/interfaz/controlador/VentanaControlador.java src/interfaz/componentes/PantallaBase.java  src/interfaz/controlador/ControlarAterrizaje.java 
 * java -cp bin interfaz.controlador.VentanaControlador
 * 
 */

package interfaz.controlador.vista;

import interfaz.componentes.PantallaBase;
import interfaz.controlador.cuartaPantalla.vista.PanelVerCola;
import interfaz.controlador.enums.ComandoVentanaControladorEnum;
import interfaz.controlador.primeraPantalla.vista.PanelControlarAterrizajes;
import interfaz.controlador.segundaPantalla.vista.PanelControlarDespegues;
import interfaz.controlador.terceraPantalla.vista.PanelControlarEstadoVuelo;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.aplicacion.Notificacion;
import funcionalidad.usuarios.Usuario;

public class VentanaControlador extends JFrame {
    
    private final String NOMBRE_USUARIO_CONTROLADOR = "Controlador Aéreo";
    private PantallaBase pantalla;
    private List<JButton> botones;
    private String nombreUsuario;

    // Subpaneles
    private PanelControlarAterrizajes panelAterrizajes;
    private PanelControlarDespegues panelDespegues;
    private PanelControlarEstadoVuelo panelEstadoVuelo;
    private PanelVerCola panelVerCola;

    public VentanaControlador() {
        this.nombreUsuario = NOMBRE_USUARIO_CONTROLADOR;
        setTitle("Sistema Aeropuerto - Controlador");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        botones = List.of(
            crearBotonMenu("Controlar Aterrizajes", ComandoVentanaControladorEnum.CONTROLAR_ATERRIZAJES),
            crearBotonMenu("Controlar Despegues", ComandoVentanaControladorEnum.CONTROLAR_DESPEGUES),
            crearBotonMenu("Controlar el Estado de un Vuelo", ComandoVentanaControladorEnum.CONTROLAR_ESTADO_VUELO),
            crearBotonMenu("Ver Cola", ComandoVentanaControladorEnum.VER_COLA),
            crearBotonMenu("Ver notificaciones", ComandoVentanaControladorEnum.VER_NOTIFICACIONES),
            crearBotonMenu("Guardar aplicacion", ComandoVentanaControladorEnum.GUARDAR_APLICACION),
            crearBotonMenu("Cargar aplicacion", ComandoVentanaControladorEnum.CARGAR_APLICACION)

        );

        for (JButton boton : botones) {
            boton.setHorizontalAlignment(SwingConstants.CENTER);
        }

        /* NOTIFICACIONES */
        Aplicacion app = Aplicacion.init("acceder");
        Usuario logueado = app.getUsuarioLogueado();

        List<String> notificaciones = new ArrayList<>();

        if (logueado != null && !logueado.getNotificacion().isEmpty()) {
            Notificacion ultima = logueado.getNotificacion().get(logueado.getNotificacion().size() - 1);
            notificaciones.add("<html>" + ultima.getMensaje().toString() + "</html>");
        } else {
            notificaciones.add("Sin notificaciones recientes.");
        }

        pantalla = new PantallaBase(logueado.getNombreUsuario(), botones, notificaciones);
        add(pantalla);
    }

    /* HELPER */
    private JButton crearBotonMenu(String texto, ComandoVentanaControladorEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        boton.setHorizontalAlignment(SwingConstants.CENTER);
        return boton;
    }

    public PantallaBase getPantallaBase() {
        return pantalla;
    }

    public void mostrarPanel(JPanel panel) {
        pantalla.mostrarContenidoEnPanelCentral(panel);
    }

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
        pantalla.getCerrarSesionButton().setActionCommand(ComandoVentanaControladorEnum.CERRAR_SESION.name());
        pantalla.getCerrarSesionButton().addActionListener(c);
        pantalla.getAvanzar5MinButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_5M.name());
        pantalla.getAvanzar5MinButton().addActionListener(c);
        pantalla.getAvanzar30miButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_30M.name());
        pantalla.getAvanzar30miButton().addActionListener(c);
        pantalla.getAvanzar1hButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_1H.name());
        pantalla.getAvanzar1hButton().addActionListener(c);
        pantalla.getAvanzar1dButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_1D.name());
        pantalla.getAvanzar1dButton().addActionListener(c);
    }

    public String getNombreUsuario() {
        return this.nombreUsuario;
    }

    public PanelControlarAterrizajes getPanelControlarAterrizajes() {
        if (panelAterrizajes == null) {
            panelAterrizajes = new PanelControlarAterrizajes(pantalla);
        }
        return panelAterrizajes;
    }

    public PanelControlarDespegues getPanelControlarDespegues() {
        if (panelDespegues == null) {
            panelDespegues = new PanelControlarDespegues(pantalla);
        }
        return panelDespegues;
    }

    public PanelControlarEstadoVuelo getPanelControlarEstadoVuelo() {
        if (panelEstadoVuelo == null) {
            panelEstadoVuelo = new PanelControlarEstadoVuelo(pantalla);
        }
        return panelEstadoVuelo;
    }

    public PanelVerCola getPanelVerCola() {
        if (panelVerCola == null) {
            panelVerCola = new PanelVerCola(pantalla);
        }
        return panelVerCola;
    }

    public JButton getBotonCerrarSesion() {
        return pantalla.getCerrarSesionButton();
    }

    public void update() {
        pantalla.mostrarContenidoEnPanelCentral(new JPanel());
    }
}
