package interfaz.controlador.terceraPantalla.vista;

import interfaz.componentes.PantallaBase;
import interfaz.controlador.terceraPantalla.enums.ComandoEstadoVueloEnum;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class PanelControlarEstadoVuelo extends JPanel {

    private PantallaBase pantallaBase;
    private JTextField campoCodigoVuelo;
    private List<JButton> botones;
    private JButton botonBuscar;

    public PanelControlarEstadoVuelo(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 5, 10, 5);
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.CENTER;

        // Label de título
        JLabel labelTitulo = new JLabel("Buscar Vuelo por Código:");
        labelTitulo.setFont(new Font("SansSerif", Font.BOLD, 16));
        add(labelTitulo, gbc);

        // Campo de texto
        gbc.gridy = 1;
        campoCodigoVuelo = new JTextField(15);
        campoCodigoVuelo.setHorizontalAlignment(SwingConstants.CENTER);
        add(campoCodigoVuelo, gbc);

        // Botones
        botonBuscar = crearBoton("Buscar", ComandoEstadoVueloEnum.BUSCAR_VUELO);

        botones = List.of(
            botonBuscar,
            crearBoton("Ver Vuelos en Curso", ComandoEstadoVueloEnum.VUELOS_EN_CURSO),
            crearBoton("Ver Vuelos Pendientes", ComandoEstadoVueloEnum.VUELOS_PENDIENTES),
            crearBoton("Ver Histórico", ComandoEstadoVueloEnum.VUELOS_HISTORICO)
        );

        for (JButton boton : botones) {
            gbc.gridy++;
            add(boton, gbc);
        }
    }

    private JButton crearBoton(String texto, ComandoEstadoVueloEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        boton.setPreferredSize(new Dimension(200, 40));
        return boton;
    }

    public void setControlador(ActionListener controlador) {
        for (JButton boton : botones) {
            boton.addActionListener(controlador);
        }
    }

    public String getCodigoVuelo() {
        return campoCodigoVuelo.getText().trim();
    }

    public void limpiar() {
        campoCodigoVuelo.setText("");
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void mostrarPanel(JPanel panel) {
        pantallaBase.mostrarContenidoEnPanelCentral(panel);
    }
}
