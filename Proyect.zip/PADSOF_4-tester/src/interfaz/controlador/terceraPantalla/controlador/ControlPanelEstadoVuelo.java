package interfaz.controlador.terceraPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import interfaz.componentes.PantallaBase;
import interfaz.controlador.primeraPantalla.asignarPista.controlador.ControlPanelAsignarPista;
import interfaz.controlador.primeraPantalla.asignarPista.vista.PanelAsignarPista;
import interfaz.controlador.primeraPantalla.aterrizarAvion.controlador.ControlPanelAterrizarAvion;
import interfaz.controlador.primeraPantalla.aterrizarAvion.vista.PanelAterrizarAvion;
import interfaz.controlador.segundaPantalla.despegarAvion.controlador.ControlPanelDespegarAvion;
import interfaz.controlador.segundaPantalla.despegarAvion.vista.PanelDespegarAvion;
import interfaz.controlador.segundaPantalla.esperandoPistaDespegue.controlador.ControlPanelEsperandoPistaDespegue;
import interfaz.controlador.segundaPantalla.esperandoPistaDespegue.vista.PanelEsperandoPistaDespegue;
import interfaz.controlador.segundaPantalla.moverAAparcamiento.controlador.ControlPanelMoverAAparcamiento;
import interfaz.controlador.segundaPantalla.moverAAparcamiento.vista.PanelMoverAAparcamiento;
import interfaz.controlador.segundaPantalla.sacarAvionHangar.controlador.ControlPanelSacarAvion;
import interfaz.controlador.segundaPantalla.sacarAvionHangar.vista.PanelSacarAvion;
import interfaz.controlador.segundaPantalla.sacarDeCola.controlador.ControlPanelSacarDeCola;
import interfaz.controlador.segundaPantalla.sacarDeCola.vista.PanelSacarDeCola;
import interfaz.controlador.terceraPantalla.enums.ComandoEstadoVueloEnum;
import interfaz.controlador.terceraPantalla.historico.controlador.ControlPanelVuelosHistorico;
import interfaz.controlador.terceraPantalla.historico.vista.PanelVuelosHistorico;
import interfaz.controlador.terceraPantalla.verDatosVuelo.controlador.ControlPanelVerDatosVuelo;
import interfaz.controlador.terceraPantalla.verDatosVuelo.vista.PanelVerDatosVuelo;
import interfaz.controlador.terceraPantalla.verVuelosEnCurso.controlador.ControlPanelVuelosEnCurso;
import interfaz.controlador.terceraPantalla.verVuelosEnCurso.vista.PanelVuelosEnCurso;
import interfaz.controlador.terceraPantalla.verVuelosPendientes.controlador.ControlPanelVuelosPendientes;
import interfaz.controlador.terceraPantalla.verVuelosPendientes.vista.PanelVuelosPendientes;
import interfaz.controlador.terceraPantalla.vista.PanelControlarEstadoVuelo;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;

public class ControlPanelEstadoVuelo implements ActionListener {

    private PanelControlarEstadoVuelo vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelEstadoVuelo(PanelControlarEstadoVuelo vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("acceder");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoEstadoVueloEnum comando = ComandoEstadoVueloEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case BUSCAR_VUELO:
                String codigo = vista.getCodigoVuelo();

                if (codigo == null || codigo.isBlank()) {
                    JOptionPane.showMessageDialog(null, "Ingresa un código de vuelo para buscar.", "Campo vacío", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Vuelo vuelo = aplicacion.buscarVueloxCodigo(codigo);

                if (vuelo == null) {
                    JOptionPane.showMessageDialog(null, "No se encontró ningún vuelo con ese código.", "No encontrado", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                EstadosVuelo estado = vuelo.getEstado();

                switch (estado) {
                    case ESPERANDO_PISTA_ATERRIZAJE:
                        PanelAsignarPista panelAsignarPista = new PanelAsignarPista(pantalla, codigo);
                        new ControlPanelAsignarPista(panelAsignarPista, codigo, pantalla);
                        pantalla.mostrarContenidoEnPanelCentral(panelAsignarPista);                       
                        break;
                    
                    case ESPERANDO_ATERRIZAR:
                        PanelAterrizarAvion panelAterrizarAvion = new PanelAterrizarAvion(pantalla, codigo);
                        new ControlPanelAterrizarAvion(panelAterrizarAvion, codigo, pantalla);
                        pantalla.mostrarContenidoEnPanelCentral(panelAterrizarAvion);
                        break;

                    case EN_HANGAR:
                        PanelSacarAvion panelSacarAvion = new PanelSacarAvion(pantalla, vuelo.getCodigoVuelo());
                        new ControlPanelSacarAvion(panelSacarAvion, pantalla, vuelo);
                        pantalla.mostrarContenidoEnPanelCentral(panelSacarAvion);
                        break;
                    
                    case ESPERANDO_PISTA_DESPEGUE:
                        PanelEsperandoPistaDespegue panelEsperandoPistaDespegue = new PanelEsperandoPistaDespegue(pantalla, codigo);
                        new ControlPanelEsperandoPistaDespegue(panelEsperandoPistaDespegue, codigo, pantalla);
                        pantalla.mostrarContenidoEnPanelCentral(panelEsperandoPistaDespegue);
                        break;
                    
                    case EN_COLA:
                        PanelSacarDeCola panelSacarDeCola = new PanelSacarDeCola(pantalla, codigo);
                        new ControlPanelSacarDeCola(panelSacarDeCola, pantalla, vuelo);
                        pantalla.mostrarContenidoEnPanelCentral(panelSacarDeCola);
                        break;
                    
                    case ESPERANDO_DESPEGUE:
                        PanelDespegarAvion panelDespegarAvion = new PanelDespegarAvion(pantalla, codigo);
                        new ControlPanelDespegarAvion(panelDespegarAvion, codigo, pantalla);
                        pantalla.mostrarContenidoEnPanelCentral(panelDespegarAvion);
                        break;
                    
                    default:
                        PanelVerDatosVuelo panelVerDatosVuelo = new PanelVerDatosVuelo();
                        new ControlPanelVerDatosVuelo(panelVerDatosVuelo, vuelo);
                        pantalla.mostrarContenidoEnPanelCentral(panelVerDatosVuelo);
                        break;
                }
                break;

            case VUELOS_EN_CURSO:
                PanelVuelosEnCurso panelVuelos = new PanelVuelosEnCurso(pantalla);
                new ControlPanelVuelosEnCurso(panelVuelos);
                pantalla.mostrarContenidoEnPanelCentral(panelVuelos);
                break;

            case VUELOS_PENDIENTES:
                PanelVuelosPendientes panelPendientes = new PanelVuelosPendientes(pantalla);
                new ControlPanelVuelosPendientes(panelPendientes);
                pantalla.mostrarContenidoEnPanelCentral(panelPendientes);
                break;

            case VUELOS_HISTORICO:
                PanelVuelosHistorico panelHistorico = new PanelVuelosHistorico(pantalla);
                new ControlPanelVuelosHistorico(panelHistorico);
                pantalla.mostrarContenidoEnPanelCentral(panelHistorico);
                break;
        }
    }
}
