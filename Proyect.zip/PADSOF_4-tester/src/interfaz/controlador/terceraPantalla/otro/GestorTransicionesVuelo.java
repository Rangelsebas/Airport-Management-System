package interfaz.controlador.terceraPantalla.otro;

import java.util.ArrayList;
import java.util.List;

//import funcionalidad.aerolinea.CategoriaAvion;
//import funcionalidad.vuelo.EstadosVuelo;
//import funcionalidad.vuelo.Vuelo;

public class GestorTransicionesVuelo {

    /*
     * Este método analiza el estado actual y devuelve las acciones posibles:
     */
    public static List<TransicionVuelo> obtenerTransicionesDisponibles(/*Vuelo vuelo*/) {
        List<TransicionVuelo> acciones = new ArrayList<>();
        //EstadosVuelo estado = vuelo.getEstado();
        // CategoriaAvion categoria = vuelo.getAvion().getCategoria();

        // switch (estado) {
        //     case FINALIZADO -> {
        //         acciones.add(new TransicionVuelo("Pasar al Hangar", "PASAR_HANGAR"));
        //         acciones.add(new TransicionVuelo("Dejar Operativo", "DEJAR_OPERATIVO"));
        //     }
        //     case EN_HANGAR -> {
        //         acciones.add(new TransicionVuelo("Sacar del Hangar", "SACAR_HANGAR"));
        //     }
        //     case EN_APARCAMIENTO -> {
        //         acciones.add(new TransicionVuelo("Pasar a Preparación", "PASAR_PREPARACION"));
        //     }
        //     case EN_PREPARACION -> {
        //         if (categoria == CategoriaAvion.PASAJEROS) {
        //             acciones.add(new TransicionVuelo("Iniciar Embarque", "INICIAR_EMBARQUE"));
        //         } else if (categoria == CategoriaAvion.MERCANCIAS) {
        //             acciones.add(new TransicionVuelo("Iniciar Carga", "INICIAR_CARGA"));
        //         }
        //     }
        //     case EMBARCANDO, CARGANDO -> {
        //         acciones.add(new TransicionVuelo("Finalizar Embarque/Carga", "FINALIZAR_EMBARQUE"));
        //     }
        //     // Añadir más casos según crezca la lógica
        // }

        // acciones.add(new TransicionVuelo("Cancelar", "CANCELAR")); // Siempre disponible

        return acciones;
    }

}
