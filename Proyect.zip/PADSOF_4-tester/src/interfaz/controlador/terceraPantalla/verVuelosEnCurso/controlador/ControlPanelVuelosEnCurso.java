package interfaz.controlador.terceraPantalla.verVuelosEnCurso.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.controlador.terceraPantalla.verVuelosEnCurso.vista.PanelVuelosEnCurso;

public class ControlPanelVuelosEnCurso {

    private PanelVuelosEnCurso vista;
    private Aplicacion aplicacion;

    public ControlPanelVuelosEnCurso(PanelVuelosEnCurso vista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");

        cargarVuelosEnCurso();
    }

    private void cargarVuelosEnCurso() {
        List<Vuelo> vuelos = new ArrayList<>();
        vuelos.addAll(aplicacion.vuelosSalidas());
        vuelos.addAll(aplicacion.vuelosLlegadas());
        vuelos.addAll(aplicacion.vuelosHistoricos());

        List<Vuelo> enCurso = vuelos.stream()
            .filter(v -> switch (v.getEstado()) {
                case ESPERANDO_PISTA_ATERRIZAJE,
                     ESPERANDO_ATERRIZAR,
                     ATERRIZADO,
                     DESEMBARCANDO,
                     DESCARGANDO,
                     EN_HANGAR,
                     EN_APARCAMIENTO,
                     OPERATIVO,
                     EN_PREPARACION,
                     EMBARCANDO,
                     CARGANDO,
                     ESPERANDO_PISTA_DESPEGUE,
                     ESPERANDO_DESPEGUE -> true;
                default -> false;
            })
            .collect(Collectors.toList());

        vista.mostrarVuelos(enCurso);
    }
}
