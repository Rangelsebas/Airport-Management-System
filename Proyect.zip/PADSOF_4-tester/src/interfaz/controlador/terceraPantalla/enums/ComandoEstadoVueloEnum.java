package interfaz.controlador.terceraPantalla.enums;

public enum ComandoEstadoVueloEnum {
    BUSCAR_VUELO,
    VUELOS_EN_CURSO,
    VUELOS_PENDIENTES,
    VUELOS_HISTORICO
}
