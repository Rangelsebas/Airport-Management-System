package interfaz.controlador.terceraPantalla.verDatosVuelo.controlador;

import funcionalidad.vuelo.Vuelo;
import interfaz.controlador.terceraPantalla.verDatosVuelo.vista.PanelVerDatosVuelo;

public class ControlPanelVerDatosVuelo {
    private PanelVerDatosVuelo vista;
    private Vuelo vuelo;

    public ControlPanelVerDatosVuelo(PanelVerDatosVuelo vista, Vuelo vuelo) {
        this.vista = vista;
        this.vuelo = vuelo;

        cargarInformacion();
    }

    private void cargarInformacion() {
        vista.setCodigoVuelo(vuelo.getCodigoVuelo());
        vista.setOrigen(vuelo.getOrigen().getNombre());
        vista.setDestino(vuelo.getDestino().getNombre());
        vista.setFecha(vuelo.getFecha().toString());
        vista.setHoraSalida(vuelo.getHoraSalida().toString());
        vista.setHoraLlegada(vuelo.getHoraLlegada().toString());
        vista.setEstado(vuelo.getEstado().toString());

        String avionTexto = vuelo.getAvion().getTipoAvion().getMarca() + " " +
                            vuelo.getAvion().getTipoAvion().getModelo() + " - Matrícula " +
                            vuelo.getAvion().getMatricula();
        vista.setAvion(avionTexto);

        int capacidad = vuelo.getAvion().getTipoAvion().getCapacidad();
        switch (vuelo.getAvion().getCategoria()) {
            case PASAJEROS -> vista.setCapacidadPasajeros(capacidad);
            case MERCANCIAS -> vista.setCapacidadCarga(capacidad);
        }

        vista.setPuntualidad(vuelo.getEnTiempo() ? "En hora" : "Con retraso");
    }
}
