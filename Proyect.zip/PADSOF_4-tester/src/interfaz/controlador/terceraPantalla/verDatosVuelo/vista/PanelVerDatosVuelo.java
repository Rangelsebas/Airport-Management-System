package interfaz.controlador.terceraPantalla.verDatosVuelo.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import java.awt.*;

public class PanelVerDatosVuelo extends JPanel {
    private JLabel labelCodigoVuelo;
    private JLabel labelOrigen;
    private JLabel labelDestino;
    private JLabel labelFecha;
    private JLabel labelHoraSalida;
    private JLabel labelHoraLlegada;
    private JLabel labelEstado;
    private JLabel labelAvion;
    private JLabel labelCapacidad;
    private JLabel labelPuntualidad;

    public PanelVerDatosVuelo() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Margen general exterior

        JPanel panelContenido = new JPanel();
        panelContenido.setLayout(new BoxLayout(panelContenido, BoxLayout.Y_AXIS));
        panelContenido.setBackground(Color.WHITE);
        panelContenido.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(Color.LIGHT_GRAY, 1), // Recuadro gris claro
            new EmptyBorder(20, 20, 20, 20)       // Margen interno
        ));

        // Código de vuelo destacado arriba
        labelCodigoVuelo = new JLabel("Código: ");
        labelCodigoVuelo.setFont(new Font("Arial", Font.BOLD, 18));
        labelCodigoVuelo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelContenido.add(labelCodigoVuelo);

        panelContenido.add(Box.createVerticalStrut(15));

        // Info secundaria
        labelOrigen = crearEtiquetaInfo("Origen: ");
        labelDestino = crearEtiquetaInfo("Destino: ");
        labelFecha = crearEtiquetaInfo("Fecha: ");
        labelHoraSalida = crearEtiquetaInfo("Hora de Salida: ");
        labelHoraLlegada = crearEtiquetaInfo("Hora de Llegada: ");
        labelEstado = crearEtiquetaInfo("Estado: ");
        labelAvion = crearEtiquetaInfo("Avión: ");
        labelCapacidad = crearEtiquetaInfo("Capacidad: ");
        labelPuntualidad = crearEtiquetaInfo("Puntualidad: ");

        panelContenido.add(labelOrigen);
        panelContenido.add(labelDestino);
        panelContenido.add(labelFecha);
        panelContenido.add(labelHoraSalida);
        panelContenido.add(labelHoraLlegada);
        panelContenido.add(labelEstado);
        panelContenido.add(labelAvion);
        panelContenido.add(labelCapacidad);
        panelContenido.add(labelPuntualidad);

        add(panelContenido); // Añadimos el recuadro
    }

    private JLabel crearEtiquetaInfo(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    // Métodos para actualizar dinámicamente

    public void setCodigoVuelo(String texto) {
        labelCodigoVuelo.setText("✈️ Código: " + texto);
    }

    public void setOrigen(String texto) {
        labelOrigen.setText("Origen: " + texto);
    }

    public void setDestino(String texto) {
        labelDestino.setText("Destino: " + texto);
    }

    public void setFecha(String texto) {
        labelFecha.setText("Fecha: " + texto);
    }

    public void setHoraSalida(String texto) {
        labelHoraSalida.setText("Hora de Salida: " + texto);
    }

    public void setHoraLlegada(String texto) {
        labelHoraLlegada.setText("Hora de Llegada: " + texto);
    }

    public void setEstado(String texto) {
        labelEstado.setText("Estado: " + texto);
    }

    public void setAvion(String texto) {
        labelAvion.setText("Avión: " + texto);
    }

    public void setCapacidadPasajeros(int cantidad) {
        labelCapacidad.setText("Capacidad: " + cantidad + " pasajeros");
    }

    public void setCapacidadCarga(int kilos) {
        labelCapacidad.setText("Capacidad: " + kilos + " kg de carga");
    }

    public void setPuntualidad(String texto) {
        labelPuntualidad.setText("Puntualidad: " + texto);
    }
}
