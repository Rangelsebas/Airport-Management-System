package interfaz.gestor.peticionesVuelosRecu.controlador;

import java.time.format.DateTimeFormatter;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.SolicitudRecurrente;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.peticionesVuelosRecu.aprobar.controlador.ControlPanelAprobarSoliRecu;
import interfaz.gestor.peticionesVuelosRecu.aprobar.vista.PanelAprobarSoliRecu;
import interfaz.gestor.peticionesVuelosRecu.vista.PanelPeticionesVuelosRecu;

public class ControlPanelPeticionesVuelosRecu {
    private final PanelPeticionesVuelosRecu vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelPeticionesVuelosRecu(PanelPeticionesVuelosRecu vista) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.aplicacion = Aplicacion.init("");

        if (aplicacion.verSolicitudesVuelosRecurrentes().isEmpty()) {
            vista.añadirSolicitud("No hay nuevas solicitudes");
        } else {
            for (SolicitudRecurrente soli : aplicacion.verSolicitudesVuelosRecurrentes()) {
                Vuelo vuelo = soli.getVuelos().get(0);
                String texto = "SolicitudRecurrente con id: " + soli.getIdSolicitud() + " Aerolinea: " + vuelo.getAerolineaOperadora().getNombre() + " | " + 
                " | " + vuelo.getHoraSalida().format(DateTimeFormatter.ofPattern("HH:mm")) + " - " + vuelo.getHoraLlegada().format(DateTimeFormatter.ofPattern("HH:mm")) + 
                " | " + vuelo.getOrigen().getNombre() + " - " + vuelo.getDestino().getNombre() + " Cantidad de vuelos: " + soli.getVuelos().size() + "\n";
                vista.añadirSolicitud(texto);
            }
            
            vista.getListaSolicitudes().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int index = vista.getListaSolicitudes().locationToIndex(evt.getPoint());
                    String texto = vista.getListaSolicitudes().getModel().getElementAt(index);
                    String codigo = getCodigo(texto);
                    
                    if (index >= 0) {                     
                        PanelAprobarSoliRecu panelGestion = new PanelAprobarSoliRecu(
                            pantalla, codigo
                            );
                            new ControlPanelAprobarSoliRecu(panelGestion, codigo, pantalla);
                            pantalla.mostrarContenidoEnPanelCentral(panelGestion);
                        }
                    }
                }
            });
        }
    }
    
    private String getCodigo(String texto){
        String clave = "SolicitudRecurrente con id: ";
        int pos = texto.indexOf(clave);
        String codigo = "";

        if (pos != -1) {
            // comenzamos justo tras la clave
            int start = pos + clave.length();
            // buscamos el siguiente separador " "
            int end = texto.indexOf(" ", start);
            if (end == -1) {
                // si no hay barra, cogemos hasta el cierre del div
                end = texto.indexOf("<", start);
            }
            codigo = texto.substring(start, end).trim();
        }

        return codigo;
    }
}
