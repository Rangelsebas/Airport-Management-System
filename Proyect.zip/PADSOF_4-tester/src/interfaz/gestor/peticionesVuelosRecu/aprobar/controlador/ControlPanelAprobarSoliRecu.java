package interfaz.gestor.peticionesVuelosRecu.aprobar.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;

import funcionalidad.aeropuerto.elementos.Terminal;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.ControladorAereo;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.peticionesVuelosRecu.aprobar.vista.PanelAprobarSoliRecu;
import interfaz.gestor.peticionesVuelosRecu.controlador.ControlPanelPeticionesVuelosRecu;
import interfaz.gestor.peticionesVuelosRecu.vista.PanelPeticionesVuelosRecu;

public class ControlPanelAprobarSoliRecu implements ActionListener {
    private final PanelAprobarSoliRecu vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelAprobarSoliRecu(PanelAprobarSoliRecu vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("");
        this.vista.getBtnAprobar().addActionListener(this);
        this.vista.getBtnRechazar().addActionListener(this);
        actualizarDatos();
    }

    private void actualizarDatos() {
        List<Terminal> terminales = aplicacion.getAeropuertoPropio().getTerminales();
        
        for (Terminal terminal : terminales) {
            vista.añadirTerminal(terminal.getNombre());
            List<ControladorAereo> controladores = aplicacion.getAeropuertoPropio().getTerminal(terminal.getNombre()).getControladores();
            for (ControladorAereo controlador : controladores) {
                vista.añadirControlador(terminal.getNombre(), controlador.getNombreUsuario());
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnAprobar()) {
            String terminal = (String) vista.getComboTerminal().getSelectedItem();
            String controlador = (String) vista.getComboControlador().getSelectedItem();

            if (terminal == null || controlador == null) {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione un terminal y un controlador.");
                return;
            }

            if(aplicacion.aprobarVuelosRecurrentes(codigo, terminal, controlador)){
                System.out.println("✅ Solicitud aprobada:");
                System.out.println("→ Terminal asignado: " + terminal);
                System.out.println("→ Controlador asignado: " + controlador);
                JOptionPane.showMessageDialog(null, "Solicitud aprobada correctamente.");
                volver();
            } else {
                JOptionPane.showMessageDialog(null, "Error al aprobar la solicitud.");
            }            

        } else if (source == vista.getBtnRechazar()) {
            System.out.println("❌ Solicitud rechazada:");
            
            if(aplicacion.rechazarSolicitudVuelo(codigo, "Rechazado por el gestor")){
                JOptionPane.showMessageDialog(null, "Solicitud rechazada.");
                volver();
            } else {
                JOptionPane.showMessageDialog(null, "Error inesperado al intentar rechazar la solicitud.");
            }

        }
    }

    private void volver(){
        // Volver a la pantalla de Solicitudes
        PanelPeticionesVuelosRecu panelPeticiones = new PanelPeticionesVuelosRecu(pantalla);
        new ControlPanelPeticionesVuelosRecu(panelPeticiones);
        pantalla.mostrarContenidoEnPanelCentral(panelPeticiones);
    }
}
