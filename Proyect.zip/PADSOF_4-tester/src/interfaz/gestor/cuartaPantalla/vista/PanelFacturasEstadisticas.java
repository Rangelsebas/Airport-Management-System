package interfaz.gestor.cuartaPantalla.vista;

import javax.swing.*;
import interfaz.componentes.PantallaBase;
import java.awt.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class PanelFacturasEstadisticas extends JPanel {

    private PantallaBase pantallaBase;
    private JList<String> listaFacturas;
    private DefaultListModel<String> modeloFacturas;
    private JSpinner spinnerDesde;
    private JSpinner spinnerHasta;
    private JButton botonEmitirFactura;
    private JButton botonEstadisticas;

    public PanelFacturasEstadisticas(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // --- Título ---
        JLabel titulo = new JLabel("📑 Histórico de Facturas", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        add(titulo, BorderLayout.NORTH);

        // --- Centro: Lista de facturas ---
        modeloFacturas = new DefaultListModel<>();
        listaFacturas = new JList<>(modeloFacturas);
        listaFacturas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaFacturas.setFont(new Font("Monospaced", Font.PLAIN, 14));
        DefaultListCellRenderer renderer = new DefaultListCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.CENTER);
        listaFacturas.setCellRenderer(renderer);

        JScrollPane scrollFacturas = new JScrollPane(listaFacturas);
        scrollFacturas.setPreferredSize(new Dimension(900, 250));
        scrollFacturas.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        add(scrollFacturas, BorderLayout.CENTER);

        // --- Sur: Filtros y botones ---
        JPanel panelSur = new JPanel();
        panelSur.setLayout(new BoxLayout(panelSur, BoxLayout.Y_AXIS));
        panelSur.setBackground(Color.WHITE);

        JLabel filtroLabel = new JLabel("📆 Filtrar por fechas", SwingConstants.CENTER);
        filtroLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        filtroLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        panelSur.add(filtroLabel);
        panelSur.add(Box.createVerticalStrut(10));

        JPanel fechasPanel = new JPanel(new FlowLayout());
        fechasPanel.setBackground(Color.WHITE);

        // Spinner para fecha "Desde"
        spinnerDesde = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorDesde = new JSpinner.DateEditor(spinnerDesde, "dd/MM/yyyy");
        spinnerDesde.setEditor(editorDesde);

        // Spinner para fecha "Hasta"
        spinnerHasta = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editorHasta = new JSpinner.DateEditor(spinnerHasta, "dd/MM/yyyy");
        spinnerHasta.setEditor(editorHasta);

        fechasPanel.add(new JLabel("Desde:"));
        fechasPanel.add(spinnerDesde);
        fechasPanel.add(new JLabel("Hasta:"));
        fechasPanel.add(spinnerHasta);
        panelSur.add(fechasPanel);

        JPanel botonesPanel = new JPanel(new FlowLayout());
        botonesPanel.setBackground(Color.WHITE);
        botonEmitirFactura = new JButton("Emitir nueva factura");
        botonEstadisticas = new JButton("Filtrar");
        botonesPanel.add(botonEmitirFactura);
        botonesPanel.add(botonEstadisticas);
        panelSur.add(botonesPanel);

        add(panelSur, BorderLayout.SOUTH);
    }

    /**
     * Permite convertir el valor del spinner a LocalDate
     */
    private LocalDate toLocalDate(JSpinner spinner) {
        Date date = (Date) spinner.getValue();
        return Instant.ofEpochMilli(date.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    public void añadirFactura(String factura) {
        modeloFacturas.addElement(factura.toString());
    }

    public LocalDate getFechaDesde() {
        return toLocalDate(spinnerDesde);
    }

    public LocalDate getFechaHasta() {
        return toLocalDate(spinnerHasta);
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public JList<String> getListaFacturas() {
        return listaFacturas;
    }

    public JButton getBotonEmitirFactura() {
        return botonEmitirFactura;
    }

    public JButton getBotonEstadisticas() {
        return botonEstadisticas;
    }
}
