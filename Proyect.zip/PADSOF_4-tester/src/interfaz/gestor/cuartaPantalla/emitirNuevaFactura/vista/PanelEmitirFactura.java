package interfaz.gestor.cuartaPantalla.emitirNuevaFactura.vista;

import interfaz.componentes.PantallaBase;
import java.awt.*;
import java.util.List;
import java.util.*;
import javax.swing.*;

public class PanelEmitirFactura extends JPanel {

    private PantallaBase pantallaBase;

    private JComboBox<String> comboAerolinea;
    private JComboBox<String> comboAno;
    private JComboBox<String> comboMes;
    private JButton btnGenerarFactura;

    // Datos: Aerolínea -> (Año -> Lista de meses disponibles)
    private Map<String, Map<Integer, List<Integer>>> aerolineaFechasMap = new HashMap<>();

    public PanelEmitirFactura(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        // Título
        add(crearLabel("🧾 Emitir Nueva Factura", Font.BOLD, 18));
        add(Box.createVerticalStrut(10));

        // Combo Aerolíneas
        comboAerolinea = new JComboBox<>(new String[]{"Seleccionar Aerolínea"});
        comboAerolinea.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(new JLabel("Aerolínea:"));
        add(comboAerolinea);
        add(Box.createVerticalStrut(10));

        // Combo Años
        comboAno = new JComboBox<>(new String[]{"Seleccionar Año"});
        comboAno.setAlignmentX(Component.CENTER_ALIGNMENT);
        comboAno.setEnabled(false);
        add(new JLabel("Año:"));
        add(comboAno);
        add(Box.createVerticalStrut(10));

        // Combo Meses
        comboMes = new JComboBox<>(new String[]{"Seleccionar Mes"});
        comboMes.setAlignmentX(Component.CENTER_ALIGNMENT);
        comboMes.setEnabled(false);
        add(new JLabel("Mes:"));
        add(comboMes);
        add(Box.createVerticalStrut(20));

        // Botón Generar Factura
        btnGenerarFactura = new JButton("Generar Factura");
        btnGenerarFactura.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnGenerarFactura.setEnabled(false);
        add(btnGenerarFactura);

        // Listeners para actualizar fechas
        comboAerolinea.addActionListener(e -> actualizarAnios());
        comboAno.addActionListener(e -> actualizarMeses());
        comboMes.addActionListener(e -> comprobarGeneracion());
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    /**
     * Añade una aerolínea al combo y prepara su mapa interno.
     */
    public void añadirAerolinea(String nombre) {
        aerolineaFechasMap.putIfAbsent(nombre, new HashMap<>());
        comboAerolinea.addItem(nombre);
    }

    /**
     * Añade un año válido para una aerolínea.
     */
    public void añadirAno(String aerolinea, int ano) {
        aerolineaFechasMap.putIfAbsent(aerolinea, new HashMap<>());
        aerolineaFechasMap.get(aerolinea).putIfAbsent(ano, new ArrayList<>());
    }

    /**
     * Añade un mes válido para una aerolínea y año.
     */
    public void añadirMes(String aerolinea, int ano, int mes) {
        añadirAno(aerolinea, ano);
        List<Integer> meses = aerolineaFechasMap.get(aerolinea).get(ano);
        if (!meses.contains(mes)) {
            meses.add(mes);
        }
    }

        /**
     * Actualiza el combo de años en función de la aerolínea seleccionada.
     */
    public void actualizarAnios() {
        String aero = (String) comboAerolinea.getSelectedItem();
        comboAno.removeAllItems();
        comboAno.addItem("Seleccionar Año");
        comboMes.removeAllItems();
        comboMes.addItem("Seleccionar Mes");
        comboMes.setEnabled(false);
        btnGenerarFactura.setEnabled(false);

        if (aero != null && aerolineaFechasMap.containsKey(aero)) {
            for (Integer ano : aerolineaFechasMap.get(aero).keySet()) {
                comboAno.addItem(String.valueOf(ano));
            }
            comboAno.setEnabled(true);
        } else {
            comboAno.setEnabled(false);
        }

        revalidate();
        repaint();
    }

    /**
     * Actualiza el combo de meses en función de la aerolínea y año seleccionados.
     */
    public void actualizarMeses() {
        String aero = (String) comboAerolinea.getSelectedItem();
        String selAno = (String) comboAno.getSelectedItem();
        comboMes.removeAllItems();
        comboMes.addItem("Seleccionar Mes");
        btnGenerarFactura.setEnabled(false);

        if (aero != null && selAno != null && !selAno.equals("Seleccionar Año")) {
            int ano = Integer.parseInt(selAno);
            List<Integer> meses = aerolineaFechasMap.get(aero).getOrDefault(ano, Collections.emptyList());
            for (Integer mes : meses) {
                comboMes.addItem(String.valueOf(mes));
            }
            comboMes.setEnabled(true);
        } else {
            comboMes.setEnabled(false);
        }

        revalidate();
        repaint();
    }

    /**
     * Habilita o deshabilita el botón de generar factura según la selección de mes.
     */
    public void comprobarGeneracion() {
        String selMes = (String) comboMes.getSelectedItem();
        btnGenerarFactura.setEnabled(selMes != null && !selMes.equals("Seleccionar Mes"));
    }

    // Getters ...
    public JComboBox<String> getComboAerolinea() { return comboAerolinea; }
    public JComboBox<String> getComboAno() { return comboAno; }
    public JComboBox<String> getComboMes() { return comboMes; }
    public JButton getBtnGenerarFactura() { return btnGenerarFactura; }
    public PantallaBase getPantallaBase() { return pantallaBase; }
}

