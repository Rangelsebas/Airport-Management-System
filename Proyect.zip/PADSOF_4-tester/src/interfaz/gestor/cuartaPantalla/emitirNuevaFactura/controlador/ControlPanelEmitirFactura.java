package interfaz.gestor.cuartaPantalla.emitirNuevaFactura.controlador;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Ocupacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.cuartaPantalla.emitirNuevaFactura.vista.PanelEmitirFactura;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.*;

public class ControlPanelEmitirFactura implements ActionListener {
    private PanelEmitirFactura vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelEmitirFactura(PanelEmitirFactura vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("");

        // Poblado inicial sin duplicados
        List<Vuelo> historicos = aplicacion.vuelosHistoricos();
        Set<String> aeros = new HashSet<>();
        for (Vuelo v : historicos) {
            for (Ocupacion o : v.getOcupaciones()) {
                String nombre = o.getAerolineaSolicitante().getNombre();
                int año = v.getFecha().getYear();
                int mes = v.getFecha().getMonthValue();
                if (aeros.add(nombre)) {
                    vista.añadirAerolinea(nombre);
                }
                vista.añadirAno(nombre, año);
                vista.añadirMes(nombre, año, mes);
                
            }
        }

        // Registrar listeners en el controlador para la vista
        JComboBox<String> comboAero = vista.getComboAerolinea();
        JComboBox<String> comboAno = vista.getComboAno();
        JComboBox<String> comboMes = vista.getComboMes();
        JButton btn = vista.getBtnGenerarFactura();

        comboAero.addActionListener(this);
        comboAno.addActionListener(this);
        comboMes.addActionListener(this);
        btn.addActionListener(this);

        // Estado inicial
        comboAero.setSelectedIndex(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        JComboBox<String> comboAero = vista.getComboAerolinea();
        JComboBox<String> comboAno = vista.getComboAno();
        JComboBox<String> comboMes = vista.getComboMes();

        if (src == comboAero) {
            vista.actualizarAnios();
        } else if (src == comboAno) {
            vista.actualizarMeses();
        } else if (src == comboMes) {
            vista.comprobarGeneracion();
        } else if (src == vista.getBtnGenerarFactura()) {
            lanzarFactura();
        }
    }

    private void lanzarFactura() {
        try {
            String aero = (String) vista.getComboAerolinea().getSelectedItem();
            String añoStr = (String) vista.getComboAno().getSelectedItem();
            String mesStr = (String) vista.getComboMes().getSelectedItem();

            if (aero == null || añoStr.startsWith("Seleccionar") || mesStr.startsWith("Seleccionar")) {
                JOptionPane.showMessageDialog(pantalla,
                        "Seleccione aerolínea, año y mes.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int año = Integer.parseInt(añoStr);
            int mes = Integer.parseInt(mesStr);
            LocalDate fechaFactura = LocalDate.of(año, mes, 1);

            // NUEVA VERIFICACIÓN
            if (aplicacion.facturaYaEmitida(aplicacion.getAerolinea(aero), fechaFactura)) {
                JOptionPane.showMessageDialog(pantalla,
                        "Ya se ha emitido una factura para esta aerolínea en ese período.",
                        "Factura duplicada", JOptionPane.WARNING_MESSAGE);
                return;
            }

            aplicacion.emitirFactura(aplicacion.getAerolinea(aero), fechaFactura);
            JOptionPane.showMessageDialog(pantalla,
                    "Factura generada para " + aero + " " + mes + "/" + año,
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(pantalla,
                    "Error al generar factura: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}