package interfaz.gestor.cuartaPantalla.controlador;

import javax.swing.*;

import java.util.regex.Matcher; 
import java.util.regex.Pattern;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.Factura;
import interfaz.gestor.cuartaPantalla.emitirNuevaFactura.controlador.ControlPanelEmitirFactura;
import interfaz.gestor.cuartaPantalla.emitirNuevaFactura.vista.PanelEmitirFactura;
import interfaz.gestor.cuartaPantalla.vista.PanelFacturasEstadisticas;

import java.awt.Dimension;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class ControlPanelFacturasEstadisticas implements ActionListener {

    private PanelFacturasEstadisticas vista;
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private Aplicacion aplicacion = Aplicacion.init("");

    public ControlPanelFacturasEstadisticas(PanelFacturasEstadisticas vista) {
        this.vista = vista;
        configurarListeners();
        cargarInicial();
    }

    private void configurarListeners() {
        // Doble clic: abrir detalle factura
        vista.getListaFacturas().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int index = vista.getListaFacturas().locationToIndex(evt.getPoint());
                    if (index >= 0) {
                        String selected = vista.getListaFacturas().getModel().getElementAt(index);
                        Pattern pattern = Pattern.compile("(F-\\d+):");
                        Matcher matcher = pattern.matcher(selected);
                        String idFactura;
                        if (matcher.find()) {
                            idFactura = matcher.group(1);       
                        } else {
                            // Si no encaja, lo marcamos como error y salimos
                            JOptionPane.showMessageDialog(vista,
                                "No se ha podido extraer el ID de la factura.",
                                "Error de formato",
                                JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        Factura factura = aplicacion.getFacturaById(idFactura);
                        System.out.println("Factura seleccionada: " + idFactura);
                        if (factura != null) {
                            // Creamos un área de texto multilinea
                            JTextArea area = new JTextArea(factura.toString());
                            area.setEditable(false);
                            area.setLineWrap(true);
                            area.setWrapStyleWord(true);
                            area.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

                            // Lo metemos en un scroll por si es muy largo
                            JScrollPane scroll = new JScrollPane(area);
                            scroll.setPreferredSize(new Dimension(400, 200));

                            // Lo mostramos en el JOptionPane
                            JOptionPane.showMessageDialog(vista,
                                scroll,
                                "Detalles de la factura " + factura.getId(),
                                JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(vista,
                                "Factura no encontrada.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        });

        // Emitir nueva factura
        vista.getBotonEmitirFactura().addActionListener(this);

        // Filtrar por fechas
        vista.getBotonEstadisticas().addActionListener(e -> filtrarFacturas());
    }

    private void cargarInicial() {
        // Carga todas las facturas sin filtro
        List<Factura> facturas = aplicacion.getFacturas();
        mostrarFacturas(facturas);
    }

    private void filtrarFacturas() {
        try {
            LocalDate desde = vista.getFechaDesde();
            LocalDate hasta = vista.getFechaHasta();
            List<Factura> facturas = aplicacion
                .getFacturas().stream()
                .filter(f -> !f.verFechaEmision().isBefore(desde) && !f.verFechaEmision().isAfter(hasta))
                .collect(Collectors.toList());
            mostrarFacturas(facturas);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista,
                "Fecha no válida. Usar formato dd/MM/yyyy",
                "Error de formato",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarFacturas(List<Factura> facturas) {
        for (Factura f : facturas) {
            vista.añadirFactura(
                "Datos de la factura " + f.getId() + ": " + " Aerolinea: " + f.getAirline() + " Fecha de emision: " + f.verFechaEmision().format(formatter) 
                + " Vuelos cobrados: " + f.getVuelosCobrados().size() + " Precio total: " + f.getPrice() + "€" + "\n"
            );
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBotonEmitirFactura()) {
            PanelEmitirFactura panelEmitir = new PanelEmitirFactura(vista.getPantallaBase());
            new ControlPanelEmitirFactura(panelEmitir, vista.getPantallaBase());
            vista.getPantallaBase().mostrarContenidoEnPanelCentral(panelEmitir);
        }
    }
}
