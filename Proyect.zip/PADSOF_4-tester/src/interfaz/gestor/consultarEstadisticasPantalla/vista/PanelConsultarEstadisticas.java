package interfaz.gestor.consultarEstadisticasPantalla.vista;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelConsultarEstadisticas extends JPanel {

    private JButton botonActualizar;
    private JLabel labelPorcentajeRetrasados;
    private JLabel labelParticipacionAerolinea;
    private JLabel labelMediaDiaria;
    private JComboBox<String> comboAerolineas;

    public PanelConsultarEstadisticas() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 40, 20, 40));

        add(crearTitulo("Estadísticas del Aeropuerto"));

        labelPorcentajeRetrasados = crearEtiqueta("Porcentaje de vuelos retrasados: --%");
        add(labelPorcentajeRetrasados);

        add(Box.createVerticalStrut(20));

        comboAerolineas = new JComboBox<>();
        comboAerolineas.setMaximumSize(new Dimension(300, 30));
        add(new JLabel("Seleccionar Aerolínea:"));
        add(comboAerolineas);

        labelParticipacionAerolinea = crearEtiqueta("Participación de la aerolínea: --%");
        add(labelParticipacionAerolinea);

        add(Box.createVerticalStrut(20));

        labelMediaDiaria = crearEtiqueta("Media diaria de vuelos: -- vuelos/día");
        add(labelMediaDiaria);

        add(Box.createVerticalStrut(30));

        botonActualizar = new JButton("Actualizar estadísticas");
        botonActualizar.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(botonActualizar);
    }

    public void setControlador(ActionListener c) {
        botonActualizar.addActionListener(c);
    }

    public String getAerolineaSeleccionada() {
        return (String) comboAerolineas.getSelectedItem();
    }

    public void setAerolineas(String[] aerolineas) {
        comboAerolineas.removeAllItems();
        for (String a : aerolineas) comboAerolineas.addItem(a);
    }

    public void mostrarPorcentajeRetrasados(int porcentaje) {
        labelPorcentajeRetrasados.setText("Porcentaje de vuelos retrasados: " + porcentaje + "%");
    }

    public void mostrarParticipacionAerolinea(int porcentaje) {
        labelParticipacionAerolinea.setText("Participación de la aerolínea: " + porcentaje + "%");
    }

    public void mostrarMediaDiaria(int media) {
        labelMediaDiaria.setText("Media diaria de vuelos: " + media + " vuelos/día");
    }

    private JLabel crearTitulo(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.BOLD, 22));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalStrut(10));
        return label;
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }
}