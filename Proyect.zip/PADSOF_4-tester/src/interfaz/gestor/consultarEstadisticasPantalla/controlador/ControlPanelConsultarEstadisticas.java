package interfaz.gestor.consultarEstadisticasPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.gestor.consultarEstadisticasPantalla.vista.PanelConsultarEstadisticas;

public class ControlPanelConsultarEstadisticas implements ActionListener {

    private final PanelConsultarEstadisticas vista;
    private final Aplicacion aplicacion;

    public ControlPanelConsultarEstadisticas(PanelConsultarEstadisticas vista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");

        vista.setControlador(this);

        // Cargar aerolíneas al iniciar
        List<Aerolinea> aerolineas = aplicacion.getAerolineasDisponibles();
        String[] nombres = aerolineas.stream().map(Aerolinea::getNombre).toArray(String[]::new);
        vista.setAerolineas(nombres);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        actualizarEstadisticas();
    }

    private void actualizarEstadisticas() {
        int porcentajeRetrasados = aplicacion.porcentajeVuelosRetrasados();
        int mediaDiaria = aplicacion.mediaDiaria();

        vista.mostrarPorcentajeRetrasados(porcentajeRetrasados);
        vista.mostrarMediaDiaria(mediaDiaria);

        String seleccion = vista.getAerolineaSeleccionada();
        if (seleccion != null) {
            int porcentajeParticipacion = aplicacion.porcentajeParticipacionAerolinea(seleccion);
            vista.mostrarParticipacionAerolinea(porcentajeParticipacion);
        }
    }
}
