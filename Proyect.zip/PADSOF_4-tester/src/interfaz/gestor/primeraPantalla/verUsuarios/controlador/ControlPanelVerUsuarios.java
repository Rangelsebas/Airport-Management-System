package interfaz.gestor.primeraPantalla.verUsuarios.controlador;

import java.util.List;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.Usuario;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.primeraPantalla.verUsuarios.vista.PanelVerUsuarios;

public class ControlPanelVerUsuarios {

    private PanelVerUsuarios vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelVerUsuarios(PanelVerUsuarios vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        //cargarUsuariosDePrueba();
        this.aplicacion = Aplicacion.init("");
        cargarUsuarios();
    }

    // private void cargarUsuariosDePrueba() {
    //     // Mock de usuarios para pruebas visuales

    //     vista.agregarUsuario("admin");
    //     vista.agregarUsuario("operador01");
    //     vista.agregarUsuario("gestorMain");
    //     vista.agregarUsuario("controladorVuelo1");
    //     vista.agregarUsuario("supervisorPistas");
    // }

    public void cargarUsuarios() {
        vista.reset();
        List<Usuario> usuarios = aplicacion.listarUsuarios();
        for (Usuario usuario : usuarios) {
            vista.agregarUsuario(usuario.toString());
        }
    }
}
