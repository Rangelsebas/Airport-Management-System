package interfaz.gestor.primeraPantalla.eliminarUsuario.controlador;

import javax.swing.*;

import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.primeraPantalla.eliminarUsuario.vista.PanelEliminarUsuario;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelEliminarUsuario implements ActionListener {

    private PanelEliminarUsuario vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelEliminarUsuario(PanelEliminarUsuario vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case ELIMINAR_USUARIO:
                procesarEliminacionUsuario();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarEliminacionUsuario() {
        String usuario = vista.getUsuario();
        String contrasena = vista.getContrasena();

        // Validaciones
        if (usuario == null || contrasena == null) {
            JOptionPane.showMessageDialog(vista, "Error interno: Campos nulos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (usuario.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe completar ambos campos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (usuario.equals("Usuario a eliminar")) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar el nombre de usuario.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (contrasena.equals("Contraseña")) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar la contraseña.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    

        // TODO: Aquí deberías conectar con la lógica real para verificar existencia del usuario
        if (aplicacion.getUsuario(usuario) == null) {
            JOptionPane.showMessageDialog(vista, "El usuario no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else if (!aplicacion.eliminarUsuario(usuario, contrasena)) {
            JOptionPane.showMessageDialog(vista, "Error al eliminar el usuario. Verifique la contraseña.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Si pasa la validación
        System.out.println("🗑️ Usuario eliminado: " + usuario);
        JOptionPane.showMessageDialog(vista, "¡Usuario eliminado exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        vista.limpiarCampos();
    }
}
