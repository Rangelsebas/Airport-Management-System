package interfaz.gestor.primeraPantalla.controlador;

import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.primeraPantalla.crearUsuario.controlador.ControlPanelCrearUsuario;
import interfaz.gestor.primeraPantalla.crearUsuario.vista.PanelCrearUsuario;
import interfaz.gestor.primeraPantalla.eliminarUsuario.controlador.ControlPanelEliminarUsuario;
import interfaz.gestor.primeraPantalla.eliminarUsuario.vista.PanelEliminarUsuario;
import interfaz.gestor.primeraPantalla.verUsuarios.controlador.ControlPanelVerUsuarios;
import interfaz.gestor.primeraPantalla.verUsuarios.vista.PanelVerUsuarios;
import interfaz.gestor.primeraPantalla.vista.PanelAdministrarUsuarios;

public class ControlPanelAdministrarUsuarios implements ActionListener {

    private final PanelAdministrarUsuarios vista;
    private final PantallaBase pantalla;

    public ControlPanelAdministrarUsuarios(PanelAdministrarUsuarios vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CREAR_USUARIO:
                PanelCrearUsuario panelCrearUsuario = new PanelCrearUsuario();
                new ControlPanelCrearUsuario(panelCrearUsuario, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelCrearUsuario);
                break;

            case ELIMINAR_USUARIO:
                PanelEliminarUsuario panelEliminarUsuario = new PanelEliminarUsuario();
                new ControlPanelEliminarUsuario(panelEliminarUsuario, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelEliminarUsuario);
                break;

            case VER_USUARIOS:
                PanelVerUsuarios panelVerUsuarios = new PanelVerUsuarios();
                new ControlPanelVerUsuarios(panelVerUsuarios, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelVerUsuarios);
                break;
            default:
                break;
        }
    }
}