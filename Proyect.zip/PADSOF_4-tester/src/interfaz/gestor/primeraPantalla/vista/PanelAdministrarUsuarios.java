package interfaz.gestor.primeraPantalla.vista;

import java.awt.*;
import java.util.List;
import javax.swing.*;

import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.event.ActionListener;

public class PanelAdministrarUsuarios extends JPanel {

    private PantallaBase pantallaBase;
    private List<JButton> botones;

    public PanelAdministrarUsuarios(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        botones = List.of(
            crearBoton("Crear Usuario", ComandoVentanaGestorEnum.CREAR_USUARIO),
            crearBoton("Eliminar Usuario", ComandoVentanaGestorEnum.ELIMINAR_USUARIO),
            crearBoton("Ver Usuarios del Sistema", ComandoVentanaGestorEnum.VER_USUARIOS)
        );

        // Contenedor vertical
        JPanel contenedor = new JPanel();
        contenedor.setLayout(new BoxLayout(contenedor, BoxLayout.Y_AXIS));
        contenedor.setBackground(Color.WHITE);

        for (JButton boton : botones) {
            boton.setAlignmentX(Component.CENTER_ALIGNMENT);
            boton.setMaximumSize(new Dimension(220, 50));
            boton.setMinimumSize(new Dimension(220, 50));
            boton.setPreferredSize(new Dimension(220, 50));
            boton.setFont(new Font("SansSerif", Font.PLAIN, 14));
            boton.setFocusable(false);
            boton.setHorizontalAlignment(SwingConstants.CENTER);
            contenedor.add(Box.createVerticalStrut(12)); // Separación
            contenedor.add(boton);
        }

        add(contenedor); // Añadir al centro
    }

    private JButton crearBoton(String texto, ComandoVentanaGestorEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        return boton;
    }

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void mostrarPanel(JPanel panel) {
        pantallaBase.mostrarContenidoEnPanelCentral(panel);
    }
}
