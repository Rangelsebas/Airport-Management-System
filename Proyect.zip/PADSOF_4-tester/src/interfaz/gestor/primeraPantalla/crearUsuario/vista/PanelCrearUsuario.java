package interfaz.gestor.primeraPantalla.crearUsuario.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class PanelCrearUsuario extends JPanel {

    private JTextField noombre;
    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JTextField campoEmail;
    private JTextField campoDNI;
    private JButton botonCrear;
    private JComboBox<String> tipoUsuarioCombo;
    private JComboBox<String> terminalCombo;
    private JComboBox<String> aerolineaCombo;

    public PanelCrearUsuario() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50));

        // Campo para nombre
        noombre = new JTextField();
        noombre.setMaximumSize(new Dimension(500, 30));
        noombre.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(noombre, "Nombre");
        add(noombre);

        add(Box.createVerticalStrut(20));

        // Campo para nuevo usuario
        campoUsuario = new JTextField();
        campoUsuario.setMaximumSize(new Dimension(500, 30));
        campoUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoUsuario, "Nuevo Usuario");
        add(campoUsuario);

        add(Box.createVerticalStrut(20));

        // Campo para contraseña
        campoContrasena = new JPasswordField();
        campoContrasena.setMaximumSize(new Dimension(500, 30));
        campoContrasena.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoContrasena, "Contraseña");
        add(campoContrasena);

        add(Box.createVerticalStrut(20));

        // Campo para Email
        campoEmail = new JTextField();
        campoEmail.setMaximumSize(new Dimension(500, 30));
        campoEmail.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoEmail, "Email");
        add(campoEmail);

        add(Box.createVerticalStrut(20));

        // Campo para DNI
        campoDNI = new JTextField();
        campoDNI.setMaximumSize(new Dimension(500, 30));
        campoDNI.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoDNI, "DNI");
        add(campoDNI);

        add(Box.createVerticalStrut(20));

        // Combo para tipo de usuario (inicio en blanco)
        tipoUsuarioCombo = new JComboBox<>(new String[]{"", "Controlador Aereo", "Operador de Aerolinea"});
        tipoUsuarioCombo.setMaximumSize(new Dimension(500, 30));
        tipoUsuarioCombo.setAlignmentX(Component.CENTER_ALIGNMENT);
        tipoUsuarioCombo.setSelectedIndex(0);
        add(tipoUsuarioCombo);

        add(Box.createVerticalStrut(20));

        // Combo para terminales (solo Controlador)
        terminalCombo = new JComboBox<>(new String[]{"Terminal 1", "Terminal 2", "Terminal 3"});
        terminalCombo.setMaximumSize(new Dimension(500, 30));
        terminalCombo.setAlignmentX(Component.CENTER_ALIGNMENT);
        terminalCombo.setVisible(false);
        add(terminalCombo);

        add(Box.createVerticalStrut(20));

        // Combo para aerolíneas (solo Gestor)
        aerolineaCombo = new JComboBox<>(new String[]{"Aerolínea A", "Aerolínea B", "Aerolínea C"});
        aerolineaCombo.setMaximumSize(new Dimension(500, 30));
        aerolineaCombo.setAlignmentX(Component.CENTER_ALIGNMENT);
        aerolineaCombo.setVisible(false);
        add(aerolineaCombo);

        add(Box.createVerticalStrut(20));

        // Botón Crear
        botonCrear = new JButton("Crear");
        botonCrear.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonCrear.setActionCommand(ComandoVentanaGestorEnum.CREAR_USUARIO.name());
        add(botonCrear);

        // Listener para mostrar/ocultar combos según tipo de usuario
        tipoUsuarioCombo.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    String seleccionado = (String) tipoUsuarioCombo.getSelectedItem();
                    boolean esControlador = "Controlador Aereo".equals(seleccionado);
                    terminalCombo.setVisible(esControlador);
                    aerolineaCombo.setVisible(!esControlador);
                    revalidate();
                    repaint();
                }
            }
        });
    }

    // Métodos MVC

    public void setControlador(ActionListener c) {
        botonCrear.addActionListener(c);
    }

    public String getNombre() {
        return noombre.getText().trim();
    }

    public String getUsuario() {
        return campoUsuario.getText().trim();
    }

    public String getContrasena() {
        return new String(campoContrasena.getPassword()).trim();
    }
    public String getDNI() {
        return campoDNI.getText().trim();
    }
    public String getEmail() {
        return campoEmail.getText().trim();
    }

    public String getTipoUsuario() {
        return (String) tipoUsuarioCombo.getSelectedItem();
    }

    /**
     * Devuelve el combo de terminales para poblar o leer valores.
     */
    public JComboBox<String> getTerminalCombo() {
        return terminalCombo;
    }

    /**
     * Devuelve el combo de aerolíneas para poblar o leer valores.
     */
    public JComboBox<String> getAerolineaCombo() {
        return aerolineaCombo;
    }

    public String getTerminalSeleccionada() {
        return terminalCombo.isVisible() ? (String) terminalCombo.getSelectedItem() : null;
    }

    public String getAerolineaSeleccionada() {
        return aerolineaCombo.isVisible() ? (String) aerolineaCombo.getSelectedItem() : null;
    }

    public void limpiarCampos() {
        restaurarPlaceholder(campoUsuario, "Nuevo Usuario");
        restaurarPlaceholder(campoContrasena, "Contraseña");
        tipoUsuarioCombo.setSelectedIndex(0);
        terminalCombo.setVisible(false);
        aerolineaCombo.setVisible(false);
    }

    private void restaurarPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);
    }

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }
}
