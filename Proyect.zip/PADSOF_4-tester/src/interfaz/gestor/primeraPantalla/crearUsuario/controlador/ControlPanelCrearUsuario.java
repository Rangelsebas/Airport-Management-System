package interfaz.gestor.primeraPantalla.crearUsuario.controlador;

import javax.swing.*;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.primeraPantalla.crearUsuario.vista.PanelCrearUsuario;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.ControladorAereo;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aeropuerto.elementos.Terminal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.stream.Stream;

public class ControlPanelCrearUsuario implements ActionListener {

    private PanelCrearUsuario vista;
    //private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelCrearUsuario(PanelCrearUsuario vista, PantallaBase pantalla) {
        this.vista = vista;
        //this.pantalla = pantalla;
        this.vista.setControlador(this);

        // Obtener instancia de la aplicación
        this.aplicacion = Aplicacion.init("");

        // Poblar combos
        inicializarCombos();
    }

    /**
     * Carga y configura los JComboBox para terminales y aerolíneas usando Streams.
     */
    private void inicializarCombos() {
        // --- Terminales disponibles ---
        List<Terminal> terminalesObj = aplicacion.getAeropuertoPropio().getTerminales();
        JComboBox<String> comboTerm = vista.getTerminalCombo();
        comboTerm.setModel(new DefaultComboBoxModel<>(
            Stream.concat(
                Stream.of(""),
                terminalesObj.stream().map(Terminal::getNombre)
            )
            .toArray(String[]::new)
        ));
        comboTerm.setVisible(false);

        // --- Aerolíneas disponibles ---
        List<Aerolinea> aerolineas = aplicacion.getAerolineasDisponibles();
        JComboBox<String> comboAero = vista.getAerolineaCombo();
        comboAero.setModel(new DefaultComboBoxModel<>(
            Stream.concat(
                Stream.of(""),
                aerolineas.stream().map(Aerolinea::getNombre)
            )
            .toArray(String[]::new)
        ));
        comboAero.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());
        if (comando == ComandoVentanaGestorEnum.CREAR_USUARIO) {
            procesarCreacionUsuario();
        } else {
            JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void procesarCreacionUsuario() {
        String nombre     = vista.getNombre();
        String usuario   = vista.getUsuario();
        String contrasena = vista.getContrasena();
        String email     = vista.getEmail();
        String dni       = vista.getDNI();
        String tipo      = vista.getTipoUsuario();
        String terminal  = vista.getTerminalSeleccionada();
        String aerolinea = vista.getAerolineaSeleccionada();

        // Validaciones
        if (usuario == null || contrasena == null) {
            JOptionPane.showMessageDialog(vista, "Error interno: Campos nulos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (nombre.isEmpty() && usuario.isEmpty() && contrasena.isEmpty() && email.isEmpty() && dni.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe completar ambos campos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (usuario.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar el nombre de usuario.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar la contraseña.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (usuario.equals("Nuevo Usuario")) {
            JOptionPane.showMessageDialog(vista, "El nombre de usuario no puede ser 'Nuevo Usuario'.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (contrasena.equals("Contraseña")) {
            JOptionPane.showMessageDialog(vista, "La contraseña no puede ser 'Contraseña'.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
              

        // Crear usuario en la lógica de negocio
        switch (tipo) {
            case "Controlador Aereo":
                if(!aplicacion.registrarControlador(usuario, dni, nombre, email, contrasena)){
                    JOptionPane.showMessageDialog(vista, "Error: El usuario ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if(aplicacion.getAeropuertoPropio().getTerminal(terminal) == null){
                    JOptionPane.showMessageDialog(vista, "Error inesperado, no se encuentra la terminal.", "Error", JOptionPane.ERROR_MESSAGE);
                    aplicacion.eliminarUsuario(usuario, contrasena);
                    return;
                } else if (!aplicacion.getAeropuertoPropio().getTerminal(terminal).añadirControlador((ControladorAereo)aplicacion.getUsuario(usuario))){
                    JOptionPane.showMessageDialog(vista, "Error inesperado.", "Error", JOptionPane.ERROR_MESSAGE);
                    aplicacion.eliminarUsuario(usuario, contrasena);
                    return;
                }
                break;
            case "Operador de Aerolinea":
                aplicacion.registrarOperador(usuario, dni, nombre, email, contrasena);
                if(aplicacion.getAerolinea(aerolinea) == null){
                    JOptionPane.showMessageDialog(vista, "Error inesperado, no se encuentra la aerolinea." + aerolinea + ".", "Error", JOptionPane.ERROR_MESSAGE);
                    aplicacion.eliminarUsuario(usuario, contrasena);
                    return;
                } else if (aplicacion.getAerolinea(aerolinea).getOperadorAerolinea() != null){
                    JOptionPane.showMessageDialog(vista, "Error: La aerolinea ya tiene operador asignado.", "Error", JOptionPane.ERROR_MESSAGE);
                    aplicacion.eliminarUsuario(usuario, contrasena);
                    return;
                } else if(!((OperadorAerolinea)aplicacion.getUsuario(usuario)).asignarAerolinea(aplicacion.getAerolinea(aerolinea))){
                    JOptionPane.showMessageDialog(vista, "Error inesperado.", "Error", JOptionPane.ERROR_MESSAGE);
                    aplicacion.eliminarUsuario(usuario, contrasena);
                    return;
                }
                break;
            default:
                break;
        }

        System.out.println("✅ Usuario creado: " + usuario + " | Tipo: " + tipo
                + (terminal != null ? (" | Terminal: " + terminal) : (" | Aerolínea: " + aerolinea)));

        JOptionPane.showMessageDialog(vista, "¡Usuario creado exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        vista.limpiarCampos();
    }
}
