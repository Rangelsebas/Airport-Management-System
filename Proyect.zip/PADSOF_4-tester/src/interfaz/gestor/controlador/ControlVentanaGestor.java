package interfaz.gestor.controlador;

import interfaz.componentes.PantallaBase;
import interfaz.comunNotificaciones.controlador.ControlPanelVerNotificaciones;
import interfaz.comunNotificaciones.vista.PanelVerNotificaciones;
import interfaz.gestor.añadirAerolinea.controlador.ControlPanelAnadirAerolinea;
import interfaz.gestor.añadirAerolinea.vista.PanelAnadirAerolinea;
import interfaz.gestor.cargarAeropuertosExternos.controlador.ControlPanelCargarAE;
import interfaz.gestor.cargarAeropuertosExternos.vista.PanelCargarAE;
import interfaz.gestor.consultarEstadisticasPantalla.controlador.ControlPanelConsultarEstadisticas;
import interfaz.gestor.consultarEstadisticasPantalla.vista.PanelConsultarEstadisticas;
import interfaz.gestor.cuartaPantalla.controlador.ControlPanelFacturasEstadisticas;
import interfaz.gestor.cuartaPantalla.vista.PanelFacturasEstadisticas;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.peticionesVuelosRecu.controlador.ControlPanelPeticionesVuelosRecu;
import interfaz.gestor.peticionesVuelosRecu.vista.PanelPeticionesVuelosRecu;
import interfaz.gestor.primeraPantalla.controlador.ControlPanelAdministrarUsuarios;
import interfaz.gestor.primeraPantalla.vista.PanelAdministrarUsuarios;
import interfaz.gestor.quintaPantalla.controlador.ControlPanelVerTiposAviones;
import interfaz.gestor.quintaPantalla.vista.PanelVerTiposAviones;
import interfaz.gestor.segundaPantalla.controlador.ControlPanelConfiguracionAeropuerto;
import interfaz.gestor.segundaPantalla.vista.PanelConfiguracionAeropuerto;
import interfaz.gestor.terceraPantalla.controlador.ControlPanelPeticionesVuelos;
import interfaz.gestor.terceraPantalla.vista.PanelPeticionesVuelos;

import interfaz.gestor.vista.VentanaGestor;
import interfaz.login.controlador.ControlPanelLoginFrame;
import interfaz.login.vista.PanelLoginFrame;

import java.awt.Component;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import funcionalidad.aplicacion.Aplicacion;

public class ControlVentanaGestor implements ActionListener {

    private VentanaGestor vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlVentanaGestor(VentanaGestor vista) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
        actualizarFechaYHora();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case ADMINISTRAR_USUARIOS:
                PanelAdministrarUsuarios panelUsuarios = new PanelAdministrarUsuarios(pantalla);
                new ControlPanelAdministrarUsuarios(panelUsuarios, vista.getPantallaBase()); // conecta el controlador de la vista
                pantalla.mostrarContenidoEnPanelCentral(panelUsuarios);
                break;

            case CREAR_AEROLINEA:
                PanelAnadirAerolinea panelAnadirAerolinea = new PanelAnadirAerolinea();
                new ControlPanelAnadirAerolinea(panelAnadirAerolinea, pantalla); // conecta el controlador de la vista
                pantalla.mostrarContenidoEnPanelCentral(panelAnadirAerolinea);
                break;

            case CONFIGURACION_AEROPUERTO:
                PanelConfiguracionAeropuerto panelConfiguracion = new PanelConfiguracionAeropuerto(vista.getPantallaBase());
                new ControlPanelConfiguracionAeropuerto(panelConfiguracion, pantalla); // conecta el controlador de la vista
                vista.mostrarPanel(panelConfiguracion);
                break;

            case PETICIONES_VUELOS:
                PanelPeticionesVuelos panelPeticiones = new PanelPeticionesVuelos(pantalla);
                new ControlPanelPeticionesVuelos(panelPeticiones);
                pantalla.mostrarContenidoEnPanelCentral(panelPeticiones);
                break;

            case PETICIONES_VUELOS_RECURRENTE:
                PanelPeticionesVuelosRecu panelPeticionesRecu = new PanelPeticionesVuelosRecu(pantalla);
                new ControlPanelPeticionesVuelosRecu(panelPeticionesRecu);
                pantalla.mostrarContenidoEnPanelCentral(panelPeticionesRecu);
                break;

            case VER_FACTURAS_ESTADISTICAS:
                PanelFacturasEstadisticas panelFacturas = new PanelFacturasEstadisticas(vista.getPantallaBase());
                new ControlPanelFacturasEstadisticas(panelFacturas); // conectar lógica
                vista.mostrarPanel(panelFacturas);
                break;

            case CONSULTAR_ESTADISTICAS:
                PanelConsultarEstadisticas panelEstadisticas = new PanelConsultarEstadisticas();
                new ControlPanelConsultarEstadisticas(panelEstadisticas); // conecta el controlador
                vista.mostrarPanel(panelEstadisticas);
                break;

            case CARGAR_AEROPUERTOS_EXTERNOS:
                PanelCargarAE panelCargarAE = new PanelCargarAE();
                new ControlPanelCargarAE(panelCargarAE); // conecta el controlador
                vista.mostrarPanel(panelCargarAE);
                break;

            case CARGAR_TIPOS_AVIONES:
                PanelVerTiposAviones panelTipos = new PanelVerTiposAviones();
                new ControlPanelVerTiposAviones(panelTipos); // conecta el controlador
                vista.mostrarPanel(panelTipos);
                break;
            case VER_NOTIFICACIONES:
                PanelVerNotificaciones panelNotificaciones = new PanelVerNotificaciones(vista.getPantallaBase());
                new ControlPanelVerNotificaciones(panelNotificaciones); // conecta el controlador
                vista.mostrarPanel(panelNotificaciones);
                break;
            case GUARDAR_APLICACION:
                if(aplicacion.salvarAplicacion("aeropuerto.txt")) {
                    JOptionPane.showMessageDialog(vista, "Aplicación guardada correctamente.", "Guardar Aplicación", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(vista, "Error al guardar la aplicación.", "Guardar Aplicación", JOptionPane.ERROR_MESSAGE);
                }
                break;

            case CARGAR_APLICACION:
                if(aplicacion.cargarAplicacion("aeropuerto.txt")) {
                    JOptionPane.showMessageDialog(vista, "Aplicación cargada correctamente.", "Cargar Aplicación", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(vista, "Error al cargar la aplicación.", "Cargar Aplicación", JOptionPane.ERROR_MESSAGE);
                }

                // 🔥 Cerrar ventana actual
                Window ventana = SwingUtilities.getWindowAncestor((Component) e.getSource());
                cerrarSesionIrALogin(ventana);

                break;

            case CERRAR_SESION:
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Estás seguro que deseas cerrar sesión?",
                        "Cerrar sesión", JOptionPane.YES_NO_OPTION);

                if (respuesta == JOptionPane.YES_OPTION) {
                    // Cerrar sesión
                    cerrarSesionIrALogin(SwingUtilities.getWindowAncestor((Component) e.getSource()));
                } else {
                    System.out.println("No se ha cerrado la sesión.");
                }
                break;

            case AVANZAR_5M:
                aplicacion.avanzarCincoMinutos();
                JOptionPane.showMessageDialog(vista, "Tiempo avanzado 5 minutos.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Tiempo avanzado 5 minutos. Tiempo actual: " + aplicacion.getRealTime());
                actualizarFechaYHora();
                break;

            case AVANZAR_30M:
                aplicacion.avanzarTreintaMinutos();
                JOptionPane.showMessageDialog(vista, "Tiempo avanzado 30 minutos.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Tiempo avanzado 30 minutos. Tiempo actual: " + aplicacion.getRealTime());
                actualizarFechaYHora();
                break;

            case AVANZAR_1H:
                aplicacion.avanzarUnaHora();
                JOptionPane.showMessageDialog(vista, "Tiempo avanzado 1 hora.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Tiempo avanzado 1 hora. Tiempo actual: " + aplicacion.getRealTime());
                actualizarFechaYHora();
                break;

            case AVANZAR_1D:
                aplicacion.avanzarUnDia();
                JOptionPane.showMessageDialog(vista, "Tiempo avanzado 1 día.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Tiempo avanzado 1 día. Tiempo actual: " + aplicacion.getRealTime());
                actualizarFechaYHora();
                break;

            default:
                System.err.println("Comando no reconocido: " + e.getActionCommand());
                break;
        }
    }

    private void actualizarFechaYHora() {
        String fechaHora = aplicacion.getRealTime().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        pantalla.setFechaHora(fechaHora);
    }

    private void cerrarSesionIrALogin(Window ventana) {
        // Cerrar sesión
        aplicacion.cerrarSesion();
        System.out.println("Sesión cerrada correctamente.");

        // Cerrar ventana actual
        if (ventana != null) {
            ventana.dispose();
        }

        // Volver al login
        SwingUtilities.invokeLater(() -> {
            PanelLoginFrame loginFrame = new PanelLoginFrame();
            new ControlPanelLoginFrame(loginFrame); // conecta el controlador
            loginFrame.setVisible(true);
        });
    }
}
