package interfaz.gestor.añadirAerolinea.controlador;

import java.awt.event.*;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.añadirAerolinea.listadoSubMenu.controlador.ControlPanelListaAerolineas;
import interfaz.gestor.añadirAerolinea.listadoSubMenu.vista.PanelListaAerolineas;
import interfaz.gestor.añadirAerolinea.vista.PanelAnadirAerolinea;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;


public class ControlPanelAnadirAerolinea implements ActionListener {
    private PanelAnadirAerolinea vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelAnadirAerolinea(PanelAnadirAerolinea vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        aplicacion = Aplicacion.init("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());
        if (comando == ComandoVentanaGestorEnum.AÑADIR_AEROLINEA) {
            procesarCreacionAerolinea();
        } else if (comando == ComandoVentanaGestorEnum.LISTADO_AEROLINEAS) {
            PanelListaAerolineas panelListaAerolineas = new PanelListaAerolineas();
            new ControlPanelListaAerolineas(panelListaAerolineas, pantalla);
            pantalla.mostrarContenidoEnPanelCentral(panelListaAerolineas);   
        }
        
        else {
            JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void procesarCreacionAerolinea(){
        String nombreAerolinea = vista.getNombreAerolinea();
        String codigoAerolinea = vista.getCodigoAerolinea();

        if (nombreAerolinea.isEmpty() || nombreAerolinea.equals("Nombre Aerolínea")) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar un nombre para la aerolínea válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (codigoAerolinea.isEmpty() || codigoAerolinea.equals("Código Aerolínea")) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar un código para la aerolínea válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Aquí se llamaría a la lógica de negocio para crear la aerolínea
        if(!aplicacion.añadirAerolinea(nombreAerolinea, codigoAerolinea)){
            JOptionPane.showMessageDialog(vista, "Error al crear la aerolínea. Verifique los datos ingresados.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            JOptionPane.showMessageDialog(vista, "Aerolínea creada con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("Aerolínea creada: " + nombreAerolinea + " con código: " + codigoAerolinea);
        }

        // Si la creación es exitosa, se puede limpiar los campos
        vista.limpiarCampos();
    }
}
