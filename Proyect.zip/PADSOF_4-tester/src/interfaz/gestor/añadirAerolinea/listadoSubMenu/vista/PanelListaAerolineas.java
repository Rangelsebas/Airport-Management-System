package interfaz.gestor.añadirAerolinea.listadoSubMenu.vista;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ResourceBundle.Control;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import interfaz.gestor.añadirAerolinea.listadoSubMenu.controlador.ControlPanelListaAerolineas;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;

public class PanelListaAerolineas extends JPanel {
    private JPanel panelListado;
    private JButton volver;

    public PanelListaAerolineas() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Título
        JLabel titulo = new JLabel("Listado de Aerolineas", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Panel de listado
        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        // Botón "Volver"
        volver = new JButton("Volver");
        volver.setAlignmentX(Component.CENTER_ALIGNMENT);
        volver.setActionCommand(ComandoVentanaGestorEnum.ANADIR_AEROLINEA.name());

        JPanel panelVolver = new JPanel();
        panelVolver.setBackground(Color.WHITE);
        panelVolver.setBorder(new EmptyBorder(0, 0, 20, 0));
        panelVolver.add(volver);

        add(panelVolver, BorderLayout.SOUTH);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(900, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);
    }

    public void agregarAerolinea(String aerolinea) {
        JLabel aerolineaLabel = new JLabel(
            String.format(
                "%s ", aerolinea
            )
        );
        aerolineaLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        aerolineaLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelAerolinea = new JPanel();
        panelAerolinea.setLayout(new BoxLayout(panelAerolinea, BoxLayout.Y_AXIS));
        panelAerolinea.setBackground(Color.WHITE);
        panelAerolinea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelAerolinea.add(aerolineaLabel);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelAerolinea);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void setControlador(ActionListener controlador) {
        volver.addActionListener(controlador);
    }
    
}
