package interfaz.gestor.añadirAerolinea.listadoSubMenu.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.añadirAerolinea.controlador.ControlPanelAnadirAerolinea;
import interfaz.gestor.añadirAerolinea.listadoSubMenu.vista.PanelListaAerolineas;
import interfaz.gestor.añadirAerolinea.vista.PanelAnadirAerolinea;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;

public class ControlPanelListaAerolineas implements ActionListener {
    private PanelListaAerolineas vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelListaAerolineas(PanelListaAerolineas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        aplicacion = Aplicacion.init("");
        cargarAerolineas();
    }

    private void cargarAerolineas() {
        List<Aerolinea> aerolineas = aplicacion.getAerolineasDisponibles();

        for (Aerolinea aerolinea : aerolineas) {
            vista.agregarAerolinea(aerolinea.toString());
        }
    }   

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());
        System.out.println("Comando recibido: " + comando);
        if (comando.equals(ComandoVentanaGestorEnum.ANADIR_AEROLINEA)) {
            // Volver a la pantalla anterior
            PanelAnadirAerolinea panelAnadirAerolinea = new PanelAnadirAerolinea();
            new ControlPanelAnadirAerolinea(panelAnadirAerolinea, pantalla);
            pantalla.mostrarContenidoEnPanelCentral(panelAnadirAerolinea);
        }
    }
}
