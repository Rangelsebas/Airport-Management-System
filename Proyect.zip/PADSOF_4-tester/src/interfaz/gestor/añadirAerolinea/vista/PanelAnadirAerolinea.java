package interfaz.gestor.añadirAerolinea.vista;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfaz.gestor.enums.ComandoVentanaGestorEnum;

public class PanelAnadirAerolinea extends JPanel {
    private JTextField campoNombreAerolinea;
    private JTextField campoCodigoAerolinea;
    private JButton botonAñadir;
    private JButton botonListado;

    public PanelAnadirAerolinea() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Márgenes generosos

        // Campo Nombre Aerolínea
        campoNombreAerolinea = new JTextField();
        campoNombreAerolinea.setMaximumSize(new Dimension(300, 30));
        campoNombreAerolinea.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoNombreAerolinea, "Nombre Aerolínea");
        add(campoNombreAerolinea);

        add(Box.createVerticalStrut(20));

        // Campo Código Aerolínea
        campoCodigoAerolinea = new JTextField();
        campoCodigoAerolinea.setMaximumSize(new Dimension(300, 30));
        campoCodigoAerolinea.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoCodigoAerolinea, "Código Aerolínea");
        add(campoCodigoAerolinea);

        add(Box.createVerticalStrut(20));

        // Botón Añadir
        botonAñadir = new JButton("Añadir");
        botonAñadir.setActionCommand(ComandoVentanaGestorEnum.AÑADIR_AEROLINEA.name());
        botonAñadir.setAlignmentX(Component.CENTER_ALIGNMENT);  
        add(botonAñadir);

        add(Box.createVerticalStrut(20));

        // Botón Listado
        botonListado = new JButton("Ver Listado");
        botonListado.setActionCommand(ComandoVentanaGestorEnum.LISTADO_AEROLINEAS.name());
        botonListado.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(botonListado);
    }

    // ================================
    // MÉTODOS DE VISTA MVC
    // ================================

    public void setControlador(ActionListener c) {
        botonAñadir.addActionListener(c);
        botonListado.addActionListener(c);
    }

    public String getNombreAerolinea() {
        return campoNombreAerolinea.getText();
    }

    public String getCodigoAerolinea() {
        return campoCodigoAerolinea.getText();
    }

    public void limpiarCampos() {
        campoNombreAerolinea.setText("");
        campoCodigoAerolinea.setText("");
    }

    // ================================
    // HELPERS
    // ================================

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }
    
}
