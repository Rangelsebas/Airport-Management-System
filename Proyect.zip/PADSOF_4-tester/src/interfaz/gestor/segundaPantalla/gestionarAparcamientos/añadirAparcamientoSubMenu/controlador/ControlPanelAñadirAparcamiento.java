package interfaz.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.controlador;

import javax.swing.*;

import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.vista.PanelAñadirAparcamiento;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelAñadirAparcamiento implements ActionListener {

    private PanelAñadirAparcamiento vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelAñadirAparcamiento(PanelAñadirAparcamiento vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONFIRMAR_AÑADIR_APARCAMIENTO:
                procesarCreacionAparcamiento();
                break;

            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarCreacionAparcamiento() {
        String nombre = vista.getNombre();
        int capacidad = vista.getCapacidad();
        int largo = vista.getLargo();
        int ancho = vista.getAncho();
        double costexhora = vista.getCosteXHora();

        // Validaciones básicas
        if (capacidad <= 0 || largo <= 0 || ancho <= 0 || costexhora <= 0) {
            JOptionPane.showMessageDialog(vista, "Todos los valores deben ser mayores a cero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (nombre.isEmpty() || nombre.equals("Nombre Aparcamiento")) {
            JOptionPane.showMessageDialog(vista, "El nombre no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Crear el aparcamiento
        if (!aplicacion.getAeropuertoPropio().añadirAparcamiento(nombre, capacidad, costexhora, largo, ancho)) {
            JOptionPane.showMessageDialog(vista, "Error al crear el aparcamiento. Verifique los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }      

        System.out.println("✅ Nuevo aparcamiento creado: Nombre: " + nombre);
        System.out.println("- Capacidad: " + capacidad);
        System.out.println("- Dimensiones de plaza: " + largo + "m x " + ancho + "m x " + costexhora + "€/h");

        JOptionPane.showMessageDialog(vista, "¡Aparcamiento creado exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        vista.limpiarCampos();
    }
}
