package interfaz.gestor.segundaPantalla.gestionarAparcamientos.controlador;

import javax.swing.*;

import funcionalidad.aeropuerto.elementos.Aparcamiento;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.controlador.ControlPanelAñadirAparcamiento;
import interfaz.gestor.segundaPantalla.gestionarAparcamientos.añadirAparcamientoSubMenu.vista.PanelAñadirAparcamiento;
import interfaz.gestor.segundaPantalla.gestionarAparcamientos.vista.PanelGestionarAparcamientos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelGestionarAparcamientos implements ActionListener {

    private PanelGestionarAparcamientos vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelGestionarAparcamientos(PanelGestionarAparcamientos vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
        cargarAparcamientos();
    }

    private void cargarAparcamientos() {
        // Aquí deberías obtener la lista de aparcamientos desde la aplicación
        // y agregar cada uno al panel de listado.
        // Por ejemplo:
        for (Aparcamiento aparcamiento : aplicacion.getAeropuertoPropio().getAparcamientos()) {
            vista.agregarAparcamiento(aparcamiento.toString());
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case AÑADIR_APARCAMIENTO:
                PanelAñadirAparcamiento panelAñadirAparcamiento = new PanelAñadirAparcamiento();
                new ControlPanelAñadirAparcamiento(panelAñadirAparcamiento, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelAñadirAparcamiento);
                break;

            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }
}
