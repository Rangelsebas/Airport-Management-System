package interfaz.gestor.segundaPantalla.gestionarPistas.añadirPistaSubMenu.controlador;

import javax.swing.*;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Orientacion;
import funcionalidad.otro.Uso;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.segundaPantalla.gestionarPistas.añadirPistaSubMenu.vista.PanelAñadirPista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelAñadirPista implements ActionListener {

    private PanelAñadirPista vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelAñadirPista(PanelAñadirPista vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONFIRMAR_AÑADIR_PISTA:
                procesarCreacionPista();
                break;
        
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private Orientacion procesarOrientacion(String orientacion){
        switch (orientacion) {
            case "Norte":
                return Orientacion.NORTE;
            case "Sur":
                return Orientacion.SUR;
            case "Este":
                return Orientacion.ESTE;
            case "Oeste":
                return Orientacion.OESTE;
            default:
                JOptionPane.showMessageDialog(vista, "Orientación no válida.", "Error", JOptionPane.ERROR_MESSAGE);
                return null;
        }
    }

    private Uso procesarUso(String uso) {
        switch (uso) {
            case "Despegue":
                return Uso.DESPEGUE;
            case "Aterrizaje":
                return Uso.ATERRIZAJE;
            default:
                JOptionPane.showMessageDialog(vista, "Uso no válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return null;
        }
    }

    private void procesarCreacionPista() {
        String nombre = vista.getNombre();
        int longitud = vista.getLongitud();
        Orientacion orientacion = procesarOrientacion(vista.getOrientacion());
        Uso uso = procesarUso(vista.getUso());

        if (nombre.isEmpty() || nombre.equals("Nombre Pista")) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar un nombre de pista válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        /* Logica de aplicacion */
        if (!aplicacion.getAeropuertoPropio().añadirPista(nombre, longitud, orientacion, uso)) {
            JOptionPane.showMessageDialog(vista, "Error al crear la pista. Verifique los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        System.out.println("✅ Nueva pista creada:");
        System.out.println("- Nombre: " + nombre);
        System.out.println("- Longitud: " + longitud + " metros");
        System.out.println("- Orientación: " + orientacion);
        System.out.println("- Uso: " + uso);

        JOptionPane.showMessageDialog(vista, "¡Pista creada exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        vista.limpiarCampos();
    }
}