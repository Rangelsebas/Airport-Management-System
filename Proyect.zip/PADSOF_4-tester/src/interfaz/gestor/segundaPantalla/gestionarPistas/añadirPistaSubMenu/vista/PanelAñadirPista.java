package interfaz.gestor.segundaPantalla.gestionarPistas.añadirPistaSubMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfaz.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelAñadirPista extends JPanel {

    private JTextField campoNombre;
    private JSpinner spinnerLongitud;
    private JComboBox<String> comboOrientacion;
    private JComboBox<String> comboUso;
    private JButton botonAñadir;

    public PanelAñadirPista() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Márgenes generosos

        // Campo Nombre
        campoNombre = new JTextField();
        campoNombre.setMaximumSize(new Dimension(300, 30));
        campoNombre.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoNombre, "Nombre Pista");
        add(campoNombre);

        add(Box.createVerticalStrut(20));

        // Spinner Longitud
        spinnerLongitud = crearSpinner(3500, 500, 5000, 100);
        add(crearEtiqueta("Longitud (metros)"));
        add(spinnerLongitud);

        add(Box.createVerticalStrut(20));

        // Combo Orientacion
        comboOrientacion = new JComboBox<>(new String[] { "Norte", "Sur", "Este", "Oeste" });
        comboOrientacion.setMaximumSize(new Dimension(300, 30));
        comboOrientacion.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(crearEtiqueta("Orientación"));
        add(comboOrientacion);

        add(Box.createVerticalStrut(20));

        // Combo Uso
        comboUso = new JComboBox<>(new String[] { "Despegue", "Aterrizaje" });
        comboUso.setMaximumSize(new Dimension(300, 30));
        comboUso.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(crearEtiqueta("Uso"));
        add(comboUso);

        add(Box.createVerticalStrut(20));

        // Botón Añadir Pista
        botonAñadir = new JButton("Añadir Pista");
        botonAñadir.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadir.setActionCommand(ComandoVentanaGestorEnum.CONFIRMAR_AÑADIR_PISTA.name());
        add(botonAñadir);
    }

    // ================================
    // MÉTODOS DE VISTA MVC
    // ================================

    public void setControlador(ActionListener c) {
        botonAñadir.addActionListener(c);
    }

    public String getNombre() {
        return campoNombre.getText().trim();
    }

    public int getLongitud() {
        return (Integer) spinnerLongitud.getValue();
    }

    public String getOrientacion() {
        return (String) comboOrientacion.getSelectedItem();
    }

    public String getUso() {
        return (String) comboUso.getSelectedItem();
    }

    public void limpiarCampos() {
        campoNombre.setText("");
        restaurarPlaceholder(campoNombre, "Nombre Pista");
        spinnerLongitud.setValue(3500);
        comboOrientacion.setSelectedIndex(0);
        comboUso.setSelectedIndex(0);
    }

    // ================================
    // HELPERS
    // ================================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        spinner.setAlignmentX(Component.CENTER_ALIGNMENT);
        return spinner;
    }

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }

    private void restaurarPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);
    }
}
