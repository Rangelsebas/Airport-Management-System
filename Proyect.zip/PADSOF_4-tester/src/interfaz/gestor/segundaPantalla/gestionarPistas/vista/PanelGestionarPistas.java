package interfaz.gestor.segundaPantalla.gestionarPistas.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfaz.gestor.enums.ComandoVentanaGestorEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelGestionarPistas extends JPanel {

    private JPanel panelListado;
    private JButton botonAñadirPista;

    public PanelGestionarPistas() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Título
        JLabel titulo = new JLabel("Listado de Pistas", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Panel de listado
        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(900, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);

        // Botón "Añadir Pista"
        botonAñadirPista = new JButton("Añadir Pista");
        botonAñadirPista.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadirPista.setActionCommand(ComandoVentanaGestorEnum.AÑADIR_PISTA.name());

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(Color.WHITE);
        panelBoton.setBorder(new EmptyBorder(0, 0, 20, 0));
        panelBoton.add(botonAñadirPista);

        add(panelBoton, BorderLayout.SOUTH);
    }

    public void agregarPista(String nombre) {
        JLabel pistaLabel = new JLabel(
            String.format(
                "%s", nombre)
        );
        pistaLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        pistaLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelPista = new JPanel();
        panelPista.setLayout(new BoxLayout(panelPista, BoxLayout.Y_AXIS));
        panelPista.setBackground(Color.WHITE);
        panelPista.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelPista.add(pistaLabel);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelPista);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void setControlador(ActionListener c) {
        botonAñadirPista.addActionListener(c);
    }
}
