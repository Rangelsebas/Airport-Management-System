package interfaz.gestor.segundaPantalla.gestionarPistas.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;

import funcionalidad.aeropuerto.elementos.Pista;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.segundaPantalla.gestionarPistas.añadirPistaSubMenu.controlador.ControlPanelAñadirPista;
import interfaz.gestor.segundaPantalla.gestionarPistas.añadirPistaSubMenu.vista.PanelAñadirPista;
import interfaz.gestor.segundaPantalla.gestionarPistas.vista.PanelGestionarPistas;

public class ControlPanelGestionarPistas implements ActionListener {

    private PanelGestionarPistas vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelGestionarPistas(PanelGestionarPistas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
        cargarPistas();
    }

    private void cargarPistas(){
        List<Pista> pistas = aplicacion.getAeropuertoPropio().getPistas();
        for (Pista pista : pistas) {
            vista.agregarPista(
                pista.toString()
            );
        }
    }

    private void cargarPistasDePrueba() {
        // Mock de pistas para visualizar
        // vista.agregarPista("01", 3500, "Norte", "Despegue", "14:30", 3);
        // vista.agregarPista("02", 3200, "Sur", "Aterrizaje", "15:00", 1);
        // vista.agregarPista("03", 4000, "Este", "Despegue", "13:45", 5);
        // vista.agregarPista("04", 2900, "Oeste", "Aterrizaje", "16:10", 2);

        // TODO: Con lógica de negocio real sería:
        // List<Pista> pistas = aeropuerto.getPistas();
        // for (Pista pista : pistas) {
        //     vista.agregarPista(
        //         pista.getNombre(),
        //         pista.getLongitud(),
        //         pista.getOrientacion().toString(),
        //         pista.getUso().toString(),
        //         pista.getUltimoTiempoOcupacion() != null ? pista.getUltimoTiempoOcupacion().toString() : "Sin uso reciente",
        //         pista.getCola() != null ? pista.getCola().size() : 0
        //     );
        // }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case AÑADIR_PISTA:
                PanelAñadirPista panelAñadirPista = new PanelAñadirPista();
                new ControlPanelAñadirPista(panelAñadirPista, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelAñadirPista);
            break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }
}
