package interfaz.gestor.segundaPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.segundaPantalla.gestionarAparcamientos.controlador.ControlPanelGestionarAparcamientos;
import interfaz.gestor.segundaPantalla.gestionarAparcamientos.vista.PanelGestionarAparcamientos;
import interfaz.gestor.segundaPantalla.gestionarHangares.controlador.ControlPanelGestionarHangares;
import interfaz.gestor.segundaPantalla.gestionarHangares.vista.PanelGestionarHangares;
import interfaz.gestor.segundaPantalla.gestionarPistas.controlador.ControlPanelGestionarPistas;
import interfaz.gestor.segundaPantalla.gestionarPistas.vista.PanelGestionarPistas;
import interfaz.gestor.segundaPantalla.gestionarTerminales.controlador.ControlPanelGestionarTerminales;
import interfaz.gestor.segundaPantalla.gestionarTerminales.vista.PanelGestionarTerminales;
import interfaz.gestor.segundaPantalla.verMiAeropuerto.controlador.ControlVerAeropuerto;
import interfaz.gestor.segundaPantalla.verMiAeropuerto.vista.PanelVerAeropuerto;
import interfaz.gestor.segundaPantalla.vista.PanelConfiguracionAeropuerto;

public class ControlPanelConfiguracionAeropuerto implements ActionListener {

    private PanelConfiguracionAeropuerto vista;
    private PantallaBase pantalla;

    public ControlPanelConfiguracionAeropuerto(PanelConfiguracionAeropuerto vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case GESTIONAR_PISTAS:
                PanelGestionarPistas panelGestionarPistas = new PanelGestionarPistas();
                new ControlPanelGestionarPistas(panelGestionarPistas, vista.getPantallaBase());
                pantalla.mostrarContenidoEnPanelCentral(panelGestionarPistas);
                break;

            case GESTIONAR_TERMINALES:
                PanelGestionarTerminales panelGestionarTerminales = new PanelGestionarTerminales();
                new ControlPanelGestionarTerminales(panelGestionarTerminales, vista.getPantallaBase());
                pantalla.mostrarContenidoEnPanelCentral(panelGestionarTerminales);
                break;

            case GESTIONAR_HANGARES:
                PanelGestionarHangares panelGestionarHangares = new PanelGestionarHangares();
                new ControlPanelGestionarHangares(panelGestionarHangares, vista.getPantallaBase());
                pantalla.mostrarContenidoEnPanelCentral(panelGestionarHangares);
                break;

            case GESTIONAR_APARCAMIENTOS:
                PanelGestionarAparcamientos panelGestionarAparcamientos = new PanelGestionarAparcamientos();
                new ControlPanelGestionarAparcamientos(panelGestionarAparcamientos, vista.getPantallaBase());
                pantalla.mostrarContenidoEnPanelCentral(panelGestionarAparcamientos);
                break;

            case VER_AEROPUERTO:
                PanelVerAeropuerto panelVerAeropuerto = new PanelVerAeropuerto();
                new ControlVerAeropuerto(panelVerAeropuerto);
                pantalla.mostrarContenidoEnPanelCentral(panelVerAeropuerto);
                break;
            default:
                break;
        }
    }
}