package interfaz.gestor.segundaPantalla.verMiAeropuerto.vista;

import javax.swing.*;

public class PanelVerAeropuerto extends JPanel {
    private JPanel panelAeropuerto;

    public PanelVerAeropuerto() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        panelAeropuerto = new JPanel();
        panelAeropuerto.setLayout(new BoxLayout(panelAeropuerto, BoxLayout.Y_AXIS));
        add(panelAeropuerto);
    }

    public void actualizarAeropuerto(String infoAeropuerto) {
        panelAeropuerto.removeAll();
        String texto = "<html><div style='text-align: center; width:500px;'>" + infoAeropuerto + "</div></html>";
        JLabel infoLabel = new JLabel(texto);
        infoLabel.setAlignmentX(CENTER_ALIGNMENT);
        panelAeropuerto.add(infoLabel);
        panelAeropuerto.revalidate();
        panelAeropuerto.repaint();
    }
}
