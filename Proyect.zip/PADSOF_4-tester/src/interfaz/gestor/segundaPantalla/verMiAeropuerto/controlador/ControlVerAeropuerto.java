package interfaz.gestor.segundaPantalla.verMiAeropuerto.controlador;

import funcionalidad.aplicacion.Aplicacion;
import interfaz.gestor.segundaPantalla.verMiAeropuerto.vista.PanelVerAeropuerto;

public class ControlVerAeropuerto {
    private PanelVerAeropuerto vista;
    private Aplicacion aplicacion;

    public ControlVerAeropuerto(PanelVerAeropuerto vista) {
        this.vista = vista;
        aplicacion = Aplicacion.init("");
        cargarAeropuerto();
    }

    private void cargarAeropuerto() {
        String infoAeropuerto = aplicacion.getAeropuertoPropio().toString();
        vista.actualizarAeropuerto(infoAeropuerto);
    }
}
