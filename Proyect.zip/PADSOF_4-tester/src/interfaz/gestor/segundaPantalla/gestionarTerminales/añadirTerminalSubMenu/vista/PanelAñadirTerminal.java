package interfaz.gestor.segundaPantalla.gestionarTerminales.añadirTerminalSubMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelAñadirTerminal extends JPanel {

    private JTextField campoNombre;
    private JSpinner spinnerPuertas;
    private JSpinner spinnerBuses;
    private JSpinner spinnerLargoPuerta;
    private JSpinner spinnerAnchoPuerta;
    private JSpinner spinnerAltoPuerta;
    private JSpinner spinnerCosteHora;
    private JButton botonAñadir;

    public PanelAñadirTerminal() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50)); // Márgenes generosos

        // Campo Nombre
        campoNombre = new JTextField();
        campoNombre.setMaximumSize(new Dimension(300, 30));
        campoNombre.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoNombre, "Nombre Terminal");
        add(campoNombre);

        add(Box.createVerticalStrut(20));

        // Spinner Puertas
        spinnerPuertas = crearSpinner(50, 2, 100, 1);
        add(crearEtiqueta("Cantidad de Puertas"));
        add(spinnerPuertas);

        add(Box.createVerticalStrut(10));

        // Spinner Buses
        spinnerBuses = crearSpinner(50, 1, 100, 1);
        add(crearEtiqueta("Cantidad de Buses"));
        add(spinnerBuses);

        add(Box.createVerticalStrut(10));

        // Campos para dimensiones de las puertas
        spinnerLargoPuerta = crearSpinner(15, 1, 100, 1);
        add(crearEtiqueta("Largo de Puerta (m)"));
        add(spinnerLargoPuerta);

        add(Box.createVerticalStrut(10));

        spinnerAnchoPuerta = crearSpinner(15, 1, 100, 1);
        add(crearEtiqueta("Ancho de Puerta (m)"));
        add(spinnerAnchoPuerta);

        add(Box.createVerticalStrut(10));

        spinnerAltoPuerta = crearSpinner(50, 1, 200, 1);
        add(crearEtiqueta("Alto de Puerta (m)"));
        add(spinnerAltoPuerta);

        add(Box.createVerticalStrut(10));

        // Campo para coste por hora
        spinnerCosteHora = crearSpinnerDouble(50.0, 0.0, 1000.0, 1.0);
        add(crearEtiqueta("Coste por Hora (€)"));
        add(spinnerCosteHora);

        add(Box.createVerticalStrut(20));

        // Botón Añadir Terminal
        botonAñadir = new JButton("Añadir Terminal");
        botonAñadir.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadir.setActionCommand(ComandoVentanaGestorEnum.CONFIRMAR_AÑADIR_TERMINAL.name());
        add(botonAñadir);
    }

    // ================================
    // MÉTODOS DE VISTA MVC
    // ================================

    public void setControlador(ActionListener c) {
        botonAñadir.addActionListener(c);
    }

    public String getNombre() {
        return campoNombre.getText().trim();
    }

    public int getCantidadPuertas() {
        return (Integer) spinnerPuertas.getValue();
    }

    public int getCantidadBuses() {
        return (Integer) spinnerBuses.getValue();
    }

    public int getLargoPuerta() {
        return (int) spinnerLargoPuerta.getValue();
    }

    public int getAnchoPuerta() {
        return (int) spinnerAnchoPuerta.getValue();
    }

    public int getAltoPuerta() {
        return (int) spinnerAltoPuerta.getValue();
    }

    public double getCosteHora() {
        return (double) spinnerCosteHora.getValue();
    }

    public void limpiarCampos() {
        campoNombre.setText("");
        restaurarPlaceholder(campoNombre, "Nombre Terminal");
        spinnerPuertas.setValue(10);
        spinnerBuses.setValue(5);
        spinnerLargoPuerta.setValue(5);
        spinnerAnchoPuerta.setValue(5);
        spinnerAltoPuerta.setValue(5);
        spinnerCosteHora.setValue(50.0);
    }

    // ================================
    // HELPERS
    // ================================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        spinner.setAlignmentX(Component.CENTER_ALIGNMENT);
        return spinner;
    }

    private JSpinner crearSpinnerDouble(double value, double min, double max, double step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        spinner.setAlignmentX(Component.CENTER_ALIGNMENT);
        return spinner;
    }

    private void añadirPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);

        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(texto)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(texto);
                }
            }
        });
    }

    private void restaurarPlaceholder(JTextField campo, String texto) {
        campo.setForeground(Color.GRAY);
        campo.setText(texto);
    }
}
