package interfaz.gestor.segundaPantalla.gestionarTerminales.añadirTerminalSubMenu.controlador;

import javax.swing.*;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.segundaPantalla.gestionarTerminales.añadirTerminalSubMenu.vista.PanelAñadirTerminal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelAñadirTerminal implements ActionListener {

    private PanelAñadirTerminal vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelAñadirTerminal(PanelAñadirTerminal vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        // Inicializar la aplicación (parámetros de configuración asumidos)
        this.aplicacion = Aplicacion.init("");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());
        if (comando == ComandoVentanaGestorEnum.CONFIRMAR_AÑADIR_TERMINAL) {
            procesarCreacionTerminal();
        } else {
            JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Recoge datos de la vista, valida y crea la nueva terminal en la lógica de negocio.
     */
    private void procesarCreacionTerminal() {
        String nombre = vista.getNombre();
        int puertas = vista.getCantidadPuertas();
        int buses = vista.getCantidadBuses();
        int largoPuerta = vista.getLargoPuerta();
        int anchoPuerta = vista.getAnchoPuerta();
        int altoPuerta = vista.getAltoPuerta();
        double costeHora = vista.getCosteHora();

        // Validaciones básicas
        if (nombre.isEmpty() || nombre.equals("Nombre Terminal")) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar un nombre de terminal válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Llamada a la lógica de negocio para crear la terminal con sus propiedades
        if(!aplicacion.getAeropuertoPropio().añadirTerminal(nombre, buses)){
            JOptionPane.showMessageDialog(vista, "Error al crear la terminal. Verifique los datos ingresados.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if(!aplicacion.getAeropuertoPropio().añadirPuertasTerminal(nombre, costeHora, largoPuerta, anchoPuerta, altoPuerta, puertas)){
            JOptionPane.showMessageDialog(vista, "Error al añadir puertas a la terminal. Verifique los datos ingresados.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }


        // Log y feedback al usuario
        System.out.println("✅ Nueva terminal creada:");
        System.out.println("- Nombre: " + nombre);
        System.out.println("- Puertas: " + puertas);
        System.out.println("- Buses: " + buses);
        System.out.println("- Ancho Puerta: " + anchoPuerta + " m");
        System.out.println("- Alto Puerta: " + altoPuerta + " m");
        System.out.println("- Coste Hora: €" + costeHora);

        JOptionPane.showMessageDialog(vista, "¡Terminal creada exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        // Limpiar campos para nueva entrada
        vista.limpiarCampos();
    }
}
