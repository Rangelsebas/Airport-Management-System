package interfaz.gestor.segundaPantalla.gestionarHangares.añadirHangarSubMenu.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import funcionalidad.aerolinea.CategoriaAvion;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelAñadirHangar extends JPanel {

    private JTextField campoNombre;
    private JSpinner spinnerCosteHora;
    private JSpinner spinnerCapacidad;
    private JSpinner spinnerLargo;
    private JSpinner spinnerAncho;
    private JSpinner spinnerAlto;
    private JComboBox<CategoriaAvion> comboCategoria;
    private JCheckBox checkBoxMercanciasPeligrosas;
    private JButton botonAñadir;

    public PanelAñadirHangar() {
        setLayout(new BorderLayout());
        // Panel interno con BoxLayout para contenidos
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(new EmptyBorder(20, 50, 20, 50));

        // Campos
        campoNombre = new JTextField();
        campoNombre.setMaximumSize(new Dimension(300, 30));
        campoNombre.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoNombre, "Nombre Hangar");
        contentPanel.add(campoNombre);
        contentPanel.add(Box.createVerticalStrut(20));

        spinnerCosteHora = crearSpinnerDouble(100.0, 1.0, 10000.0, 10.0);
        contentPanel.add(crearEtiqueta("Coste por Hora (€)"));
        contentPanel.add(spinnerCosteHora);
        contentPanel.add(Box.createVerticalStrut(20));

        spinnerCapacidad = crearSpinner(50, 0, 500, 10);
        contentPanel.add(crearEtiqueta("Capacidad"));
        contentPanel.add(spinnerCapacidad);
        contentPanel.add(Box.createVerticalStrut(20));

        spinnerLargo = crearSpinner(200, 2, 500, 1);
        contentPanel.add(crearEtiqueta("Largo (m)"));
        contentPanel.add(spinnerLargo);
        contentPanel.add(Box.createVerticalStrut(20));

        spinnerAncho = crearSpinner(200, 2, 500, 1);
        contentPanel.add(crearEtiqueta("Ancho (m)"));
        contentPanel.add(spinnerAncho);
        contentPanel.add(Box.createVerticalStrut(20));

        spinnerAlto = crearSpinner(50, 5, 200, 1);
        contentPanel.add(crearEtiqueta("Alto (m)"));
        contentPanel.add(spinnerAlto);
        contentPanel.add(Box.createVerticalStrut(20));

        comboCategoria = new JComboBox<>(CategoriaAvion.values());
        comboCategoria.setMaximumSize(new Dimension(200, 30));
        comboCategoria.setAlignmentX(Component.CENTER_ALIGNMENT);
        contentPanel.add(crearEtiqueta("Categoría de Avión"));
        contentPanel.add(comboCategoria);
        contentPanel.add(Box.createVerticalStrut(10));

        checkBoxMercanciasPeligrosas = new JCheckBox("Mercancías peligrosas");
        checkBoxMercanciasPeligrosas.setAlignmentX(Component.CENTER_ALIGNMENT);
        checkBoxMercanciasPeligrosas.setVisible(false);
        contentPanel.add(checkBoxMercanciasPeligrosas);
        comboCategoria.addActionListener(e -> {
            CategoriaAvion cat = (CategoriaAvion) comboCategoria.getSelectedItem();
            checkBoxMercanciasPeligrosas.setVisible(cat == CategoriaAvion.MERCANCIAS);
            contentPanel.revalidate();
        });

        contentPanel.add(Box.createVerticalStrut(30));

        botonAñadir = new JButton("Añadir Hangar");
        botonAñadir.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadir.setActionCommand(ComandoVentanaGestorEnum.CONFIRMAR_AÑADIR_HANGAR.name());
        contentPanel.add(botonAñadir);

        // JScrollPane para el panel interno
        JScrollPane scrollPane = new JScrollPane(contentPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // Quitar borde y ajustar ancho
        scrollPane.setBorder(null);
        scrollPane.setPreferredSize(new Dimension(600, scrollPane.getPreferredSize().height));

        this.add(scrollPane, BorderLayout.CENTER);
    }

    // Métodos MVC
    public void setControlador(ActionListener c) {
        botonAñadir.addActionListener(c);
    }

    public String getNombre() { return campoNombre.getText().trim(); }
    public double getCosteHora() { return (Double) spinnerCosteHora.getValue(); }
    public int getCapacidad() { return (Integer) spinnerCapacidad.getValue(); }
    public int getLargo() { return (Integer) spinnerLargo.getValue(); }
    public int getAncho() { return (Integer) spinnerAncho.getValue(); }
    public int getAlto() { return (Integer) spinnerAlto.getValue(); }
    public CategoriaAvion getCategoria() { return (CategoriaAvion) comboCategoria.getSelectedItem(); }
    public boolean isMercanciasPeligrosas() { return checkBoxMercanciasPeligrosas.isSelected(); }

    public void limpiarCampos() {
        restaurarPlaceholder(campoNombre, "Nombre Hangar");
        spinnerCosteHora.setValue(100.0);
        spinnerCapacidad.setValue(50);
        spinnerLargo.setValue(100);
        spinnerAncho.setValue(100);
        spinnerAlto.setValue(25);
        comboCategoria.setSelectedIndex(0);
        checkBoxMercanciasPeligrosas.setVisible(false);
        checkBoxMercanciasPeligrosas.setSelected(false);
    }

    // Helpers
    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }
    private JSpinner crearSpinner(int v,int min,int max,int step) {
        JSpinner s=new JSpinner(new SpinnerNumberModel(v,min,max,step));
        s.setMaximumSize(new Dimension(200,30));s.setAlignmentX(Component.CENTER_ALIGNMENT);return s;
    }
    private JSpinner crearSpinnerDouble(double v,double min,double max,double step) {
        JSpinner s=new JSpinner(new SpinnerNumberModel(v,min,max,step));
        s.setMaximumSize(new Dimension(200,30));s.setAlignmentX(Component.CENTER_ALIGNMENT);return s;
    }
    private void añadirPlaceholder(JTextField campo,String texto) {
        campo.setForeground(Color.GRAY);campo.setText(texto);
        campo.addFocusListener(new java.awt.event.FocusAdapter(){
            public void focusGained(java.awt.event.FocusEvent e){
                if(campo.getText().equals(texto)){campo.setText("");campo.setForeground(Color.BLACK);} }
            public void focusLost(java.awt.event.FocusEvent e){
                if(campo.getText().isEmpty()){campo.setText(texto);campo.setForeground(Color.GRAY);} }
        });
    }
    private void restaurarPlaceholder(JTextField c,String t){c.setText(t);c.setForeground(Color.GRAY);}    
}
