package interfaz.gestor.segundaPantalla.gestionarHangares.añadirHangarSubMenu.controlador;

import javax.swing.*;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.aerolinea.CategoriaAvion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.segundaPantalla.gestionarHangares.añadirHangarSubMenu.vista.PanelAñadirHangar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelAñadirHangar implements ActionListener {

    private PanelAñadirHangar vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelAñadirHangar(PanelAñadirHangar vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum cmd = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());
        if (cmd == ComandoVentanaGestorEnum.CONFIRMAR_AÑADIR_HANGAR) {
            procesarCreacionHangar();
        } else {
            JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void procesarCreacionHangar() {
        String nombre = vista.getNombre();
        double costeHora = vista.getCosteHora();
        int capacidad = vista.getCapacidad();
        int largo = vista.getLargo();
        int ancho = vista.getAncho();
        int alto = vista.getAlto();
        CategoriaAvion categoria = vista.getCategoria();
        boolean peligrosas = vista.isMercanciasPeligrosas();

        // Validaciones
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "El nombre del hangar no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (capacidad <= 0 || largo <= 0 || ancho <= 0 || alto <= 0 || costeHora <= 0) {
            JOptionPane.showMessageDialog(vista, "Todos los valores deben ser mayores a cero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Llamada a la lógica de negocio
        boolean ok = aplicacion.getAeropuertoPropio()
            .añadirHangar(nombre, capacidad, costeHora, largo, ancho, alto, categoria, peligrosas);

        if (!ok) {
            JOptionPane.showMessageDialog(vista, "Error al crear el hangar. Verifica los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        System.out.println("✅ Nuevo hangar creado:");
        System.out.println("- Nombre: " + nombre);
        System.out.println("- Categoría: " + categoria);
        if (categoria == CategoriaAvion.MERCANCIAS) {
            System.out.println("- Mercancías peligrosas: " + peligrosas);
        }
        System.out.println("- Capacidad: " + capacidad);
        System.out.println("- Dimensiones (L×A×H): " + largo + "×" + ancho + "×" + alto + " m");
        System.out.println("- Coste por hora: €" + costeHora);

        JOptionPane.showMessageDialog(vista, "¡Hangar creado exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        vista.limpiarCampos();
    }
}
