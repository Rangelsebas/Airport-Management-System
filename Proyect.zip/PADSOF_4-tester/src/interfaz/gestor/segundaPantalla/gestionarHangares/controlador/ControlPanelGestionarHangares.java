package interfaz.gestor.segundaPantalla.gestionarHangares.controlador;

import javax.swing.*;

import funcionalidad.aeropuerto.elementos.Hangar;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.gestor.segundaPantalla.gestionarHangares.añadirHangarSubMenu.controlador.ControlPanelAñadirHangar;
import interfaz.gestor.segundaPantalla.gestionarHangares.añadirHangarSubMenu.vista.PanelAñadirHangar;
import interfaz.gestor.segundaPantalla.gestionarHangares.vista.PanelGestionarHangares;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ControlPanelGestionarHangares implements ActionListener {

    private PanelGestionarHangares vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelGestionarHangares(PanelGestionarHangares vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
        cargarHangares();
    }

    private void cargarHangares() {
        List<Hangar> hangares = aplicacion.getAeropuertoPropio().getHangares();
        for (Hangar hangar : hangares) {
            vista.agregarHangar(hangar.toString());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVentanaGestorEnum comando = ComandoVentanaGestorEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case AÑADIR_HANGAR:
                PanelAñadirHangar panelAñadirHangar = new PanelAñadirHangar();
                new ControlPanelAñadirHangar(panelAñadirHangar, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelAñadirHangar);
                break;

            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    
    }
}
