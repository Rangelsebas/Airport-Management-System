package interfaz.gestor.segundaPantalla.gestionarHangares.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;

import interfaz.gestor.enums.ComandoVentanaGestorEnum; // Importas tu enum aquí

public class PanelGestionarHangares extends JPanel {

    private JPanel panelListado;
    private JButton botonAñadirHangar;

    public PanelGestionarHangares() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Título
        JLabel titulo = new JLabel("Listado de Hangares", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Panel de listado
        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(900, 400));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);

        // Botón "Añadir Hangar"
        botonAñadirHangar = new JButton("Añadir Hangar");
        botonAñadirHangar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAñadirHangar.setActionCommand(ComandoVentanaGestorEnum.AÑADIR_HANGAR.name());

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(Color.WHITE);
        panelBoton.setBorder(new EmptyBorder(0, 0, 20, 0));
        panelBoton.add(botonAñadirHangar);

        add(panelBoton, BorderLayout.SOUTH);
    }

    public void agregarHangar(String hangar) {
        String texto = "<html><div style='text-align: center; width:500px;'>" + hangar + "</div></html>";
        JLabel hangarLabel = new JLabel(texto);
        hangarLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        hangarLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelHangar = new JPanel();
        panelHangar.setLayout(new BoxLayout(panelHangar, BoxLayout.Y_AXIS));
        panelHangar.setBackground(Color.WHITE);
        panelHangar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelHangar.add(hangarLabel);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelHangar);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void reset() {
        panelListado.removeAll();
        panelListado.revalidate();
        panelListado.repaint();
    }

    public void setControlador(ActionListener c) {
        botonAñadirHangar.addActionListener(c);
    }
}
