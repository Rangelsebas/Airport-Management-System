package interfaz.gestor.quintaPantalla.vista;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import interfaz.gestor.quintaPantalla.enums.ComandoVerTiposAvionesEnum;

public class PanelVerTiposAviones extends JPanel {

    private JTable tablaTiposAviones;
    private DefaultTableModel modeloTabla;
    private JButton botonRefrescar;

    public PanelVerTiposAviones() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        // --- Panel superior ---
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(Color.WHITE);

        JLabel titulo = new JLabel("🛬 Lista de Tipos de Aviones Disponibles");
        titulo.setFont(new Font("Arial", Font.BOLD, 18));

        botonRefrescar = new JButton("🔄 Refrescar");
        botonRefrescar.setActionCommand(ComandoVerTiposAvionesEnum.REFRESCAR_TIPOS_AVIONES.name());

        panelSuperior.add(titulo, BorderLayout.WEST);
        panelSuperior.add(botonRefrescar, BorderLayout.EAST);
        add(panelSuperior, BorderLayout.NORTH);

        // --- Tabla ---
        String[] columnas = {
            "ID", "Marca", "Modelo", "Capacidad", "Temperatura", "Largo", "Ancho", "Alto", "Categoría"
        };

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tabla solo lectura
            }
        };

        tablaTiposAviones = new JTable(modeloTabla);
        tablaTiposAviones.setFillsViewportHeight(true);

        // --- Tooltip dinámico para mostrar el contenido completo de cada celda ---
        tablaTiposAviones.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent e) {
                int fila = tablaTiposAviones.rowAtPoint(e.getPoint());
                int columna = tablaTiposAviones.columnAtPoint(e.getPoint());

                if (fila > -1 && columna > -1) {
                    Object valorCelda = tablaTiposAviones.getValueAt(fila, columna);
                    if (valorCelda != null) {
                        tablaTiposAviones.setToolTipText(valorCelda.toString());
                    } else {
                        tablaTiposAviones.setToolTipText(null);
                    }
                }
            }
        });

        JScrollPane scroll = new JScrollPane(tablaTiposAviones);
        scroll.setPreferredSize(new java.awt.Dimension(900, 400)); // Aumentamos espacio
        add(scroll, BorderLayout.CENTER);

    }

    // ========== MÉTODOS ==========

    public void setControlador(java.awt.event.ActionListener c) {
        botonRefrescar.addActionListener(c);
    }

    public void anadirFila(Object[] datosFila) {
        int columnasExistentes = modeloTabla.getColumnCount();
        if (datosFila.length != columnasExistentes) {
            throw new IllegalArgumentException(
                "El array de datos debe tener exactamente " + columnasExistentes + " elementos");
        }
        modeloTabla.addRow(datosFila);
    }

    public JTable getTabla() {
        return tablaTiposAviones;
    }

    public int getFilaSeleccionada() {
        return tablaTiposAviones.getSelectedRow();
    }
}