package interfaz.gestor.quintaPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import funcionalidad.aerolinea.TipoAvion;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.gestor.quintaPantalla.enums.ComandoVerTiposAvionesEnum;
import interfaz.gestor.quintaPantalla.vista.PanelVerTiposAviones;

public class ControlPanelVerTiposAviones implements ActionListener {

    private PanelVerTiposAviones vista;
    private Aplicacion aplicacion;

    public ControlPanelVerTiposAviones(PanelVerTiposAviones vista) {
        this.vista = vista;
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVerTiposAvionesEnum comando = ComandoVerTiposAvionesEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case REFRESCAR_TIPOS_AVIONES:
                System.out.println("🔄 Refrescando tipos de aviones...");

                if(!aplicacion.cargarTiposDeAviones("tiposAviones.txt")) {
                    System.out.println("❌ Error al cargar los tipos de aviones.");
                    return;
                }

                for (TipoAvion tipoAvion : aplicacion.listarTiposDeAviones()) {
                    Object[] fila = {
                        tipoAvion.getId(),
                        tipoAvion.getMarca(),
                        tipoAvion.getModelo(),
                        tipoAvion.getCapacidad(),
                        tipoAvion.getControlTemperatura() ? "Sí" : "No",
                        tipoAvion.getDimension().getLargo() + "m",
                        tipoAvion.getDimension().getAncho() + "m",
                        tipoAvion.getDimension().getAlto() + "m",
                        tipoAvion.getCategoria().name()
                    };
                    vista.anadirFila(fila);
                }
                break;
            default:
                break;
        }
    }
}