package interfaz.gestor.vista;

import java.util.ArrayList;

//  import interfaz.componentes.PantallaBase;
//  import interfaz.gestor.enums.ComandoVentanaGestorEnum;
//  import interfaz.gestor.primeraPantalla.vista.PanelAdministrarUsuarios;
//  import interfaz.gestor.segundaPantalla.vista.PanelConfiguracionAeropuerto;
//  import interfaz.gestor.terceraPantalla.vista.PanelPeticionesVuelos;
//  import interfaz.gestor.cuartaPantalla.vista.PanelFacturasEstadisticas;

import java.util.List;
import java.awt.event.ActionListener;
import javax.swing.*;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.aplicacion.Notificacion;
import funcionalidad.usuarios.Usuario;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;

public class VentanaGestor extends JFrame {
    private final String NOMBRE_USUARIO_GESTOR = "Gestor de Aeropuerto";
    private PantallaBase pantalla;
    private List<JButton> botones;
    private String nombreUsuario;

    // private PanelAdministrarUsuarios panelUsuarios;
    // private PanelConfiguracionAeropuerto panelConfiguracion;
    // private PanelPeticionesVuelos panelPeticiones;
    // private PanelFacturasEstadisticas panelFacturasEstadisticas;

    public VentanaGestor() {
        this.nombreUsuario = NOMBRE_USUARIO_GESTOR;
        setTitle("Sistema Aeropuerto - Gestor");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        botones = List.of(
            crearBotonMenu("Administrar usuarios", ComandoVentanaGestorEnum.ADMINISTRAR_USUARIOS),
            crearBotonMenu("Añadir aerolinea", ComandoVentanaGestorEnum.CREAR_AEROLINEA),
            crearBotonMenu("Configuración del aeropuerto", ComandoVentanaGestorEnum.CONFIGURACION_AEROPUERTO),
            crearBotonMenu("Peticiones de vuelos", ComandoVentanaGestorEnum.PETICIONES_VUELOS),
            crearBotonMenu("Peticiones de vuelos recurrentes", ComandoVentanaGestorEnum.PETICIONES_VUELOS_RECURRENTE),
            crearBotonMenu("Emitir o consultar facturas", ComandoVentanaGestorEnum.VER_FACTURAS_ESTADISTICAS),
            crearBotonMenu("Consultar estadísticas", ComandoVentanaGestorEnum.CONSULTAR_ESTADISTICAS),
            crearBotonMenu("Cargar aeropuertos externos", ComandoVentanaGestorEnum.CARGAR_AEROPUERTOS_EXTERNOS),
            crearBotonMenu("Cargar aviones", ComandoVentanaGestorEnum.CARGAR_TIPOS_AVIONES),
            crearBotonMenu("Ver notificaciones", ComandoVentanaGestorEnum.VER_NOTIFICACIONES),
            crearBotonMenu("Guardar aplicacion", ComandoVentanaGestorEnum.GUARDAR_APLICACION),
            crearBotonMenu("Cargar aplicacion", ComandoVentanaGestorEnum.CARGAR_APLICACION)
        );

        for (JButton boton : botones) {
            boton.setHorizontalAlignment(SwingConstants.CENTER);
        }

        /* NOTIFICACIONES */
        Aplicacion app = Aplicacion.init("acceder");
        app = Aplicacion.init("acceder");
        Usuario logueado = app.getUsuarioLogueado();

        List<String> notificaciones = new ArrayList<>();

        if (logueado != null && !logueado.getNotificacion().isEmpty()) {
            Notificacion ultima = logueado.getNotificacion().get(logueado.getNotificacion().size() - 1);
            notificaciones.add("<html>" + ultima.getMensaje().toString() + "</html>");
        } else {
            notificaciones.add("Sin notificaciones recientes.");
        }

        pantalla = new PantallaBase(logueado.getNombreUsuario(), botones, notificaciones);
        add(pantalla);
    }

    /* Helper */
    private JButton crearBotonMenu(String texto, ComandoVentanaGestorEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        return boton;
    }

    public void setFechaHora(String fechaHora) {
        pantalla.setFechaHora(fechaHora);
    } 

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
        pantalla.getCerrarSesionButton().setActionCommand(ComandoVentanaGestorEnum.CERRAR_SESION.name());
        pantalla.getCerrarSesionButton().addActionListener(c);
        pantalla.getAvanzar5MinButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_5M.name());
        pantalla.getAvanzar5MinButton().addActionListener(c);
        pantalla.getAvanzar30miButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_30M.name());
        pantalla.getAvanzar30miButton().addActionListener(c);
        pantalla.getAvanzar1hButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_1H.name());
        pantalla.getAvanzar1hButton().addActionListener(c);
        pantalla.getAvanzar1dButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_1D.name());
        pantalla.getAvanzar1dButton().addActionListener(c);
    }

    public PantallaBase getPantallaBase() {
        return pantalla;
    }

    public void mostrarPanel(JPanel panel) {
        pantalla.mostrarContenidoEnPanelCentral(panel);
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public JButton getBotonCerrarSesion() {
        return pantalla.getCerrarSesionButton();
    }

    public void update() {
        pantalla.mostrarContenidoEnPanelCentral(new JPanel());
    }

    // public PanelAdministrarUsuarios getPanelUsuarios() {
    //     if (panelUsuarios == null) {
    //         panelUsuarios = new PanelAdministrarUsuarios(pantalla);
    //     }
    //     return panelUsuarios;
    // }

    // public PanelConfiguracionAeropuerto getPanelConfiguracion() {
    //     if (panelConfiguracion == null) {
    //         panelConfiguracion = new PanelConfiguracionAeropuerto(pantalla);
    //     }
    //     return panelConfiguracion;
    // }

    // public PanelPeticionesVuelos getPanelPeticiones() {
    //     if (panelPeticiones == null) {
    //         panelPeticiones = new PanelPeticionesVuelos(pantalla);
    //     }
    //     return panelPeticiones;
    // }

    // public PanelFacturasEstadisticas getPanelFacturasEstadisticas() {
    //     if (panelFacturasEstadisticas == null) {
    //         panelFacturasEstadisticas = new PanelFacturasEstadisticas(pantalla);
    //     }
    //     return panelFacturasEstadisticas;
    // }
}
