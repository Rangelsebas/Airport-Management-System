package interfaz.gestor.cargarAeropuertosExternos.enums;

public enum ComandoCargarAeropuertos {
    CARGAR_AEROPUERTOS
}
