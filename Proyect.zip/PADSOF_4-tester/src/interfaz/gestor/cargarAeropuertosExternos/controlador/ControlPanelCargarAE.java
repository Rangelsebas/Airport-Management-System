package interfaz.gestor.cargarAeropuertosExternos.controlador;

import java.awt.event.*;

import funcionalidad.aeropuerto.AeropuertoExterno;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.gestor.cargarAeropuertosExternos.enums.ComandoCargarAeropuertos;
import interfaz.gestor.cargarAeropuertosExternos.vista.PanelCargarAE;

public class ControlPanelCargarAE implements ActionListener {
    private PanelCargarAE vista;
    private Aplicacion aplicacion;

    public ControlPanelCargarAE(PanelCargarAE vista) {
        this.vista = vista;
        this.vista.setControlador(this);
        this.aplicacion = Aplicacion.init("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoCargarAeropuertos comando = ComandoCargarAeropuertos.valueOf(e.getActionCommand());

        switch (comando) {
            case CARGAR_AEROPUERTOS:
                System.out.println("🔄 Refrescando aeropuertos conectados...");

                if(!aplicacion.cargarAeropuertosExternos("aeropuertosExternos.txt")) {
                    System.out.println("❌ Error al cargar los aeropuertos.");
                    return;
                }

                for (AeropuertoExterno ae : aplicacion.listarAeropuertosExternos()) {
                    Object[] fila = {
                        ae.getNombre(),
                        ae.getCiudad(),
                        ae.getDistancia(),
                        ae.getDireccion(),
                        ae.getCodigo(),
                        ae.getHoraApertura(),
                        ae.getHoraCierre(),
                        ae.getDiferenciaHoraria()
                    };
                    vista.anadirFila(fila);
                }
                break;
            default:
                break;
        }
    }
}
