package interfaz.gestor.cargarAeropuertosExternos.vista;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import interfaz.gestor.cargarAeropuertosExternos.enums.ComandoCargarAeropuertos;

public class PanelCargarAE extends JPanel {
    private JTable tablaAeropuertosExternos;
    private DefaultTableModel modeloTabla;
    private JButton botonRefrescar;

    public PanelCargarAE() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        // --- Panel superior ---
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(Color.WHITE);

        JLabel titulo = new JLabel("🛬 Lista de aeropuertos conectados.");
        titulo.setFont(new Font("Arial", Font.BOLD, 18));

        botonRefrescar = new JButton("🔄 Refrescar");
        botonRefrescar.setActionCommand(ComandoCargarAeropuertos.CARGAR_AEROPUERTOS.name());

        panelSuperior.add(titulo, BorderLayout.WEST);
        panelSuperior.add(botonRefrescar, BorderLayout.EAST);
        add(panelSuperior, BorderLayout.NORTH);

        // --- Tabla ---
        String[] columnas = {
            "Nombre", "Ciudad Más Cercana", "Distancia", "Dirección", "Código", "Hora de Apertura", "Hora de Cierre", "Diferencia Horaria"
        };

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tabla solo lectura
            }
        };

        tablaAeropuertosExternos = new JTable(modeloTabla);
        tablaAeropuertosExternos.setFillsViewportHeight(true);

        // --- Tooltip dinámico para mostrar el contenido completo de cada celda ---
        tablaAeropuertosExternos.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent e) {
                int fila = tablaAeropuertosExternos.rowAtPoint(e.getPoint());
                int columna = tablaAeropuertosExternos.columnAtPoint(e.getPoint());

                if (fila > -1 && columna > -1) {
                    Object valorCelda = tablaAeropuertosExternos.getValueAt(fila, columna);
                    if (valorCelda != null) {
                        tablaAeropuertosExternos.setToolTipText(valorCelda.toString());
                    } else {
                        tablaAeropuertosExternos.setToolTipText(null);
                    }
                }
            }
        });

        JScrollPane scroll = new JScrollPane(tablaAeropuertosExternos);
        scroll.setPreferredSize(new java.awt.Dimension(900, 400)); // Aumentamos espacio
        add(scroll, BorderLayout.CENTER);
    }

    // ========== MÉTODOS ==========

    public void setControlador(java.awt.event.ActionListener c) {
        botonRefrescar.addActionListener(c);
    }

    public void anadirFila(Object[] datosFila) {
        int columnasExistentes = modeloTabla.getColumnCount();
        if (datosFila.length != columnasExistentes) {
            throw new IllegalArgumentException(
                "El array de datos debe tener exactamente " + columnasExistentes + " elementos");
        }
        modeloTabla.addRow(datosFila);
    }

    public JTable getTabla() {
        return tablaAeropuertosExternos;
    }

    public int getFilaSeleccionada() {
        return tablaAeropuertosExternos.getSelectedRow();
    }
}
