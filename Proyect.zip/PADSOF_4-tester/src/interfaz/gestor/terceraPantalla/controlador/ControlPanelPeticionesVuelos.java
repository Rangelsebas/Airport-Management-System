package interfaz.gestor.terceraPantalla.controlador;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.terceraPantalla.submenu.controlador.ControlPanelGestionSolicitud;
import interfaz.gestor.terceraPantalla.submenu.vista.PanelGestionSolicitud;
import interfaz.gestor.terceraPantalla.vista.PanelPeticionesVuelos;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.format.DateTimeFormatter;

public class ControlPanelPeticionesVuelos {
    private final PanelPeticionesVuelos vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelPeticionesVuelos(PanelPeticionesVuelos vista) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.aplicacion = Aplicacion.init("");

        if (aplicacion.getVuelosEstadoPendiente().isEmpty()) {
            vista.añadirSolicitud("No hay nuevas solicitudes");
        } else {
            for (Vuelo vuelo : aplicacion.getVuelosEstadoPendiente()) {
                String texto = "Codigo del vuelo: " + vuelo.getCodigoVuelo() + " | " + vuelo.getAerolineaOperadora().getNombre() + " | " + vuelo.getFecha() + 
                " | " + vuelo.getHoraSalida().format(DateTimeFormatter.ofPattern("HH:mm")) + " - " + vuelo.getHoraLlegada().format(DateTimeFormatter.ofPattern("HH:mm")) + 
                " | " + vuelo.getOrigen().getNombre() + " - " + vuelo.getDestino().getNombre() + "\n";
                vista.añadirSolicitud(texto);
            }
            
            vista.getListaSolicitudes().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int index = vista.getListaSolicitudes().locationToIndex(evt.getPoint());
                    
                    if (index >= 0) {
                        String texto = vista.getListaSolicitudes().getModel().getElementAt(index);
                        String codigo = getCodigo(texto);
                        
                        PanelGestionSolicitud panelGestion = new PanelGestionSolicitud(
                            pantalla, codigo
                            );
                            new ControlPanelGestionSolicitud(panelGestion, codigo, pantalla);
                            pantalla.mostrarContenidoEnPanelCentral(panelGestion);
                        }
                    }
                }
            });
        }
    }
    
    private String getCodigo(String texto){
        String clave = "Codigo del vuelo:";
        int pos = texto.indexOf(clave);
        String codigo = "";

        if (pos != -1) {
            // comenzamos justo tras la clave
            int start = pos + clave.length();
            // buscamos el siguiente separador " |"
            int end = texto.indexOf("|", start);
            if (end == -1) {
                // si no hay barra, cogemos hasta el cierre del div
                end = texto.indexOf("<", start);
            }
            codigo = texto.substring(start, end).trim();
        }

        return codigo;
    }
}
