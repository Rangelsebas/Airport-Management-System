package interfaz.gestor.terceraPantalla.submenu.vista;

import interfaz.componentes.PantallaBase;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import javax.swing.*;

public class PanelGestionSolicitud extends JPanel {

    private PantallaBase pantallaBase;

    private JComboBox<String> comboTerminal;
    private JComboBox<String> comboControlador;
    private JButton btnAprobar;
    private JButton btnRechazar;

    private Map<String, List<String>> terminalControladoresMap = new HashMap<>();

    public PanelGestionSolicitud(PantallaBase pantallaBase, String codigo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("✈️ Nueva solicitud de vuelo, codigo: " + codigo, Font.BOLD, 18));
        add(Box.createVerticalStrut(10));

        add(Box.createVerticalStrut(20));

        // Combo de terminales
        comboTerminal = new JComboBox<>(new String[]{"Seleccionar terminal"});
        comboTerminal.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(new JLabel("Selecciona Terminal:"));
        add(comboTerminal);

        add(Box.createVerticalStrut(10));

        // Combo de controladores (vacío al inicio)
        comboControlador = new JComboBox<>();
        comboControlador.setAlignmentX(Component.CENTER_ALIGNMENT);
        comboControlador.setVisible(false); // oculto al principio
        add(new JLabel("Selecciona Controlador:"));
        add(comboControlador);

        add(Box.createVerticalStrut(20));

        // Botones
        btnAprobar = new JButton("Aprobar");
        btnRechazar = new JButton("Rechazar");

        btnAprobar.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnRechazar.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(btnAprobar);
        add(Box.createVerticalStrut(10));
        add(btnRechazar);

        // Listener para actualizar controladores cuando seleccionas una terminal
        comboTerminal.addActionListener(e -> actualizarControladores());
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public JComboBox<String> getComboTerminal() {
        return comboTerminal;
    }

    public JComboBox<String> getComboControlador() {
        return comboControlador;
    }

    public JButton getBtnAprobar() {
        return btnAprobar;
    }

    public JButton getBtnRechazar() {
        return btnRechazar;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void añadirTerminal(String terminal) {
        terminalControladoresMap.put(terminal, new ArrayList<>());
        comboTerminal.addItem(terminal);
    }

    public void añadirControlador(String terminal, String controlador) {
        if (!terminalControladoresMap.containsKey(terminal)) return;
        else {
            terminalControladoresMap.get(terminal).add(controlador);
        }

        if (comboTerminal.getSelectedItem() != null && comboTerminal.getSelectedItem().equals(terminal)) {
            comboControlador.addItem(controlador);
        }
    }

    private void actualizarControladores() {
        String seleccion = (String) comboTerminal.getSelectedItem();

        if (seleccion != null && terminalControladoresMap.containsKey(seleccion)) {
            List<String> controladores = terminalControladoresMap.get(seleccion);

            comboControlador.removeAllItems();
            controladores.forEach(comboControlador::addItem);
            comboControlador.setVisible(true);
        } else {
            comboControlador.removeAllItems();
            comboControlador.setVisible(false);
        }

        revalidate();
        repaint();
    }

}
