package interfaz.login.vista;

import javax.swing.*;

import interfaz.login.enums.ComandoLoginEnum;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelLoginFrame extends JFrame {
    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JButton botonIniciarSesion;
    private JButton botonOlvidoContrasena;

    public PanelLoginFrame() {
        setTitle("Sistema Aeropuerto - Inicio de Sesión");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        JLabel labelBienvenido = new JLabel("Bienvenido");
        labelBienvenido.setFont(new Font("SansSerif", Font.BOLD, 22));
        labelBienvenido.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(labelBienvenido);
        panel.add(Box.createVerticalStrut(20));

        // Icono de usuario 
        ImageIcon icono = new ImageIcon("resources/gestor_image.png");
        Image imagenEscalada = icono.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        icono = new ImageIcon(imagenEscalada);

        JLabel labelIcono = new JLabel(icono);
        labelIcono.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(labelIcono);

        campoUsuario = new JTextField();
        campoUsuario.setMaximumSize(new Dimension(300, 30));
        campoUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholder(campoUsuario, "Usuario"); 
        panel.add(campoUsuario);
        panel.add(Box.createVerticalStrut(10));

        campoContrasena = new JPasswordField();
        campoContrasena.setMaximumSize(new Dimension(300, 30));
        campoContrasena.setAlignmentX(Component.CENTER_ALIGNMENT);
        añadirPlaceholderPassword(campoContrasena, "Contraseña");
        panel.add(campoContrasena);

        botonIniciarSesion = new JButton("Iniciar Sesión");
        botonIniciarSesion.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(botonIniciarSesion);
        panel.add(Box.createVerticalStrut(20));

        botonOlvidoContrasena = new JButton("He olvidado mi contraseña");
        botonOlvidoContrasena.setBorderPainted(false);
        botonOlvidoContrasena.setFocusPainted(false);
        botonOlvidoContrasena.setContentAreaFilled(false);
        botonOlvidoContrasena.setForeground(Color.BLUE.darker());
        botonOlvidoContrasena.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(botonOlvidoContrasena);

        add(panel);
    }

    // ====================
    // GETTERS - MVC
    // ====================
    public String getUsuario() {
        return campoUsuario.getText().trim();
    }

    public String getContrasena() {
        return new String(campoContrasena.getPassword()).trim();
    }

    public void setControlador(ActionListener c) {
        botonIniciarSesion.setActionCommand(ComandoLoginEnum.INICIAR_SESION.name());
        botonOlvidoContrasena.setActionCommand(ComandoLoginEnum.OLVIDAR_CONTRASENA.name());

        botonIniciarSesion.addActionListener(c);
        botonOlvidoContrasena.addActionListener(c);
    }

    public void limpiarCampos() {
        campoUsuario.setText("");
        campoContrasena.setText("");
    }

    // ====================
    // HELPERS
    // ====================
    private void añadirPlaceholder(JTextField campo, String placeholder) {
        campo.setForeground(Color.GRAY);
        campo.setText(placeholder);
    
        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (campo.getText().equals(placeholder)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                }
            }
    
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (campo.getText().isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(placeholder);
                }
            }
        });
    }

    private void añadirPlaceholderPassword(JPasswordField campo, String placeholder) {
        campo.setForeground(Color.GRAY);
        campo.setEchoChar((char) 0); // Mostrar texto normalmente
        campo.setText(placeholder);
    
        campo.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (new String(campo.getPassword()).equals(placeholder)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                    campo.setEchoChar('•'); // Volver a ocultar caracteres
                }
            }
    
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (new String(campo.getPassword()).isEmpty()) {
                    campo.setForeground(Color.GRAY);
                    campo.setText(placeholder);
                    campo.setEchoChar((char) 0); // Mostrar placeholder normalmente
                }
            }
        });
    }

    public void establecerBotonPorDefecto() {
        SwingUtilities.getRootPane(botonIniciarSesion).setDefaultButton(botonIniciarSesion);
    }

}
