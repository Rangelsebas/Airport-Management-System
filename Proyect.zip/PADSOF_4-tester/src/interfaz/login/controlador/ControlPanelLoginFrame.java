package interfaz.login.controlador;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.Rol;
import funcionalidad.usuarios.Usuario;
import interfaz.controlador.controlador.ControlVentanaControlador;
import interfaz.controlador.vista.VentanaControlador;
import interfaz.gestor.controlador.ControlVentanaGestor;
import interfaz.gestor.vista.VentanaGestor;
import interfaz.login.enums.ComandoLoginEnum;
import interfaz.login.vista.PanelLoginFrame;
import interfaz.operador.controlador.ControlVentanaOperador;
import interfaz.operador.vista.VentanaOperador;

public class ControlPanelLoginFrame implements ActionListener {
    private final PanelLoginFrame vista;
    private Aplicacion aplicacion;

    public ControlPanelLoginFrame(PanelLoginFrame vista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");
        this.vista.setControlador(this);
        this.vista.establecerBotonPorDefecto(); // Para que el enter funcione

        // TODO: Borraré esto cuando esté hecho
        /* Prueba de Angel NO BORRAR */

        // aplicacion.iniciarSesion("cris", "1234");
        // Vuelo vuelo = aplicacion.buscarVueloxCodigo("KLM00001");
        // vuelo.iniciarDescargaCambioEstado();
        // aplicacion.avanzarCincoMinutos();
        // vuelo.descargaFinalizadaCambioEstado();
        // // vuelo.pasarAPreparacionCambioEstado();
        // // vuelo.iniciarEmbarqueCambioEstado();
        // // vuelo.embarqueFinalizadoCambioEstado();
        // Vuelo vuelo2 = aplicacion.buscarVueloxCodigo("KLM00002");
        // vuelo2.iniciarDescargaCambioEstado();
        // aplicacion.avanzarCincoMinutos();
        // vuelo2.descargaFinalizadaCambioEstado();
        // // vuelo.pasarAPreparacionCambioEstado();
        // // vuelo.iniciarEmbarqueCambioEstado();
        // // vuelo.embarqueFinalizadoCambioEstado();
        // aplicacion.cerrarSesion();
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoLoginEnum comando = ComandoLoginEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case INICIAR_SESION:
                procesarInicioSesion();
                break;

            case OLVIDAR_CONTRASENA:
                procesarOlvidoContrasena();
                break;
        }
    }

    private void procesarInicioSesion() {
        String username = vista.getUsuario().trim();
        String password = vista.getContrasena().trim();

        if (username.isBlank() || username.equals("Usuario") ||
            password.isBlank() || password.equals("Contraseña")) {
            JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean exito = aplicacion.iniciarSesion(username, password);

        if (!exito) {
            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos.", "Acceso denegado", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Usuario usuario = aplicacion.getUsuarioLogueado();

        // Comprobación y ejecución del cambio de contraseña si es primer login
        if (aplicacion.esPrimerLogin()) {
            boolean cambioExitoso = mostrarDialogoCambioContraseña(password);

            if (!cambioExitoso) {
                aplicacion.cerrarSesion(); // Muy importante: detener el proceso si no se cambia la contraseña
                return;
            }
        }

        // Redirigir por rol
        if (usuario.checkRol(Rol.GESTORAEROPUERTO)) {
            VentanaGestor ventana = new VentanaGestor();
            new ControlVentanaGestor(ventana);
            ventana.setVisible(true);

        } else if (usuario.checkRol(Rol.OPERADORAEROLINEA)) {
            VentanaOperador ventana = new VentanaOperador();
            new ControlVentanaOperador(ventana);
            ventana.setVisible(true);

        } else if (usuario.checkRol(Rol.CONTROLADORAEREO)) {
            VentanaControlador ventana = new VentanaControlador();
            new ControlVentanaControlador(ventana);
            ventana.setVisible(true);

        } else {
            JOptionPane.showMessageDialog(null, "Rol de usuario no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
            aplicacion.cerrarSesion();
            return;
        }

        vista.dispose(); // Cierra la ventana de login
    }

    private void procesarOlvidoContrasena() {
        aplicacion.enviarNotificacionDeOlvidoGestorAeropuerto(vista.getUsuario());
        JOptionPane.showMessageDialog(null,
            "Se ha enviado una notificación al Gestor de Aeropuerto para restablecer tu contraseña.\nPor favor, espera instrucciones.",
            "Solicitud enviada", JOptionPane.INFORMATION_MESSAGE);
    }

    private boolean mostrarDialogoCambioContraseña(String contraseñaActual) {
        JPanel panelCambio = new JPanel(new GridLayout(2, 2));
        JPasswordField nuevaField = new JPasswordField();
        JPasswordField repetirField = new JPasswordField();
        panelCambio.add(new JLabel("Nueva contraseña:"));
        panelCambio.add(nuevaField);
        panelCambio.add(new JLabel("Repetir contraseña:"));
        panelCambio.add(repetirField);

        while (true) {
            int resultado = JOptionPane.showConfirmDialog(null, panelCambio,
                    "Cambia tu contraseña", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (resultado != JOptionPane.OK_OPTION) {
                JOptionPane.showMessageDialog(null, "Debes cambiar la contraseña para continuar.", "Atención", JOptionPane.WARNING_MESSAGE);
                return false;
            }

            String nueva = new String(nuevaField.getPassword()).trim();
            String repetir = new String(repetirField.getPassword()).trim();

            if (!nueva.equals(repetir)) {
                JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden. Intenta de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
                continue;
            }

            if (nueva.isBlank() || nueva.length() < 4) {
                JOptionPane.showMessageDialog(null, "La contraseña debe tener al menos 4 caracteres.", "Error", JOptionPane.WARNING_MESSAGE);
                continue;
            }

            aplicacion.getUsuarioLogueado().cambiarContrasena(contraseñaActual, nueva);
            aplicacion.getUsuarioLogueado().setPrimerLogin();
            JOptionPane.showMessageDialog(null, "Contraseña cambiada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            return true;
        }
    }

}
