package interfaz.operador.vista;

import interfaz.operador.cuartaPantalla.vista.PanelRendimientoVuelo;
import interfaz.componentes.PantallaBase;
import interfaz.gestor.enums.ComandoVentanaGestorEnum;
import interfaz.operador.controlador.ControlVentanaOperador;
import interfaz.operador.controlarDesembarquesPantalla.vista.PanelControlarDesembarques;
import interfaz.operador.controlarEmbarquesPantalla.vista.PanelControlarEmbarques;
import interfaz.operador.enums.ComandoVentanaOperadorEnum;
import interfaz.operador.primeraPantalla.vista.PanelGestionarFlota;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.aplicacion.Notificacion;
import funcionalidad.usuarios.Usuario;
import interfaz.operador.quintaPantalla.vista.PanelFacturas;
import interfaz.operador.segundaPantalla.vista.PanelProponerVuelo;
import interfaz.operador.terceraPantalla.vista.PanelControlarEstadoVuelo;

public class VentanaOperador extends JFrame {
    private final String NOMBRE_USUARIO_OPERADOR = "Operador de Aerolínea";
    private PantallaBase pantalla;
    private List<JButton> botones;
    private PanelGestionarFlota panelGestionarFlota;
    private String nombreUsuario;

    private PanelControlarEstadoVuelo panelEstadoVuelo;
    private PanelControlarEmbarques panelControlarEmbarques;
    private PanelControlarDesembarques panelControlarDesembarques;
    private PanelProponerVuelo panelProponerVuelo;
    private PanelRendimientoVuelo panelRendimiento;
    private PanelFacturas panelFacturas;

    private Aplicacion app;


    public VentanaOperador() {
        this.nombreUsuario = NOMBRE_USUARIO_OPERADOR;
        setTitle("Sistema Aeropuerto - Operador");
        setSize(1280, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        botones = List.of(
            crearBotonMenu("Gestionar Flota", ComandoVentanaOperadorEnum.GESTIONAR_FLOTA),
            crearBotonMenu("Proponer Vuelos", ComandoVentanaOperadorEnum.PROPONER_VUELOS),
            crearBotonMenu("Controlar el Estado de un Vuelo", ComandoVentanaOperadorEnum.CONTROLAR_ESTADO),
            crearBotonMenu("Controlar Embarques", ComandoVentanaOperadorEnum.CONTROLAR_EMBARQUES),
            crearBotonMenu("Controlar Desembarques", ComandoVentanaOperadorEnum.CONTROLAR_DESEMBARQUES),
            crearBotonMenu("Ver el Rendimiento de los Vuelos", ComandoVentanaOperadorEnum.VER_RENDIMIENTO),
            crearBotonMenu("Ver facturas", ComandoVentanaOperadorEnum.VER_FACTURAS),
            crearBotonMenu("Ver notificaciones", ComandoVentanaOperadorEnum.VER_NOTIFICACIONES),
            crearBotonMenu("Guardar aplicacion", ComandoVentanaOperadorEnum.GUARDAR_APLICACION),
            crearBotonMenu("Cargar aplicacion", ComandoVentanaOperadorEnum.CARGAR_APLICACION)
        );

        for (JButton boton : botones) {
            boton.setHorizontalAlignment(SwingConstants.CENTER);
        }

        /* NOTIFICACIONES */
        app = Aplicacion.init("acceder");
        Usuario logueado = app.getUsuarioLogueado();

        List<String> notificaciones = new ArrayList<>();

        if (logueado != null && !logueado.getNotificacion().isEmpty()) {
            Notificacion ultima = logueado.getNotificacion().get(logueado.getNotificacion().size() - 1);
            notificaciones.add(ultima.getMensaje().toString());
        } else {
            notificaciones.add("Sin notificaciones recientes.");
        }

        pantalla = new PantallaBase(logueado.getNombreUsuario(), botones, notificaciones);
        add(pantalla);
    }

    /* HELPER */
    private JButton crearBotonMenu(String texto, ComandoVentanaOperadorEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        boton.setHorizontalAlignment(SwingConstants.CENTER);
        return boton;
    }

    public PantallaBase getPantallaBase() {
        return pantalla;
    }

    public void mostrarPanel(JPanel panel) {
        pantalla.mostrarContenidoEnPanelCentral(panel);
    }

    public PanelGestionarFlota getPanelGestionarFlota() {
        if (panelGestionarFlota == null) {
            panelGestionarFlota = new PanelGestionarFlota(pantalla);
        }
        return panelGestionarFlota;
    }

    public void setControlador(ActionListener c) {
        for (JButton boton : botones) {
            boton.addActionListener(c);
        }
        pantalla.getCerrarSesionButton().setActionCommand(ComandoVentanaOperadorEnum.CERRAR_SESION.name());
        pantalla.getAvanzar5MinButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_5M.name());
        pantalla.getAvanzar5MinButton().addActionListener(c);
        pantalla.getAvanzar30miButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_30M.name());
        pantalla.getAvanzar30miButton().addActionListener(c);
        pantalla.getAvanzar1hButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_1H.name());
        pantalla.getAvanzar1hButton().addActionListener(c);
        pantalla.getAvanzar1dButton().setActionCommand(ComandoVentanaGestorEnum.AVANZAR_1D.name());
        pantalla.getAvanzar1dButton().addActionListener(c);
    }

    public String getNombreUsuario() {
        return this.nombreUsuario;
    }

    public PanelControlarEstadoVuelo getPanelEstadoVuelo() {
        if (panelEstadoVuelo == null) {
            panelEstadoVuelo = new PanelControlarEstadoVuelo(getPantallaBase());
        }
        return panelEstadoVuelo;
    }

    public PanelControlarEmbarques getPanelControlarEmbarques() {
        if (panelControlarEmbarques == null) {
            panelControlarEmbarques = new PanelControlarEmbarques(getPantallaBase());
        }
        return panelControlarEmbarques;
    }

    public PanelControlarDesembarques getPanelControlarDesembarques() {
        if (panelControlarDesembarques == null) {
            panelControlarDesembarques = new PanelControlarDesembarques(getPantallaBase());
        }
        return panelControlarDesembarques;
    }

    public PanelProponerVuelo getPanelProponerVuelo() {
        if (panelProponerVuelo == null) {
            panelProponerVuelo = new PanelProponerVuelo(getPantallaBase());
        }
        return panelProponerVuelo;
    }


    public PanelRendimientoVuelo getPanelRendimientoVuelo() {
        if (panelRendimiento == null) {
            panelRendimiento = new PanelRendimientoVuelo();
        }
        return panelRendimiento;
    }

    public PanelFacturas getPanelFacturas() {
        if (panelFacturas == null) {
            panelFacturas = new PanelFacturas(getPantallaBase());
        }
        return panelFacturas;
    }

    public JButton getBotonCerrarSesion() {
        return pantalla.getCerrarSesionButton();
    }

    public void update() {
        pantalla.mostrarContenidoEnPanelCentral(new JPanel());
    }
}

