package interfaz.operador.enums;


public enum ComandoVentanaOperadorEnum {
    GESTIONAR_FLOTA,
    PROPONER_VUELOS,
    CONTROLAR_ESTADO,
    CONTROLAR_EMBARQUES,
    CONTROLAR_DESEMBARQUES,
    VER_RENDIMIENTO,
    VER_FACTURAS,
    VER_NOTIFICACIONES,
    GUARDAR_APLICACION,
    CARGAR_APLICACION,
    CERRAR_SESION,

    // Subcomandos de control de tiempo
    AVANZAR_5M,
    AVANZAR_30M,
    AVANZAR_1H,
    AVANZAR_1D,
}

