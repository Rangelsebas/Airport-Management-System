package interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.vista;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import interfaz.componentes.PantallaBase;

public class PanelEnPreparacionMenuPasajeros extends JPanel {
    private PantallaBase pantallaBase;

    private JButton btnEmbarque;

    public PanelEnPreparacionMenuPasajeros(PantallaBase pantallaBase, String codigo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("Embarque pendiente para vuelo con código: " + codigo, Font.BOLD, 18));
        add(Box.createVerticalStrut(30));

        btnEmbarque = new JButton("Iniciar Embarque");
        btnEmbarque.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(btnEmbarque);

        add(Box.createVerticalStrut(10));
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public JButton getBtnEmbarque() {
        return btnEmbarque;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}
