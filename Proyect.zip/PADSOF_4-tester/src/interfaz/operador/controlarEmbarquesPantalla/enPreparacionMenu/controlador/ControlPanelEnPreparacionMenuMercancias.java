package interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.controlador;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarEmbarquesPantalla.controlador.ControlPanelControlarEmbarques;
import interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.vista.PanelEnPreparacionMenuMercancias;
import interfaz.operador.controlarEmbarquesPantalla.vista.PanelControlarEmbarques;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControlPanelEnPreparacionMenuMercancias implements ActionListener {
    private final PanelEnPreparacionMenuMercancias vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelEnPreparacionMenuMercancias(PanelEnPreparacionMenuMercancias vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;

        this.aplicacion = Aplicacion.init("acceder");
        this.vista.getBtnCarga().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnCarga()) {

            Vuelo v = aplicacion.buscarVueloxCodigo(codigo);

            if (v == null) {
                JOptionPane.showMessageDialog(null, "El Vuelo no puede ser null.");
                return;
            }

            try {
                if (!v.iniciarCargaCambioEstado()) {
                    JOptionPane.showMessageDialog(vista,
                        "Para cambiar al estado CARGANDO deben pasar al menos 15 minutos desde el inicio de la preparación.",
                        "Tiempo insuficiente",
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }

                System.out.println("Vuelo " + v.getCodigoVuelo() + " en estado CARGANDO.");
                JOptionPane.showMessageDialog(null, "Vuelo en estado CARGANDO.");
                volver();

            } catch (Exception x) {
                JOptionPane.showMessageDialog(null, "Error inesperado: " + x.getMessage());
            }
        } 
    }

    private void volver(){
        PanelControlarEmbarques panelControlarDesembarques = new PanelControlarEmbarques(pantalla);
        new ControlPanelControlarEmbarques(panelControlarDesembarques);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDesembarques);
    }
}
