package interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarEmbarquesPantalla.controlador.ControlPanelControlarEmbarques;
import interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.vista.PanelEnPreparacionMenuPasajeros;
import interfaz.operador.controlarEmbarquesPantalla.vista.PanelControlarEmbarques;

public class ControlPanelEnPreparacionMenuPasajeros implements ActionListener {
    private final PanelEnPreparacionMenuPasajeros vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelEnPreparacionMenuPasajeros(PanelEnPreparacionMenuPasajeros vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;

        this.aplicacion = Aplicacion.init("acceder");
        this.vista.getBtnEmbarque().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnEmbarque()) {

            Vuelo v = aplicacion.buscarVueloxCodigo(codigo);

            if (v == null) {
                JOptionPane.showMessageDialog(null, "El Vuelo no puede ser null.");
                return;
            }

            try {
                if (!v.iniciarEmbarqueCambioEstado()) {
                    JOptionPane.showMessageDialog(vista,
                        "Para cambiar al estado EMBARCANDO deben pasar al menos 30 minutos desde el inicio de la preparación.",
                        "Tiempo insuficiente",
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }

                System.out.println("Vuelo " + v.getCodigoVuelo() + " en estado EMBARCANDO.");
                JOptionPane.showMessageDialog(null, "Vuelo en estado EMBARCANDO.");
                volver();

            } catch (Exception x) {
                JOptionPane.showMessageDialog(null, "Error inesperado.");
            }
        }
    }

    private void volver(){
        PanelControlarEmbarques panelControlarDesembarques = new PanelControlarEmbarques(pantalla);
        new ControlPanelControlarEmbarques(panelControlarDesembarques);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDesembarques);
    }
}
