package interfaz.operador.controlarEmbarquesPantalla.controlador;

import java.awt.event.MouseAdapter;
import java.time.format.DateTimeFormatter;
import java.util.List;

import java.awt.event.MouseEvent;

import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarEmbarquesPantalla.cargandoMenu.controlador.ControlPanelFinalizarCargaMenu;
import interfaz.operador.controlarEmbarquesPantalla.cargandoMenu.vista.PanelFinalizarCargaMenu;
import interfaz.operador.controlarEmbarquesPantalla.embarcandoMenu.controlador.ControlPanelFinalizarEmbarqueMenu;
import interfaz.operador.controlarEmbarquesPantalla.embarcandoMenu.vista.PanelFinalizarEmbarqueMenu;
import interfaz.operador.controlarEmbarquesPantalla.enAparcamientoMenu.controlador.ControlPanelEnAparcamientoMenu;
import interfaz.operador.controlarEmbarquesPantalla.enAparcamientoMenu.vista.PanelEnAparcamientoMenu;
import interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.controlador.ControlPanelEnPreparacionMenuMercancias;
import interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.controlador.ControlPanelEnPreparacionMenuPasajeros;
import interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.vista.PanelEnPreparacionMenuMercancias;
import interfaz.operador.controlarEmbarquesPantalla.enPreparacionMenu.vista.PanelEnPreparacionMenuPasajeros;
import interfaz.operador.controlarEmbarquesPantalla.vista.PanelControlarEmbarques;

public class ControlPanelControlarEmbarques {

    private final PantallaBase pantallaBase;
    private final PanelControlarEmbarques vista;
    private final OperadorAerolinea operadorAerolinea;
    private final Aplicacion aplicacion;
    
    public ControlPanelControlarEmbarques(PanelControlarEmbarques vista) {
        this.vista = vista;
        this.pantallaBase = vista.getPantallaBase();

        aplicacion = Aplicacion.init("");
        this.operadorAerolinea = (OperadorAerolinea) aplicacion.getUsuarioLogueado();

        List<Vuelo> vuelos = aplicacion.getAerolinea(operadorAerolinea.getAerolinea().getNombre()).getVuelosEmbarque();

        vista.resetSolicitudes(); // Evita que se acumulen los elementos visualmente

        if (vuelos.isEmpty()) {
            vista.añadirSolicitud("No hay vuelos que atender");
        } else {
            for (Vuelo vuelo : vuelos) {
                String texto = "Codigo del vuelo: " + vuelo.getCodigoVuelo() + " | Aerolinea: " + vuelo.getAerolineaOperadora().getNombre() + " | Fecha: " + vuelo.getFecha() + 
                " | " + vuelo.getHoraSalida().format(DateTimeFormatter.ofPattern("HH:mm")) + " - " + vuelo.getHoraLlegada().format(DateTimeFormatter.ofPattern("HH:mm")) + 
                " | " + vuelo.getOrigen().getNombre() + " - " + vuelo.getDestino().getNombre() + " | Estado : " + vuelo.getEstado() + " | Retraso: " + (vuelo.getEnTiempo()? "No" : "Si") + "\n";
                vista.añadirSolicitud(texto);
            }

            vista.getListaSolicitudes().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent evt) {
                    if (evt.getClickCount() == 2) {
                        int index = vista.getListaSolicitudes().locationToIndex(evt.getPoint());

                        if (index >= 0) {
                            String texto = vista.getListaSolicitudes().getModel().getElementAt(index);
                            String codigo = getCodigo(texto);

                            Vuelo vuelo = aplicacion.buscarVueloxCodigo(codigo);

                            switch (vuelo.getEstado()) {
                                case EN_APARCAMIENTO:
                                    PanelEnAparcamientoMenu panelEnAparcamientoMenu = new PanelEnAparcamientoMenu(pantallaBase, vuelo.getCodigoVuelo());
                                    new ControlPanelEnAparcamientoMenu(panelEnAparcamientoMenu, codigo, pantallaBase);
                                    pantallaBase.mostrarContenidoEnPanelCentral(panelEnAparcamientoMenu);
                                    break;
                                case EN_PREPARACION:

                                    CategoriaAvion categoriaAvion = vuelo.getAvion().getTipoAvion().getCategoria();

                                    switch (categoriaAvion) {
                                        case MERCANCIAS:
                                            PanelEnPreparacionMenuMercancias panelEnPreparacionMenuMercancias = new PanelEnPreparacionMenuMercancias(pantallaBase, vuelo.getCodigoVuelo());
                                            new ControlPanelEnPreparacionMenuMercancias(panelEnPreparacionMenuMercancias, codigo, pantallaBase);
                                            pantallaBase.mostrarContenidoEnPanelCentral(panelEnPreparacionMenuMercancias);
                                            break;
                                        case PASAJEROS:
                                            PanelEnPreparacionMenuPasajeros panelEnPreparacionMenu = new PanelEnPreparacionMenuPasajeros(pantallaBase, vuelo.getCodigoVuelo());
                                            new ControlPanelEnPreparacionMenuPasajeros(panelEnPreparacionMenu, codigo, pantallaBase);
                                            pantallaBase.mostrarContenidoEnPanelCentral(panelEnPreparacionMenu);
                                            break;
                                        default:
                                            break;
                                    }
                                    
                                    break;
                                case EMBARCANDO:
                                    PanelFinalizarEmbarqueMenu panelFinalizarEmbarqueMenu = new PanelFinalizarEmbarqueMenu(pantallaBase, codigo);
                                    new ControlPanelFinalizarEmbarqueMenu(panelFinalizarEmbarqueMenu, codigo, pantallaBase);
                                    pantallaBase.mostrarContenidoEnPanelCentral(panelFinalizarEmbarqueMenu);
                                    break;
                                case CARGANDO:
                                    PanelFinalizarCargaMenu panelFinalizarCargaMenu = new PanelFinalizarCargaMenu(pantallaBase, codigo);
                                    new ControlPanelFinalizarCargaMenu(panelFinalizarCargaMenu, codigo, pantallaBase);
                                    pantallaBase.mostrarContenidoEnPanelCentral(panelFinalizarCargaMenu);
                                    break;
                            
                                default:
                                    break;
                            }
                        }
                    }
                }
            });
        }
    }

    private String getCodigo(String texto){
        String clave = "Codigo del vuelo:";
        int pos = texto.indexOf(clave);
        String codigo = "";

        if (pos != -1) {
            // comenzamos justo tras la clave
            int start = pos + clave.length();
            // buscamos el siguiente separador " |"
            int end = texto.indexOf("|", start);
            if (end == -1) {
                // si no hay barra, cogemos hasta el cierre del div
                end = texto.indexOf("<", start);
            }
            codigo = texto.substring(start, end).trim();
        }

        return codigo;
    }
}
