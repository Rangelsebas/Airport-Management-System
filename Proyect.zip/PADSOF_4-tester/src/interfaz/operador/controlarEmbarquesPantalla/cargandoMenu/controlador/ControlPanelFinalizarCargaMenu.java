package interfaz.operador.controlarEmbarquesPantalla.cargandoMenu.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarEmbarquesPantalla.cargandoMenu.vista.PanelFinalizarCargaMenu;
import interfaz.operador.controlarEmbarquesPantalla.controlador.ControlPanelControlarEmbarques;
import interfaz.operador.controlarEmbarquesPantalla.vista.PanelControlarEmbarques;


public class ControlPanelFinalizarCargaMenu implements ActionListener {
    private final PanelFinalizarCargaMenu vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelFinalizarCargaMenu(PanelFinalizarCargaMenu vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;

        this.aplicacion = Aplicacion.init("acceder");
        this.vista.getBtnCarga().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnCarga()) {

            Vuelo v = aplicacion.buscarVueloxCodigo(codigo);

            if (v == null) {
                JOptionPane.showMessageDialog(null, "El Vuelo no puede ser null.");
                return;
            }

            try {
                if (v.embarqueFinalizadoCambioEstado()){
                    System.out.println("Vuelo " + v.getCodigoVuelo() + " en estado ESPERANDO_PISTA_DESPEGUE.");
                    JOptionPane.showMessageDialog(null, "Vuelo en estado ESPERANDO_PISTA_DESPEGUE.");
                    volver();
                }
            } catch (Exception x) {
                JOptionPane.showMessageDialog(null, "Error inesperado.");
            }
        } 
    }

    private void volver(){
        PanelControlarEmbarques panelControlarDesembarques = new PanelControlarEmbarques(pantalla);
        new ControlPanelControlarEmbarques(panelControlarDesembarques);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDesembarques);
    }
}
