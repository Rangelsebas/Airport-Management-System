package interfaz.operador.controlarDesembarquesPantalla.finalizarDescargaMenu.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarDesembarquesPantalla.controlador.ControlPanelControlarDesembarques;
import interfaz.operador.controlarDesembarquesPantalla.finalizarDescargaMenu.vista.PanelFinalizarDescargaMenu;
import interfaz.operador.controlarDesembarquesPantalla.vista.PanelControlarDesembarques;

public class ControlPanelFinalizarDescargaMenu implements ActionListener {
    private final PanelFinalizarDescargaMenu vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelFinalizarDescargaMenu(PanelFinalizarDescargaMenu vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;

        this.aplicacion = Aplicacion.init("acceder");
        this.vista.getBtnFinalizarDescarga().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Vuelo v = aplicacion.buscarVueloxCodigo(codigo);

        if (v == null) {
            JOptionPane.showMessageDialog(null, "El Vuelo no puede ser null.");
            return;
        }

        try {
            if (!v.descargaFinalizadaCambioEstado()) {
                JOptionPane.showMessageDialog(vista,
                        "Para finalizar la descarga deben pasar al menos 15 minutos desde que inició.",
                        "Tiempo insuficiente",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            System.out.println("Vuelo " + v.getCodigoVuelo() + " en estado OPERATIVO.");
            JOptionPane.showMessageDialog(null, "Vuelo en estado OPERATIVO.");
            volver();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error inesperado.");
        }
    }

    private void volver(){
        PanelControlarDesembarques panelControlarDesembarques = new PanelControlarDesembarques(pantalla);
        new ControlPanelControlarDesembarques(panelControlarDesembarques);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDesembarques);
    }
}
