package interfaz.operador.controlarDesembarquesPantalla.desembarcandoMenu.vista;

import java.awt.*;
import javax.swing.*;

import interfaz.componentes.PantallaBase;

public class PanelDesembarcandoMenu extends JPanel {
    private PantallaBase pantallaBase;

    private JButton btnIniciarDesembarque;

    public PanelDesembarcandoMenu(PantallaBase pantallaBase, String codigo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("Desembarque pendiente para vuelo con código: " + codigo, Font.BOLD, 18));
        add(Box.createVerticalStrut(30));

        btnIniciarDesembarque = new JButton("Iniciar Desembarque");
        btnIniciarDesembarque.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(btnIniciarDesembarque);

        add(Box.createVerticalStrut(10));
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public JButton getBtnIniciarDesembarque() {
        return btnIniciarDesembarque;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}
