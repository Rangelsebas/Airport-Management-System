package interfaz.operador.controlarDesembarquesPantalla.desembarcandoMenu.controlador;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarDesembarquesPantalla.controlador.ControlPanelControlarDesembarques;
import interfaz.operador.controlarDesembarquesPantalla.desembarcandoMenu.vista.PanelDesembarcandoMenu;
import interfaz.operador.controlarDesembarquesPantalla.vista.PanelControlarDesembarques;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlPanelDesembarcandoMenu implements ActionListener {
    private final PanelDesembarcandoMenu vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelDesembarcandoMenu(PanelDesembarcandoMenu vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;

        this.aplicacion = Aplicacion.init("acceder");
        this.vista.getBtnIniciarDesembarque().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnIniciarDesembarque()) {

            Vuelo v = aplicacion.buscarVueloxCodigo(codigo);

            if (v == null) {
                JOptionPane.showMessageDialog(null, "El Vuelo no puede ser null.");
                return;
            }

            try {
                if (v.iniciarDescargaCambioEstado()){
                    System.out.println("Vuelo " + v.getCodigoVuelo() + " en estado DESEMBARCANDO.");
                    JOptionPane.showMessageDialog(null, "Vuelo en estado DESEMBARCANDO.");
                    volver();
                }
            } catch (Exception x) {
                JOptionPane.showMessageDialog(null, "Error inesperado.");
            }
        } 
    }

    private void volver(){
        PanelControlarDesembarques panelControlarDesembarques = new PanelControlarDesembarques(pantalla);
        new ControlPanelControlarDesembarques(panelControlarDesembarques);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDesembarques);
    }
}
