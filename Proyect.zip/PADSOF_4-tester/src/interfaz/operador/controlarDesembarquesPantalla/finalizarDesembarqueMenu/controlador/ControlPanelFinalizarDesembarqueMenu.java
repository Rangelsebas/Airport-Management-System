package interfaz.operador.controlarDesembarquesPantalla.finalizarDesembarqueMenu.controlador;

import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarDesembarquesPantalla.controlador.ControlPanelControlarDesembarques;
import interfaz.operador.controlarDesembarquesPantalla.finalizarDesembarqueMenu.vista.PanelFinalizarDesembarqueMenu;
import interfaz.operador.controlarDesembarquesPantalla.vista.PanelControlarDesembarques;

public class ControlPanelFinalizarDesembarqueMenu implements ActionListener {
    private final PanelFinalizarDesembarqueMenu vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelFinalizarDesembarqueMenu(PanelFinalizarDesembarqueMenu vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;

        this.aplicacion = Aplicacion.init("acceder");
        this.vista.getBtnFinalizarDesembarque().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Vuelo v = aplicacion.buscarVueloxCodigo(codigo);

        if (v == null) {
            JOptionPane.showMessageDialog(null, "El Vuelo no puede ser null.");
            return;
        }

        try {
            if (!v.descargaFinalizadaCambioEstado()) {
                JOptionPane.showMessageDialog(vista,
                        "Para finalizar el desembarque deben pasar al menos 30 minutos desde que inició.",
                        "Tiempo insuficiente",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            System.out.println("Vuelo " + v.getCodigoVuelo() + " en estado OPERATIVO.");
            JOptionPane.showMessageDialog(null, "Vuelo en estado OPERATIVO.");
            volver();

        } catch (Exception x) {
            JOptionPane.showMessageDialog(null, "Error inesperado.");
        }
    }

    private void volver(){
        PanelControlarDesembarques panelControlarDesembarques = new PanelControlarDesembarques(pantalla);
        new ControlPanelControlarDesembarques(panelControlarDesembarques);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDesembarques);
    }
}
