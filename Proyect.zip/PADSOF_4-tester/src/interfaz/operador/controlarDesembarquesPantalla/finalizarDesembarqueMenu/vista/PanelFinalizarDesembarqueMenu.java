package interfaz.operador.controlarDesembarquesPantalla.finalizarDesembarqueMenu.vista;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import interfaz.componentes.PantallaBase;

public class PanelFinalizarDesembarqueMenu extends JPanel {
    private PantallaBase pantallaBase;

    private JButton btnFinalizarDesembarque;

    public PanelFinalizarDesembarqueMenu(PantallaBase pantallaBase, String codigo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("Fin de Embarque pendiente para vuelo con código: " + codigo, Font.BOLD, 18));
        add(Box.createVerticalStrut(30));

        btnFinalizarDesembarque = new JButton("Finalizar Desembarque");
        btnFinalizarDesembarque.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(btnFinalizarDesembarque);

        add(Box.createVerticalStrut(10));
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public JButton getBtnFinalizarDesembarque() {
        return btnFinalizarDesembarque;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}
