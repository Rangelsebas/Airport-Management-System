package interfaz.operador.controlarDesembarquesPantalla.controlador;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.format.DateTimeFormatter;
import java.util.List;

import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarDesembarquesPantalla.descargandoMenu.controlador.ControlPanelDescargandoMenu;
import interfaz.operador.controlarDesembarquesPantalla.descargandoMenu.vista.PanelDescargandoMenu;
import interfaz.operador.controlarDesembarquesPantalla.desembarcandoMenu.controlador.ControlPanelDesembarcandoMenu;
import interfaz.operador.controlarDesembarquesPantalla.desembarcandoMenu.vista.PanelDesembarcandoMenu;
import interfaz.operador.controlarDesembarquesPantalla.finalizarDescargaMenu.controlador.ControlPanelFinalizarDescargaMenu;
import interfaz.operador.controlarDesembarquesPantalla.finalizarDescargaMenu.vista.PanelFinalizarDescargaMenu;
import interfaz.operador.controlarDesembarquesPantalla.finalizarDesembarqueMenu.controlador.ControlPanelFinalizarDesembarqueMenu;
import interfaz.operador.controlarDesembarquesPantalla.finalizarDesembarqueMenu.vista.PanelFinalizarDesembarqueMenu;
import interfaz.operador.controlarDesembarquesPantalla.vista.PanelControlarDesembarques;

public class ControlPanelControlarDesembarques {
    private final PantallaBase pantallaBase;
    private final PanelControlarDesembarques vista;
    private final OperadorAerolinea operadorAerolinea;
    private final Aplicacion aplicacion;

    public ControlPanelControlarDesembarques(PanelControlarDesembarques vista) {
        this.vista = vista;
        this.pantallaBase = vista.getPantallaBase();

        aplicacion = Aplicacion.init("");
        this.operadorAerolinea = (OperadorAerolinea) aplicacion.getUsuarioLogueado();

        List<Vuelo> vuelos = aplicacion.getAerolinea(operadorAerolinea.getAerolinea().getNombre()).getVuelosDesembarque();
        
        vista.resetSolicitudes(); // Evita que se acumulen los elementos visualmente
        
        if (vuelos.isEmpty()) {
            vista.añadirSolicitud("No hay vuelos que atender");
        } else {
            for (Vuelo vuelo : vuelos) {
                String texto = "Codigo del vuelo: " + vuelo.getCodigoVuelo() + " | Aerolinea: " + vuelo.getAerolineaOperadora().getNombre() + " | Fecha: " + vuelo.getFecha() + 
                " | " + vuelo.getHoraSalida().format(DateTimeFormatter.ofPattern("HH:mm")) + " - " + vuelo.getHoraLlegada().format(DateTimeFormatter.ofPattern("HH:mm")) + 
                " | " + vuelo.getOrigen().getNombre() + " - " + vuelo.getDestino().getNombre() + " | Estado : " + vuelo.getEstado() + " | Retraso: " + (vuelo.getEnTiempo()? "No" : "Si") + "\n";
                vista.añadirSolicitud(texto);
            }

            vista.getListaSolicitudes().addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent evt) {
                    if (evt.getClickCount() == 2) {
                        int index = vista.getListaSolicitudes().locationToIndex(evt.getPoint());

                        if (index >= 0) {
                            String texto = vista.getListaSolicitudes().getModel().getElementAt(index);
                            String codigo = getCodigo(texto);

                            Vuelo vuelo = aplicacion.buscarVueloxCodigo(codigo);

                            switch (vuelo.getEstado()) {
                                case DESEMBARCANDO:
                                    PanelFinalizarDesembarqueMenu panelFinalizarDesembarqueMenu = new PanelFinalizarDesembarqueMenu(pantallaBase, codigo);
                                    new ControlPanelFinalizarDesembarqueMenu(panelFinalizarDesembarqueMenu, codigo, pantallaBase);
                                    pantallaBase.mostrarContenidoEnPanelCentral(panelFinalizarDesembarqueMenu);
                                    break;
                                case DESCARGANDO:
                                    PanelFinalizarDescargaMenu panelFinalizarDescargaMenu = new PanelFinalizarDescargaMenu(pantallaBase, codigo);
                                    new ControlPanelFinalizarDescargaMenu(panelFinalizarDescargaMenu, codigo, pantallaBase);
                                    pantallaBase.mostrarContenidoEnPanelCentral(panelFinalizarDescargaMenu);
                                    break;
                                case ATERRIZADO:

                                    CategoriaAvion categoriaAvion = vuelo.getAvion().getTipoAvion().getCategoria();

                                    switch (categoriaAvion) {
                                        case PASAJEROS:
                                            PanelDesembarcandoMenu panelDesembarcandoMenu = new PanelDesembarcandoMenu(pantallaBase, codigo);
                                            new ControlPanelDesembarcandoMenu(panelDesembarcandoMenu, codigo, pantallaBase);
                                            pantallaBase.mostrarContenidoEnPanelCentral(panelDesembarcandoMenu);
                                            break;
                                        case MERCANCIAS:
                                            PanelDescargandoMenu panelDescargandoMenu = new PanelDescargandoMenu(pantallaBase, codigo);
                                            new ControlPanelDescargandoMenu(panelDescargandoMenu, codigo, pantallaBase);
                                            pantallaBase.mostrarContenidoEnPanelCentral(panelDescargandoMenu);
                                            break;
                                    
                                        default:
                                            break;
                                    }
                                    break;
                            
                                default:
                                    break;
                            }
                        }
                    }
                }
            });
        }
    }

    private String getCodigo(String texto){
        String clave = "Codigo del vuelo:";
        int pos = texto.indexOf(clave);
        String codigo = "";

        if (pos != -1) {
            // comenzamos justo tras la clave
            int start = pos + clave.length();
            // buscamos el siguiente separador " |"
            int end = texto.indexOf("|", start);
            if (end == -1) {
                // si no hay barra, cogemos hasta el cierre del div
                end = texto.indexOf("<", start);
            }
            codigo = texto.substring(start, end).trim();
        }

        return codigo;
    }
}
