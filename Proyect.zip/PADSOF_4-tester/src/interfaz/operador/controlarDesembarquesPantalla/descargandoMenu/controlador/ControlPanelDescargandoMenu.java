package interfaz.operador.controlarDesembarquesPantalla.descargandoMenu.controlador;

import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.controlarDesembarquesPantalla.controlador.ControlPanelControlarDesembarques;
import interfaz.operador.controlarDesembarquesPantalla.descargandoMenu.vista.PanelDescargandoMenu;
import interfaz.operador.controlarDesembarquesPantalla.vista.PanelControlarDesembarques;

public class ControlPanelDescargandoMenu implements ActionListener{
    private final PanelDescargandoMenu vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;
    private String codigo;

    public ControlPanelDescargandoMenu(PanelDescargandoMenu vista, String codigo, PantallaBase pantalla) {
        this.vista = vista;
        this.codigo = codigo;
        this.pantalla = pantalla;

        this.aplicacion = Aplicacion.init("acceder");
        this.vista.getBtnIniciarDescarga().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == vista.getBtnIniciarDescarga()) {

            Vuelo v = aplicacion.buscarVueloxCodigo(codigo);

            if (v == null) {
                JOptionPane.showMessageDialog(null, "El Vuelo no puede ser null.");
                return;
            }

            try {
                if (v.iniciarDescargaCambioEstado()){
                    System.out.println("Vuelo " + v.getCodigoVuelo() + " en estado DESCARGANDO.");
                    JOptionPane.showMessageDialog(null, "Vuelo en estado DESCARGANDO.");
                    volver();
                }
            } catch (Exception x) {
                JOptionPane.showMessageDialog(null, "Error inesperado.");
            }
        } 
    }

    private void volver(){
        PanelControlarDesembarques panelControlarDesembarques = new PanelControlarDesembarques(pantalla);
        new ControlPanelControlarDesembarques(panelControlarDesembarques);
        pantalla.mostrarContenidoEnPanelCentral(panelControlarDesembarques);
    }
}
