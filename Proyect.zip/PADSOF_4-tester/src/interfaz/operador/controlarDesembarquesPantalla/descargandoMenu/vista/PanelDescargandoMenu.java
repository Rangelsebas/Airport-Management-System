package interfaz.operador.controlarDesembarquesPantalla.descargandoMenu.vista;

import java.awt.*;
import javax.swing.*;

import interfaz.componentes.PantallaBase;

public class PanelDescargandoMenu extends JPanel{
    private PantallaBase pantallaBase;

    private JButton btnIniciarDescarga;

    public PanelDescargandoMenu(PantallaBase pantallaBase, String codigo) {
        this.pantallaBase = pantallaBase;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        add(crearLabel("Descarga pendiente para vuelo con código: " + codigo, Font.BOLD, 18));
        add(Box.createVerticalStrut(30));

        // Botón de descarga
        btnIniciarDescarga = new JButton("Iniciar Descarga");
        btnIniciarDescarga.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(btnIniciarDescarga);

        add(Box.createVerticalStrut(10));
    }

    private JLabel crearLabel(String texto, int estilo, int tamaño) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("SansSerif", estilo, tamaño));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public JButton getBtnIniciarDescarga() {
        return btnIniciarDescarga;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}
