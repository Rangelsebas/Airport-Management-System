package interfaz.operador.quintaPantalla.listadoFacturasSubMenu.controlador;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.Factura;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import interfaz.componentes.PantallaBase;
import interfaz.operador.quintaPantalla.listadoFacturasSubMenu.vista.PanelListadoFacturas;

public class ControlPanelListadoFacturas {

    private PanelListadoFacturas vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelListadoFacturas(PanelListadoFacturas vista, PantallaBase pantalla, Date desdeDate, Date hastaDate) {
        this.vista = vista;
        this.pantalla = pantalla;
        aplicacion = Aplicacion.init("acceder");

        cargarFacturasReales(desdeDate, hastaDate);
    }

    private void cargarFacturasReales(Date desdeDate, Date hastaDate) {
        // Convertir Date → LocalDate
        LocalDate desde = new java.sql.Date(desdeDate.getTime()).toLocalDate();
        LocalDate hasta = new java.sql.Date(hastaDate.getTime()).toLocalDate();

        OperadorAerolinea operadorAerolinea = (OperadorAerolinea) aplicacion.getUsuarioLogueado();
        if (operadorAerolinea == null || !operadorAerolinea.checkRol(Rol.OPERADORAEROLINEA)) {
            JOptionPane.showMessageDialog(vista, "No se ha encontrado un operador de aerolínea.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Aerolinea aerolinea = aplicacion.getAerolinea(operadorAerolinea.getAerolinea().getNombre());
        if (aerolinea == null) {
            JOptionPane.showMessageDialog(vista, "No se ha encontrado la aerolínea del operador.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<Factura> facturasEnRango = aerolinea.getFacturas().stream()
            .filter(f -> {
                LocalDate fecha = f.verFechaEmision();
                return (fecha.isEqual(desde) || fecha.isAfter(desde)) &&
                       (fecha.isEqual(hasta) || fecha.isBefore(hasta));
            })
            .collect(Collectors.toList());

        if (facturasEnRango.isEmpty()) {
            vista.agregarFactura("ℹNo se encontraron facturas en ese rango de fechas.");
            return;
        }

        for (Factura f : facturasEnRango) {
            String info = f.getId()
                        + " | Fecha: " + f.verFechaEmision()
                        + " | Estado: " + f.getEstadoPago()
                        + " | Total: $" + String.format("%.2f", f.getPrice());
            vista.agregarFactura(info);
        }
    }
}
