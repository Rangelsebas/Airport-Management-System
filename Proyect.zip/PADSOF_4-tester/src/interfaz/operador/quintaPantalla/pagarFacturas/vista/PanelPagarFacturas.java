package interfaz.operador.quintaPantalla.pagarFacturas.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfaz.operador.quintaPantalla.pagarFacturas.enums.ComandoPagarFacturasEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class PanelPagarFacturas extends JPanel {

    private JPanel panelListado;
    private JButton botonPagar;
    private List<JCheckBox> listaCheckboxes;
    private JTextField campoTarjeta;

    public PanelPagarFacturas() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Título
        JLabel titulo = new JLabel("Pagar Facturas", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Panel de facturas con scroll
        panelListado = new JPanel();
        panelListado.setLayout(new BoxLayout(panelListado, BoxLayout.Y_AXIS));
        panelListado.setBackground(Color.WHITE);
        listaCheckboxes = new ArrayList<>();

        JScrollPane scroll = new JScrollPane(panelListado);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setPreferredSize(new Dimension(500, 300));
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scroll, BorderLayout.CENTER);

        // ===== PANEL INFERIOR =====
        JPanel panelInferior = new JPanel();
        panelInferior.setLayout(new BoxLayout(panelInferior, BoxLayout.Y_AXIS));
        panelInferior.setBackground(Color.WHITE);

        // Campo de tarjeta
        campoTarjeta = new JTextField();
        campoTarjeta.setMaximumSize(new Dimension(300, 30));
        campoTarjeta.setFont(new Font("Arial", Font.PLAIN, 14));
        campoTarjeta.setAlignmentX(Component.CENTER_ALIGNMENT);
        campoTarjeta.setToolTipText("Introduce tu número de tarjeta");

        JPanel panelTarjeta = new JPanel();
        panelTarjeta.setBackground(Color.WHITE);
        panelTarjeta.setLayout(new BoxLayout(panelTarjeta, BoxLayout.Y_AXIS));
        panelTarjeta.setBorder(new EmptyBorder(10, 0, 10, 0));
        panelTarjeta.add(new JLabel("Número de Tarjeta:", SwingConstants.CENTER));
        panelTarjeta.add(campoTarjeta);

        // Botón de pagar
        botonPagar = new JButton("Pagar Seleccionadas");
        botonPagar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonPagar.setActionCommand(ComandoPagarFacturasEnum.PAGAR_FACTURAS.name());

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(Color.WHITE);
        panelBoton.setBorder(new EmptyBorder(0, 0, 20, 0));
        panelBoton.add(botonPagar);

        // Añadir al panel inferior
        panelInferior.add(panelTarjeta);
        panelInferior.add(panelBoton);

        // Añadir panel inferior al sur
        add(panelInferior, BorderLayout.SOUTH);
    }

    public String getNumeroTarjeta() {
        return campoTarjeta.getText().trim();
    }

    public void agregarFactura(String infoFactura) {
        JCheckBox checkbox = new JCheckBox(infoFactura);
        checkbox.setFont(new Font("Arial", Font.PLAIN, 16));
        checkbox.setBackground(Color.WHITE);
        checkbox.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelFactura = new JPanel();
        panelFactura.setLayout(new BoxLayout(panelFactura, BoxLayout.Y_AXIS));
        panelFactura.setBackground(Color.WHITE);
        panelFactura.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelFactura.add(checkbox);

        panelListado.add(Box.createVerticalStrut(10));
        panelListado.add(panelFactura);

        listaCheckboxes.add(checkbox);
        panelListado.revalidate();
        panelListado.repaint();
    }

    public List<JCheckBox> getCheckboxes() {
        return listaCheckboxes;
    }

    public void setControlador(ActionListener c) {
        botonPagar.addActionListener(c);
    }

    public void reset() {
        panelListado.removeAll();
        listaCheckboxes.clear();
        panelListado.revalidate();
        panelListado.repaint();
    }
}
