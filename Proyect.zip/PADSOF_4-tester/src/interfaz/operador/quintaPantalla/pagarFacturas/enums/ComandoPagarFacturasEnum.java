package interfaz.operador.quintaPantalla.pagarFacturas.enums;

public enum ComandoPagarFacturasEnum {
    PAGAR_FACTURAS
}
