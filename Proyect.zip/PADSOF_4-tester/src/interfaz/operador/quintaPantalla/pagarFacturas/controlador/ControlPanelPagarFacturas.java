package interfaz.operador.quintaPantalla.pagarFacturas.controlador;

import javax.swing.*;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.EstadoPago;
import funcionalidad.facturacion.Factura;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import interfaz.componentes.PantallaBase;
import interfaz.operador.quintaPantalla.pagarFacturas.enums.ComandoPagarFacturasEnum;
import interfaz.operador.quintaPantalla.pagarFacturas.vista.PanelPagarFacturas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ControlPanelPagarFacturas implements ActionListener {

    private PanelPagarFacturas vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;
    private Map<JCheckBox, Factura> mapCheckboxFactura;

    public ControlPanelPagarFacturas(PanelPagarFacturas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("acceso");
        this.vista.setControlador(this);
        this.mapCheckboxFactura = new HashMap<>();
        cargarFacturasPendientes();
    }

    private void cargarFacturasPendientes() {

        OperadorAerolinea operadorAerolinea = (OperadorAerolinea) aplicacion.getUsuarioLogueado();
        if (operadorAerolinea == null || !operadorAerolinea.checkRol(Rol.OPERADORAEROLINEA)) {
            JOptionPane.showMessageDialog(vista, "No se ha encontrado un operador de aerolínea.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }


        Aerolinea aerolinea = aplicacion.getAerolinea(operadorAerolinea.getAerolinea().getNombre());
        List<Factura> facturas = aerolinea.getFacturas(); // Paga las facturas de su aerolinea correspondiente

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        for (Factura factura : facturas) {
            if (factura.getEstadoPago() == EstadoPago.PENDIENTE) {
                String texto = factura.getId()
                        + " | Fecha: " + factura.verFechaEmision().format(formatter)
                        + " | Monto: $" + factura.getPrice();

                new JCheckBox(texto);
                vista.agregarFactura(texto); 
                mapCheckboxFactura.put(vista.getCheckboxes().get(vista.getCheckboxes().size() - 1), factura); 
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoPagarFacturasEnum comando = ComandoPagarFacturasEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case PAGAR_FACTURAS:
                procesarPagoFacturas();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarPagoFacturas() {
        boolean algunaSeleccionada = false;

        for (JCheckBox checkbox : vista.getCheckboxes()) {
            if (checkbox.isSelected() && checkbox.isEnabled()) {
                Factura factura = mapCheckboxFactura.get(checkbox);
                if (factura != null) {

                    String tarjeta = vista.getNumeroTarjeta();
                    try {
                        validarTarjeta(tarjeta);
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(vista, ex.getMessage(), "Error de validación", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    boolean exito = aplicacion.pagarFactura(factura, tarjeta);

                    if (exito) {
                        checkbox.setSelected(false);
                        checkbox.setEnabled(false);
                        algunaSeleccionada = true;
                    } else {
                        JOptionPane.showMessageDialog(vista, "Error al pagar la factura " + factura.getId(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }

        if (!algunaSeleccionada) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar al menos una factura para pagar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(vista, "¡Pago realizado con éxito!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void validarTarjeta(String tarjeta) {
        if (tarjeta == null || tarjeta.isBlank()) {
            throw new IllegalArgumentException("Por favor, introduce un número de tarjeta.");
        }
        if (!tarjeta.matches("\\d{16}")) {
            throw new IllegalArgumentException("El número de tarjeta debe tener 16 dígitos numéricos.");
        }
    }
}
