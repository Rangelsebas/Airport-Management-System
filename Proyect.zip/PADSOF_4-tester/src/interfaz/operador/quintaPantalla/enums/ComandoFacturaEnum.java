package interfaz.operador.quintaPantalla.enums;

public enum ComandoFacturaEnum {
    HISTORICO_FACTURAS,
    PAGAR_FACTURA
}