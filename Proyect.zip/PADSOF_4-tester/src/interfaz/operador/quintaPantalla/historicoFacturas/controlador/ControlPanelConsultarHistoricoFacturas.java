package interfaz.operador.quintaPantalla.historicoFacturas.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.Factura;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import interfaz.componentes.PantallaBase;
import interfaz.operador.quintaPantalla.historicoFacturas.enums.ComandoHistoricoFacturasEnum;
import interfaz.operador.quintaPantalla.historicoFacturas.vista.PanelConsultarHistoricoFacturas;
import interfaz.operador.quintaPantalla.listadoFacturasSubMenu.controlador.ControlPanelListadoFacturas;
import interfaz.operador.quintaPantalla.listadoFacturasSubMenu.vista.PanelListadoFacturas;

public class ControlPanelConsultarHistoricoFacturas implements ActionListener {

    private PanelConsultarHistoricoFacturas vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelConsultarHistoricoFacturas(PanelConsultarHistoricoFacturas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        aplicacion = Aplicacion.init("acceder");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoHistoricoFacturasEnum comando = ComandoHistoricoFacturasEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONSULTAR_HISTORICO_FACTURAS:
                procesarConsulta();
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    private void procesarConsulta() {
        Date fechaDesde = vista.getFechaDesde();
        Date fechaHasta = vista.getFechaHasta();

        if (fechaDesde == null || fechaHasta == null) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar ambas fechas.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (fechaDesde.after(fechaHasta)) {
            JOptionPane.showMessageDialog(vista, "La fecha 'Desde' no puede ser posterior a la fecha 'Hasta'.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        LocalDate desde = fechaDesde.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
        LocalDate hasta = fechaHasta.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();

        
        OperadorAerolinea operador = (OperadorAerolinea) aplicacion.getUsuarioLogueado();
        if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
            JOptionPane.showMessageDialog(vista, "No se ha encontrado un operador de aerolínea.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Aerolinea aerolinea = aplicacion.getAerolinea(operador.getAerolinea().getNombre());

        List<Factura> facturasEnRango = aerolinea.getFacturas().stream()
                .filter(f -> {
                    LocalDate fecha = f.verFechaEmision();
                    return (fecha.isEqual(desde) || fecha.isAfter(desde)) &&
                           (fecha.isEqual(hasta) || fecha.isBefore(hasta));
                })
                .collect(Collectors.toList());

        if (facturasEnRango.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "No se encontraron facturas en ese rango.", "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        PanelListadoFacturas panelListado = new PanelListadoFacturas();
        new ControlPanelListadoFacturas(panelListado, pantalla, fechaDesde, fechaHasta);
        pantalla.mostrarContenidoEnPanelCentral(panelListado);
    }
}
