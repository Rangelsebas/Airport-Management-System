package interfaz.operador.quintaPantalla.vista;

import javax.swing.*;

import interfaz.componentes.PantallaBase;
import interfaz.operador.quintaPantalla.enums.ComandoFacturaEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class PanelFacturas extends JPanel {

    private PantallaBase pantallaBase;
    private List<JButton> botones;

    public PanelFacturas(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);

        botones = List.of(
            crearBoton("Histórico Facturas", ComandoFacturaEnum.HISTORICO_FACTURAS),
            crearBoton("Pagar Factura", ComandoFacturaEnum.PAGAR_FACTURA)
        );

        botones.forEach(btn -> {
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.setMaximumSize(new Dimension(200, 50));
            btn.setPreferredSize(new Dimension(200, 50));
            add(Box.createVerticalStrut(10));
            add(btn);
        });
    }

    private JButton crearBoton(String texto, ComandoFacturaEnum comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando.name());
        return boton;
    }

    public void setControlador(ActionListener c) {
        for (JButton b : botones) {
            b.addActionListener(c);
        }
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    public void mostrarPanel(JPanel panel) {
        pantallaBase.mostrarContenidoEnPanelCentral(panel);
    }
}
