package interfaz.operador.quintaPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.EstadoPago;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import interfaz.componentes.PantallaBase;
import interfaz.operador.quintaPantalla.enums.ComandoFacturaEnum;
import interfaz.operador.quintaPantalla.historicoFacturas.controlador.ControlPanelConsultarHistoricoFacturas;
import interfaz.operador.quintaPantalla.historicoFacturas.vista.PanelConsultarHistoricoFacturas;
import interfaz.operador.quintaPantalla.pagarFacturas.controlador.ControlPanelPagarFacturas;
import interfaz.operador.quintaPantalla.pagarFacturas.vista.PanelPagarFacturas;
import interfaz.operador.quintaPantalla.vista.PanelFacturas;

public class ControlPanelFacturas implements ActionListener {

    private PanelFacturas vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelFacturas(PanelFacturas vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("acceder");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoFacturaEnum comando = ComandoFacturaEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case HISTORICO_FACTURAS:
                PanelConsultarHistoricoFacturas panelConsultarFacturas = new PanelConsultarHistoricoFacturas();
                new ControlPanelConsultarHistoricoFacturas(panelConsultarFacturas, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelConsultarFacturas);
                break;

            case PAGAR_FACTURA:
                OperadorAerolinea operador = (OperadorAerolinea) aplicacion.getUsuarioLogueado();
                if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
                    JOptionPane.showMessageDialog(vista, "No se ha encontrado un operador de aerolínea.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Aerolinea aerolinea = aplicacion.getAerolinea(operador.getAerolinea().getNombre());
                boolean hayPendientes = aerolinea.getFacturas().stream()
                    .anyMatch(f -> f.getEstadoPago() == EstadoPago.PENDIENTE);

                if (!hayPendientes) {
                    JOptionPane.showMessageDialog(null, "No tienes facturas pendientes por pagar.", "Sin facturas", JOptionPane.INFORMATION_MESSAGE);
                    break;
                }

                PanelPagarFacturas panelPagar = new PanelPagarFacturas();
                new ControlPanelPagarFacturas(panelPagar, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelPagar);
                break;
        }
    }
}
