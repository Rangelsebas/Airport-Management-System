package interfaz.operador.cuartaPantalla.rendimientoVuelo.controlador;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.cuartaPantalla.rendimientoVuelo.vista.PanelResumenRendimientoVuelos;
import java.util.List;

public class ControlPanelResumenRendimientoVuelos {

    private final PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelResumenRendimientoVuelos(PantallaBase pantalla, List<Vuelo> todos) {
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("acceder");

        String resumen = generarResumen(todos);

        PanelResumenRendimientoVuelos panel = new PanelResumenRendimientoVuelos();
        panel.setPantallaBase(pantalla);          // Asignamos pantalla
        panel.setContenido(resumen);              // Asignamos resumen generado
        pantalla.mostrarContenidoEnPanelCentral(panel); // Mostramos
    }

    private String generarResumen(List<Vuelo> todos) {
        int total = todos.size();

        int finalizados = contarPorEstado(todos, EstadosVuelo.FINALIZADO);
        int cancelados = contarPorEstado(todos, EstadosVuelo.CANCELADO);
        int pendientes = contarPorEstado(todos, EstadosVuelo.PENDIENTE);
        int enCurso = (int) todos.stream().filter(this::esEnCurso).count();

        return """
            📊 Resumen de Rendimiento de Vuelos

            ✈️ Total de vuelos registrados: %d
            ✅ Finalizados: %d (%d%%)
            ❌ Cancelados: %d (%d%%)
            🔄 En curso: %d (%d%%)
            🕓 Pendientes: %d (%d%%)
            """.formatted(
                total,
                finalizados, porc(finalizados, total),
                cancelados, porc(cancelados, total),
                enCurso, porc(enCurso, total),
                pendientes, porc(pendientes, total)
            );
    }

    private int contarPorEstado(List<Vuelo> vuelos, EstadosVuelo estado) {
        return (int) vuelos.stream().filter(v -> v.getEstado() == estado).count();
    }

    private boolean esEnCurso(Vuelo v) {
        return switch (v.getEstado()) {
            case ESPERANDO_PISTA_ATERRIZAJE,
                ESPERANDO_ATERRIZAR,
                ATERRIZADO,
                DESEMBARCANDO,
                DESCARGANDO,
                EN_HANGAR,
                EN_APARCAMIENTO,
                OPERATIVO,
                EN_PREPARACION,
                EMBARCANDO,
                CARGANDO,
                ESPERANDO_PISTA_DESPEGUE,
                ESPERANDO_DESPEGUE,
                VOLANDO -> true;
            default -> false;
        };
    }

    private int porc(int cantidad, int total) {
        return (total == 0) ? 0 : (int) Math.round((cantidad * 100.0) / (double) total);
    }
}
