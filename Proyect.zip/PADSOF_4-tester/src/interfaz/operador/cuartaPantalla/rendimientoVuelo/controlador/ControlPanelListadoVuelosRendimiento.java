package interfaz.operador.cuartaPantalla.rendimientoVuelo.controlador;

import javax.swing.*;

import funcionalidad.vuelo.Vuelo;
import interfaz.operador.cuartaPantalla.detallesVuelosSubMenu.controlador.ControlPanelDetallesVueloRendimiento;
import interfaz.operador.cuartaPantalla.detallesVuelosSubMenu.vista.PanelDetallesVueloRendimiento;
import interfaz.operador.cuartaPantalla.rendimientoVuelo.vista.PanelListadoVuelosRendimiento;
import interfaz.componentes.PantallaBase;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ControlPanelListadoVuelosRendimiento {

    private PanelListadoVuelosRendimiento vista;
    private Map<JButton, Vuelo> vuelosMap;

    private PantallaBase pantalla;

    public ControlPanelListadoVuelosRendimiento(PanelListadoVuelosRendimiento vista, PantallaBase pantalla, List<Vuelo> vuelos) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vuelosMap = new HashMap<>();

        for (Vuelo v : vuelos) {
            agregarVuelo(v);
        }
    }

    public void agregarVuelo(Vuelo vuelo) {
        String info = "Código: " + vuelo.getCodigoVuelo() + " - " + vuelo.getOrigen().getNombre()
                    + " → " + vuelo.getDestino().getNombre() + " - " + vuelo.getFecha();
    
        JButton botonVuelo = new JButton(info);
        botonVuelo.setAlignmentX(JButton.CENTER_ALIGNMENT);
        botonVuelo.setMaximumSize(new java.awt.Dimension(500, 40));
        botonVuelo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vueloSeleccionado(vuelo);
            }
        });
    
        vuelosMap.put(botonVuelo, vuelo);
        vista.agregarBotonVuelo(botonVuelo);
    }

    private void vueloSeleccionado(Vuelo vuelo) {
        PanelDetallesVueloRendimiento panelDetalles = new PanelDetallesVueloRendimiento();
        new ControlPanelDetallesVueloRendimiento(panelDetalles, vuelo);     
    
        panelDetalles.setCodigoVuelo(vuelo.getCodigoVuelo());
        panelDetalles.setOrigen(vuelo.getOrigen().getNombre());
        panelDetalles.setDestino(vuelo.getDestino().getNombre());
        panelDetalles.setFecha(vuelo.getFecha().toString());
        panelDetalles.setHoraSalida(vuelo.getHoraSalida().toString());
        panelDetalles.setHoraLlegada(vuelo.getHoraLlegada().toString());
        panelDetalles.setAvion(vuelo.getAvion().getTipoAvion().getMarca() + " " + vuelo.getAvion().getTipoAvion().getModelo()
                + " - Matrícula " + vuelo.getAvion().getMatricula());
        panelDetalles.setCapacidadPasajeros(vuelo.getAvion().getTipoAvion().getCapacidad()); // Ajusta si es carga
        panelDetalles.setPuntualidad(vuelo.getEnTiempo() ? "En hora" : "Con retraso");
    
        pantalla.mostrarContenidoEnPanelCentral(panelDetalles);
    }
}
