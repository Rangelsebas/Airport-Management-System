package interfaz.operador.cuartaPantalla.detallesVuelosSubMenu.controlador;

import funcionalidad.vuelo.Vuelo;
import interfaz.operador.cuartaPantalla.detallesVuelosSubMenu.vista.PanelDetallesVueloRendimiento;

public class ControlPanelDetallesVueloRendimiento {
    private PanelDetallesVueloRendimiento vista;
    private Vuelo vuelo;

    public ControlPanelDetallesVueloRendimiento(PanelDetallesVueloRendimiento vista, Vuelo vuelo) {
        this.vista = vista;
        this.vuelo = vuelo;

        cargarInformacion();
    }

    private void cargarInformacion() {
        vista.setCodigoVuelo(vuelo.getCodigoVuelo());
        vista.setOrigen(vuelo.getOrigen().getNombre());
        vista.setDestino(vuelo.getDestino().getNombre());
        vista.setFecha(vuelo.getFecha().toString());
        vista.setHoraSalida(vuelo.getHoraSalida().toString());
        vista.setHoraLlegada(vuelo.getHoraLlegada().toString());

        String avionTexto = vuelo.getAvion().getTipoAvion().getMarca() + " " +
                            vuelo.getAvion().getTipoAvion().getModelo() + " - Matrícula " +
                            vuelo.getAvion().getMatricula();
        vista.setAvion(avionTexto);

        int capacidad = vuelo.getAvion().getTipoAvion().getCapacidad();
        switch (vuelo.getAvion().getCategoria()) {
            case PASAJEROS -> vista.setCapacidadPasajeros(capacidad);
            case MERCANCIAS -> vista.setCapacidadCarga(capacidad);
        }

        vista.setPuntualidad(vuelo.getEnTiempo() ? "En hora" : "Con retraso");
    }
}
