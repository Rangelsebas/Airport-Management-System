package interfaz.operador.cuartaPantalla.detallesVuelosSubMenu.controlador;

import javax.swing.*;

import interfaz.operador.cuartaPantalla.detallesVuelosSubMenu.vista.PanelDetallesVueloRendimiento;
import interfaz.operador.cuartaPantalla.rendimientoVuelo.vista.PanelListadoVuelosRendimiento;
import interfaz.componentes.PantallaBase;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class ControlPanelListadoVuelosRendimiento {

    private PanelListadoVuelosRendimiento vista;
    private PantallaBase pantalla;
    private Map<JButton, String> vuelosMap;
    /* FLUJO CON LOGICA DE NEGOCIO */
    // Map<JButton, Vuelo> vuelosMap;

    public ControlPanelListadoVuelosRendimiento(PanelListadoVuelosRendimiento vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vuelosMap = new HashMap<>();
    }

    public void agregarVuelo(String infoVuelo) {
        JButton botonVuelo = new JButton(infoVuelo);
        botonVuelo.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonVuelo.setMaximumSize(new java.awt.Dimension(500, 40));

        botonVuelo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vueloSeleccionado(infoVuelo);
            }
        });

        vuelosMap.put(botonVuelo, infoVuelo);
        // vuelosMap.put(botonVuelo, vuelo); // vuelo es un objeto Vuelo
        vista.agregarBotonVuelo(botonVuelo);
    }

    private void vueloSeleccionado(String infoVuelo) {
        System.out.println("✈️ Vuelo seleccionado: " + infoVuelo);

        // Crear panel de detalles
        PanelDetallesVueloRendimiento panelDetalles = new PanelDetallesVueloRendimiento();

        // Simular carga de datos de ejemplo
        panelDetalles.setCodigoVuelo("VH001");
        panelDetalles.setOrigen("Madrid");
        panelDetalles.setDestino("París");
        panelDetalles.setFecha("02/12/2025");
        panelDetalles.setHoraSalida("10:30");
        panelDetalles.setHoraLlegada("12:45");
        panelDetalles.setAvion("Airbus A320 - Matrícula N12345");
        panelDetalles.setCapacidadPasajeros(180); 
        panelDetalles.setPuntualidad("En hora");

        // Mostrar detalles en pantalla principal
        pantalla.mostrarContenidoEnPanelCentral(panelDetalles);

        //TODO: Con la logica de negocio, quedaria algo como:
        // Vuelo vuelo = vuelosMap.get(boton); // ahora obtenemos el Vuelo real

        // if (vuelo == null) {
        //     System.err.println("Error: Vuelo no encontrado.");
        //     return;
        // }

        // // Crear panel de detalles
        // PanelDetallesVueloRendimiento panelDetalles = new PanelDetallesVueloRendimiento();

        // // Cargar datos REALES del vuelo
        // panelDetalles.setCodigoVuelo(vuelo.getCodigoVuelo());
        // panelDetalles.setOrigen(vuelo.getOrigen());
        // panelDetalles.setDestino(vuelo.getDestino());
        // panelDetalles.setFecha(vuelo.getFecha().toString()); // LocalDate → String
        // panelDetalles.setHoraSalida(vuelo.getHoraSalida().toString());
        // panelDetalles.setHoraLlegada(vuelo.getHoraLlegada().toString());

        // panelDetalles.setAvion(
        //     vuelo.getAvion().getMarca() + " " + vuelo.getAvion().getModelo() +
        //     " - Matrícula " + vuelo.getAvion().getMatricula()
        // );

        // if (vuelo.getAvion().getCategoria().toString().equals("PASAJEROS")) {
        //     panelDetalles.setCapacidad(vuelo.getAvion().getTipoAvion().getCapacidad() + " pasajeros");
        // } else {
        //     panelDetalles.setCapacidad(vuelo.getAvion().getTipoAvion().getCapacidad() + " kg carga");
        // }

        // panelDetalles.setPuntualidad(vuelo.getEnTiempo() ? "En hora" : "Con retraso");

        // // Mostrar en pantalla principal
        // pantalla.mostrarContenidoEnPanelCentral(panelDetalles);
    }
}
