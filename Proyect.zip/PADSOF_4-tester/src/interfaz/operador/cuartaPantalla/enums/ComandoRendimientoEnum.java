package interfaz.operador.cuartaPantalla.enums;

public enum ComandoRendimientoEnum {
    CONSULTAR_RENDIMIENTO_VUELOS,
    VER_RESUMEN_RENDIMIENTO
}
