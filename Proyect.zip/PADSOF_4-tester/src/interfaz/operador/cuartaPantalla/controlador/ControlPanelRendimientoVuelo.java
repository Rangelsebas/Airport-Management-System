package interfaz.operador.cuartaPantalla.controlador;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;
import interfaz.operador.cuartaPantalla.enums.ComandoRendimientoEnum;
import interfaz.operador.cuartaPantalla.rendimientoVuelo.controlador.ControlPanelListadoVuelosRendimiento;
import interfaz.operador.cuartaPantalla.rendimientoVuelo.controlador.ControlPanelResumenRendimientoVuelos;
import interfaz.operador.cuartaPantalla.rendimientoVuelo.vista.PanelListadoVuelosRendimiento;
import interfaz.operador.cuartaPantalla.rendimientoVuelo.vista.PanelResumenRendimientoVuelos;
import interfaz.operador.cuartaPantalla.vista.PanelRendimientoVuelo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class ControlPanelRendimientoVuelo implements ActionListener {

    private final PanelRendimientoVuelo vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelRendimientoVuelo(PanelRendimientoVuelo vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("acceder");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoRendimientoEnum comando = ComandoRendimientoEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONSULTAR_RENDIMIENTO_VUELOS:
                procesarConsulta();
                break;
            case VER_RESUMEN_RENDIMIENTO:
                // Obtener vuelos reales
                List<Vuelo> todos = new ArrayList<>();
                todos.addAll(aplicacion.vuelosHistoricos());
                todos.addAll(aplicacion.vuelosSalidas());
                todos.addAll(aplicacion.vuelosLlegadas());

                if (todos.isEmpty()) {
                    JOptionPane.showMessageDialog(vista, "No se encontraron vuelos.", "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                PanelResumenRendimientoVuelos panelResumen = new PanelResumenRendimientoVuelos();
                new ControlPanelResumenRendimientoVuelos(pantalla, todos);
                pantalla.mostrarContenidoEnPanelCentral(panelResumen);
                break;
            default:
                JOptionPane.showMessageDialog(vista, "Comando no reconocido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void procesarConsulta() {
        Date fechaDesde = vista.getFechaDesde();
        Date fechaHasta = vista.getFechaHasta();

        if (fechaDesde == null || fechaHasta == null) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar ambas fechas.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (fechaDesde.after(fechaHasta)) {
            JOptionPane.showMessageDialog(vista, "La fecha 'Desde' no puede ser posterior a la fecha 'Hasta'.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Conversión a LocalDate
        LocalDate desde = fechaDesde.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate hasta = fechaHasta.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        // Obtener vuelos reales
        List<Vuelo> vuelos = aplicacion.vuelosHistoricos(desde, hasta);

        if (vuelos.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "No se encontraron vuelos entre esas fechas.", "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Mostrar nuevo panel con los vuelos encontrados
        PanelListadoVuelosRendimiento panelListado = new PanelListadoVuelosRendimiento();
        new ControlPanelListadoVuelosRendimiento(panelListado, pantalla, vuelos);
        pantalla.mostrarContenidoEnPanelCentral(panelListado);
    }
}
