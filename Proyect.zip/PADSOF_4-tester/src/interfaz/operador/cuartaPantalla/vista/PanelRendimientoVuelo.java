package interfaz.operador.cuartaPantalla.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfaz.operador.cuartaPantalla.enums.ComandoRendimientoEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Date;

public class PanelRendimientoVuelo extends JPanel {

    private JSpinner spinnerDesde;
    private JSpinner spinnerHasta;
    private JButton botonConsultar;
    private JButton botonResumen;

    public PanelRendimientoVuelo() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 50, 20, 50));

        // Fecha Desde
        add(crearEtiqueta("Desde:"));
        spinnerDesde = new JSpinner(new SpinnerDateModel());
        spinnerDesde.setEditor(new JSpinner.DateEditor(spinnerDesde, "dd/MM/yyyy"));
        spinnerDesde.setMaximumSize(new Dimension(200, 30));
        add(spinnerDesde);

        add(Box.createVerticalStrut(20));

        // Fecha Hasta
        add(crearEtiqueta("Hasta:"));
        spinnerHasta = new JSpinner(new SpinnerDateModel());
        spinnerHasta.setEditor(new JSpinner.DateEditor(spinnerHasta, "dd/MM/yyyy"));
        spinnerHasta.setMaximumSize(new Dimension(200, 30));
        add(spinnerHasta);

        add(Box.createVerticalStrut(30));

        // Botón Consultar
        botonConsultar = new JButton("Consultar");
        botonConsultar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonConsultar.setActionCommand(ComandoRendimientoEnum.CONSULTAR_RENDIMIENTO_VUELOS.name());
        add(botonConsultar);

        add(Box.createVerticalStrut(280));

        // Botón Ver Resumen
        botonResumen = new JButton("Ver resumen");
        botonResumen.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonResumen.setActionCommand(ComandoRendimientoEnum.VER_RESUMEN_RENDIMIENTO.name());
        add(botonResumen);
    }

    // =============================
    // MÉTODOS VISTA MVC
    // =============================

    public void setControlador(ActionListener c) {
        botonConsultar.addActionListener(c);
        botonResumen.addActionListener(c);
    }

    public Date getFechaDesde() {
        return (Date) spinnerDesde.getValue();
    }

    public Date getFechaHasta() {
        return (Date) spinnerHasta.getValue();
    }

    // =============================
    // HELPERS
    // =============================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }
}
