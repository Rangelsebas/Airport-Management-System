package interfaz.operador.terceraPantalla.historico.controlador;


import java.util.ArrayList;
import java.util.List;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.operador.terceraPantalla.historico.vista.PanelVuelosHistorico;

public class ControlPanelVuelosHistorico {

    private PanelVuelosHistorico vista;
    private Aplicacion aplicacion;

    public ControlPanelVuelosHistorico(PanelVuelosHistorico vista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");

        cargarHistorico();
    }

    private void cargarHistorico() {
        List<Vuelo> todos = new ArrayList<>();

        todos.addAll(aplicacion.vuelosSalidas());
        todos.addAll(aplicacion.vuelosLlegadas());
        todos.addAll(aplicacion.vuelosHistoricos());

        vista.mostrarVuelos(todos);
    }
}