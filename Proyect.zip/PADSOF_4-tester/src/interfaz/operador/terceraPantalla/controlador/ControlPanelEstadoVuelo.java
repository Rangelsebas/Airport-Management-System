package interfaz.operador.terceraPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import interfaz.componentes.PantallaBase;
import interfaz.operador.terceraPantalla.enums.ComandoEstadoVueloEnum;
import interfaz.operador.terceraPantalla.historico.controlador.ControlPanelVuelosHistorico;
import interfaz.operador.terceraPantalla.historico.vista.PanelVuelosHistorico;
import interfaz.operador.terceraPantalla.verDatosVuelo.controlador.ControlPanelVerDatosVuelo;
import interfaz.operador.terceraPantalla.verDatosVuelo.vista.PanelVerDatosVuelo;
import interfaz.operador.terceraPantalla.verVuelosEnCurso.controlador.ControlPanelVuelosEnCurso;
import interfaz.operador.terceraPantalla.verVuelosEnCurso.vista.PanelVuelosEnCurso;
import interfaz.operador.terceraPantalla.verVuelosPendientes.controlador.ControlPanelVuelosPendientes;
import interfaz.operador.terceraPantalla.verVuelosPendientes.vista.PanelVuelosPendientes;
import interfaz.operador.terceraPantalla.vista.PanelControlarEstadoVuelo;

import javax.swing.JOptionPane;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;

public class ControlPanelEstadoVuelo implements ActionListener {

    private PanelControlarEstadoVuelo vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelEstadoVuelo(PanelControlarEstadoVuelo vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.aplicacion = Aplicacion.init("acceder");
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoEstadoVueloEnum comando = ComandoEstadoVueloEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case BUSCAR_VUELO:
                String codigo = vista.getCodigoVuelo();

                if (codigo == null || codigo.isBlank()) {
                    JOptionPane.showMessageDialog(null, "Ingresa un código de vuelo para buscar.", "Campo vacío", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Vuelo vuelo = aplicacion.buscarVueloxCodigo(codigo);

                if (vuelo == null) {
                    JOptionPane.showMessageDialog(null, "No se encontró ningún vuelo con ese código.", "No encontrado", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                EstadosVuelo estado = vuelo.getEstado();

                switch (estado) {
                    /* DESEMBARQUES */
                    case DESEMBARCANDO:
                        break;
                    case DESCARGANDO:
                        break;
                    case EN_APARCAMIENTO:
                        break;
                    /* EMBARQUES */
                    case EN_PREPARACION:
                        break;
                    case EMBARCANDO:
                        break;
                    case CARGANDO:
                        break;
                
                    default:
                        PanelVerDatosVuelo panelVerDatosVuelo = new PanelVerDatosVuelo();
                        new ControlPanelVerDatosVuelo(panelVerDatosVuelo, vuelo);
                        pantalla.mostrarContenidoEnPanelCentral(panelVerDatosVuelo);
                        break;
                }

                
                break;

            case VUELOS_EN_CURSO:
                PanelVuelosEnCurso panelVuelos = new PanelVuelosEnCurso(pantalla);
                new ControlPanelVuelosEnCurso(panelVuelos);
                pantalla.mostrarContenidoEnPanelCentral(panelVuelos);
                break;

            case VUELOS_PENDIENTES:
                PanelVuelosPendientes panelPendientes = new PanelVuelosPendientes(pantalla);
                new ControlPanelVuelosPendientes(panelPendientes);
                pantalla.mostrarContenidoEnPanelCentral(panelPendientes);
                break;

            case VUELOS_HISTORICO:
                PanelVuelosHistorico panelHistorico = new PanelVuelosHistorico(pantalla);
                new ControlPanelVuelosHistorico(panelHistorico);
                pantalla.mostrarContenidoEnPanelCentral(panelHistorico);
                break;
        }
    }
}
