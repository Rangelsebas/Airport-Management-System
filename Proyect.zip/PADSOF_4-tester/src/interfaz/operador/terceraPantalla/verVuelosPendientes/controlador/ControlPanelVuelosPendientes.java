package interfaz.operador.terceraPantalla.verVuelosPendientes.controlador;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;
import interfaz.operador.terceraPantalla.verVuelosPendientes.vista.PanelVuelosPendientes;

public class ControlPanelVuelosPendientes {

    private PanelVuelosPendientes vista;
    private Aplicacion aplicacion;

    public ControlPanelVuelosPendientes(PanelVuelosPendientes vista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");

        cargarVuelosPendientes();
    }

    private void cargarVuelosPendientes() {
        List<Vuelo> pendientes = new ArrayList<>();

        pendientes.addAll(
            aplicacion.getVuelosEstadoPendiente().stream()
                .filter(v -> v.getEstado() == EstadosVuelo.PENDIENTE)
                .collect(Collectors.toList())
        );

        pendientes.addAll(
            aplicacion.vuelosLlegadas().stream()
                .filter(v -> v.getEstado() == EstadosVuelo.APROBADO)
                .collect(Collectors.toList())
        );

        pendientes.addAll(
            aplicacion.vuelosHistoricos().stream()
                .filter(v -> v.getEstado() == EstadosVuelo.APROBADO)
                .collect(Collectors.toList())
        );

        vista.mostrarVuelos(pendientes);
    }
}
