package interfaz.operador.terceraPantalla.verVuelosEnCurso.vista;

import java.awt.*;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import java.util.List;
import funcionalidad.vuelo.Vuelo;
import interfaz.componentes.PantallaBase;

public class PanelVuelosEnCurso extends JPanel {

    private PantallaBase pantallaBase;
    private JTextArea areaVuelos;

    public PanelVuelosEnCurso(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel titulo = new JLabel("Vuelos en Curso");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        add(titulo, BorderLayout.NORTH);

        areaVuelos = new JTextArea();
        areaVuelos.setEditable(false);
        areaVuelos.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaVuelos.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(areaVuelos);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scroll.setPreferredSize(new Dimension(900, 500)); 
        add(scroll, BorderLayout.CENTER);
    }

    public void mostrarVuelos(List<Vuelo> vuelos) {
        if (vuelos == null || vuelos.isEmpty()) {
            areaVuelos.setText("No hay vuelos en curso.");
            return;
        }
    
        StringBuilder texto = new StringBuilder();
    
        for (Vuelo v : vuelos) {
            texto.append("Código: ").append(v.getCodigoVuelo())
                .append(" | Estado: ").append(v.getEstado().name())
                .append(" | Origen: ").append(v.getOrigen().getNombre())
                .append(" | Destino: ").append(v.getDestino().getNombre())
                .append(" | Aerolíneas: ")
                .append(v.getAerolineas().stream()
                        .map(a -> a.getNombre())
                        .reduce((a1, a2) -> a1 + ", " + a2).orElse("Ninguna"))
                .append("\n\n");
        }
    
        areaVuelos.setText(texto.toString());
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }
}