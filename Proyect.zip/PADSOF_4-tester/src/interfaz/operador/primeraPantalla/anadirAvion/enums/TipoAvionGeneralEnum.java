package interfaz.operador.primeraPantalla.anadirAvion.enums;

public enum TipoAvionGeneralEnum {
    AVION_PASAJEROS("Avión de Pasajeros"),
    AVION_MERCANCIAS("Avión de Mercancías");

    private final String descripcion;

    TipoAvionGeneralEnum(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }

    public static TipoAvionGeneralEnum fromString(String text) {
        for (TipoAvionGeneralEnum tipo : TipoAvionGeneralEnum.values()) {
            if (tipo.descripcion.equalsIgnoreCase(text)) {
                return tipo;
            }
        }
        throw new IllegalArgumentException("Tipo de avión no reconocido: " + text);
    }
}