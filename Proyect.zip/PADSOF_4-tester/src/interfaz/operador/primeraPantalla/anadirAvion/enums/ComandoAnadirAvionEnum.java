package interfaz.operador.primeraPantalla.anadirAvion.enums;


public enum ComandoAnadirAvionEnum {
    AÑADIR_AVION_CONFIRMADO
}
