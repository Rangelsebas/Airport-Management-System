package interfaz.operador.primeraPantalla.anadirAvion.controlador;

import interfaz.componentes.PantallaBase;
import interfaz.operador.primeraPantalla.anadirAvion.enums.ComandoAnadirAvionEnum;
import interfaz.operador.primeraPantalla.anadirAvion.vista.PanelAnadirAvion;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.TipoAvion;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;

public class ControlPanelAnadirAvion implements ActionListener {

    private PanelAnadirAvion vista;
    private PantallaBase pantalla;
    private Aplicacion app;

    public ControlPanelAnadirAvion(PanelAnadirAvion vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);

        this.app = Aplicacion.init("acceder");

        // Cargar tipos registrados en el combo
        List<TipoAvion> tiposRegistrados = app.listarTiposDeAviones();
        vista.cargarTiposDeAvion(tiposRegistrados);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoAnadirAvionEnum comando = ComandoAnadirAvionEnum.valueOf(e.getActionCommand());

        if (comando == ComandoAnadirAvionEnum.AÑADIR_AVION_CONFIRMADO) {
            try {
                TipoAvion tipoSeleccionado = vista.getTipoSeleccionado();

                if (tipoSeleccionado == null) {
                    JOptionPane.showMessageDialog(null, "Debes seleccionar un Tipo de Avión.", "Falta selección", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                LocalDate fechaCompra = vista.getFechaCompra().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                LocalDate fechaRevision = vista.getFechaUltimaRevision().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

                if (fechaCompra.isAfter(LocalDate.now())) {
                    JOptionPane.showMessageDialog(null, "La fecha de compra no puede ser futura.", "Fecha inválida", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                if (fechaRevision.isBefore(fechaCompra)) {
                    JOptionPane.showMessageDialog(null, "La fecha de revisión no puede ser anterior a la de compra.", "Fecha inválida", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                OperadorAerolinea operador = (OperadorAerolinea)app.getUsuarioLogueado();
                if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
                    JOptionPane.showMessageDialog(vista, "Debe haber un operador logueado para usar esta funcionalidad.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Aerolinea aerolinea = app.getAerolinea(operador.getAerolinea().getNombre());
                if (aerolinea == null) {
                    JOptionPane.showMessageDialog(null, "No tienes ninguna aerolínea asignada.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                boolean exito = aerolinea.anadirAvion(
                        tipoSeleccionado.getCategoria(),
                        tipoSeleccionado,
                        fechaCompra,
                        fechaRevision
                );

                if (exito) {
                    JOptionPane.showMessageDialog(null, "Avión añadido con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    vista.update();
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo añadir el avión.", "Error", JOptionPane.WARNING_MESSAGE);
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error inesperado. Revisa los datos e inténtalo de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
