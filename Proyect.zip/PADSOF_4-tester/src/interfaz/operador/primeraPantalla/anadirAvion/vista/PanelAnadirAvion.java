package interfaz.operador.primeraPantalla.anadirAvion.vista;

import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aerolinea.TipoAvion;
import interfaz.operador.primeraPantalla.anadirAvion.enums.ComandoAnadirAvionEnum;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;

public class PanelAnadirAvion extends JPanel {

    private JComboBox<TipoAvion> comboTipos;
    private JSpinner spinnerFechaCompra;
    private JSpinner spinnerFechaRevision;
    private JButton botonAceptar;

    public PanelAnadirAvion() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        // Título
        add(crearEtiqueta("Selecciona un Tipo de Avión:"));

        // Combo tipos de avión
        comboTipos = new JComboBox<>();
        comboTipos.setMaximumSize(new Dimension(300, 30));

        /* RENDER: ListCellRender */
        comboTipos.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                        boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if (value instanceof TipoAvion tipo) {
                    String resumen = tipo.getMarca() + " " + tipo.getModelo() + " | " +
                                    tipo.getCapacidad() + (tipo.getCategoria() == CategoriaAvion.PASAJEROS ? " pax" : " kg") +
                                    " | ID: " + tipo.getId();

                    setText(resumen);
                }

                return this;
            }
        });
        
        add(comboTipos);

        // Fecha compra
        add(Box.createVerticalStrut(15));
        add(crearEtiqueta("Fecha de compra:"));
        spinnerFechaCompra = new JSpinner(new SpinnerDateModel());
        spinnerFechaCompra.setEditor(new JSpinner.DateEditor(spinnerFechaCompra, "dd/MM/yyyy"));
        spinnerFechaCompra.setMaximumSize(new Dimension(200, 30));
        add(spinnerFechaCompra);

        // Fecha revisión
        add(Box.createVerticalStrut(10));
        add(crearEtiqueta("Fecha de última revisión:"));
        spinnerFechaRevision = new JSpinner(new SpinnerDateModel());
        spinnerFechaRevision.setEditor(new JSpinner.DateEditor(spinnerFechaRevision, "dd/MM/yyyy"));
        spinnerFechaRevision.setMaximumSize(new Dimension(200, 30));
        add(spinnerFechaRevision);

        // Botón
        add(Box.createVerticalStrut(20));
        botonAceptar = new JButton("Añadir avión");
        botonAceptar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonAceptar.setActionCommand(ComandoAnadirAvionEnum.AÑADIR_AVION_CONFIRMADO.name());
        add(botonAceptar);
    }

    // ===== MVC =====

    public void setControlador(ActionListener c) {
        botonAceptar.addActionListener(c);
    }

    // ===== GETTERS =====

    public TipoAvion getTipoSeleccionado() {
        return (TipoAvion) comboTipos.getSelectedItem();
    }

    public Date getFechaCompra() {
        return (Date) spinnerFechaCompra.getValue();
    }

    public Date getFechaUltimaRevision() {
        return (Date) spinnerFechaRevision.getValue();
    }


    public void cargarTiposDeAvion(List<TipoAvion> lista) {
        comboTipos.removeAllItems();
        for (TipoAvion tipo : lista) {
            comboTipos.addItem(tipo);
        }
    }

    public void update() {
        comboTipos.setSelectedIndex(-1);
        spinnerFechaCompra.setValue(new Date());
        spinnerFechaRevision.setValue(new Date());
    }

    // ===== HELPERS =====

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }
}
