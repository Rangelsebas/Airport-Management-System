package interfaz.operador.primeraPantalla.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import interfaz.componentes.PantallaBase;
import interfaz.operador.primeraPantalla.anadirAvion.controlador.ControlPanelAnadirAvion;
import interfaz.operador.primeraPantalla.anadirAvion.vista.PanelAnadirAvion;
import interfaz.operador.primeraPantalla.enums.ComandoFlotaEnum;
import interfaz.operador.primeraPantalla.vista.PanelGestionarFlota;
import interfaz.operador.primeraPantalla.editarAvion.controlador.ControlPanelEditarAvion;
import interfaz.operador.primeraPantalla.editarAvion.vista.PanelEditarAvion;
import interfaz.operador.primeraPantalla.verFlota.controlador.ControlPanelVerFlota;
import interfaz.operador.primeraPantalla.verFlota.vista.PanelVerFlota;

public class ControlPanelGestionarFlota implements ActionListener {

    private PanelGestionarFlota vista;
    private PantallaBase pantalla;
    private Aplicacion aplicacion;
    private Aerolinea aerolinea;

    public ControlPanelGestionarFlota(PanelGestionarFlota vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this); 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoFlotaEnum comando = ComandoFlotaEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case VER_FLOTA:
                PanelVerFlota panel = new PanelVerFlota();
                new ControlPanelVerFlota(panel, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panel);
                break;
            case EDITAR_AVION:
                aplicacion = Aplicacion.init("acceder");

                OperadorAerolinea operador = (OperadorAerolinea) aplicacion.getUsuarioLogueado();
                if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
                    JOptionPane.showMessageDialog(vista, "Debe haber un operador logueado para usar esta funcionalidad.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Aerolinea aerolinea = aplicacion.getAerolinea(operador.getAerolinea().getNombre());
                if (aerolinea == null) {
                    JOptionPane.showMessageDialog(null, "No tienes ninguna aerolínea asignada. Debes crear una primero.", "Error", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                if (aerolinea.getAviones().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No tienes aviones registrados para editar.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                PanelEditarAvion panelEditar = new PanelEditarAvion();
                new ControlPanelEditarAvion(panelEditar, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelEditar);
                break;
            case AÑADIR_AVION:
                PanelAnadirAvion panelAñadir = new PanelAnadirAvion();
                new ControlPanelAnadirAvion(panelAñadir, pantalla);
                pantalla.mostrarContenidoEnPanelCentral(panelAñadir);
                break;
        }
    }
    
}
