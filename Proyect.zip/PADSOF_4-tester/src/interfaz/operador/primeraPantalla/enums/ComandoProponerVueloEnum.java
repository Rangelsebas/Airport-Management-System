package interfaz.operador.primeraPantalla.enums;

public enum ComandoProponerVueloEnum {
    PROPONER_VUELO,
    PROPONER_VUELO_RECURRENTE,
    SOLICITAR_COMPARTIR,
    VER_SOLICITUDES
}
