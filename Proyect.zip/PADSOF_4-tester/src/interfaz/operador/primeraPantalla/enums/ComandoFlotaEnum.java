package interfaz.operador.primeraPantalla.enums;

public enum ComandoFlotaEnum {
    VER_FLOTA, EDITAR_AVION, AÑADIR_AVION
}

