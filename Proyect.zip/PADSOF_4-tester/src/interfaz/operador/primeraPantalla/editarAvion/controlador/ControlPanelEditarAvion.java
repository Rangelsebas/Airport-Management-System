package interfaz.operador.primeraPantalla.editarAvion.controlador;

import interfaz.componentes.PantallaBase;
import interfaz.operador.primeraPantalla.editarAvion.enums.ComandoEditarAvionEnum;
import interfaz.operador.primeraPantalla.editarAvion.vista.PanelEditarAvion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;

public class ControlPanelEditarAvion implements ActionListener {

    private final PanelEditarAvion vista;
    private final PantallaBase pantalla;
    private Vuelo vueloSeleccionado;
    private Aplicacion app;
    private Aerolinea aerolinea;

    public ControlPanelEditarAvion(PanelEditarAvion vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;
        this.vista.setControlador(this);

        this.app = Aplicacion.init("acceder");

        // Validar operador logueado
        OperadorAerolinea operador = (OperadorAerolinea) app.getUsuarioLogueado();
        if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
            JOptionPane.showMessageDialog(vista, "Debe haber un operador de aerolínea logueado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        this.aerolinea = app.getAerolinea(operador.getAerolinea().getNombre());

        if (aerolinea == null || aerolinea.getAviones().isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tienes aviones registrados aún.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<String> matriculas = aerolinea.getAviones().stream()
                .map(Avion::getMatricula)
                .collect(Collectors.toList());

        vista.cargarAviones(matriculas);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoEditarAvionEnum comando = ComandoEditarAvionEnum.valueOf(e.getActionCommand());

        if (comando == ComandoEditarAvionEnum.GUARDAR_CAMBIOS_AVION) {
            String matricula = vista.getMatriculaSeleccionada();
            Date fechaNueva = vista.getFechaSeleccionada();

            if (matricula == null || matricula.isBlank()) {
                JOptionPane.showMessageDialog(vista, "Selecciona un avión.", "Dato requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (fechaNueva == null) {
                JOptionPane.showMessageDialog(vista, "Selecciona una fecha válida.", "Dato requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Avion avion = aerolinea.getAvion(matricula);
            if (avion == null) {
                JOptionPane.showMessageDialog(vista, "No se encontró el avión seleccionado.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            LocalDate nuevaFecha = fechaNueva.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
            avion.setFechaUltimaRevision(nuevaFecha);

            JOptionPane.showMessageDialog(vista, "Fecha de revisión actualizada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            vista.reset();
        }
    }
}
