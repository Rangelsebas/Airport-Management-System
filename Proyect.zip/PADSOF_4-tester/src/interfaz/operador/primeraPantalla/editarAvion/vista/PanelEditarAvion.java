package interfaz.operador.primeraPantalla.editarAvion.vista;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import interfaz.operador.primeraPantalla.editarAvion.enums.ComandoEditarAvionEnum;

public class PanelEditarAvion extends JPanel {

    private JComboBox<String> comboAviones;
    private JSpinner spinnerFechaRevision;
    private JButton botonGuardar;

    public PanelEditarAvion() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        // --- Selección de avión ---
        add(crearEtiqueta("Selecciona un avión:"));
        comboAviones = new JComboBox<>();
        comboAviones.setMaximumSize(new Dimension(300, 30));
        add(comboAviones);

        add(Box.createVerticalStrut(20));

        // --- Fecha nueva revisión ---
        add(crearEtiqueta("Nueva fecha de última revisión:"));
        spinnerFechaRevision = new JSpinner(new SpinnerDateModel());
        spinnerFechaRevision.setEditor(new JSpinner.DateEditor(spinnerFechaRevision, "dd/MM/yyyy"));
        spinnerFechaRevision.setMaximumSize(new Dimension(200, 30));
        add(spinnerFechaRevision);

        add(Box.createVerticalStrut(20));

        // --- Botón guardar ---
        botonGuardar = new JButton("Guardar cambios");
        botonGuardar.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonGuardar.setActionCommand(ComandoEditarAvionEnum.GUARDAR_CAMBIOS_AVION.name());
        add(botonGuardar);
    }

    public void setControlador(ActionListener c) {
        botonGuardar.addActionListener(c);
    }

    public void cargarAviones(List<String> matriculas) {
        comboAviones.removeAllItems();
        for (String m : matriculas) {
            comboAviones.addItem(m);
        }
    }

    public String getMatriculaSeleccionada() {
        return (String) comboAviones.getSelectedItem();
    }

    public java.util.Date getFechaSeleccionada() {
        return (java.util.Date) spinnerFechaRevision.getValue();
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    public void reset() {
        comboAviones.setSelectedIndex(-1);
        spinnerFechaRevision.setValue(new java.util.Date());
    }
}
