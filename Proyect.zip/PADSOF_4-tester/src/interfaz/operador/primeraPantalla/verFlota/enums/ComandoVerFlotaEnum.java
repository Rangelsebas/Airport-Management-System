package interfaz.operador.primeraPantalla.verFlota.enums;

public enum ComandoVerFlotaEnum {
    REFRESCAR_TABLA
}
