package interfaz.operador.primeraPantalla.verFlota.vista;

import interfaz.operador.primeraPantalla.verFlota.enums.ComandoVerFlotaEnum;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class PanelVerFlota extends JPanel {

    private JTable tablaAviones;
    private DefaultTableModel modeloTabla;
    private JLabel labelCantidad;
    private JButton botonRefrescar;

    public PanelVerFlota() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        // --- Panel superior con título y botón ---
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(Color.WHITE);

        JLabel titulo = new JLabel("✈️ Lista Completa de Aviones");
        titulo.setFont(new Font("Arial", Font.BOLD, 18));

        botonRefrescar = new JButton("🔄 Refrescar");
        botonRefrescar.setActionCommand(ComandoVerFlotaEnum.REFRESCAR_TABLA.name());

        panelSuperior.add(titulo, BorderLayout.WEST);
        panelSuperior.add(botonRefrescar, BorderLayout.EAST);
        add(panelSuperior, BorderLayout.NORTH);

        // --- Tabla con todas las columnas ---
        String[] columnas = {
            "Matrícula", "Tipo (ID)", "Marca", "Modelo", "Capacidad",
            "Ctrl. Temperatura", "Largo", "Ancho", "Alto", "Categoría",
            "Fecha Compra", "Última Revisión",
            "Mat. Peligroso"
        };

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tabla solo lectura
            }
        };

        tablaAviones = new JTable(modeloTabla);
        tablaAviones.setFillsViewportHeight(true);
        tablaAviones.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tablaAviones.setPreferredScrollableViewportSize(new java.awt.Dimension(900, 400));
        
        JScrollPane scroll = new JScrollPane(tablaAviones,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(scroll, BorderLayout.CENTER);

        // --- Tooltip dinámico para mostrar el contenido completo de cada celda ---
        tablaAviones.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent e) {
                int fila = tablaAviones.rowAtPoint(e.getPoint());
                int columna = tablaAviones.columnAtPoint(e.getPoint());

                if (fila > -1 && columna > -1) {
                    Object valorCelda = tablaAviones.getValueAt(fila, columna);
                    if (valorCelda != null) {
                        tablaAviones.setToolTipText(valorCelda.toString());
                    } else {
                        tablaAviones.setToolTipText(null);
                    }
                }
            }
        });

        // --- Panel inferior con total de aviones ---
        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelInferior.setBackground(Color.WHITE);

        labelCantidad = new JLabel("Total de aviones: 0");
        panelInferior.add(labelCantidad);

        add(panelInferior, BorderLayout.SOUTH);
    }

    // ========== MÉTODOS ==========

    public void setControlador(java.awt.event.ActionListener c) {
        botonRefrescar.addActionListener(c);
    }

    public void actualizarTabla(Object[][] datos) {
        modeloTabla.setRowCount(0); // limpia tabla
        for (Object[] fila : datos) {
            modeloTabla.addRow(fila);
        }
        labelCantidad.setText("Total de aviones: " + datos.length);
    }

    public JTable getTabla() {
        return tablaAviones;
    }

    
    public int getFilaSeleccionada() {
        return tablaAviones.getSelectedRow();
    }
}
