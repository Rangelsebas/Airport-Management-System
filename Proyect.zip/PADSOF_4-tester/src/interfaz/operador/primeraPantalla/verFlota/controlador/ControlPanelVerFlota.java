package interfaz.operador.primeraPantalla.verFlota.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.TipoAvion;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import interfaz.componentes.PantallaBase;
import interfaz.operador.primeraPantalla.verFlota.enums.ComandoVerFlotaEnum;
import interfaz.operador.primeraPantalla.verFlota.vista.PanelVerFlota;

public class ControlPanelVerFlota implements ActionListener {
    private PanelVerFlota vista;
    private PantallaBase pantalla;
    private Aplicacion app;
    private Aerolinea aerolinea;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public ControlPanelVerFlota(PanelVerFlota vista, PantallaBase pantalla) {
        this.vista = vista;
        this.pantalla = pantalla;

        this.app = Aplicacion.init("acceder");

        OperadorAerolinea operador = (OperadorAerolinea) app.getUsuarioLogueado();
        if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
            JOptionPane.showMessageDialog(vista, "Debe haber un operador logueado para usar esta funcionalidad.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        this.aerolinea = app.getAerolinea(operador.getAerolinea().getNombre());
        if (aerolinea == null) {
            JOptionPane.showMessageDialog(null, "No tienes ninguna aerolínea asignada.", "Error", JOptionPane.WARNING_MESSAGE);
            vista.actualizarTabla(new Object[0][0]);
            return;
        }

        
        this.vista.setControlador(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVerFlotaEnum comando = ComandoVerFlotaEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case REFRESCAR_TABLA:
                cargarTabla();
                break;
        }
    }

    private void cargarTabla() {
        List<Avion> lista = aerolinea.getAviones();

        if (lista.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tienes aviones registrados aún.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            vista.actualizarTabla(new Object[0][0]);
            return;
        }

        Object[][] datos = new Object[lista.size()][13];

        for (int i = 0; i < lista.size(); i++) {
            Avion a = lista.get(i);
            TipoAvion t = a.getTipoAvion();

            datos[i][0] = a.getMatricula();
            datos[i][1] = t.getId();
            datos[i][2] = t.getMarca();
            datos[i][3] = t.getModelo();
            datos[i][4] = t.getCapacidad();
            datos[i][5] = t.getControlTemperatura() ? "Sí" : "No";
            datos[i][6] = t.getLargo();
            datos[i][7] = t.getAncho();
            datos[i][8] = t.getAlto();
            datos[i][9] = t.getCategoria().name();
            datos[i][10] = a.getFechaCompra().format(formatter);
            datos[i][11] = a.getFechaUltimaRevision().format(formatter);
            datos[i][12] = a.tieneMaterialPeligroso() ? "Sí" : "No";
        }

        vista.actualizarTabla(datos);
    }
}
