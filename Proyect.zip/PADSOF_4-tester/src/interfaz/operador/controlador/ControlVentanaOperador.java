package interfaz.operador.controlador;


import java.awt.Component;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import interfaz.operador.controlarDesembarquesPantalla.controlador.ControlPanelControlarDesembarques;
import interfaz.operador.controlarDesembarquesPantalla.vista.PanelControlarDesembarques;
import interfaz.operador.controlarEmbarquesPantalla.controlador.ControlPanelControlarEmbarques;
import interfaz.operador.controlarEmbarquesPantalla.vista.PanelControlarEmbarques;
import interfaz.operador.cuartaPantalla.controlador.ControlPanelRendimientoVuelo;
import interfaz.operador.cuartaPantalla.vista.PanelRendimientoVuelo;
import funcionalidad.aplicacion.Aplicacion;
import interfaz.componentes.PantallaBase;
import interfaz.comunNotificaciones.controlador.ControlPanelVerNotificaciones;
import interfaz.comunNotificaciones.vista.PanelVerNotificaciones;
import interfaz.login.controlador.ControlPanelLoginFrame;
import interfaz.login.vista.PanelLoginFrame;
import interfaz.operador.enums.ComandoVentanaOperadorEnum;
import interfaz.operador.primeraPantalla.controlador.ControlPanelGestionarFlota;
import interfaz.operador.primeraPantalla.vista.PanelGestionarFlota;
import interfaz.operador.vista.VentanaOperador;
import interfaz.operador.quintaPantalla.controlador.ControlPanelFacturas;
import interfaz.operador.quintaPantalla.vista.PanelFacturas;
import interfaz.operador.segundaPantalla.controlador.ControlPanelProponerVuelo;
import interfaz.operador.segundaPantalla.vista.PanelProponerVuelo;
import interfaz.operador.terceraPantalla.controlador.ControlPanelEstadoVuelo;
import interfaz.operador.terceraPantalla.vista.PanelControlarEstadoVuelo;

public class ControlVentanaOperador implements ActionListener {
    private VentanaOperador vista;
    private Aplicacion aplicacion;
    private PantallaBase pantalla;

    public ControlVentanaOperador(VentanaOperador vista) {
        this.vista = vista;
        this.vista.setControlador(this); 
        this.pantalla = vista.getPantallaBase();
        this.aplicacion = Aplicacion.init("acceder"); 
        actualizarFechaYHora();
        vista.getBotonCerrarSesion().setActionCommand(ComandoVentanaOperadorEnum.CERRAR_SESION.name());
        vista.getBotonCerrarSesion().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            ComandoVentanaOperadorEnum comando = ComandoVentanaOperadorEnum.valueOf(e.getActionCommand());

            switch (comando) {
                case GESTIONAR_FLOTA:
                    PanelGestionarFlota panelFlota = vista.getPanelGestionarFlota();
                    new ControlPanelGestionarFlota(panelFlota, vista.getPantallaBase()); 
                    vista.mostrarPanel(panelFlota);
                    break;

                case PROPONER_VUELOS:
                    PanelProponerVuelo panelProponer = vista.getPanelProponerVuelo();
                    new ControlPanelProponerVuelo(panelProponer); 
                    vista.mostrarPanel(panelProponer);
                    break;

                case CONTROLAR_ESTADO:
                    PanelControlarEstadoVuelo panelEstado = vista.getPanelEstadoVuelo(); 
                    new ControlPanelEstadoVuelo(panelEstado, vista.getPantallaBase()); 
                    vista.mostrarPanel(panelEstado); 
                    break;

                case CONTROLAR_EMBARQUES:
                    PanelControlarEmbarques panelEmbarques = vista.getPanelControlarEmbarques();
                    new ControlPanelControlarEmbarques(panelEmbarques);
                    vista.mostrarPanel(panelEmbarques);
                    break;

                case CONTROLAR_DESEMBARQUES:
                    PanelControlarDesembarques panelDesembarques = vista.getPanelControlarDesembarques();
                    new ControlPanelControlarDesembarques(panelDesembarques);
                    vista.mostrarPanel(panelDesembarques);
                    break;

                case VER_RENDIMIENTO:
                    PanelRendimientoVuelo panelRendimiento = vista.getPanelRendimientoVuelo();
                    new ControlPanelRendimientoVuelo(panelRendimiento, vista.getPantallaBase());
                    vista.mostrarPanel(panelRendimiento);
                    break;

                case VER_FACTURAS:
                    PanelFacturas panelFacturas = vista.getPanelFacturas();
                    new ControlPanelFacturas(panelFacturas, vista.getPantallaBase());
                    vista.mostrarPanel(panelFacturas);
                    break;

                case VER_NOTIFICACIONES:
                    PanelVerNotificaciones panelNotificaciones = new PanelVerNotificaciones(vista.getPantallaBase());
                    new ControlPanelVerNotificaciones(panelNotificaciones); // conecta el controlador
                    vista.mostrarPanel(panelNotificaciones);
                    break;
                case GUARDAR_APLICACION:
                    if(aplicacion.salvarAplicacion("aeropuerto.txt")) {
                        JOptionPane.showMessageDialog(vista, "Aplicación guardada correctamente.", "Guardar Aplicación", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(vista, "Error al guardar la aplicación.", "Guardar Aplicación", JOptionPane.ERROR_MESSAGE);
                    }
                    break;
                case CARGAR_APLICACION:
                    if(aplicacion.cargarAplicacion("aeropuerto.txt")) {
                        JOptionPane.showMessageDialog(vista, "Aplicación cargada correctamente.", "Cargar Aplicación", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(vista, "Error al cargar la aplicación.", "Cargar Aplicación", JOptionPane.ERROR_MESSAGE);
                    }

                    // 🔥 Cerrar ventana actual
                    Window ventana = SwingUtilities.getWindowAncestor((Component) e.getSource());
                    cerrarSesionIrALogin(ventana);
                    break;

                case CERRAR_SESION:
                    int respuesta = JOptionPane.showConfirmDialog(null,
                    "¿Estás seguro que deseas cerrar sesión?",
                    "Cerrar sesión", JOptionPane.YES_NO_OPTION);

                    if (respuesta == JOptionPane.YES_OPTION) {
                        // Cerrar sesión
                        cerrarSesionIrALogin(SwingUtilities.getWindowAncestor((Component) e.getSource()));
                    } else {
                        System.out.println("No se ha cerrado la sesión.");
                    }
                    break;
                
                case AVANZAR_5M:
                    aplicacion.avanzarCincoMinutos();
                    JOptionPane.showMessageDialog(vista, "Tiempo avanzado 5 minutos.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("Tiempo avanzado 5 minutos. Tiempo actual: " + aplicacion.getRealTime());
                    actualizarFechaYHora();
                    break;

                case AVANZAR_30M:
                    aplicacion.avanzarTreintaMinutos();
                    JOptionPane.showMessageDialog(vista, "Tiempo avanzado 30 minutos.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("Tiempo avanzado 30 minutos. Tiempo actual: " + aplicacion.getRealTime());
                    actualizarFechaYHora();
                    break;

                case AVANZAR_1H:
                    aplicacion.avanzarUnaHora();
                    JOptionPane.showMessageDialog(vista, "Tiempo avanzado 1 hora.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("Tiempo avanzado 1 hora. Tiempo actual: " + aplicacion.getRealTime());
                    actualizarFechaYHora();
                    break;

                case AVANZAR_1D:
                    aplicacion.avanzarUnDia();
                    JOptionPane.showMessageDialog(vista, "Tiempo avanzado 1 día.", "Avanzar Tiempo", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("Tiempo avanzado 1 día. Tiempo actual: " + aplicacion.getRealTime());
                    actualizarFechaYHora();
                    break;
            }

        } catch (IllegalArgumentException ex) {
            System.err.println("Comando no reconocido: " + e.getActionCommand());
        }
    }

    private void actualizarFechaYHora() {
        String fechaHora = aplicacion.getRealTime().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        pantalla.setFechaHora(fechaHora);
    }

    private void cerrarSesionIrALogin(Window ventana) {
        // Cerrar sesión
        aplicacion.cerrarSesion();
        System.out.println("Sesión cerrada correctamente.");

        // Cerrar ventana actual
        if (ventana != null) {
            ventana.dispose();
        }

        // Volver al login
        SwingUtilities.invokeLater(() -> {
            PanelLoginFrame loginFrame = new PanelLoginFrame();
            new ControlPanelLoginFrame(loginFrame); // conecta el controlador
            loginFrame.setVisible(true);
        });
    }

}
