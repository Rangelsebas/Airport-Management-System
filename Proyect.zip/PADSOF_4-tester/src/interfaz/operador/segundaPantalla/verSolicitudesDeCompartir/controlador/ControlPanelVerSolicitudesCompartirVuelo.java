package interfaz.operador.segundaPantalla.verSolicitudesDeCompartir.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.EstadoSolicitud;
import funcionalidad.vuelo.Ocupacion;
import funcionalidad.vuelo.Vuelo;
import interfaz.operador.segundaPantalla.verSolicitudesDeCompartir.enums.ComandoVerSolicitudesCompartirVuelo;
import interfaz.operador.segundaPantalla.verSolicitudesDeCompartir.vista.PanelVerSolicitudesCompartirVuelo;

public class ControlPanelVerSolicitudesCompartirVuelo implements ActionListener {

    private final PanelVerSolicitudesCompartirVuelo vista;
    private final Aplicacion aplicacion;
    private final Aerolinea aerolinea;
    private final List<Ocupacion> solicitudesPendientes = new ArrayList<>();

    public ControlPanelVerSolicitudesCompartirVuelo(PanelVerSolicitudesCompartirVuelo vista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");

        OperadorAerolinea operador = (OperadorAerolinea) aplicacion.getUsuarioLogueado();
        if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
            JOptionPane.showMessageDialog(vista, "Debes iniciar sesión como operador para ver esta información.", "Error", JOptionPane.ERROR_MESSAGE);
            this.aerolinea = null;
            return;
        }

        this.aerolinea = operador.getAerolinea();
        this.vista.setControlador(this);
        cargarSolicitudesPendientes();
    }

    private void cargarSolicitudesPendientes() {
        solicitudesPendientes.clear();
        vista.setSolicitudes(new ArrayList<>()); // limpia la vista

        if (aerolinea == null) return;

        for (Vuelo vuelo : aerolinea.getVuelos()) {
            for (Ocupacion ocupacion : vuelo.getOcupaciones()) {
                if (!ocupacion.getAerolineaSolicitante().equals(aerolinea) &&
                    ocupacion.getEstado() == EstadoSolicitud.PENDIENTE) {

                    solicitudesPendientes.add(ocupacion);
                }
            }
        }

        vista.setSolicitudes(solicitudesPendientes);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoVerSolicitudesCompartirVuelo comando = ComandoVerSolicitudesCompartirVuelo.valueOf(e.getActionCommand());
        Ocupacion seleccionada = vista.getOcupacionSeleccionada();

        if (seleccionada == null) {
            JOptionPane.showMessageDialog(vista, "Selecciona una solicitud de la lista.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Vuelo vueloRelacionado = buscarVueloPorOcupacion(seleccionada);

        if (vueloRelacionado == null) {
            JOptionPane.showMessageDialog(vista, "No se pudo encontrar el vuelo correspondiente.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        switch (comando) {
            case ACEPTAR:
                if (vueloRelacionado.aceptarVueloCompartido(seleccionada)) {
                    JOptionPane.showMessageDialog(vista, "Solicitud aceptada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(vista, "No se pudo aceptar la solicitud.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                break;

            case RECHAZAR:
                if (vueloRelacionado.rechazarVueloCompartido(seleccionada)) {
                    JOptionPane.showMessageDialog(vista, "Solicitud rechazada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(vista, "No se pudo rechazar la solicitud.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                break;
        }

        // Actualizar vista
        cargarSolicitudesPendientes();
    }

    private Vuelo buscarVueloPorOcupacion(Ocupacion o) {
        for (Vuelo v : aerolinea.getVuelos()) {
            if (v.getOcupaciones().contains(o)) {
                return v;
            }
        }
        return null;
    }
}
