package interfaz.operador.segundaPantalla.verSolicitudesDeCompartir.enums;

public enum ComandoVerSolicitudesCompartirVuelo {
    ACEPTAR,
    RECHAZAR
}
