package interfaz.operador.segundaPantalla.verSolicitudesDeCompartir.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import funcionalidad.vuelo.EstadoSolicitud;
import funcionalidad.vuelo.Ocupacion;
import interfaz.operador.segundaPantalla.verSolicitudesDeCompartir.enums.ComandoVerSolicitudesCompartirVuelo;

import java.util.List;

import java.awt.*;
import java.awt.event.ActionListener;

public class PanelVerSolicitudesCompartirVuelo extends JPanel {

    private JList<Ocupacion> listaSolicitudes;
    private DefaultListModel<Ocupacion> modeloLista;
    private JButton btnAceptar;
    private JButton btnRechazar;

    public PanelVerSolicitudesCompartirVuelo() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        modeloLista = new DefaultListModel<>();
        listaSolicitudes = new JList<>(modeloLista);
        listaSolicitudes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaSolicitudes.setCellRenderer(new OcupacionRenderer());

        JScrollPane scrollPane = new JScrollPane(listaSolicitudes);
        add(scrollPane, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelBotones.setBackground(Color.WHITE);

        btnAceptar = new JButton("Aceptar solicitud");
        btnRechazar = new JButton("Rechazar solicitud");

        btnAceptar.setActionCommand(ComandoVerSolicitudesCompartirVuelo.ACEPTAR.name());
        btnRechazar.setActionCommand(ComandoVerSolicitudesCompartirVuelo.RECHAZAR.name());

        panelBotones.add(btnAceptar);
        panelBotones.add(btnRechazar);

        add(panelBotones, BorderLayout.SOUTH);
    }

    public void setControlador(ActionListener listener) {
        btnAceptar.addActionListener(listener);
        btnRechazar.addActionListener(listener);
    }

    public void setSolicitudes(List<Ocupacion> ocupaciones) {
        modeloLista.clear();
        for (Ocupacion o : ocupaciones) {
            if (o.getEstado() == EstadoSolicitud.PENDIENTE) {
                modeloLista.addElement(o);
            }
        }
    }

    public Ocupacion getOcupacionSeleccionada() {
        return listaSolicitudes.getSelectedValue();
    }

    private static class OcupacionRenderer extends JLabel implements ListCellRenderer<Ocupacion> {
        @Override
        public Component getListCellRendererComponent(JList<? extends Ocupacion> list, Ocupacion value, int index, boolean isSelected, boolean cellHasFocus) {
            if (value != null) {
                setText("✈ Aerolínea: " + value.getAerolineaSolicitante().getNombre() + 
                        " | Porcentaje: " + value.getPorcentajeAsientos() + "% | Estado: " + value.getEstado());
            }
            setOpaque(true);
            setBackground(isSelected ? new Color(220, 220, 255) : Color.WHITE);
            setForeground(Color.BLACK);
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }
}