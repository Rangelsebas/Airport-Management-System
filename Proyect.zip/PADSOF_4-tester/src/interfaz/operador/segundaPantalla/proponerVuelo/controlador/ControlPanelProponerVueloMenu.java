package interfaz.operador.segundaPantalla.proponerVuelo.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aeropuerto.AeropuertoPropio;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import interfaz.operador.segundaPantalla.proponerVuelo.enums.ComandoPanelProponerVueloMenu;
import interfaz.operador.segundaPantalla.proponerVuelo.vista.PanelProponerVueloMenu;

public class ControlPanelProponerVueloMenu implements ActionListener {

    private PanelProponerVueloMenu vista;
    private Aplicacion aplicacion;
    private Aerolinea aerolinea;
    private OperadorAerolinea operador;

    public ControlPanelProponerVueloMenu(PanelProponerVueloMenu vista) {

        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");

        try {
            operador = (OperadorAerolinea)aplicacion.getUsuarioLogueado();
            if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
                JOptionPane.showMessageDialog(vista, "Debe haber un operador logueado para usar esta funcionalidad.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            this.aerolinea = aplicacion.getAerolinea(operador.getAerolinea().getNombre()); 
            if (aerolinea == null) {
                JOptionPane.showMessageDialog(vista, "No se pudo encontrar una aerolínea vinculada al operador actual.", "Error", JOptionPane.ERROR_MESSAGE);
                return; 
            }

            this.vista.setControlador(this);
            cargarAeropuertos();
            cargarAviones();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(vista, "Error al inicializar el panel. Verifique que haya sesión iniciada y datos cargados.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoPanelProponerVueloMenu comando = ComandoPanelProponerVueloMenu.valueOf(e.getActionCommand());

        switch (comando) {
            case PROPONER_VUELO_CONFIRMADO:
                procesarPropuestaVuelo();
                break;
            default:
                break;
        }
    }

    private void procesarPropuestaVuelo() {
        CategoriaAvion tipo = vista.getTipo();
        LocalDateTime fechaHoraSalida = vista.getFechaHoraSalida(); 
        LocalDateTime fechaHoraLlegada = vista.getFechaHoraLlegada();
        String origen = vista.getOrigen();
        String destino = vista.getDestino();

        Avion avionSeleccionado = vista.getAvion();
        if (avionSeleccionado == null) {
            JOptionPane.showMessageDialog(vista, "Selecciona un avión válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        CategoriaAvion categoriaAvion = avionSeleccionado.getCategoria();
        if ((tipo == CategoriaAvion.MERCANCIAS && categoriaAvion != CategoriaAvion.MERCANCIAS) ||
            (tipo == CategoriaAvion.PASAJEROS && categoriaAvion != CategoriaAvion.PASAJEROS)) {
            JOptionPane.showMessageDialog(vista, "El tipo de vuelo no coincide con el tipo de avión seleccionado.", "Error de tipo", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (origen == null || destino == null || origen.equals(destino)) {
            JOptionPane.showMessageDialog(vista, "Selecciona un origen y destino válidos (distintos entre sí).", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        // Validar que uno sea el propio y otro externo
        String aeropuertoPropio = aplicacion.getAeropuertoPropio().getNombre();
    
        boolean origenEsPropio = origen.equals(aeropuertoPropio);
        boolean destinoEsPropio = destino.equals(aeropuertoPropio);
    
        if (origenEsPropio == destinoEsPropio) {
            JOptionPane.showMessageDialog(vista, "Uno de los aeropuertos debe ser el propio y el otro externo.", "Selección inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            if (aplicacion.solicitarNuevoVuelo(
                origen,
                destino,
                fechaHoraSalida.toLocalDate(),
                fechaHoraSalida.toLocalTime(),
                fechaHoraLlegada.toLocalTime(),
                aerolinea,
                avionSeleccionado
            )) {
                JOptionPane.showMessageDialog(vista, "Solicitud de vuelo enviada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                vista.reset();
                cargarAviones();
                cargarAeropuertos();
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo enviar la solicitud de vuelo. Verifica los datos.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    
    }

    private void cargarAeropuertos() {
        try {
            List<String> aeropuertos = new ArrayList<>();
    
            AeropuertoPropio aeropuertoPropio = aplicacion.getAeropuertoPropio();
            if (aeropuertoPropio == null) {
                JOptionPane.showMessageDialog(vista, "No se ha creado el aeropuerto propio. Por favor, contacte con el gestor.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            // Añadir primero el aeropuerto propio
            aeropuertos.add(aeropuertoPropio.getNombre());
    
            // Añadir los externos sin sobrescribir
            aeropuertos.addAll(
                aplicacion.listarAeropuertosExternos()
                    .stream()
                    .map(a -> a.getNombre())
                    .collect(Collectors.toList())
            );
    
            vista.setListaAeropuertos(aeropuertos.toArray(new String[0]));
    
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(vista, "No se pudieron cargar los aeropuertos. Verifique la configuración del sistema.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarAviones() {
        if (aerolinea == null) {
            JOptionPane.showMessageDialog(vista, "No se ha podido obtener la aerolínea actual.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        List<Avion> aviones = aplicacion.getAerolinea(operador.getAerolinea().getNombre()).getAviones();
        vista.setListaAviones(aviones);
    }
}
