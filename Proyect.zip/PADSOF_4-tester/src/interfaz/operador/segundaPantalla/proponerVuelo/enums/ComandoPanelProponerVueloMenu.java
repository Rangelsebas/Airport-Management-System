package interfaz.operador.segundaPantalla.proponerVuelo.enums;

public enum ComandoPanelProponerVueloMenu {
    PROPONER_VUELO_CONFIRMADO
}
