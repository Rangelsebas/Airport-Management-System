package interfaz.operador.segundaPantalla.proponerVuelo.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import interfaz.operador.segundaPantalla.proponerVuelo.enums.ComandoPanelProponerVueloMenu;
import java.util.List;

import java.awt.*;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class PanelProponerVueloMenu extends JPanel {


    private JComboBox<CategoriaAvion> comboTipo;
    private JSpinner spinnerFecha;
    private JSpinner spinnerHora;
    private JSpinner spinnerMinuto;
    private JSpinner spinnerHoraLlegada;     
    private JSpinner spinnerMinutoLlegada;  

    private JComboBox<Avion> comboAvion;
    private JButton botonHacerPropuesta;

    /* Aeropuertos */
    private JComboBox<String> comboOrigen;
    private JComboBox<String> comboDestino;

    public PanelProponerVueloMenu() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        comboTipo = new JComboBox<>(CategoriaAvion.values());
        comboTipo.setMaximumSize(new Dimension(200, 30));
        add(comboTipo);
        add(Box.createVerticalStrut(10));

        add(crearEtiqueta("Fecha:"));
        spinnerFecha = new JSpinner(new SpinnerDateModel());
        spinnerFecha.setEditor(new JSpinner.DateEditor(spinnerFecha, "dd/MM/yyyy"));
        spinnerFecha.setMaximumSize(new Dimension(200, 30));
        add(spinnerFecha);
        add(Box.createVerticalStrut(10));

        add(crearEtiqueta("Hora de salida:"));
        JPanel panelHora = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        panelHora.setBackground(Color.WHITE);
        spinnerHora = crearSpinner(12, 0, 23, 1);
        spinnerMinuto = crearSpinner(0, 0, 59, 1);
        panelHora.add(spinnerHora);
        panelHora.add(new JLabel(":"));
        panelHora.add(spinnerMinuto);
        add(panelHora);
        add(Box.createVerticalStrut(10));

        add(crearEtiqueta("Hora de llegada:")); 
        JPanel panelHoraLlegada = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        panelHoraLlegada.setBackground(Color.WHITE);
        spinnerHoraLlegada = crearSpinner(14, 0, 23, 1);
        spinnerMinutoLlegada = crearSpinner(0, 0, 59, 1);
        panelHoraLlegada.add(spinnerHoraLlegada);
        panelHoraLlegada.add(new JLabel(":"));
        panelHoraLlegada.add(spinnerMinutoLlegada);
        add(panelHoraLlegada);
        add(Box.createVerticalStrut(10));

        add(crearEtiqueta("Origen:"));
        comboOrigen = new JComboBox<>();
        comboOrigen.setMaximumSize(new Dimension(300, 30));
        add(comboOrigen);

        add(crearEtiqueta("Destino:"));
        comboDestino = new JComboBox<>();
        comboDestino.setMaximumSize(new Dimension(300, 30));
        add(comboDestino);
        add(Box.createVerticalStrut(10));

        add(crearEtiqueta("Avión:"));
        comboAvion = new JComboBox<>();
        comboAvion.setMaximumSize(new Dimension(500, 30));
        comboAvion.setPreferredSize(new Dimension(500, 30));

        /* RENDER: ListCellRenderer */
        comboAvion.setRenderer(new DefaultListCellRenderer() {
        @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                        boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                if (value instanceof Avion avion) {
                    String resumen = avion.getTipoAvion().getMarca() + " " +
                                    avion.getTipoAvion().getModelo() + " | " +
                                    avion.getTipoAvion().getCapacidad() +
                                    (avion.getCategoria() == CategoriaAvion.PASAJEROS ? " pax" : " kg") +
                                    " | " + avion.getMatriculaUsuario();

                    setText(resumen);
                }

                return this;
            }
        });
        
        add(comboAvion);


        add(Box.createVerticalStrut(15));

        botonHacerPropuesta = new JButton("Hacer propuesta");
        botonHacerPropuesta.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonHacerPropuesta.setActionCommand(ComandoPanelProponerVueloMenu.PROPONER_VUELO_CONFIRMADO.name());
        add(botonHacerPropuesta);
    }

    // ================================
    // MÉTODOS DE VISTA MVC
    // ================================

    public void setControlador(ActionListener c) {
        botonHacerPropuesta.addActionListener(c);
    }

    public CategoriaAvion getTipo() {
        return (CategoriaAvion) comboTipo.getSelectedItem();
    }

    public Date getFecha() {
        return (Date) spinnerFecha.getValue();
    }

    public int getHora() {
        return (Integer) spinnerHora.getValue();
    }

    public int getMinuto() {
        return (Integer) spinnerMinuto.getValue();
    }

    public int getHoraLlegada() {  
        return (Integer) spinnerHoraLlegada.getValue();
    }

    public int getMinutoLlegada() { 
        return (Integer) spinnerMinutoLlegada.getValue();
    }

    public Avion getAvion() {
        return (Avion) comboAvion.getSelectedItem();
    }

    public String getOrigen() {
        return (String) comboOrigen.getSelectedItem();
    }
    
    public String getDestino() {
        return (String) comboDestino.getSelectedItem();
    }

    public void setListaAviones(List<Avion> aviones) {
        comboAvion.removeAllItems();
        for (Avion a : aviones) {
            comboAvion.addItem(a);
        }
    }

    public void setListaAeropuertos(String[] aeropuertos) {
        comboOrigen.removeAllItems();
        comboDestino.removeAllItems();
        for (String nombre : aeropuertos) {
            comboOrigen.addItem(nombre);
            comboDestino.addItem(nombre);
        }
    }

    public LocalDateTime getFechaHoraSalida() {
        Date fechaBase = (Date) spinnerFecha.getValue();
        int hora = getHora();
        int minuto = getMinuto();

        return fechaBase.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate()
                .atTime(hora, minuto);
    }

    public LocalDateTime getFechaHoraLlegada() {
        Date fechaBase = (Date) spinnerFecha.getValue();
        int hora = getHoraLlegada();
        int minuto = getMinutoLlegada();

        return fechaBase.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate()
                .atTime(hora, minuto);
    }

    public void reset() {
        comboTipo.setSelectedIndex(0);
        spinnerFecha.setValue(new Date());
        spinnerHora.setValue(12);
        spinnerMinuto.setValue(0);
        comboAvion.setSelectedIndex(0);
    }

    // ================================
    // HELPERS
    // ================================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(60, 30));
        return spinner;
    }   
}
