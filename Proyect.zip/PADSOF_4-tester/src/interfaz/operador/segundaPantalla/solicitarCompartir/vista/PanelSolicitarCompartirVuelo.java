package interfaz.operador.segundaPantalla.solicitarCompartir.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.vuelo.Vuelo;
import java.util.List;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import interfaz.operador.segundaPantalla.solicitarCompartir.enums.ComandoSolicitarCompartirVueloEnum;

public class PanelSolicitarCompartirVuelo extends JPanel {

    private JComboBox<Aerolinea> comboAerolineas;
    private JComboBox<Vuelo> comboVuelos;
    private JLabel labelCantidad;
    private JSpinner spinnerCantidad;
    private JButton botonSolicitarCompartir;

    private ActionListener listenerCambioAerolinea;

    public PanelSolicitarCompartirVuelo() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        // Aerolínea
        add(crearEtiqueta("Seleccionar aerolínea destino:"));
        comboAerolineas = new JComboBox<>();
        comboAerolineas.setMaximumSize(new Dimension(250, 30));
        comboAerolineas.addActionListener(e -> {
            Aerolinea seleccionada = getAerolineaDestino();
            if (seleccionada != null && listenerCambioAerolinea != null) {
                listenerCambioAerolinea.actionPerformed(new ActionEvent(seleccionada, ActionEvent.ACTION_PERFORMED, "CAMBIO_AEROLINEA"));
            }
        });
        add(comboAerolineas);

        add(Box.createVerticalStrut(10));

        // Vuelos
        add(crearEtiqueta("Seleccionar vuelo:"));
        comboVuelos = new JComboBox<>();
        comboVuelos.setMaximumSize(new Dimension(300, 30));
        comboVuelos.setRenderer(new VueloRenderer());
        add(comboVuelos);

        add(Box.createVerticalStrut(10));

        // Cantidad a aportar
        labelCantidad = crearEtiqueta("Cantidad a aportar:");
        add(labelCantidad);

        spinnerCantidad = crearSpinner(0, 0, 1000, 1);
        add(spinnerCantidad);

        add(Box.createVerticalStrut(15));

        // Botón
        botonSolicitarCompartir = new JButton("Solicitar Compartir");
        botonSolicitarCompartir.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonSolicitarCompartir.setActionCommand(ComandoSolicitarCompartirVueloEnum.SOLICITAR_COMPARTIR_CONFIRMADO.name());
        add(botonSolicitarCompartir);
    }

    // =============================
    // MÉTODOS VISTA MVC
    // =============================

    public void setControlador(ActionListener c) {
        botonSolicitarCompartir.addActionListener(c);
    }

    public void setListenerCambioAerolinea(ActionListener l) {
        this.listenerCambioAerolinea = l;
    }

    public Aerolinea getAerolineaDestino() {
        return (Aerolinea) comboAerolineas.getSelectedItem();
    }

    public Vuelo getVueloSeleccionado() {
        return (Vuelo) comboVuelos.getSelectedItem();
    }

    public int getCantidad() {
        return (Integer) spinnerCantidad.getValue();
    }

    public void setListaAerolineas(List<Aerolinea> aerolineas) {
        comboAerolineas.removeAllItems();
        for (Aerolinea a : aerolineas) {
            comboAerolineas.addItem(a);
        }
    }

    public void setListaVuelos(List<Vuelo> vuelos) {
        comboVuelos.removeAllItems();
        for (Vuelo vuelo : vuelos) {
            comboVuelos.addItem(vuelo);
        }
    }

    public void reset() {
        comboVuelos.setSelectedIndex(0);
        spinnerCantidad.setValue(0);
    }

    // =============================
    // HELPERS
    // =============================

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(200, 30));
        return spinner;
    }

    // Renderer para mostrar vuelos de forma personalizada
    private static class VueloRenderer extends JLabel implements ListCellRenderer<Vuelo> {
        @Override
        public Component getListCellRendererComponent(JList<? extends Vuelo> list, Vuelo value, int index, boolean isSelected, boolean cellHasFocus) {
            if (value != null) {
                setText(value.getCodigoVuelo()
                        + " | " + value.getOrigen().getNombre()
                        + " ➝ " + value.getDestino().getNombre()
                        + " | Operado por: " + value.getAerolineaOperadora().getNombre());
            } else {
                setText("Seleccionar vuelo");
            }
            setOpaque(true);
            setBackground(isSelected ? new Color(220, 220, 255) : Color.WHITE);
            setForeground(Color.BLACK);
            setBorder(BorderFactory.createEmptyBorder(3, 5, 3, 5));
            return this;
        }
    }
}
