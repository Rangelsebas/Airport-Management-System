package interfaz.operador.segundaPantalla.solicitarCompartir.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;
import interfaz.operador.segundaPantalla.solicitarCompartir.enums.ComandoSolicitarCompartirVueloEnum;
import interfaz.operador.segundaPantalla.solicitarCompartir.vista.PanelSolicitarCompartirVuelo;

public class ControlPanelSolicitarCompartirVuelo implements ActionListener {

    private final PanelSolicitarCompartirVuelo vista;
    private final Aplicacion aplicacion;
    private final Aerolinea aerolineaOperador;

    public ControlPanelSolicitarCompartirVuelo(PanelSolicitarCompartirVuelo vista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");

        // Validar operador
        OperadorAerolinea operador = (OperadorAerolinea) aplicacion.getUsuarioLogueado();
        if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
            JOptionPane.showMessageDialog(vista, "Debes estar logueado como operador para compartir vuelos.", "Error", JOptionPane.ERROR_MESSAGE);
            this.aerolineaOperador = null;
            return;
        }

        this.aerolineaOperador = aplicacion.getAerolinea(operador.getAerolinea().getNombre());
        this.vista.setControlador(this);

        // Establecer listener para cuando el usuario seleccione una aerolínea
        this.vista.setListenerCambioAerolinea(e -> {
            Aerolinea seleccionada = (Aerolinea) e.getSource();
            cargarVuelosDeAerolíneaSeleccionada(seleccionada);
        });

        cargarAerolineasDisponibles(); // Solo las otras
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoSolicitarCompartirVueloEnum comando = ComandoSolicitarCompartirVueloEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case SOLICITAR_COMPARTIR_CONFIRMADO:
                procesarSolicitudCompartir();
                break;
            default:
                break;
        }
    }

    private void procesarSolicitudCompartir() {
        Vuelo vuelo = vista.getVueloSeleccionado();
    
        if (vuelo == null) {
            JOptionPane.showMessageDialog(vista, "Selecciona una aerolínea y un vuelo válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        EstadosVuelo estadoVuelo = vuelo.getEstado();
        int porcentaje = vista.getCantidad();
    
        if (estadoVuelo != EstadosVuelo.APROBADO) {
            JOptionPane.showMessageDialog(vista, "El vuelo debe estar aprobado para solicitar compartirlo.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (vuelo.getFecha().isBefore(aplicacion.getRealTime().toLocalDate().plusDays(2))) {
            JOptionPane.showMessageDialog(vista, "La fecha del vuelo debe ser al menos 2 días después de hoy.", "Fecha inválida", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (porcentaje <= 0 || porcentaje > 50) {
            JOptionPane.showMessageDialog(vista, "El porcentaje debe ser mayor a 0 y no mayor al 50%.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        boolean exito = vuelo.solicitarVueloCompartido(porcentaje);
    
        if (exito) {
            JOptionPane.showMessageDialog(vista, "Solicitud enviada correctamente. Espera la aprobación del operador original.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            vista.reset();
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo enviar la solicitud. Verifica que no estés excediendo el 50% permitido o que ya hayas enviado una solicitud.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void cargarAerolineasDisponibles() {
        List<Aerolinea> todas = aplicacion.getAerolineasDisponibles();
        List<Aerolinea> otras = todas.stream()
            .filter(a -> !a.equals(aerolineaOperador))
            .collect(Collectors.toList());

        vista.setListaAerolineas(otras);
    }

    private void cargarVuelosDeAerolíneaSeleccionada(Aerolinea aerolineaSeleccionada) {
        if (aerolineaSeleccionada == null) {
            vista.setListaVuelos(List.of());
            return;
        }

        List<Vuelo> vuelos = aerolineaSeleccionada.getVuelos();
        vista.setListaVuelos(vuelos);
    }
}
