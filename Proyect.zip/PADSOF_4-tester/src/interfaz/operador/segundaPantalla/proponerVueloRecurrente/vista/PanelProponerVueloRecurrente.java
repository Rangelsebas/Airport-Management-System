package interfaz.operador.segundaPantalla.proponerVueloRecurrente.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.otro.Recurrencia;
import interfaz.operador.segundaPantalla.proponerVueloRecurrente.enums.ComandoPanelProponerVueloRecurrenteEnum;

import java.awt.*;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

public class PanelProponerVueloRecurrente extends JPanel {

    private JComboBox<String> comboOrigen;
    private JComboBox<String> comboDestino;
    private JSpinner spinnerFecha;
    private JSpinner spinnerHoraSalida;
    private JSpinner spinnerMinutoSalida;
    private JSpinner spinnerHoraLlegada;
    private JSpinner spinnerMinutoLlegada;
    private JComboBox<CategoriaAvion> comboTipo;
    private JComboBox<Recurrencia> comboRecurrencia;
    private JSpinner spinnerCantidad;
    private JComboBox<Avion> comboAvion;
    private JButton botonProponer;

    public PanelProponerVueloRecurrente() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        add(crearEtiqueta("Origen:"));
        comboOrigen = new JComboBox<>();
        comboOrigen.setMaximumSize(new Dimension(300, 30));
        add(comboOrigen);

        add(crearEtiqueta("Destino:"));
        comboDestino = new JComboBox<>();
        comboDestino.setMaximumSize(new Dimension(300, 30));
        add(comboDestino);

        add(crearEtiqueta("Fecha de primer vuelo:"));
        spinnerFecha = new JSpinner(new SpinnerDateModel());
        spinnerFecha.setEditor(new JSpinner.DateEditor(spinnerFecha, "dd/MM/yyyy"));
        spinnerFecha.setMaximumSize(new Dimension(200, 30));
        add(spinnerFecha);

        JPanel filaHoraSalida = new JPanel();
        filaHoraSalida.setLayout(new BoxLayout(filaHoraSalida, BoxLayout.X_AXIS));
        filaHoraSalida.setBackground(Color.WHITE);

        JLabel lblHoraSalida = new JLabel("Hora de salida:");
        lblHoraSalida.setPreferredSize(new Dimension(150, 30)); // ancho fijo para alinear
        spinnerHoraSalida = crearSpinner(10, 0, 23, 1);
        spinnerMinutoSalida = crearSpinner(0, 0, 59, 1);

        filaHoraSalida.add(lblHoraSalida);
        filaHoraSalida.add(Box.createHorizontalStrut(10));
        filaHoraSalida.add(spinnerHoraSalida);
        filaHoraSalida.add(new JLabel(":"));
        filaHoraSalida.add(spinnerMinutoSalida);
        add(filaHoraSalida);
        add(Box.createVerticalStrut(10)); // Añade espacio entre la hora de salida y la llegada

        JPanel filaHoraLlegada = new JPanel();
        filaHoraLlegada.setLayout(new BoxLayout(filaHoraLlegada, BoxLayout.X_AXIS));
        filaHoraLlegada.setBackground(Color.WHITE);

        JLabel lblHoraLlegada = new JLabel("Hora de llegada:");
        lblHoraLlegada.setPreferredSize(new Dimension(150, 30)); // mismo ancho que el de hora de salida

        spinnerHoraLlegada = crearSpinner(12, 0, 23, 1);
        spinnerMinutoLlegada = crearSpinner(0, 0, 59, 1);

        filaHoraLlegada.add(lblHoraLlegada);
        filaHoraLlegada.add(Box.createHorizontalStrut(10));
        filaHoraLlegada.add(spinnerHoraLlegada);
        filaHoraLlegada.add(new JLabel(":"));
        filaHoraLlegada.add(spinnerMinutoLlegada);

        add(filaHoraLlegada);
        add(Box.createVerticalStrut(10)); // espaciado entre secciones

        add(crearEtiqueta("Tipo de vuelo:"));
        comboTipo = new JComboBox<>(CategoriaAvion.values());
        comboTipo.setMaximumSize(new Dimension(200, 30));
        add(comboTipo);

        add(crearEtiqueta("Recurrencia:"));
        comboRecurrencia = new JComboBox<>(Recurrencia.values());
        comboRecurrencia.setMaximumSize(new Dimension(200, 30));
        add(comboRecurrencia);

        add(crearEtiqueta("Cantidad de repeticiones:"));
        spinnerCantidad = crearSpinner(1, 1, 30, 1);
        add(spinnerCantidad);

        add(crearEtiqueta("Avión:"));
        comboAvion = new JComboBox<>();
        comboAvion.setMaximumSize(new Dimension(400, 30));
        add(comboAvion);

        add(Box.createVerticalStrut(15));
        botonProponer = new JButton("Proponer vuelos recurrentes");
        botonProponer.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonProponer.setActionCommand(ComandoPanelProponerVueloRecurrenteEnum.CONFIRMAR_PROPUESTA_RECURRENTES.name());
        add(botonProponer);
    }

    // ================= MÉTODOS DE VISTA =================

    public void setControlador(ActionListener c) {
        botonProponer.addActionListener(c);
    }

    public String getOrigen() { return (String) comboOrigen.getSelectedItem(); }
    public String getDestino() { return (String) comboDestino.getSelectedItem(); }
    public LocalDate getFecha() {
        return ((Date) spinnerFecha.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
    public LocalTime getHoraSalida() {
        int hora = (Integer) spinnerHoraSalida.getValue();
        int minuto = (Integer) spinnerMinutoSalida.getValue();
        return LocalTime.of(hora, minuto);
    }
    public int getMinutoSalida() { return (Integer) spinnerMinutoSalida.getValue(); }
    public LocalTime getHoraLlegada() {
        int hora = (Integer) spinnerHoraLlegada.getValue();
        int minuto = (Integer) spinnerMinutoLlegada.getValue();
        return LocalTime.of(hora, minuto);
    }
    public int getMinutoLlegada() { return (Integer) spinnerMinutoLlegada.getValue(); }
    public Recurrencia getRecurrencia() { return (Recurrencia) comboRecurrencia.getSelectedItem(); }
    public int getCantidad() { return (Integer) spinnerCantidad.getValue(); }
    public CategoriaAvion getTipo() { return (CategoriaAvion) comboTipo.getSelectedItem(); }
    public Avion getAvion() { return (Avion) comboAvion.getSelectedItem(); }

    public void setListaAeropuertos(String[] aeropuertos) {
        comboOrigen.removeAllItems();
        comboDestino.removeAllItems();
        for (String aeropuerto : aeropuertos) {
            comboOrigen.addItem(aeropuerto);
            comboDestino.addItem(aeropuerto);
        }
    }

    public void reset() {
        comboOrigen.setSelectedIndex(0);
        comboDestino.setSelectedIndex(0);
        spinnerFecha.setValue(new Date());
        spinnerHoraSalida.setValue(10);
        spinnerMinutoSalida.setValue(0);
        spinnerHoraLlegada.setValue(12);
        spinnerMinutoLlegada.setValue(0);
        comboTipo.setSelectedIndex(0);
        comboRecurrencia.setSelectedIndex(0);
        spinnerCantidad.setValue(1);
        comboAvion.removeAllItems();
    }

    public void setListaAviones(List<Avion> aviones) {
        comboAvion.removeAllItems();
        for (Avion a : aviones) {
            comboAvion.addItem(a);
        }
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private JSpinner crearSpinner(int value, int min, int max, int step) {
        SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
        JSpinner spinner = new JSpinner(model);
        spinner.setMaximumSize(new Dimension(80, 30));
        return spinner;
    }
}
