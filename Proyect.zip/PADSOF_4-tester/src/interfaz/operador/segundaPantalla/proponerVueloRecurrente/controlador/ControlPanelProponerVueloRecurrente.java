package interfaz.operador.segundaPantalla.proponerVueloRecurrente.controlador;

import javax.swing.*;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aeropuerto.AeropuertoPropio;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Recurrencia;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import interfaz.operador.segundaPantalla.proponerVueloRecurrente.enums.ComandoPanelProponerVueloRecurrenteEnum;
import interfaz.operador.segundaPantalla.proponerVueloRecurrente.vista.PanelProponerVueloRecurrente;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

public class ControlPanelProponerVueloRecurrente implements ActionListener {

    private final PanelProponerVueloRecurrente vista;
    private Aplicacion aplicacion;
    private final Aerolinea aerolinea;

    public ControlPanelProponerVueloRecurrente(PanelProponerVueloRecurrente vista) {
        this.vista = vista;
        this.aplicacion = Aplicacion.init("acceder");

        OperadorAerolinea operador = (OperadorAerolinea) aplicacion.getUsuarioLogueado();
        if (operador == null || !operador.checkRol(Rol.OPERADORAEROLINEA)) {
            JOptionPane.showMessageDialog(vista, "Debes estar logueado como operador para acceder a esta función.", "Error", JOptionPane.ERROR_MESSAGE);
            this.aerolinea = null;
            return;
        }

        this.aerolinea = operador.getAerolinea();
        this.vista.setControlador(this);

        cargarAeropuertos();
        cargarAviones();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ComandoPanelProponerVueloRecurrenteEnum comando = ComandoPanelProponerVueloRecurrenteEnum.valueOf(e.getActionCommand());

        switch (comando) {
            case CONFIRMAR_PROPUESTA_RECURRENTES:
                procesarSolicitudRecurrente();
                break;
        
            default:
                break;
        }
    }

    private void procesarSolicitudRecurrente() {
        String origen = vista.getOrigen();
        String destino = vista.getDestino();
        LocalDate fecha = vista.getFecha();
        LocalTime horaSalida = vista.getHoraSalida();
        LocalTime horaLlegada = vista.getHoraLlegada();
        Avion avion = vista.getAvion();
        Recurrencia recurrencia = vista.getRecurrencia();
        int cantidad = vista.getCantidad();
        CategoriaAvion tipo = avion.getCategoria();

        if (origen == null || destino == null || origen.equals(destino)) {
            JOptionPane.showMessageDialog(vista, "El origen y destino deben estar seleccionados y ser diferentes.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (fecha.isBefore(aplicacion.getRealTime().toLocalDate().plusDays(2))) {
            JOptionPane.showMessageDialog(vista, "La primera fecha debe ser al menos 2 días después de hoy.", "Fecha inválida", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (horaSalida == null || horaLlegada == null || horaSalida.equals(horaLlegada)) {
            JOptionPane.showMessageDialog(vista, "Debes ingresar horas válidas de salida y llegada.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (cantidad <= 0 || cantidad > 50) {
            JOptionPane.showMessageDialog(vista, "La cantidad de repeticiones debe estar entre 1 y 20.", "Cantidad inválida", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean exito = aplicacion.solicitarVueloRecurrente(
            origen,
            destino,
            fecha,
            horaSalida,
            horaLlegada,
            aerolinea,
            avion,
            cantidad,
            recurrencia,
            tipo
        );

        if (exito) {
            JOptionPane.showMessageDialog(vista, "Solicitud de vuelos recurrentes enviada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            vista.reset();
            cargarAviones();
            cargarAeropuertos();
        } else {
            JOptionPane.showMessageDialog(vista, "No se pudo enviar la solicitud. Verifica los datos o si hay restricciones del sistema.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void cargarAeropuertos() {
        AeropuertoPropio aeropuertoPropio = aplicacion.getAeropuertoPropio();
        if (aeropuertoPropio == null) {
            JOptionPane.showMessageDialog(vista, "No se ha creado un aeropuerto propio aún.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<String> aeropuertos = aplicacion.listarAeropuertosExternos().stream()
            .map(a -> a.getNombre())
            .collect(Collectors.toList());

        aeropuertos.add(0, aeropuertoPropio.getNombre());

        vista.setListaAeropuertos(aeropuertos.toArray(new String[0]));
    }

    private void cargarAviones() {
        if (aerolinea != null) {
            vista.setListaAviones(aerolinea.getAviones());
        }
    }
}
