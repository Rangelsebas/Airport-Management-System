package interfaz.operador.segundaPantalla.proponerVueloRecurrente.enums;

public enum ComandoPanelProponerVueloRecurrenteEnum {
    CONFIRMAR_PROPUESTA_RECURRENTES
}
