package interfaz.componentes;

import javax.swing.*;

public class InicioAplicacionFrame extends JFrame {

    public InicioAplicacionFrame() {
        setTitle("Sistema Aeroportuario - Inicio");
        setSize(1280, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
    }

    // Este método lo usará el controlador para cargar vistas
    public void mostrarContenido(JPanel nuevoPanel) {
        setContentPane(nuevoPanel);
        revalidate();
        repaint();
    }
}
