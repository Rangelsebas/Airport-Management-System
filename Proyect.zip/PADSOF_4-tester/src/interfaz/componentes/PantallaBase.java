package interfaz.componentes;

import java.awt.*;
import java.util.List;
import javax.swing.*;

public class PantallaBase extends JPanel {

    public HeaderPanel header;
    public MenuLateralPanel menuIzquierdo;
    public JPanel panelCentral;
    public PanelNotificaciones panelNotificaciones;

    public PantallaBase(String nombreUsuario, List<JButton> botonesMenu, List<String> notificaciones) {
        setLayout(new BorderLayout());

        /* -------------------- HEADER -------------------- */
        header = new HeaderPanel(nombreUsuario);
        add(header, BorderLayout.NORTH);

        /* -------------------- CENTRO -------------------- */
        JPanel centro = new JPanel(new BorderLayout());

        menuIzquierdo = new MenuLateralPanel(botonesMenu);
        JScrollPane scrollMenu = new JScrollPane(menuIzquierdo,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollMenu.setPreferredSize(new Dimension(320, 0));
        centro.add(scrollMenu, BorderLayout.WEST);

        panelCentral = new JPanel();
        panelCentral.setPreferredSize(new Dimension(400, 300));
        panelCentral.setBackground(Color.WHITE);
        centro.add(panelCentral, BorderLayout.CENTER);

        add(centro, BorderLayout.CENTER);

        /* -------------------- NOTIFICACIONES -------------------- */
        panelNotificaciones = new PanelNotificaciones(notificaciones);
        add(panelNotificaciones, BorderLayout.SOUTH);
    }

    public void setFechaHora(String fechaHora) {
        header.setFechaHora(fechaHora);
    }

    public JPanel getPanelCentral(){
        return this.panelCentral;
    }

    public JButton getCerrarSesionButton() {
        return header.getCerrarSesionButton();
    }

    public JButton getAvanzar5MinButton() {
        return header.getAvanzar5MinButton();
    }

    public JButton getAvanzar30miButton() {
        return header.getAvanzar30miButton();
    }

    public JButton getAvanzar1hButton() {
        return header.getAvanzar1hButton();
    }

    public JButton getAvanzar1dButton() {
        return header.getAvanzar1dButton();
    }

    public void mostrarContenidoEnPanelCentral(JPanel nuevoContenido) {
        panelCentral.removeAll();
        panelCentral.add(nuevoContenido);
        panelCentral.revalidate();
        panelCentral.repaint();
    }
}
