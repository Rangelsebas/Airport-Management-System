package interfaz.componentes;

import java.awt.*;
import javax.swing.*;

public class HeaderPanel extends JPanel {
    public JLabel usuarioLabel;
    protected JLabel fechaHoraLabel;
    public JButton cerrarSesionButton;
    protected JButton avanzar5MinButton;
    protected JButton avanzar30miButton;
    protected JButton avanzar1hButton;
    protected JButton avanzar1dButton;

    public HeaderPanel(String nombreUsuario) {
        setLayout(new BorderLayout());

        usuarioLabel = new JLabel("< " + nombreUsuario + " >");
        usuarioLabel.setFont(new Font("Arial", Font.BOLD, 14));

        String fechaHora = "No time set"; 

        // Añadir espacio horizontal entre el nombre de usuario y la fecha
        usuarioLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));

        fechaHoraLabel = new JLabel("Fecha y Hora: " + fechaHora);
        fechaHoraLabel.setFont(new Font("Arial", Font.BOLD, 14));

        cerrarSesionButton = new JButton("Cerrar Sesión");
        avanzar5MinButton = new JButton("Avanzar 5 min");
        avanzar30miButton = new JButton("Avanzar 30 min");
        avanzar1hButton = new JButton("Avanzar 1 h");
        avanzar1dButton = new JButton("Avanzar 1 d");

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        derecha.add(avanzar5MinButton);
        derecha.add(avanzar30miButton);
        derecha.add(avanzar1hButton);
        derecha.add(avanzar1dButton);
        derecha.add(cerrarSesionButton);

        setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(usuarioLabel, BorderLayout.WEST);
        add(fechaHoraLabel, BorderLayout.CENTER);
        add(derecha, BorderLayout.EAST);
    }

    public void setFechaHora(String fechaHora) {
        fechaHoraLabel.setText("Fecha y Hora: " + fechaHora);
    }

    public JButton getAvanzar5MinButton() {
        return avanzar5MinButton;
    }

    public JButton getAvanzar30miButton() {
        return avanzar30miButton;
    }

    public JButton getAvanzar1hButton() {
        return avanzar1hButton;
    }

    public JButton getAvanzar1dButton() {
        return avanzar1dButton;
    }

    public JButton getCerrarSesionButton() {
        return cerrarSesionButton;
    }
}
