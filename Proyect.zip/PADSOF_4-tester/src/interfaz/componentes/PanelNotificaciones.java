package interfaz.componentes;

import java.awt.*;
import java.util.List;
import javax.swing.*;

public class PanelNotificaciones extends JPanel {

    
    public PanelNotificaciones(List<String> notificaciones) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel titulo = new JLabel("Últimas notificaciones");
        titulo.setFont(new Font("Arial", Font.BOLD, 13));
        titulo.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        add(titulo);

        JPanel contenido = new JPanel();
        contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));
        contenido.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        contenido.setPreferredSize(new Dimension(350, 100));

        for (String msg : notificaciones) {
            JLabel label = new JLabel(msg);
            label.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            contenido.add(label);
        }

        add(contenido);
    }
}

