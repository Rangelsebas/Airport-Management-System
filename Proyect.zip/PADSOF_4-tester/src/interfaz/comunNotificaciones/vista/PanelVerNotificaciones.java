package interfaz.comunNotificaciones.vista;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import interfaz.componentes.PantallaBase;

public class PanelVerNotificaciones extends JPanel {
    private final PantallaBase pantallaBase;
    private final DefaultListModel<String> modeloLista;
    private final JList<String> listaSolicitudes;

    public PanelVerNotificaciones(PantallaBase pantallaBase) {
        this.pantallaBase = pantallaBase;
        this.modeloLista = new DefaultListModel<>();
        this.listaSolicitudes = new JList<>(modeloLista);

        // Configurar la lista para multilinea
        listaSolicitudes.setFont(new Font("Monospaced", Font.PLAIN, 13));
        listaSolicitudes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaSolicitudes.setCellRenderer(new MultiLineCellRenderer());
        // Permitir ancho fijo y altura variable
        listaSolicitudes.setFixedCellWidth(900);
        // Allow variable cell height based on content
        listaSolicitudes.setVisibleRowCount(10); // max 10 rows visible before scroll

        JScrollPane scroll = new JScrollPane(listaSolicitudes,
        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // Force preferred size to enable vertical scrolling
        scroll.setPreferredSize(new Dimension(900, 400));
        scroll.setBorder(BorderFactory.createEmptyBorder());
        listaSolicitudes.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(Color.WHITE);

        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(20, 20, 20, 20));
        add(scroll, BorderLayout.CENTER);

        // Ajustar ancho de celdas al tamaño real del viewport
        scroll.getViewport().addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int w = scroll.getViewport().getWidth();
                listaSolicitudes.setFixedCellWidth(w);
            }
        });
    }

    public void añadirNotificacion(String texto) {
        modeloLista.addElement(texto);
    }

    public JList<String> getListaSolicitudes() {
        return listaSolicitudes;
    }

    public PantallaBase getPantallaBase() {
        return pantallaBase;
    }

    /**
     * Renderer para celdas multilinea en JList.
     */
    private static class MultiLineCellRenderer extends JTextArea implements ListCellRenderer<String> {
        public MultiLineCellRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
            setOpaque(true);
        }

        @Override
        public Component getListCellRendererComponent(
                JList<? extends String> list,
                String value,
                int index,
                boolean isSelected,
                boolean cellHasFocus) {

            setText(value);
            setFont(list.getFont());
            // el ancho ya lo fija la lista
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }
            // Ajustar altura según contenido
            setSize(list.getFixedCellWidth(), Short.MAX_VALUE);
            return this;
        }
    }
}
