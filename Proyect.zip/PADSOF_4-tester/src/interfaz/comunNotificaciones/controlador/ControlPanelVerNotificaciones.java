package interfaz.comunNotificaciones.controlador;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.aplicacion.Notificacion;
import interfaz.componentes.PantallaBase;
import interfaz.comunNotificaciones.vista.PanelVerNotificaciones;

public class ControlPanelVerNotificaciones { 
    private final PanelVerNotificaciones vista;
    private final PantallaBase pantalla;
    private Aplicacion aplicacion;

    public ControlPanelVerNotificaciones(PanelVerNotificaciones vista) {
        this.vista = vista;
        this.pantalla = vista.getPantallaBase();
        this.aplicacion = Aplicacion.init("");
        cargarNotificaciones();
    }

    private void cargarNotificaciones() {
        List<Notificacion> notificaciones = aplicacion.verTodasMisNotificacionesGrafico();
        if (notificaciones == null) {
            vista.añadirNotificacion("No hay notificaciones pendientes.");
            return;
        }
        if(notificaciones.isEmpty()) {
            vista.añadirNotificacion("No hay notificaciones pendientes.");
            return;
        }
        
        notificaciones.stream()
        .collect(Collectors.collectingAndThen(Collectors.toList(), lst -> {
            Collections.reverse(lst);
            return lst.stream();
        }))
        .forEach(n -> vista.añadirNotificacion(n.getMensaje()));

    }
}
