package funcionalidad.usuarios;
import funcionalidad.aerolinea.Aerolinea;

public class OperadorAerolinea extends Usuario {

	/* REFERENCIAS (ESTO LO HIZO SEBITAS 👻) */
	private Aerolinea aerolinea;

	public OperadorAerolinea (String nombreDeUsuario, String dni, String nombre, String email, String contrasena) {
		super (nombreDeUsuario, dni, nombre, email, contrasena, Rol.OPERADORAEROLINEA);
	}

	/* RELACION BIDIRECCIONAL (ESTO LO HIZO SEBITAS, PORQUE ES NECESARIO Y PARA QUE NO DE ERRORES) */
	public Boolean asignarAerolinea(Aerolinea aerolinea) {
        if (this.aerolinea == null) {  // Verifica que no se asigne más de una aerolínea
            this.aerolinea = aerolinea;
            return aerolinea.asignarOperador(this);  // Relación bidireccional
    	}

		return false;
	}

	public Aerolinea getAerolinea() {
		return aerolinea;
	}

	@Override
	public String toString() {
		return super.toString() + "\nOperador de Aerolínea: " + (aerolinea != null ? aerolinea.getNombre() : "Ninguna");
	}


		/* EJEMPLO DE USO */
		// public class Main {
		// 	public static void main(String[] args) {
		// 		// Crear objetos
		// 		OperadorAerolinea operador = new OperadorAerolinea("Juan Pérez");
		// 		Aerolinea aerolinea = new Aerolinea("Aerolinea X");
		
		// 		// Establecer la relación bidireccional
		// 		operador.asignarAerolinea(aerolinea);
		
		// 		// Verificación de la relación bidireccional
		// 		System.out.println("Operador: " + operador.getNombre());
		// 		System.out.println("Aerolinea: " + operador.getAerolinea().getNombre());
		
		// 		// Verificar desde la aerolínea
		// 		System.out.println("Operador asociado a la aerolínea: " + aerolinea.getOperador().getNombre());
		// 	}
		// }
		
}