package funcionalidad.usuarios;
public enum Rol {
    GESTORAEROPUERTO,
    OPERADORAEROLINEA,
    CONTROLADORAEREO
}
