package funcionalidad.usuarios;
import funcionalidad.aeropuerto.elementos.Terminal;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ControladorAereo extends Usuario {
	private List<Vuelo> vuelos;
	private Terminal terminal;

	public ControladorAereo (String nombreDeUsuario, String dni, String nombre, String email, String contrasena) {
		super (nombreDeUsuario, dni, nombre, email, contrasena, Rol.CONTROLADORAEREO);
		this.vuelos = new ArrayList<>();
	}

	/* RELACION BIDIRECCIONAL */
	public void asignarVuelo (Vuelo vueloAsignado) {
		if (vueloAsignado == null) return;
		if (!vuelos.contains (vueloAsignado)) {
			vuelos.add (vueloAsignado);
			vueloAsignado.vincularControlador (this);
		}
	}

	public Boolean asignarTerminal (Terminal terminal) {
		if (this.terminal == null) {
			this.terminal = terminal;
			terminal.añadirControlador(this);
			return true;
		}
		return false;
	}	

	public Terminal getTerminal() {
		return terminal;
	}

	public void eliminarTerminal (Terminal terminal) {
		if (this.terminal != null) {
			this.terminal = null;
			terminal.eliminarControlador(this);
		}
	}

	public List<Vuelo> getVuelos() {
        return Collections.unmodifiableList(vuelos);
    }

	public List<Vuelo> getVuelosPendientesAterrizar(){
		List<Vuelo> vuelosPendientes = new ArrayList<>();
		for (Vuelo vuelo : vuelos) {
			if (vuelo.getEstado() == EstadosVuelo.ESPERANDO_PISTA_ATERRIZAJE || vuelo.getEstado() == EstadosVuelo.ESPERANDO_ATERRIZAR) {
				vuelosPendientes.add(vuelo);
			}
			if(vuelo.getEstado() == EstadosVuelo.OPERATIVO){
				if (vuelo.getDestino().equals(Aplicacion.init("").getAeropuertoPropio())) {
					vuelosPendientes.add(vuelo);
				}
			}
			if (vuelo.getFecha().isBefore(Aplicacion.init("").getRealTime().toLocalDate())) {
				if (vuelo.getEstado() == EstadosVuelo.APROBADO && vuelo.getDestino().equals(Aplicacion.init("").getAeropuertoPropio())) {
					vuelosPendientes.add(vuelo);
				}
			}
		}
		return Collections.unmodifiableList(vuelosPendientes);
	}

	public List<Vuelo> getVuelosPendientesDespegar(){
		List<Vuelo> vuelosPendientes = new ArrayList<>();
		for (Vuelo vuelo : vuelos) {
			if (vuelo.getEstado() == EstadosVuelo.EN_HANGAR || vuelo.getEstado() == EstadosVuelo.ESPERANDO_PISTA_DESPEGUE
			 || vuelo.getEstado() == EstadosVuelo.ESPERANDO_DESPEGUE || vuelo.getEstado() == EstadosVuelo.EN_COLA) {
				vuelosPendientes.add(vuelo);
			}
			if(vuelo.getEstado() == EstadosVuelo.OPERATIVO){
				if (vuelo.getOrigen().equals(Aplicacion.init("").getAeropuertoPropio())) {
					vuelosPendientes.add(vuelo);
				}
			}
			if (vuelo.getHoraSalida().minusMinutes(75).isBefore(Aplicacion.init("").getRealTime().toLocalTime())
			 && vuelo.getFecha().isEqual(Aplicacion.init("").getRealTime().toLocalDate())) {
				if (vuelo.getEstado() == EstadosVuelo.APROBADO && vuelo.getOrigen().equals(Aplicacion.init("").getAeropuertoPropio())) {
					vuelosPendientes.add(vuelo);
				}
			}
			if (vuelo.getFecha().isBefore(Aplicacion.init("").getRealTime().toLocalDate())) {
				if (vuelo.getEstado() == EstadosVuelo.APROBADO && vuelo.getOrigen().equals(Aplicacion.init("").getAeropuertoPropio())) {
					vuelosPendientes.add(vuelo);
				}
			}
		}
		return Collections.unmodifiableList(vuelosPendientes);
	}

	@Override
	public String toString() {
		return super.toString() + " Controlador Aéreo: " + (terminal != null ? terminal.getNombre() : "Ninguna");
	}
}