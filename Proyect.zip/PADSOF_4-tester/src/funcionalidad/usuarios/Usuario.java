package funcionalidad.usuarios;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.aplicacion.Notificacion;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Usuario implements Serializable {
    private static int ID = 0;
    private int idUsario;
    private String nombreDeUsuario;
    private String dni;
    private String nombre;
    private String email;
    private String contrasena;
    private List<Notificacion> notificaciones;
    private Boolean primerLogin;

    private Rol rol;

    public Usuario(String nombreDeUsuario, String dni, String nombre, String email, String contrasena, Rol rol) {                                                
        Usuario.ID++;
        this.idUsario = Usuario.ID;
        this.nombreDeUsuario = nombreDeUsuario;
        this.dni = dni;
        this.nombre = nombre;
        this.email = email;
        this.contrasena = contrasena;
        this.notificaciones = new ArrayList<>();
        this.rol = rol;
        this.primerLogin = true;
    }

    public Boolean checkRol(Rol rol){
        return this.rol.equals(rol);
    }

    public String getNombreUsuario() {
        return this.nombreDeUsuario;
    }

    public String getDNI() {
        return this.dni;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getEmail() {
        return this.email;
    }

    public Boolean getPrimerLogin(){
        return this.primerLogin;
    }

    public void setPrimerLogin(){
        this.primerLogin = false;
    }

    public Boolean setContraseña(String contrasena) {
        if (!Aplicacion.init("").getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if (this.contrasena.equals("")) return false;
        this.contrasena = contrasena;
        return true;
    }

    /* Si el usuario logueado no es el mismo al que se intenta cambiar la contraseña, no se puede cambiar. */
    public boolean cambiarContrasena (String contraseñaActual, String nuevaContrasena) {  
        if (!Aplicacion.init("").getUsuarioLogueado().equals(this)) return false;
        if (!contraseñaActual.equals(this.contrasena)) return false;                                 
        this.contrasena = nuevaContrasena;
        System.out.println("Contraseña cambiada con éxito, nueva contraseña: " + this.contrasena + ".");
        return true;
    }

    public boolean comprobarContrasena (String contrasena) {
        return (contrasena.equals (this.contrasena));
    }

    public Boolean añadirNotificacion(Notificacion notificacion){
        this.notificaciones.add(notificacion);
        return true;
    }

    public List<Notificacion> getNotificacion(){
        return Collections.unmodifiableList(notificaciones);
    }

    public List<Notificacion> getNotificacionNoLeidas(){
        List<Notificacion> notis = new ArrayList<>();

        for (Notificacion n: this.notificaciones) {
            if(!n.getLeida()){
                notis.add(n);
                n.marcarComoLeida();
            }
        }

        return  Collections.unmodifiableList(notis);
    }

    @Override
    public String toString() {
        return "Nombre de usuario: " + nombreDeUsuario + ", DNI: " + dni + ", Nombre: "
                + nombre + ", Email: " + email + ", Rol: " + rol + ".\n";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((nombreDeUsuario == null) ? 0 : nombreDeUsuario.hashCode());
        result = prime * result + ((dni == null) ? 0 : dni.hashCode());
        result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
        result = prime * result + ((contrasena == null) ? 0 : contrasena.hashCode());
        result = prime * result + ((rol == null) ? 0 : rol.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        return true;
        if (obj == null)
        return false;
        if (getClass() != obj.getClass())
        return false;
        Usuario other = (Usuario) obj;
        System.out.println("Usuario " + this.nombreDeUsuario + " y " + other.nombreDeUsuario + " son iguales.");
        if (nombreDeUsuario == null) {
            if (other.nombreDeUsuario != null)
            return false;
        } else if (!nombreDeUsuario.equals(other.nombreDeUsuario))
        return false;
        if (dni == null) {
            if (other.dni != null)
                return false;
        } else if (!dni.equals(other.dni))
            return false;
        if (nombre == null) {
            if (other.nombre != null)
                return false;
        } else if (!nombre.equals(other.nombre))
            return false;
        if (contrasena == null) {
            if (other.contrasena != null)
                return false;
        } else if (!contrasena.equals(other.contrasena))
            return false;
        if (rol != other.rol)
            return false;


        return true;
    }

    

    
}