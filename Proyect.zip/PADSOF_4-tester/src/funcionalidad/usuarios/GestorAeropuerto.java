package funcionalidad.usuarios;

public class GestorAeropuerto extends Usuario {
	private static GestorAeropuerto instance;

	private GestorAeropuerto (String nombreDeUsuario, String dni, String nombre, String email, String contrasena) {
		super (nombreDeUsuario, dni, nombre, email, contrasena, Rol.GESTORAEROPUERTO);
	}
	
	public static GestorAeropuerto init(String nombreDeUsuario, String dni, String nombre, String email, String contrasena) {
		if (instance == null) {
			instance = new GestorAeropuerto (nombreDeUsuario, dni, nombre, email, contrasena);
		}
		return instance;
	}
}
