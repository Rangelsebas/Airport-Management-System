package funcionalidad.vuelo;
import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.Rol;
import java.io.Serializable;

public class Ocupacion implements Serializable {
    private Aerolinea aerolineaSolicitante;
    private int porcentajeAsientos;
    private EstadoSolicitud estado;

    public Ocupacion(Aerolinea aerolinea, int porcentaje, EstadoSolicitud estadoSolicitud) {

        if (aerolinea == null || porcentaje < 0 || porcentaje > 100 || estadoSolicitud == null) {
            throw new IllegalArgumentException("Parámetros inválidos en Ocupacion");
        }
        

        this.aerolineaSolicitante = aerolinea;
        this.porcentajeAsientos = porcentaje;
        this.estado = estadoSolicitud;
        
    }

    private Boolean checkLog(Rol rol, Aplicacion app){
        if (app.getUsuarioLogueado() == null) return false;
        return app.getUsuarioLogueado().checkRol(rol);
    }

    /* GETTERS */

    public Aerolinea getAerolineaSolicitante() {
        return aerolineaSolicitante;
    }

    public int getPorcentajeAsientos() {
        return porcentajeAsientos;
    }

    public EstadoSolicitud getEstado() {
        return estado;
    }

    public Boolean setNuevoPorcentaje(int porcentaje){
        Aplicacion app = Aplicacion.init("acceder");

        if (!checkLog(Rol.OPERADORAEROLINEA, app) && !checkLog(Rol.GESTORAEROPUERTO, app)) return false;
        this.porcentajeAsientos = porcentaje;
        return true;
    }

    /* FUNCIONES COMPLEMENTARIAS */

    public Boolean aprobar() {
        Aplicacion app = Aplicacion.init("acceder");

        if (!checkLog(Rol.OPERADORAEROLINEA, app) && !checkLog(Rol.GESTORAEROPUERTO, app)) return false;

        this.estado = EstadoSolicitud.APROBADA;
        return true;
    }


    public boolean rechazar() {
        Aplicacion app = Aplicacion.init("acceder");
    
        if (!checkLog(Rol.OPERADORAEROLINEA, app) && !checkLog(Rol.GESTORAEROPUERTO, app)) return false;
    
        this.estado = EstadoSolicitud.RECHAZADA;
        return true;
    }

    /* OTRAS */
    @Override
    public String toString() {
        return "Aerolínea Solicitante: " + 
            (aerolineaSolicitante != null ? aerolineaSolicitante.getNombre() : "No asignada") +
            " | Porcentaje de Asientos: " + porcentajeAsientos + 
            " | Estado de la Ocupacion: " + estado;
    }

}
