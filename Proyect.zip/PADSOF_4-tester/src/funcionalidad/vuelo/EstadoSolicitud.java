package funcionalidad.vuelo;
public enum EstadoSolicitud {
    PENDIENTE, APROBADA, RECHAZADA
}