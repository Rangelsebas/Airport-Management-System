package funcionalidad.vuelo;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aeropuerto.Aeropuerto;
import funcionalidad.aeropuerto.elementos.*;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.Factura;
import funcionalidad.otro.ElementosFacturables;
import funcionalidad.otro.Uso;
import funcionalidad.usuarios.OperadorAerolinea;
import funcionalidad.usuarios.Rol;
import funcionalidad.usuarios.Usuario;
import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Vuelo implements Serializable {
    private String codigoVuelo;
    private Aeropuerto origen;
    private Aeropuerto destino;
    private LocalTime horaSalida;
    private LocalTime horaLlegada;
    private LocalDate fecha;
    private Boolean enTiempo;

    /* Referencias */
    private Aerolinea aerolineOperadora;
    private EstadosVuelo estado;
    private List<Ocupacion> ocupaciones;
    private List<Aerolinea> aerolineas;
    private Avion avion;
    private Usuario controladorAereo;
    private Boolean cobrado;
    private Pista pistaAsignada;
    private List<ElementoAeropuerto> usoTemporal;
    private Map<ElementosFacturables, LocalTime> comienzoUso;
    private Map<ElementosFacturables, LocalTime> finUso;
    private Map<ElementosFacturables, ElementoFacturable> elementosUsados; // -> Facturas
    private Terminal terminalAsignada;
    private List<Factura> facturas;
    private Factura facturaACobrar;

    private LocalDateTime horasUso;

    public Vuelo(Aeropuerto origen, Aeropuerto destino, LocalTime horaSalida, LocalTime horaLlegada, LocalDate fecha, Aerolinea aerolinea, Avion avion, int numeroVuelo) {
        if (origen == null || destino == null || horaSalida == null || horaLlegada == null || fecha == null ||
            aerolinea == null || avion == null) {

            throw new IllegalArgumentException("Los parámetros no pueden ser nulos o vacíos.");
        }

        if (horaLlegada.isBefore(horaSalida)) {
            throw new IllegalArgumentException("La hora de llegada no puede ser anterior a la hora de salida.");
        }

        this.codigoVuelo = generarCodigoVueloUnico(aerolinea.getCodigo(), numeroVuelo);
        this.origen = origen;
        this.destino = destino;
        this.horaSalida = horaSalida;
        this.horaLlegada = horaLlegada;
        this.fecha = fecha;
        this.enTiempo = true;
        this.estado = EstadosVuelo.PENDIENTE;
        this.usoTemporal = new ArrayList<>();
        this.comienzoUso = new HashMap<>();
        this.finUso = new HashMap<>();
        this.facturas = new ArrayList<>();
        this.facturaACobrar = null;

        /* Ocupacion */
        this.ocupaciones = new ArrayList<>();
        this.ocupaciones.add(new Ocupacion(aerolinea, 100, EstadoSolicitud.PENDIENTE)); // Ocupacion al maximo

        /* Aerolinea */
        this.aerolineOperadora = aerolinea;
        this.aerolineas = new ArrayList<>();
        this.aerolineas.add(aerolinea);

        /* Avion */
        this.avion = avion;
        /* Controlador */
        this.controladorAereo = null; // Se asigna luego
        
        /* Factura */
        this.cobrado = false;

        /* Elementos */
        this.elementosUsados = new HashMap<>();
    }

    /* CODIGO VUELO */
    private static String generarCodigoVueloUnico(String codigo, int numeroVuelo) {
        return codigo + String.format("%05d", numeroVuelo);
    }

    private Boolean checkLog(Rol rol, Aplicacion app){
        if (app.getUsuarioLogueado() == null) return false;
        return app.getUsuarioLogueado().checkRol(rol);
    }


    /*----RELACIONES----*/

    /* AEROLINEA */
    public boolean vincularAerolinea(Aerolinea aerolinea) {
        if (aerolinea == null) return false;

        if(this.aerolineas.contains(aerolinea)) return true;

        aerolineas.add(aerolinea);
        aerolinea.vincularVuelo(this);
        return true;
    }
    
    /* Por qué es necesario? */
    public boolean desvincularAerolinea(Aerolinea aerolinea) {
        if (aerolinea == null) return false;
    
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.OPERADORAEROLINEA, app)) return false;
    
        if (aerolineas.contains(aerolinea)) {
            aerolineas.remove(aerolinea);
            aerolinea.desvincularVuelo(this);
            return true;
        }
    
        return false;
    }

    public Boolean añadirFactura(Factura factura){
        if (factura == null) return false;
        if (facturas.contains(factura)) return true;

        facturas.add(factura);
        return true;
    }

    public void setFacturaACobrar(Factura factura){
        this.facturaACobrar = factura;
    }

    public Factura getFacturaACobrar(){
        return this.facturaACobrar;
    }
    

    
    /* CONTROLADOR */
    public boolean vincularControlador(Usuario controladorAereo) {
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.GESTORAEROPUERTO, app)) return false;

        if (controladorAereo == null) return false;
        if (this.controladorAereo == null) {
            this.controladorAereo = controladorAereo;
            return true;
        }
    
        return false;
    }
    
    public boolean desvincularControlador() {
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.CONTROLADORAEREO, app)) return false;
    
        this.controladorAereo = null;
        return true;
    }    

    public boolean vueloCobrado(){
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.GESTORAEROPUERTO, app)) return false;

        this.cobrado = true;
        return true;
    }

    /* GETTERS */
    public String getCodigoVuelo(){
        return this.codigoVuelo;
    }

    public Aeropuerto getOrigen(){
        return this.origen;
    }

    public Aeropuerto getDestino() {
        return this.destino;
    }

    public LocalTime getHoraSalida() {
        return this.horaSalida;
    }

    public LocalTime getHoraLlegada() {
        return this.horaLlegada;
    }

    public LocalDate getFecha() {
        return this.fecha;
    }

    public Boolean getEnTiempo() {
        return this.enTiempo;
    }

    public EstadosVuelo getEstado() {
        return this.estado;
    }

    public List<Ocupacion> getOcupaciones() {
        return Collections.unmodifiableList(ocupaciones);
    }

    public Aerolinea getAerolineaOperadora() {
        return this.aerolineOperadora; // La primera aerolínea es la operadora
    }

    public List<Aerolinea> getAerolineas() {
        return Collections.unmodifiableList(aerolineas);
    }

    public Avion getAvion() {
        return this.avion;
    }

    public Usuario getControladorAereo() {
        return this.controladorAereo;
    }

    public Terminal getTerminalAsignada() {
        return this.terminalAsignada;
    }

    public Boolean askCobrado() { // true es sí
        return this.cobrado;
    }

    public LocalDateTime getHorasUso() {
        return this.horasUso;
    }

    public int getParticipacionAerolinea(Aerolinea aerolinea) {
        for (Ocupacion ocupacion : this.ocupaciones) {
            if (ocupacion.getAerolineaSolicitante().equals(aerolinea)) {
                return ocupacion.getPorcentajeAsientos();
            }
        }
        return 0;
    }

    public ElementoFacturable getElementoEspecifico(ElementosFacturables tipoElemento){
        if (tipoElemento == null) return null;
        if (!this.elementosUsados.containsKey(tipoElemento)) return null;
        return this.elementosUsados.get(tipoElemento);
    }

    public List<ElementoFacturable> getAllElementosFacturable(){
        return Collections.unmodifiableList(new ArrayList<>(this.elementosUsados.values()));
    }

    public long getMinutosUso(ElementosFacturables tipoElemento) {
        LocalTime inicio = comienzoUso.get(tipoElemento);
        LocalTime fin = finUso.get(tipoElemento);
        
        if (inicio == null || fin == null) {
            throw new IllegalArgumentException("El elemento no tiene tiempos registrados.");
        }
        
        long minutos;
        // Si el fin es anterior al inicio, significa que se ha cruzado la medianoche.
        if (fin.isBefore(inicio)) {
            minutos = Duration.between(inicio, fin.plusHours(24)).toMinutes();
        } else {
            minutos = Duration.between(inicio, fin).toMinutes();
        }
        
        return minutos;
    }
    
    public Boolean avionDisponibleParaVuelo() {
        return this.avion.isDisponible();
    }

    public Boolean cambiarAvion(Avion avion) {
        if (avion == null) return false;
        if (this.avion.equals(avion)) return false;
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.OPERADORAEROLINEA, app)) return false;
        if (!app.getUsuarioLogueado().equals(this.getAerolineaOperadora().getOperadorAerolinea())) return false;

        this.avion = avion;
        return true;
    }

    public CategoriaAvion getTipoCarga(){
        return this.avion.getCategoria();
    }

    public int getCantidadCarga(){
        return this.avion.getTipoAvion().getCapacidad();
    }

    /* FUNCIONES COMPLEMENTARIAS */
    
    private Boolean asignarPista(Pista pista) throws IllegalStateException {
        if (pista == null) return false;
    
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.CONTROLADORAEREO, app)) return false;

        try {
            pista.ocupar(this);
        } catch (Exception e) {
            throw e;
        }

        this.pistaAsignada = pista;
        return true;
    }       
    
    public Boolean asignarFinger(Finger finger){
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.CONTROLADORAEREO, app)) return false;
        this.elementosUsados.put(ElementosFacturables.FINGER, finger);
        this.comienzoUso.put(ElementosFacturables.FINGER, app.getRealTime().toLocalTime());
        finger.ocupar(this);
        return true;
    }

    /*----ESTADOS LLEGADA----*/
    /* metodo que solo deberia llamar app a efectos de simulacion */
    public void enEspacioAereo(){
        this.estado = EstadosVuelo.ESPERANDO_PISTA_ATERRIZAJE;
    }

    public Boolean asignarPistaCambioEstado(Pista pista) throws IllegalArgumentException, IllegalStateException {
        if (pista == null) {
            throw new IllegalArgumentException("La pista no puede ser null.");
        }
        if (this.estado != EstadosVuelo.ESPERANDO_PISTA_ATERRIZAJE) return false;
        if (pista.getUso() != Uso.ATERRIZAJE) return false;

        Aplicacion app = Aplicacion.init("acceder");

        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.controladorAereo)) return false;

        try {
            asignarPista(pista);
        } catch (Exception e) {
            throw e;
        }

        this.estado = EstadosVuelo.ESPERANDO_ATERRIZAR;

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);

        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha recibido una pista y está esperando aterrizar.");

        return true;
    }

    public Boolean autorizarAterrizajeCambioEstado(Aparcamiento aparcamiento, Puerta puerta) throws IllegalArgumentException {
        if (this.estado != EstadosVuelo.ESPERANDO_ATERRIZAR) return false;

        Aplicacion app = Aplicacion.init("acceder");

        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.controladorAereo)) return false;

        this.pistaAsignada.liberar(this);

        if (this.terminalAsignada.ocupar(this)) {
            this.usoTemporal.add(terminalAsignada);
        }
        else{
            throw new IllegalArgumentException("Terminal llena en este momento.");
        } 

        this.usoTemporal.removeFirst().liberar(this);
        System.out.println("\nAterrizaje autorizado. Estado actualizado a ATERRIZADO.");

        //TODO gestionar ocupar del aparcamiento
        aparcamiento.ocupar(this);
        this.elementosUsados.put(ElementosFacturables.APARCAMIENTO, aparcamiento);
        this.comienzoUso.put(ElementosFacturables.APARCAMIENTO, app.getRealTime().toLocalTime());

        this.estado = EstadosVuelo.ATERRIZADO;

        try {
            puerta.ocupar(this);
        } catch (Exception e) {
            throw e;
        }
        
        this.elementosUsados.put(ElementosFacturables.PUERTA, puerta);
        this.comienzoUso.put(ElementosFacturables.PUERTA, app.getRealTime().toLocalTime());
        
        if (this.avion.getCategoria() == CategoriaAvion.PASAJEROS) {
            if(!puerta.usarFinger(this)) {
                for (int i = 0; i < this.getAvion().getTipoAvion().getCapacidad(); i++) {
                    Bus bus = terminalAsignada.getBusDisponible();
                    this.usoTemporal.add(bus);
                    i += bus.getCapacidad();
                }
            }
        }

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);

        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha aterrizado exitosamente.");


        return true;
    }

    public Boolean iniciarDescargaCambioEstado() {
        Aplicacion app = Aplicacion.init("acceder");

        // 1. Verificar que el estado actual sea ATERRIZADO
        if (this.estado != EstadosVuelo.ATERRIZADO) return false;

        // 2. Verificar que el usuario logueado sea operador de aerolínea
        if (!app.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA)) return false;

        // 3. Validar que sea el operador asignado a la aerolínea operadora
        if (!app.getUsuarioLogueado().equals(this.getAerolineaOperadora().getOperadorAerolinea())) return false;

        // Registrar hora de inicio de la operación
        this.horasUso = app.getRealTime();

        // 4. Verificar tipo de avión para asignar nuevo estado
        switch (this.avion.getCategoria()) {
            case CategoriaAvion.PASAJEROS:
                this.estado = EstadosVuelo.DESEMBARCANDO;
                break;
            case CategoriaAvion.MERCANCIAS:
                this.estado = EstadosVuelo.DESCARGANDO;
                break;
            default:
                return false;
        }

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);

        if (this.avion.getCategoria() == CategoriaAvion.PASAJEROS) {
            app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha comenzado el desembarque");
        }
        else {
            app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha comenzado la descarga");
        }
      
        return true;
    }

    public Boolean descargaFinalizadaCambioEstado() {
        Aplicacion app = Aplicacion.init("acceder");

        if (this.estado != EstadosVuelo.DESCARGANDO && this.estado != EstadosVuelo.DESEMBARCANDO) return false;
        if (!app.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA)) return false;
        if (!app.getUsuarioLogueado().equals(this.getAerolineaOperadora().getOperadorAerolinea())) return false;

        this.estado = EstadosVuelo.OPERATIVO;

        // Verificación de tiempo mínimo de operación
        if (this.horasUso == null) return false;

        long minutosMinimos = this.estado == EstadosVuelo.DESEMBARCANDO ? 29 : 14;
        if (app.getRealTime().isBefore(this.horasUso.plusMinutes(minutosMinimos))) {
            return false;
        }

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);

        if (this.avion.getCategoria() == CategoriaAvion.PASAJEROS) {
            app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha finalizado el desembarque");
        }
        else {
            app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha finalizado la descarga");
        }

        return true;
    }

    public Boolean mantenerAvionOperativo(){
        Aplicacion app = Aplicacion.init("acceder");
        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.controladorAereo)) return false;

        if (this.estado != EstadosVuelo.OPERATIVO) return false;

        liberarTodo();    

        this.estado = EstadosVuelo.FINALIZADO;
        this.avion.setDisponible(true);

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);

        app.nuevaNotificacion(receptores, "El vuelo " + this.codigoVuelo + " ha finalizado.");
        app.nuevaNotificacion(receptores, "El avión " + this.getAvion().getMatricula() + " ahora se encuentra operativo y disponible");

        return true;
    }

    public Boolean guardarAvionEnHangar(Hangar hangar){
        Aplicacion app = Aplicacion.init("acceder");
        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.controladorAereo)) return false;

        if (this.estado != EstadosVuelo.OPERATIVO) return false;

        this.estado = EstadosVuelo.FINALIZADO;
        this.avion.setDisponible(true);

        liberarTodo();    
        hangar.guardarAvion(this.getAvion());

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);
        app.nuevaNotificacion(receptores, "El avión " + this.getAvion().getMatricula() + " ahora se encuentra en el hangar: " + hangar.getNombre());

        return true;
    }

    /*----ESTADOS SALIDA----*/
    public Boolean sacarAvionHangar() {
        Aplicacion app = Aplicacion.init("acceder");

        if (this.estado != EstadosVuelo.EN_HANGAR && this.estado != EstadosVuelo.APROBADO) return false;
        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.getControladorAereo())) return false;
        
        this.estado = EstadosVuelo.OPERATIVO;
        Hangar hangar = app.getAeropuertoPropio().buscarAvionEnHangar(this.getAvion().getMatricula());
        if (hangar == null) return false; // el avion no estaba en hangar
        hangar.sacarAvion(this.getAvion());

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);
        app.nuevaNotificacion(receptores, "El avion: " + this.getAvion().getMatricula() + " está disponible y operativo.");        

        return true;
    }

    public Boolean moverAvionAAparcamiento(Aparcamiento aparcamiento, Puerta puerta) throws IllegalArgumentException {
        Aplicacion app = Aplicacion.init("acceder");
    
        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.getControladorAereo())) return false;
        if (this.estado != EstadosVuelo.OPERATIVO) return false;

        if (this.terminalAsignada.ocupar(this)) {
            this.usoTemporal.add(terminalAsignada);
        }
        else{
            throw new IllegalArgumentException("Terminal llena en este momento.");
        } 
        
        if(!aparcamiento.ocupar(this)){
            this.usoTemporal.removeFirst().liberar(this);
            throw new IllegalArgumentException("El aparcamiento está al máximo.");
        } 
        
        this.elementosUsados.put(ElementosFacturables.APARCAMIENTO, aparcamiento);
        this.comienzoUso.put(ElementosFacturables.APARCAMIENTO, app.getRealTime().toLocalTime());
        
        if(!puerta.ocupar(this)){
            this.usoTemporal.removeFirst().liberar(this);
            aparcamiento.liberar(this);
            this.elementosUsados.remove(ElementosFacturables.APARCAMIENTO);
            this.comienzoUso.remove(ElementosFacturables.APARCAMIENTO);
            throw new IllegalArgumentException("La puerta está ocupada.");
        } 
        
        this.estado = EstadosVuelo.EN_APARCAMIENTO;
        this.elementosUsados.put(ElementosFacturables.PUERTA, puerta);
        this.comienzoUso.put(ElementosFacturables.PUERTA, app.getRealTime().toLocalTime());
        
        if (this.avion.getCategoria() == CategoriaAvion.PASAJEROS) {
            if(!puerta.usarFinger(this)) {
                for (int i = 0; i < this.getAvion().getTipoAvion().getCapacidad(); i++) {
                    Bus bus = terminalAsignada.getBusDisponible();
                    this.usoTemporal.add(bus);
                    i += bus.getCapacidad();
                }
            }
        }
    
        List<Usuario> receptores = new ArrayList<>();
        for (Aerolinea aerolinea : this.getAerolineas()) {
            receptores.add(aerolinea.getOperadorAerolinea());
        }
        receptores.add(this.controladorAereo);
        app.nuevaNotificacion(receptores, "El avión está listo para la preparación.");
    
        return true;
    }    

    public Boolean pasarAPreparacionCambioEstado(){
        Aplicacion app = Aplicacion.init("acceder");
        if (!app.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA)) return false;
        if (!app.getUsuarioLogueado().equals(this.getAerolineaOperadora().getOperadorAerolinea())) return false;

        if (this.estado != EstadosVuelo.EN_APARCAMIENTO) return false;
        this.estado = EstadosVuelo.EN_PREPARACION;
        
        // Registrar hora de inicio de uso
        this.horasUso = app.getRealTime();

        this.avion.setDisponible(false);

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        for (Aerolinea aerolinea : this.getAerolineas()) {
            receptores.add(aerolinea.getOperadorAerolinea());
        }
        receptores.add(this.controladorAereo);
        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha iniciado la preparacion.");

        return true;
    }


    public Boolean iniciarEmbarqueCambioEstado() {
        Aplicacion app = Aplicacion.init("acceder");
    
        if (this.estado != EstadosVuelo.EN_PREPARACION) return false;
    
        if (!app.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA)) return false;
        if (!app.getUsuarioLogueado().equals(this.getAerolineaOperadora().getOperadorAerolinea())) return false;

        // Verifica que hayan pasado al menos 30 minutos desde horasUso
        if (this.horasUso == null || app.getRealTime().isBefore(this.horasUso.plusMinutes(29))) {
            return false;
        }

        if (this.avion.getCategoria() != CategoriaAvion.PASAJEROS) return false;
        
        this.estado = EstadosVuelo.EMBARCANDO;

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);

        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha iniciado el embarque.");

        return true;
    }

    public Boolean iniciarCargaCambioEstado() {
        Aplicacion app = Aplicacion.init("acceder");
    
        if (this.estado != EstadosVuelo.EN_PREPARACION) return false;
    
        // Verifica que hayan pasado al menos 15 minutos desde horasUso
        if (this.horasUso == null || app.getRealTime().isBefore(this.horasUso.plusMinutes(14))) {
            return false;
        }

        if (!app.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA)) return false;
        if (!app.getUsuarioLogueado().equals(this.getAerolineaOperadora().getOperadorAerolinea())) return false;
    
        if (this.avion.getCategoria() != CategoriaAvion.MERCANCIAS) return false;

        this.estado = EstadosVuelo.CARGANDO;

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);
        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha iniciado la carga de mercancía.");

        return true;
    }

    public Boolean embarqueFinalizadoCambioEstado() {
        Aplicacion app = Aplicacion.init("acceder");
    
        if (this.estado != EstadosVuelo.EMBARCANDO && this.estado != EstadosVuelo.CARGANDO) return false;
    
        if (!app.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA)) return false;
        if (!app.getUsuarioLogueado().equals(this.getAerolineaOperadora().getOperadorAerolinea())) return false;
    
        this.estado = EstadosVuelo.ESPERANDO_PISTA_DESPEGUE;


        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);
        receptores.add(this.controladorAereo);
    
        if (this.avion.getCategoria() == CategoriaAvion.PASAJEROS) {
            app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha finalizado el embarque");
        }
        else {
            app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha finalizado el proceso de carga");
        }

        return true;
    }
    
    public Boolean asignarPistaDespegueCambioEstado(Pista pista) throws IllegalArgumentException {
        if (pista == null) throw new IllegalArgumentException("La pista no puede ser null.");
        if (this.estado != EstadosVuelo.ESPERANDO_PISTA_DESPEGUE) return false;
        if (pista.getUso() != Uso.DESPEGUE) return false;
    
        Aplicacion app = Aplicacion.init("acceder");
    
        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.controladorAereo)) return false;

        // Añadir a la cola y reorganizar
        if (!pista.añadirVueloACola(this)) return false;
        pista.reorganizarCola();

        this.usoTemporal.add(pista);    
        this.pistaAsignada = pista;
        this.estado = EstadosVuelo.EN_COLA;

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);

        app.nuevaNotificacion(receptores, "Se ha asignado una pista para el despegue del vuelo " + this.codigoVuelo + " y se encuentra en la cola.");

        return true;
    }

    public Boolean sacarPrimeroDeCola() throws IllegalArgumentException, IllegalStateException {
        if (this.estado != EstadosVuelo.EN_COLA) return false;
    
        Aplicacion app = Aplicacion.init("acceder");
    
        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.controladorAereo)) return false;

        // Validar que el vuelo sea el primero en la cola
        if (!this.equals(this.pistaAsignada.verPrimeroDeCola())) throw new IllegalArgumentException("El vuelo no es el primero en la cola.");
        
        // Validar que la pista esté disponible
        try {
            if(!this.pistaAsignada.ocupar(this))
                throw new IllegalArgumentException("Error inesperado.");
        } catch (Exception e) {
            throw e;
        }
        // Sacar el vuelo de la cola
        
        this.estado = EstadosVuelo.ESPERANDO_DESPEGUE;

        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);
        
        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " está esperando autorización de despegue.");

        return true;
    }
    

    public Boolean autorizarDespegueCambioEstado() {
        if (this.estado != EstadosVuelo.ESPERANDO_DESPEGUE) return false;
    
        Aplicacion app = Aplicacion.init("acceder");
    
        if (!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!app.getUsuarioLogueado().equals(this.controladorAereo)) return false;
    
        // Autorizar despegue y liberar recursos
        this.estado = EstadosVuelo.VOLANDO;
        this.avion.setDisponible(false);
        this.pistaAsignada.sacarPrimeroDeCola();
        this.usoTemporal.removeFirst().liberar(this);

        liberarTodo();
    
        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);
        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha sido autorizado para despegar y se encuentra en vuelo.");

        aerolineOperadora.añadirHistoricoDeVuelo(this);
    
        return true;
    }


    /*---- METODOS AUXILIARES----*/

    public Boolean solicitarVueloCompartido(int porcentaje) {
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.OPERADORAEROLINEA, app)) return false;
        
        Aerolinea aerolineaSolicitante = ((OperadorAerolinea)app.getUsuarioLogueado()).getAerolinea();
        System.out.println("🚀 Solicitud de vuelo compartido: " + this.codigoVuelo + " Aerolinea solicitante:" + aerolineaSolicitante.getNombre());
        
        // El usuario debe ser el operador de la aerolínea solicitante
        if (!app.getUsuarioLogueado().equals(aerolineaSolicitante.getOperadorAerolinea())) return false;
        
        if (aerolineaSolicitante.equals(getAerolineaOperadora())) return false;
        if (porcentaje <= 0 || porcentaje > 50) return false;

        Ocupacion nueva = new Ocupacion(aerolineaSolicitante, porcentaje, EstadoSolicitud.PENDIENTE);
        ocupaciones.add(nueva);

        // Notificacion
        List<Usuario> re = new ArrayList<>();
        re.add(this.getAerolineaOperadora().getOperadorAerolinea());
        app.nuevaNotificacion(re, "Nueva solicitud de compartir para tu vuelo con codigo: " + this.codigoVuelo + " de parte de " + aerolineaSolicitante.getNombre());
        return true;
    }

    public Boolean aceptarVueloCompartido(Ocupacion ocupacion) {
        if (ocupacion == null) return false;

        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.OPERADORAEROLINEA, app)) return false;

        // El usuario debe ser operador de la aerolínea **operadora del vuelo**
        if (!app.getUsuarioLogueado().equals(getAerolineaOperadora().getOperadorAerolinea())) return false;

        if (!ocupacion.getEstado().equals(EstadoSolicitud.PENDIENTE)) return false;
        
        for (Ocupacion o : this.getOcupaciones()) {
            if (o.getAerolineaSolicitante().equals(getAerolineaOperadora())) {
                o.setNuevoPorcentaje(o.getPorcentajeAsientos() - ocupacion.getPorcentajeAsientos());
            }
            if (!o.getAerolineaSolicitante().equals(this.getAerolineaOperadora())){
                System.out.println("Entro");
                o.getAerolineaSolicitante().añadirVueloCompartido(this);
            }
            System.out.println(o.getAerolineaSolicitante().toString());
        }



        // Notificacion
        List<Usuario> re = new ArrayList<>();
        re.add(this.getAerolineaOperadora().getOperadorAerolinea());
        for (Ocupacion op : this.getOcupaciones()) {
            re.add(op.getAerolineaSolicitante().getOperadorAerolinea());
        }
        app.nuevaNotificacion(re, "Solicitud de compartir el vuelo con codigo: " + this.codigoVuelo + " de parte de " + getAerolineaOperadora().getNombre() + " ha sido aceptada");
        ocupacion.aprobar();
        return true;
    }

    public Boolean rechazarVueloCompartido(Ocupacion ocupacion){
        if (ocupacion == null) return false;

        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.OPERADORAEROLINEA, app)) return false;

        // El usuario debe ser operador de la aerolínea **operadora del vuelo**
        if (!app.getUsuarioLogueado().equals(getAerolineaOperadora().getOperadorAerolinea())) return false;

        if (!ocupacion.getEstado().equals(EstadoSolicitud.PENDIENTE)) return false;

        ocupacion.rechazar();

        // Notificacion
        List<Usuario> re = new ArrayList<>();
        re.add(this.getAerolineaOperadora().getOperadorAerolinea());
        for (Ocupacion op : this.getOcupaciones()) {
            re.add(op.getAerolineaSolicitante().getOperadorAerolinea());
        }
        app.nuevaNotificacion(re, "Solicitud de compartir el vuelo con codigo: " + this.codigoVuelo + " de parte de " + getAerolineaOperadora().getNombre() + " ha sido rechazada");
        return true;
    }

    public List<Ocupacion> verSolicitudesVueloCompartido() {
        Aplicacion app = Aplicacion.init("acceder");

        // Verificar que el usuario tenga el rol adecuado
        if (!checkLog(Rol.OPERADORAEROLINEA, app)) return new ArrayList<>();

        // Verificar que sea el operador de la aerolínea operadora
        if (!app.getUsuarioLogueado().equals(getAerolineaOperadora().getOperadorAerolinea())) return new ArrayList<>();

        if (ocupaciones.isEmpty()) {
            System.out.println("🔍 No hay solicitudes de vuelo compartido registradas.");
            return new ArrayList<>();
        }
    
        System.out.println("📋 Listado de solicitudes de vuelo compartido:");
        for (Ocupacion ocupacion : ocupaciones) {
            System.out.println("✈ Aerolínea: " + ocupacion.getAerolineaSolicitante().getNombre() + 
                               " | Porcentaje: " + ocupacion.getPorcentajeAsientos() + "%" +
                               " | Estado: " + ocupacion.getEstado());
        }
        
        return ocupaciones;
    }

    /* Creo que deben ser funciones de aplicacion */
    public Boolean aprobarVuelo(Terminal terminal, Usuario controladorAereo) {
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.GESTORAEROPUERTO, app)) return false;
        if (terminal == null) return false;
    
        if (!vincularControlador(controladorAereo)) return false;
    
    
        if (this.estado == EstadosVuelo.CANCELADO || this.estado == EstadosVuelo.RECHAZADO) return false;
    
        // Asignación lógica (sin ocupar todavía)
        // Puedes guardar la terminal como referencia si tienes un atributo tipo:
        this.terminalAsignada = terminal;
    
        this.estado = EstadosVuelo.APROBADO;

        // Cambiar el estado de la Ocupacion
        for (Ocupacion ocupacion : this.ocupaciones) {
            if (ocupacion.getAerolineaSolicitante().equals(this.getAerolineaOperadora())) {
                ocupacion.aprobar(); // Esto ya valida internamente que sea el operador logueado
                break;
            }
        }
    
        // Notificación
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAerolineaOperadora().getOperadorAerolinea());
        receptores.add(this.controladorAereo);
        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha sido aprobado y está listo para continuar con el proceso.");

        aerolineOperadora.vincularVuelo(this);
        return true;
    }
    

    /* Lo pasa a pendiente de nuevo y deberá aprobarlo el gestor para añadir controlador y terminal */
    public Boolean aceptarVueloModificado(){
        Aplicacion app = Aplicacion.init("acceder");
    
        if (!checkLog(Rol.OPERADORAEROLINEA, app)) return false;
        if (!app.getUsuarioLogueado().equals(this.getAerolineaOperadora().getOperadorAerolinea())) return false;
        if(this.estado != EstadosVuelo.MODIFICADO) return false;

        this.estado = EstadosVuelo.PENDIENTE;
        List<Usuario> receptores = new ArrayList<>();
        Usuario gestor = app.getAeropuertoPropio().getGestorDelAeropuerto();
        if (gestor != null) {
            receptores.add(gestor);
        }
        app.nuevaNotificacion(receptores, "El vuelo: " + this.codigoVuelo + " ha sido modificado y está pendiente de aprobación nuevamente.");

        return true;
    }
    

    public Boolean rechazarVuelo(String motivo) {
        Aplicacion app = Aplicacion.init("acceder");
    
        if (!checkLog(Rol.GESTORAEROPUERTO, app)) return false;
    
        return rechazarVueloSistema(motivo);
    }    

    public Boolean rechazarVueloSistema(String motivo){
        Aplicacion app = Aplicacion.init("acceder");
    
        if (this.estado == EstadosVuelo.RECHAZADO || this.estado == EstadosVuelo.CANCELADO) return false;
    
        this.estado = EstadosVuelo.RECHAZADO;

        // Cambiar el estado de la Ocupacion
        for (Ocupacion ocupacion : this.ocupaciones) {
            if (ocupacion.getAerolineaSolicitante().equals(this.getAerolineaOperadora())) {
                ocupacion.rechazar();
                break;
            }
        }
    
        /* Poner el avion en la ubicacion previa */
        if (this.avion != null) {
            this.avion.invertirUbicacion(fecha);
        }

        /* Notificar */
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(app.getAeropuertoPropio().getGestorDelAeropuerto());
        for (Aerolinea aerolinea : this.getAerolineas()) {
            receptores.add(aerolinea.getOperadorAerolinea());
        }
        app.nuevaNotificacion(receptores, "El vuelo: "+ codigoVuelo + ", con fecha: " + fecha + " ha sido rechazado " + motivo);
    
        return true;
    }
    

    public boolean modificarVuelo(LocalTime nuevaSalida, LocalTime nuevaLlegada) {
        Aplicacion app = Aplicacion.init("acceder");
    
        if (!checkLog(Rol.GESTORAEROPUERTO, app)) return false;
    
        if (this.estado == EstadosVuelo.VOLANDO || this.estado == EstadosVuelo.CANCELADO) {
            return false;
        }
    
        this.horaSalida = nuevaSalida;
        this.horaLlegada = nuevaLlegada;
        this.estado = EstadosVuelo.MODIFICADO;
    
        return true;
    }

    private void liberarTodo(){
        Aplicacion app = Aplicacion.init("acceder");

        for (int i = this.usoTemporal.size() - 1; i >= 0; i--) {
            this.usoTemporal.get(i).liberar(this);
            this.usoTemporal.remove(i);
        }

        if (this.elementosUsados.getOrDefault(ElementosFacturables.APARCAMIENTO, null) != null) {
            this.elementosUsados.get(ElementosFacturables.APARCAMIENTO).liberar(this);
            this.finUso.put(ElementosFacturables.APARCAMIENTO, app.getRealTime().toLocalTime());
        }

        if(this.elementosUsados.getOrDefault(ElementosFacturables.PUERTA, null) != null) {
            this.elementosUsados.get(ElementosFacturables.PUERTA).liberar(this);
            this.finUso.put(ElementosFacturables.PUERTA, app.getRealTime().toLocalTime());
        }

        if (this.elementosUsados.getOrDefault(ElementosFacturables.FINGER, null) != null) {
            this.elementosUsados.get(ElementosFacturables.FINGER).liberar(this);
            this.finUso.put(ElementosFacturables.FINGER, app.getRealTime().toLocalTime());
        }       
    }

    /* OTRAS */
    // Este metodo solo deberia usarla app al actualizar
    public void setRetraso(){
        this.enTiempo = false;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Vuelo vuelo = (Vuelo) obj;
        return codigoVuelo.equals(vuelo.codigoVuelo);
    }

    @Override
    public int hashCode() {
        return codigoVuelo.hashCode();
    }

    @Override
    public String toString() {
        return "\n\nCódigo de Vuelo: " + this.codigoVuelo +
            " | Origen: " + this.origen.getNombre() +
            " | Destino: " + this.destino.getNombre() +
            " | Fecha: " + this.fecha +
            " | Hora de Salida: " + this.horaSalida +
            " | Hora de Llegada: " + this.horaLlegada +
            " | En Tiempo: " + this.enTiempo +
            " | Estado Del Vuelo: " + this.estado +
            " | Ocupaciones: " + ocupaciones.toString() +
            " | Aerolínea Operadora: " + getAerolineaOperadora().getNombre() +
            " | Avión: " + (avion != null ? avion.getMatricula() : "Sin asignar") +
            " | Controlador Aéreo: " + (controladorAereo != null ? controladorAereo.getNombreUsuario() : "No asignado") +
            " | Cobrado: " + (cobrado == true ? "sí" : "no") +
            " | Elementos Facturables Usados: " + elementosUsados.toString();
    }
}
