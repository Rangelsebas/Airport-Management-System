package funcionalidad.vuelo;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.Rol;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SolicitudRecurrente implements Serializable {
    private List<Vuelo> vuelos;
    private EstadoSolicitud estado;
    private String idSolicitud;

    public SolicitudRecurrente(int id){
        this.vuelos = new ArrayList<>();
        this.estado = EstadoSolicitud.PENDIENTE;
        this.idSolicitud = "SR" + id;
    }

    public Boolean añadirVuelo(Vuelo vuelo){
        Aplicacion aplicacion = Aplicacion.init("acceso");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA)) return false;
        this.vuelos.add(vuelo);
        return true;
    }

    public List<Vuelo> getVuelos() {
        return Collections.unmodifiableList(vuelos);
    }

    public String getIdSolicitud() {
        return idSolicitud;
    }

    public Boolean aprobarSolicitud(){
        Aplicacion aplicacion = Aplicacion.init("acceso");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        this.estado = EstadoSolicitud.APROBADA;
        return true;
    }

    public Boolean rechazarSolicitud(){
        Aplicacion aplicacion = Aplicacion.init("acceso");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        this.estado = EstadoSolicitud.RECHAZADA;
        return true;
    }

    public EstadoSolicitud getEstadoSolicitud(){
        return this.estado;
    }

    @Override
    public String toString() {
        return "SolicitudRecurrente con id: " + this.idSolicitud + "[vuelos=" + vuelos.size() + ", estado=" + estado + "]";
    }

    
}
