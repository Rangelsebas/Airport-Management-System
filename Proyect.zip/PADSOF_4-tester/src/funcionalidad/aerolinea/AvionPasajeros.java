package funcionalidad.aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.Rol;
import java.time.LocalDate;

public class AvionPasajeros extends Avion {

    private static final int MESES_MANTENIMIENTO = 6;

    public AvionPasajeros(LocalDate fechaCompra, LocalDate fechaUltimaRevision, TipoAvion tipoAvion, String matricula) {
        super(fechaCompra, fechaUltimaRevision, tipoAvion, matricula);
        if (tipoAvion == null || fechaCompra == null || fechaUltimaRevision == null || matricula == null || matricula.isEmpty()) {
            throw new IllegalArgumentException("El tipo de avión no puede ser nulo.");
        }
        if(!tipoAvion.getCategoria().equals(CategoriaAvion.PASAJEROS)) {
            throw new IllegalArgumentException("El tipo de avión no coincide con Pasajero");
        }
    }

    private Boolean checkLog(Rol rol, Aplicacion app){
        if (app.getUsuarioLogueado() == null) return false;
        return app.getUsuarioLogueado().checkRol(rol);
    }
    

    /* FUNCIONES COMPLEMENTARIAS */

    @Override
    public Boolean comprobarMantenimiento() {
        Aplicacion app = Aplicacion.init("acceder");
        LocalDate fechaActual = app.getRealTime().toLocalDate();
        LocalDate fechaProximaRevision = this.getFechaUltimaRevision().plusMonths(MESES_MANTENIMIENTO);

        return fechaProximaRevision.isBefore(fechaActual);
    }   

    @Override
    public CategoriaAvion getCategoria() {
        return CategoriaAvion.PASAJEROS;
    }


    /* PROPIO DE ESTA CLASE */

    public Boolean cargar(int pasajeros) {

        if (pasajeros < 0) {
            throw new IllegalArgumentException("El número de pasajeros no puede ser negativo.");
        }

        Aplicacion app = Aplicacion.init("acceder");

        if (!this.isDisponible()) {
            System.out.println("Error: El avión no está disponible.");
            return false;
        }

        // Validar que el usuario tenga permiso de control (puedes ajustar a otro rol si hace falta)
        if (!checkLog(Rol.CONTROLADORAEREO, app)) return false;
    
        // Verificar si hay suficiente capacidad en el avión
        if (pasajeros > this.getTipoAvion().getCapacidad()) {
            System.out.println("Error: El número de pasajeros excede la capacidad del avión.");
            return false;
        }
    
        System.out.println("Embarque exitoso. Pasajeros abordados: " + pasajeros);
        return true;
    }

    /* OTRAS */
    @Override
    public String toString() {
        return "Avión de Pasajeros -> " + super.toString();
    }    
}
