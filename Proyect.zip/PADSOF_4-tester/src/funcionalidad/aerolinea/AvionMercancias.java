package funcionalidad.aerolinea;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.Rol;
import java.time.LocalDate;

public class AvionMercancias extends Avion {
    private Boolean controlDeTemperatura;
    private Boolean permiteMaterialPeligroso;

    private static final int MESES_MANTENIMIENTO = 6;

    public AvionMercancias(LocalDate fechaCompra, LocalDate fechaUltimaRevision, TipoAvion tipoAvion, String matricula, Boolean controlDeTemperatura, Boolean permiteMaterialPeligroso) {
        super(fechaCompra, fechaUltimaRevision, tipoAvion, matricula);
        if (fechaCompra == null || fechaUltimaRevision == null || tipoAvion == null || matricula == null || matricula.isEmpty()) {
            throw new IllegalArgumentException("Ningún argumento puede ser nulo.");
        }

        if(!tipoAvion.getCategoria().equals(CategoriaAvion.MERCANCIAS)) {
            throw new IllegalArgumentException("El tipo de avión no coincide con Mercancias.");
        }
    
        this.controlDeTemperatura = controlDeTemperatura;
        this.permiteMaterialPeligroso = permiteMaterialPeligroso;
    }

    private Boolean checkLog(Rol rol, Aplicacion app){
        if (app.getUsuarioLogueado() == null) return false;
        return app.getUsuarioLogueado().checkRol(rol);
    }

    /* GETTERS */

    public Boolean getControlDeTemperatura() {
        return this.controlDeTemperatura;
    }

    public Boolean getPermiteMaterialPeligroso() {
        return this.permiteMaterialPeligroso;
    }

    /* FUNCIONES COMPLEMENTARIAS */

    @Override
    public Boolean comprobarMantenimiento() {
        Aplicacion app = Aplicacion.init("acceder");
        LocalDate fechaActual = app.getRealTime().toLocalDate();
        LocalDate fechaProximaRevision = this.getFechaUltimaRevision().plusMonths(MESES_MANTENIMIENTO);

        return fechaProximaRevision.isBefore(fechaActual);
    }

    @Override
    public CategoriaAvion getCategoria() {
        return CategoriaAvion.MERCANCIAS;
    }

    @Override
    public boolean tieneMaterialPeligroso() {
        return this.permiteMaterialPeligroso;
    }


    /* PROPIO DE ESTA CLASE */
    
    public Boolean cargar(double cargaKg) {
        if (cargaKg <= 0) {
            System.out.println("Error: La carga debe ser mayor a 0.");
            return false;
        }

        if (!this.isDisponible()) {
            System.out.println("Error: El avión no está disponible.");
            return false;
        }
        
        Aplicacion app = Aplicacion.init("acceder");

        // Validar que sea un controlador autorizado (ajusta el rol si lo necesita un operador)
        if (!checkLog(Rol.CONTROLADORAEREO, app)) return false;
    
        // Verificar si la carga excede la capacidad del avión
        if (cargaKg > this.getTipoAvion().getCapacidad()) {
            System.out.println("Error: La carga excede la capacidad del avión.");
            return false;
        }

        System.out.println("Carga exitosa. Peso cargado: " + cargaKg + " kg");
        return true;
    }
    

    /* OTRAS */
    @Override
    public String toString() {
        return super.toString() +
            " | Control de Temperatura: " + (controlDeTemperatura != null ? controlDeTemperatura : "No especificado") +
            " | Permite Material Peligroso: " + (permiteMaterialPeligroso != null ? permiteMaterialPeligroso : "No especificado");
    }
}
