package funcionalidad.aerolinea;
import funcionalidad.otro.Dimension;
import java.io.Serializable;

public class TipoAvion implements Serializable {
    private String marca;
    private String modelo;
    private int capacidad;
    private Boolean controlTemperatura;
    private Dimension dimension;
    private String id;
    private CategoriaAvion categoria;

    public TipoAvion(String id, String marca, String modelo, int capacidad, Boolean controlTemperaura, int largo, int alto, int ancho, CategoriaAvion categoria) {
        if (marca == null || marca.isEmpty() || modelo == null || modelo.isEmpty() || capacidad < 0 || largo < 0 || alto < 0 || ancho < 0) {
            throw new IllegalArgumentException("Los datos del avión no pueden ser nulos o vacíos.");
        }

        this.marca = marca;
        this.modelo = modelo;
        this.capacidad = capacidad;
        this.controlTemperatura = controlTemperaura;
        this.dimension = new Dimension(largo, ancho, alto);
        this.id = id;
        this.categoria = categoria;
    }

    /* GETTERS */
    public String getMarca() {
        return this.marca;
    }

    public String getModelo() {
        return this.modelo;
    }

    public int getCapacidad() {
        return this.capacidad;
    }

    public Boolean getControlTemperatura() {
        return this.controlTemperatura;
    }

    public String getId(){
        return this.id;
    }
    
    public Dimension getDimension() {
        return this.dimension;
    }

    public int getLargo() {
        return this.dimension.getLargo();
    }

    public int getAlto() {
        return this.dimension.getAlto();
    }

    public int getAncho() {
        return this.dimension.getAncho();
    }

    public CategoriaAvion getCategoria() {
        return this.categoria;
    }
    
    /* OTRAS */
    @Override
    public String toString() {
        return "Tipo de Avión -> " +
            "Marca: " + this.marca +
            " | Modelo: " + this.modelo +
            " | Capacidad: " + this.capacidad +
            " | Tipo: " + this.categoria + 
            " | Control de Temperatura: " + (this.controlTemperatura != null ? this.controlTemperatura : "No especificado") +
            " | Dimensiones: " + (this.dimension != null ? this.dimension.toString() : "No especificadas");
    }

}
