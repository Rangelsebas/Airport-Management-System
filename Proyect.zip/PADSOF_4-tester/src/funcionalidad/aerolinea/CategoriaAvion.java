package funcionalidad.aerolinea;
public enum CategoriaAvion {
    PASAJEROS,
    MERCANCIAS
}
