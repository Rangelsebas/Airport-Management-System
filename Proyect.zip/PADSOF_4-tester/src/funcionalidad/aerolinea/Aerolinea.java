package funcionalidad.aerolinea;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.Factura;
import funcionalidad.usuarios.Rol;
import funcionalidad.usuarios.Usuario;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;


public class Aerolinea implements Serializable {
    private String nombre;

    /* REFERENCIAS */
    private HashMap<String, Avion> aviones;
    private List<Vuelo> vuelos;
    private List<Vuelo> vueloCompartido;
    private List<Vuelo> historicoDeVuelos;
    private List<Factura> facturas;
    private Usuario operadorAerolinea;
    private String codigo;

    public Aerolinea(String nombre, String codigo) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.aviones = new HashMap<>();
        this.vuelos = new ArrayList<>();
        this.facturas = new ArrayList<>();
        this.historicoDeVuelos = new ArrayList<>();
        this.vueloCompartido = new ArrayList<>();
    }

    private Boolean checkLog(Rol rol, Aplicacion app){
        if (app.getUsuarioLogueado() == null) return false;
        return app.getUsuarioLogueado().checkRol(rol);
    }

    /*----RELACIONES----*/

    /* VUELO */
    public Boolean vincularVuelo(Vuelo vuelo) {
        if (vuelo == null) {
            throw new IllegalArgumentException("El vuelo no puede ser null.");
        }

        vuelos.add(vuelo);
        return true;
    }


    public Boolean desvincularVuelo(Vuelo vuelo) {
        if (vuelo == null) return false;
    
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.OPERADORAEROLINEA, app)) return false;
    
        if (vuelos.contains(vuelo)) {
            vuelos.remove(vuelo);
            vuelo.desvincularAerolinea(this);
            return true;
        }
    
        return false;
    }

    /* FACTURA */
    public Boolean vincularFactura(Factura factura) {
        if (factura == null) {
            throw new IllegalArgumentException("La factura no puede ser null.");
        }
    
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.GESTORAEROPUERTO, app)) return false;
        if (!this.facturas.contains(factura)) {
            this.facturas.add(factura);
            return true;
        }
        return false;
    }
    

    public Boolean desvincularFactura(Factura factura) {
        if (factura == null) return false;
    
        Aplicacion app = Aplicacion.init("acceder");
        if (!checkLog(Rol.GESTORAEROPUERTO, app)) return false;
    
        if (facturas.contains(factura)) {
            facturas.remove(factura);
            factura.desvincularAerolinea(this);
            return true;
        }
    
        return false;
    }
    

    /* OPERADOR */
    public Boolean asignarOperador(Usuario operador) {
        if (operador == null) {
            throw new IllegalArgumentException("El operador no puede ser null.");
        }

        if(!operador.checkRol(Rol.OPERADORAEROLINEA)) {
            return false;
        }

        if (this.operadorAerolinea == null) {  // Verifica que no se asigne más de un operador
            this.operadorAerolinea = operador;
            return true;
        }

        return false;
    }

    public void desvincularOperador() {
        this.operadorAerolinea = null;
    }

    public Boolean añadirVueloCompartido(Vuelo vuelo){
        if(vuelo == null) return  false;
        if (this.vueloCompartido.contains(vuelo)) return true;

        this.vueloCompartido.add(vuelo);

        return true;
    }

    public List<Vuelo> getVueloCompartido(){
        return Collections.unmodifiableList(new ArrayList<>(this.vueloCompartido));
    }

    /* GETTERS */

    public String getNombre() {
        return this.nombre;
    }

    public List<Avion> getAviones() {
        return Collections.unmodifiableList(new ArrayList<>(this.aviones.values()));
    }

    public List<Vuelo> getVuelos() {
        return Collections.unmodifiableList(vuelos);
    }

    public List<Vuelo> getVuelosEmbarque(){
        List<Vuelo> vuelosHoy = new ArrayList<>();
        for (Vuelo vuelo : vuelos) {
                if (vuelo.getEstado() == EstadosVuelo.EN_APARCAMIENTO || vuelo.getEstado() == EstadosVuelo.EN_PREPARACION || vuelo.getEstado() == EstadosVuelo.EMBARCANDO 
                    || vuelo.getEstado() == EstadosVuelo.CARGANDO) {
                    vuelosHoy.add(vuelo);
            }
        }
        return Collections.unmodifiableList(vuelosHoy);
    }

    public List<Vuelo> getVuelosDesembarque(){
        List<Vuelo> vuelosHoy = new ArrayList<>();
        for (Vuelo vuelo : vuelos) {
                if (vuelo.getEstado() == EstadosVuelo.DESCARGANDO || vuelo.getEstado() == EstadosVuelo.DESEMBARCANDO || vuelo.getEstado() == EstadosVuelo.ATERRIZADO) {
                    vuelosHoy.add(vuelo);
                }
        }
        return Collections.unmodifiableList(vuelosHoy);
    }

    public List<Factura> getFacturas() {
        return Collections.unmodifiableList(facturas);
    }

    public Usuario getOperadorAerolinea() {
        return this.operadorAerolinea;
    }

    public Avion getAvion(String matricula) {
        return this.aviones.get(matricula);
    }

    public String getCodigo(){
        return this.codigo;
    }

    public void añadirHistoricoDeVuelo(Vuelo vuelo) {
        if (vuelo == null) {
            throw new IllegalArgumentException("El vuelo no puede ser null.");
        }
        this.historicoDeVuelos.add(vuelo);
    }

    public List<Vuelo> getHistoricoDeVuelos() {
        return Collections.unmodifiableList(historicoDeVuelos);
    }

    /* FUNCIONES COMPLEMENTARIAS */

    public List<Avion> verAviones() {

        if (aviones.isEmpty()) {
            System.out.println("🔍 No hay solicitudes de vuelo compartido registradas.");
            return null;
        }

        List<Avion> aviones = new ArrayList<>(this.aviones.values());

        System.out.println("📋 Listado de solicitudes de vuelo compartido:");
        for (Avion avion : aviones) {
            System.out.println(" Fecha de Compra: " + avion.getFechaCompra() + 
                               " | Fecha de Ultima Revision: " + avion.getFechaUltimaRevision() +
                               " | Tipo de Avion: " + avion.getTipoAvion());
        }

        return Collections.unmodifiableList(aviones);
    }

    public Boolean anadirAvion(CategoriaAvion categoriaAvion, TipoAvion tipoAvion, LocalDate fechaCompra, LocalDate fechaRevision) {
        Aplicacion app = Aplicacion.init("acceder");
        //if (!checkLog(Rol.OPERADORAEROLINEA, app)) return false;
    
        String matriculaGenerada = tipoAvion.getMarca().substring(0, 2).toUpperCase() + tipoAvion.getModelo().substring(0, 2) + tipoAvion.getCapacidad();
        Avion avion = null;
        try {
            if (categoriaAvion == CategoriaAvion.PASAJEROS) {
                avion = new AvionPasajeros(fechaCompra, fechaRevision, tipoAvion, matriculaGenerada);
            } else if (categoriaAvion == CategoriaAvion.MERCANCIAS) {
                avion = new AvionMercancias(fechaCompra, fechaRevision, tipoAvion, matriculaGenerada, true, true);
            }
        } catch (Exception e) {
            System.out.println(e); /* Se comprueba que el avion sea del tipo en el constructor */
            return false;
        }
        if(avion == null) return false;
        app.getAeropuertoPropio().getHangarDisponible().guardarAvionAlCrearse(avion);
        aviones.put(avion.getMatricula(), avion);
        System.out.println("✈️ Avión añadido correctamente: " + avion.getMatricula());
        return true;
    }


    /* OTRAS */
    @Override
    public String toString() {
        return "Nombre: " + this.nombre +
            " | Cantidad de Aviones: " + (aviones != null ? aviones.size() : 0) +
            " | Cantidad de Vuelos: " + (vuelos != null ? vuelos.size() : 0) +
            " | Operador: " + (operadorAerolinea != null ? operadorAerolinea.getNombreUsuario() : "No asignado");
    }

}
