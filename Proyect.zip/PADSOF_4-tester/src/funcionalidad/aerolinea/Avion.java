package funcionalidad.aerolinea;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.time.Duration;
import java.time.LocalDate;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Dimension;
import funcionalidad.otro.Ubicacion;
import funcionalidad.usuarios.Rol;

public abstract class Avion implements Serializable {
    private LocalDate fechaCompra;
    private LocalDate fechaUltimaRevision;
    private static int ID = 0; //Para evitar posibles matriculas duplicadas

    /* Referencias */
    private TipoAvion tipoAvion;
    protected String matricula;
    private Boolean disponible = false;

    /* Estado fisico del Avion */
    private LocalDateTime EnHangarDesde;
    private List<Long> horasEnHangar;
    private HashMap<LocalDate, Ubicacion> ubicacion;

    private final String matriculaUsuario;

    public Avion(LocalDate fechaCompra, LocalDate fechaUltimaRevision, TipoAvion tipoAvion, String matricula) {

        if (tipoAvion == null || fechaCompra == null || fechaUltimaRevision == null || matricula == null || matricula.isEmpty()) {
            throw new IllegalArgumentException("Ningún parámetro puede ser nulo o vacío.");
        }
    
        this.fechaCompra = fechaCompra;
        this.fechaUltimaRevision = fechaUltimaRevision;
        this.tipoAvion = tipoAvion;

        /*
         * Separar la matrícula ingresada por el usuario de la matrícula única que genera el sistema nos permite mantener trazabilidad, 
         * facilitar las búsquedas, y conservar la lógica de unicidad. Además, no rompe nada del código existente y añade una forma más 
         * clara de interactuar con el sistema desde la interfaz.
         */
        this.matriculaUsuario = matricula.trim();
        this.matricula = matriculaUsuario + ++ID;

        this.EnHangarDesde = Aplicacion.init("acceder").getRealTime();
        this.horasEnHangar = new ArrayList<>();
        this.ubicacion = new HashMap<>();
    }

    /* GETTERS */

    public LocalDate getFechaCompra() {
        return fechaCompra;
    }

    public LocalDate getFechaUltimaRevision() {
        return fechaUltimaRevision;
    }

    public TipoAvion getTipoAvion() {
        return tipoAvion;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getMatriculaUsuario() {
        return matriculaUsuario;
    }

    public LocalDateTime getEnHangarDesde(){
        return this.EnHangarDesde;
    }

    public Dimension getDimensiones(){
        return this.tipoAvion.getDimension();
    }

    public int getTotalHorasEnHangar(){
        int horas = 0;
        for (Long l : horasEnHangar) {
            horas += l;
        }
        return horas;
    }

    public Ubicacion getUbicacion(LocalDate fecha) {
        if (fecha == null) return null;
        if (this.ubicacion.get(fecha) == null) return Ubicacion.EN_AEROPUERTO;
        return this.ubicacion.get(fecha);
    }

    public Ubicacion getUbicacionAnteriorA(LocalDate fecha) {
        if (fecha == null) return null;
        LocalDate fechaAnterior = fecha.minusDays(1);
        if (this.ubicacion.get(fechaAnterior) == null) return Ubicacion.EN_AEROPUERTO;
        return this.ubicacion.get(fechaAnterior);
    }

    public void invertirUbicacion(LocalDate fecha) {
        if (fecha == null) return;
        if (this.ubicacion.get(fecha) == null) return;
        if (this.ubicacion.get(fecha) == Ubicacion.EN_AEROPUERTO) {
            this.ubicacion.put(fecha, Ubicacion.FUERA_DEL_AEROPUERTO);
        } else {
            this.ubicacion.put(fecha, Ubicacion.EN_AEROPUERTO);
        }
    }

    /* SETTERS */

    public void setFechaUltimaRevision(LocalDate fechaUltimaRevision) {
        this.fechaUltimaRevision = fechaUltimaRevision;
    }

    public Boolean reiniciarTotalHorasEnHangar(){
        // Lo hace el gestor ya que solo él puede emitir facturas
        Aplicacion app = Aplicacion.init("acceder");
        if(app.getUsuarioLogueado() == null) return false;
        if(!app.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;

        this.horasEnHangar.clear();
        return true;
    }

    public Boolean isDisponible() {
        return this.disponible;
    }

    public Boolean isDisponibleSalida(LocalDate fecha) {
        if (fecha == null) return false;
        if (this.ubicacion.get(fecha) == null) return true;    
        if (this.ubicacion.get(fecha) == Ubicacion.EN_AEROPUERTO) return true;
        return false;
    }

    public Boolean isDisponibleLlegada(LocalDate fecha) {
        if (fecha == null) return false;
        if (this.ubicacion.get(fecha) == null) return true;    
        if (this.ubicacion.get(fecha) == Ubicacion.FUERA_DEL_AEROPUERTO) return true;
        return false;
    }

    public void setUbicacion(Ubicacion ubicacion, LocalDate fecha) {
        if (ubicacion == null || fecha == null) return;
        this.ubicacion.put(fecha, ubicacion);
    }

    public Boolean guardarEnHangar(){
        Aplicacion app = Aplicacion.init("acceder");
        if(app.getUsuarioLogueado() == null) return false;
        if(!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if(this.EnHangarDesde != null) return false; // Ya está en el hangar
        this.EnHangarDesde = app.getRealTime();
        return true;
    }

    public Boolean sacarDeHangar(){
        Aplicacion app = Aplicacion.init("acceder");
        if(app.getUsuarioLogueado() == null) return false;
        if(!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        Long diferenciaHoras = Math.abs(Duration.between(this.EnHangarDesde, app.getRealTime()).toHours());
        this.horasEnHangar.add(diferenciaHoras);
        this.EnHangarDesde = null;
        return true;
    }

    /* NECESARIO */
    public Boolean setDisponible(Boolean disponible) {
        Aplicacion app = Aplicacion.init("acceder");
        if(app.getUsuarioLogueado() == null) return false;
        if(!app.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        this.disponible = disponible;
        return true;
    }

    /* FUNCIONES COMPLEMENTARIAS */

    public abstract Boolean comprobarMantenimiento();

    public abstract CategoriaAvion getCategoria();

    public boolean tieneMaterialPeligroso() {
        return false;
    }


    /*
     * public Boolean asignarHangar(Hangar hangar) { return false; }
     */

    @Override
    public String toString() {
        return "Datos de Avion: Matrícula: " + this.matricula +
               " | Fecha de Compra: " + this.fechaCompra +
               " | Última Revisión: " + this.fechaUltimaRevision +
               " | Tipo de Avión: " + (tipoAvion != null ? tipoAvion.toString() : "No definido") + 
               "\n";
    }


}
