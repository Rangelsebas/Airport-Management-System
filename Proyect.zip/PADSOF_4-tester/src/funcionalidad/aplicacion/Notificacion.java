package funcionalidad.aplicacion;

import java.io.Serializable;

public class Notificacion implements Serializable {
    private String mensaje;
    private Boolean leida;

    public Notificacion(String mensaje){
        this.mensaje = mensaje;
        this.leida = false;
    }

    public void marcarComoLeida(){
        this.leida = true;
    }

    public Boolean getLeida(){
        return this.leida;
    }

    public String getMensaje(){
        return this.mensaje;
    }

    @Override
    public String toString() {
        return "notificacion: mensaje=" + mensaje + ",\n leida=" + leida + "]\n";
    }
}
