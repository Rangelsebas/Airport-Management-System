package funcionalidad.aplicacion;

import funcionalidad.aerolinea.*;
import funcionalidad.aeropuerto.*;
import es.uam.eps.padsof.invoices.InvoiceSystem;
import es.uam.eps.padsof.invoices.NonExistentFileException;
import es.uam.eps.padsof.invoices.UnsupportedImageTypeException;
import es.uam.eps.padsof.telecard.OrderRejectedException;
import es.uam.eps.padsof.telecard.TeleChargeAndPaySystem;
import funcionalidad.facturacion.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import funcionalidad.otro.Recurrencia;
import funcionalidad.otro.Ubicacion;
import funcionalidad.usuarios.*;
import funcionalidad.vuelo.*;

import javax.swing.JOptionPane;

import java.util.Iterator;


// GM El proyecto no tiene documentacion apenas y no tiene javadoc
public class Aplicacion implements Serializable {
    private int contadorVuelos = 1; // Esto es para evitar repetir codigos en Vuelo
    private int contadorSolicitudes = 1; // Esto es para evitar repetir codigos en SolicitudRecurrente
    private static Aplicacion instance;
    private String nombre;

    private HashMap<String, Usuario> usuarios;
    private Usuario usuarioLogueado;
    private List<Factura> facturas;
    private HashMap<String, TipoAvion> tiposDeAviones;
    private HashMap<String, Aerolinea> aerolineas;
    private HashMap<String, Vuelo> solicitudes;
    private HashMap<String, Vuelo> llegadas;
    private HashMap<String, Vuelo> salidas;
    private HashMap<String, Vuelo> historico;
    private AeropuertoPropio aeropuertoPropio;
    private HashMap<String, AeropuertoExterno> aeropuertoExternos;
    private HashMap<String, SolicitudRecurrente> solicitudesPendientes;
    private HashMap<String, Vuelo> solicitudRecurrente;
    private Boolean notificacionesActivas;

    private LocalDateTime realTime;

    private final int maxVuelosRecurrentes = 50;

    private Aplicacion(String nombreApp){
        this.nombre = nombreApp;
        this.usuarios = new HashMap<>();
        this.facturas = new ArrayList<>();
        this.tiposDeAviones = new HashMap<>();
        this.aerolineas = new HashMap<>();
        this.solicitudes = new HashMap<>();
        this.llegadas = new HashMap<>();
        this.salidas = new HashMap<>();
        this.historico = new HashMap<>();
        this.aeropuertoExternos = new HashMap<>();
        this.solicitudesPendientes = new HashMap<>();
        this.solicitudRecurrente = new HashMap<>();
        this.notificacionesActivas = true;
        this.realTime = LocalDateTime.now();
    }

    public static Aplicacion init(String nombreApp){
        if (instance == null){
            instance = new Aplicacion(nombreApp);
            return instance;
        }
        return Aplicacion.instance;
    }

    private Boolean checkLog(Rol rol){
        if (this.usuarioLogueado == null) return false;
        return this.usuarioLogueado.checkRol(rol);
    }

    public Boolean crearAeropuertoPropio(String nombre, double precioBase, String ciudadMasCercana, int distanciaCiudad, String direccion,
    String codigo, LocalTime horaApertura, LocalTime horaCierre, String gestor){
        if (nombre == null || ciudadMasCercana == null || distanciaCiudad < 0 || direccion == null || codigo == null
             || horaApertura == null || horaCierre == null || gestor == null) return false;
        /* IMPORTANTE Se debe comprobar que el usuario logueado es el gestor IMPORTANTE */
        /* No hace falta en esta implementacion */
        // if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (aeropuertoPropio != null) return false;

        AeropuertoPropio aeropuertoPropio = AeropuertoPropio.init(nombre, precioBase, ciudadMasCercana, distanciaCiudad, 
        direccion, codigo, horaApertura, horaCierre, this.usuarios.get(gestor));

        this.aeropuertoPropio = aeropuertoPropio;
        return true;
    }

    public Boolean crearGestor(String nombreUsuario, String contraseña, String DNI, String nombre, String email){
        if (!this.usuarios.isEmpty()) return false;
        this.usuarios.put(nombreUsuario, GestorAeropuerto.init(nombreUsuario, DNI, nombre, email, contraseña));
        this.usuarios.get(nombreUsuario).setPrimerLogin();
        return true;
    }

    public Boolean iniciarSesion(String nombreUsuario, String contraseña) {
        if (this.usuarioLogueado != null) return false;
        if (!this.usuarios.containsKey(nombreUsuario)) return false;
        if (this.usuarios.get(nombreUsuario).comprobarContrasena(contraseña)) {
            this.usuarioLogueado = this.usuarios.get(nombreUsuario);
            return true;
        }
        return false;
    }

    public boolean esPrimerLogin() {
        return this.usuarioLogueado != null && this.usuarioLogueado.getPrimerLogin();
    }

    public void cerrarSesion(){
        this.usuarioLogueado = null;
    }

    // GM Falta el registro de la terminar sobre la que actua el controlador
    // R: la terminal guarda la referencia del controlador y se verifica que el controlador no pertenezca a otra terminal.
    public Boolean registrarControlador(String nombreUsuario, String DNI, String nombre, String email, String primeraContraseña){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (this.usuarios.containsKey(nombreUsuario)) return false; 
        // No hace falta porque si el usuario ya existe, no se crea, entonces no se puede añadir a otra terminal un usuario que ya existe
        // 
        // for (Terminal t : this.aeropuertoPropio.getTerminales()) {
        //     if(t.checkControladorEnTerminal(nombreUsuario)){
        //         return false;
        //     }
        // }
        this.usuarios.put(nombreUsuario, new ControladorAereo(nombreUsuario, DNI, nombre, email, primeraContraseña));
        return true;
    }

    public Boolean registrarOperador(String nombreUsuario, String DNI, String nombre, String email, String primeraContraseña){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (this.usuarios.containsKey(nombreUsuario)) return false; // o true??
        this.usuarios.put(nombreUsuario, new OperadorAerolinea(nombreUsuario, DNI, nombre, email, primeraContraseña));
        return true;
    }

    // GM tal vez mejor que el la Aerolinea se pase al constructor de Operador. 
    // GM Con este método puede asignar a cualquier tipo de usuario a la aerolinea
    // R: No, solo puede agregarlo el Gestor del aeropuerto, por eso está el checkLog()
    public Boolean asignarAerolineaOperador(String operador, String aerolinea) {  //Usuario usuario ??
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if(!this.usuarios.containsKey(operador)) return false;
        if(!this.aerolineas.containsKey(aerolinea)) return false;
        return this.aerolineas.get(aerolinea).asignarOperador(this.usuarios.get(operador));
    }

    public Boolean añadirAerolinea(String nombre, String codigo){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (this.aerolineas.containsKey(nombre)) return false; // o true??
        this.aerolineas.put(nombre, new Aerolinea(nombre, codigo));
        return true;
    }

    public Boolean añadirTipoAvion(String id, String marca, String modelo, int capacidad, Boolean controlTemperatura, 
                                    int largo, int ancho, int alto, CategoriaAvion categoria){
        if (!checkLog(Rol.OPERADORAEROLINEA)) return false; // o Gestor de aeropuerto??
        TipoAvion  nuevoTipo = new TipoAvion(id, marca, modelo, capacidad, controlTemperatura, largo, alto, ancho, categoria);
        this.tiposDeAviones.put(nuevoTipo.getId(), nuevoTipo);
        return true;
    }

    public TipoAvion getTipoAvion(String id) {
        return this.tiposDeAviones.get(id);
    }

    public Aerolinea getAerolinea(String nombre){
        if (!this.aerolineas.containsKey(nombre)) return null;
        return this.aerolineas.get(nombre);
    }

    public Usuario getUsuario(String nombreUsuario){
        return this.usuarios.get(nombreUsuario);
    }

    public AeropuertoExterno getAeropuertoExterno(String nombre){
        return this.aeropuertoExternos.get(nombre);
    }

    public List<AeropuertoExterno> listarAeropuertosExternos(){
        return Collections.unmodifiableList(new ArrayList<>(this.aeropuertoExternos.values()));
    }

    public List<TipoAvion> listarTiposDeAviones(){
        return Collections.unmodifiableList(new ArrayList<>(this.tiposDeAviones.values()));
    }

    // Si, deberia ser (Usuario usuario) o mejor dicho (ControladorAereo ca) y (OperadorAerolinea oa) y usar la sobrecarga de metodos 
    // Pero ya estaba hecho este con Strings y es util con String para el controlador de la vista. El tiempo apremia :D
    public Boolean eliminarUsuario(String usuario, String contraseña) { //Usuario usuario
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (!this.usuarios.containsKey(usuario)) return false; // true??
        if (this.usuarios.get(usuario).comprobarContrasena(contraseña) == false) return false;

        /* Si el usuario era Operador de Aerolinea */
        if (this.usuarios.get(usuario).checkRol(Rol.OPERADORAEROLINEA)) {
            OperadorAerolinea operador = (OperadorAerolinea) this.usuarios.get(usuario);
            if (operador.getAerolinea() != null) {
                operador.getAerolinea().desvincularOperador();
            }
        }

        /* Si el usuario era Controlador Aereo */
        else if (this.usuarios.get(usuario).checkRol(Rol.CONTROLADORAEREO)) {
            ControladorAereo controlador = (ControladorAereo) this.usuarios.get(usuario);
            if (controlador.getTerminal() != null) {
                controlador.getTerminal().eliminarControlador(controlador);
            }
        } else {
            return false; // No se puede eliminar un usuario que no sea operador o controlador
        }

        this.usuarios.remove(usuario);
        return true;
    }

    /* Devuelve true si se consigue mandar la notificacion, false en caso de faltar un parametro o no estén activadas las notificaciones en la app */
    public Boolean nuevaNotificacion(List<Usuario> receptores, String mensaje){
        if (!this.notificacionesActivas) return false;
        if (receptores.size() == 0 || mensaje == null) return false;
        Notificacion notification = new Notificacion(mensaje);
        for (Usuario u : receptores) {
            u.añadirNotificacion(notification);
        }
        return true;
    }

    public Boolean activarNotificaciones(){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        this.notificacionesActivas = true;
        return true;
    }

    public Boolean desactivarNotificaciones(){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        this.notificacionesActivas = false;
        return true;
    }

    public List<Usuario> listarUsuarios(){
        return Collections.unmodifiableList(new ArrayList<>(this.usuarios.values()));
    }

    public Usuario getUsuarioLogueado(){
        return this.usuarioLogueado;
    }

    // % vuelos retrasados hasta hoy
    public int porcentajeVuelosRetrasados(){
        int total = 0;
        int retrasados = 0;
        for (Vuelo v : this.historico.values()) {
            if(!v.getEnTiempo()){
                retrasados++;
            }
            total++;
        }
        return (total != 0 ? retrasados/total : 0); // evitar division por cero
    }

    // % participacion aerolinea en el total de vuelos
    public int porcentajeParticipacionAerolinea(String aerolinea){
        int total = 0;
        int participo = 0;
        for (Vuelo v : this.llegadas.values()) {
            if(v.getAerolineas().contains(this.getAerolinea(aerolinea))){
                participo++;
            }
            total++;
        }
        for (Vuelo v : this.salidas.values()) {
            if(v.getAerolineas().contains(this.getAerolinea(aerolinea))){
                participo++;
            }
            total++;
        }
        for (Vuelo v : this.historico.values()) {
            if(v.getAerolineas().contains(this.getAerolinea(aerolinea))){
                participo++;
            }
            total++;
        }
        return (total != 0 ? participo/total : 0); // evitar division por cero
    }

    // Método para calcular la media diaria de vuelos
    public int mediaDiaria() {
        // Verificamos que las tres listas no estén vacías
        if (llegadas.isEmpty() && salidas.isEmpty() && historico.isEmpty()) {
            return 0; // No hay vuelos
        }

        // Variables para contar el total de vuelos y la fecha de inicio y fin
        long totalVuelos = 0;
        LocalDate fechaInicio = LocalDate.MAX;
        LocalDate fechaFin = LocalDate.MIN;

        // Método auxiliar para actualizar el rango de fechas
        totalVuelos += contarVuelosYActualizarFechas(llegadas, fechaInicio, fechaFin);
        totalVuelos += contarVuelosYActualizarFechas(salidas, fechaInicio, fechaFin);
        totalVuelos += contarVuelosYActualizarFechas(historico, fechaInicio, fechaFin);

        // Si no hay vuelos en el período, se retorna 0
        if (totalVuelos == 0) {
            return 0;
        }

        // Calculamos los días en el período
        long dias = ChronoUnit.DAYS.between(fechaInicio, fechaFin) + 1; // Incluye el día de inicio

        // Calculamos la media diaria
        return (int) (totalVuelos / dias);
    }

        // Método auxiliar para contar vuelos y actualizar las fechas de inicio y fin
    private long contarVuelosYActualizarFechas(Map<String, Vuelo> vuelos, LocalDate fechaInicio, LocalDate fechaFin) {
        long vuelosContados = 0;

        for (Vuelo vuelo : vuelos.values()) {
            LocalDate fechaVuelo = vuelo.getFecha();  // Se asume que Vuelo tiene un getter para la fecha

            // Actualizamos las fechas de inicio y fin
            if (fechaVuelo.isBefore(fechaInicio)) {
                fechaInicio = fechaVuelo;
            }
            if (fechaVuelo.isAfter(fechaFin)) {
                fechaFin = fechaVuelo;
            }

            // Incrementamos el contador de vuelos
            vuelosContados++;
        }

        return vuelosContados;
    }

    public Vuelo buscarVueloxCodigo(String codigo){
        //if (!this.usuarioLogueado.checkRol(Rol.GESTORAEROPUERTO)) return null;
        Vuelo vuelo = this.llegadas.get(codigo);
        if (vuelo == null) {
            vuelo = this.salidas.get(codigo);
            if (vuelo == null) {
                vuelo = this.historico.get(codigo);
            }
        }

        // Buscar en solicitudes si no se encontró antes
        if (vuelo == null) {
            for (Vuelo v : this.solicitudes.values()) {
                if (v.getCodigoVuelo().equals(codigo) && v.getEstado() == EstadosVuelo.PENDIENTE) {
                    return v;
                }
            }
        }

        return vuelo;
    }

    public List<Vuelo> vuelosAerolinea(String nombre){      
        return Collections.unmodifiableList(new ArrayList<>(getAerolinea(nombre).getVuelos()));
    }

    public List<Vuelo> vuelosTerminal(String nombre){
        List<Vuelo> vuelos = new ArrayList<>();
        for (Vuelo v : vuelosLlegadas()) {
            if(v.getTerminalAsignada().equals(getAeropuertoPropio().getTerminal(nombre)))
                vuelos.add(v);
        }
        for (Vuelo v : vuelosSalidas()) {
            if(v.getTerminalAsignada().equals(getAeropuertoPropio().getTerminal(nombre)))
                vuelos.add(v);
        }
        return vuelos;
    }

    public List<Vuelo> vuelosLlegadas(){
        return Collections.unmodifiableList(new ArrayList<>(this.llegadas.values()));
    }

    public List<Vuelo> getVuelosAerolinea(String Aerolinea) {
        if(!this.aerolineas.containsKey(Aerolinea)) return null;

        return this.aerolineas.get(Aerolinea).getVuelos();
    }

    public List<Vuelo> getVuelosControlador(String Controlador) {
        if(!this.usuarios.containsKey(Controlador)) return null;

        Usuario u = this.usuarios.get(Controlador);

        if(!u.checkRol(Rol.CONTROLADORAEREO)) return null;

        ControladorAereo ca = (ControladorAereo) u;

        return ca.getVuelos();
    }

    public List<Vuelo> vuelosSalidas(){
        return Collections.unmodifiableList(new ArrayList<>(this.salidas.values()));
    }

    public List<Vuelo> vuelosHistoricos(){
        return Collections.unmodifiableList(new ArrayList<>(this.historico.values()));    }

    public List<Vuelo> vuelosHistoricos(LocalDate desde, LocalDate hasta){
        List<Vuelo> historicos = new ArrayList<>();
        for (Vuelo v : this.historico.values()) {
            if(v.getFecha().isAfter(desde) || v.getFecha().isEqual(desde)){
                if(v.getFecha().isBefore(hasta) || v.getFecha().isEqual(hasta)){
                    historicos.add(v);
                }
            }
        }
        return Collections.unmodifiableList(historicos);
    }

    public List<Factura> historicoFacturas(){
        return Collections.unmodifiableList(new ArrayList<>(this.facturas));
    }

    public List<Factura> historicoFacturas(LocalDate desde, LocalDate hasta){
        List<Factura> historico = new ArrayList<>();
        for (Factura f : this.facturas) {
            if(f.verFechaEmision().isAfter(desde) || f.verFechaEmision().equals(desde)){
                if(f.verFechaEmision().isBefore(hasta) || f.verFechaEmision().equals(hasta)){
                    historico.add(f);
                }
            }
        }
        return historico;
    }

    public Boolean solicitarNuevoVuelo(String origen, String destino, LocalDate fecha, LocalTime horaSalida, LocalTime horaLlegada, Aerolinea aerolinea, Avion avion) throws IOException {
        if (!checkLog(Rol.OPERADORAEROLINEA)) return false;
        // Las horas son siempre con respecto a mi aeropuerto
        // if (horaSalida.isBefore(horaLlegada)) return false; si no es el caso, se da por hecho que la hora de llegada es del dia siguiente
        if (fecha.isBefore(this.realTime.plusDays(2).toLocalDate())) return false; // El vuelo tiene que solicitarse al menos con 2 dias de antelacion

        Aeropuerto[] aeropuertos = new Aeropuerto[2];
        if (!obtenerAeropuertos(origen, destino, aeropuertos)) {
            throw new IOException("No se obtuvieron los aeropuertos"); // Si no se obtienen los aeropuertos, lanzamos una excepcion
        }

        /* Verificar que ambos aeropuertos estarán abiertos */
        if (!aeropuertos[0].checkHorario(horaSalida) || !aeropuertos[1].checkHorario(horaLlegada)) {
            throw new IOException("Uno de los aeropuertos no está abierto en ese momento"); // Si alguno de los aeropuertos no está abierto, lanzamos una excepcion 
        }

        /* Verificamos que el avion está en el aeropuerto si es de llegada o fuera de eĺ si es de salida */
        if (aeropuertos[0].equals(this.aeropuertoPropio)) {
            /* Es de salida */
            if (!avion.isDisponibleSalida(fecha)) {
                throw new IOException("El avión no está en el aeropuerto de salida"); // Si el avion no está en el aeropuerto de salida, lanzamos una excepcion
            }
        } else {
            /* Es de llegada */
            if (!avion.isDisponibleLlegada(fecha)) {
                throw new IOException("El avión está presente en el aeropuerto para esa fecha"); // Si el avion no está en el aeropuerto de llegada, lanzamos una excepcion
            }
        }

        
        Vuelo vuelo = new Vuelo(aeropuertos[0], aeropuertos[1], horaSalida, horaLlegada, fecha, aerolinea, avion, contadorVuelos++);
        
        if (this.solicitudes.containsKey(vuelo.getCodigoVuelo())) return false; // Ya existe una solicitud con ese codigo
        
        /* Llegados hasta aqui el avion puede salir, seteamos la ubicacion correspondiente para esa fecha */
        if (aeropuertos[0].equals(this.aeropuertoPropio)) {
            avion.setUbicacion(Ubicacion.FUERA_DEL_AEROPUERTO, fecha);
        } else {
            avion.setUbicacion(Ubicacion.EN_AEROPUERTO, fecha);
        }

        this.solicitudes.put(vuelo.getCodigoVuelo(), vuelo);
        // Añadir notificacion
        List<Usuario> receptor = new ArrayList<>();
        receptor.add(this.aeropuertoPropio.getGestorDelAeropuerto());
        receptor.add(this.usuarioLogueado);
        String mensaje = "\nNueva solicitud de vuelo en estado: " + vuelo.getEstado() + " con codigo: " + vuelo.getCodigoVuelo() + "\nCon fecha: " + fecha + ", hora de salida: " + horaSalida + ", hora de llegada: " + horaLlegada + 
        "\n Con origen: "+ origen + " y destino: " + destino + ".\n Detalles.\nAerolinea: " + aerolinea.getNombre() + "\nAvion: " + avion;
        this.nuevaNotificacion(receptor, mensaje);
        return true;
    }

    // GM Estos métodos no serán útiles para la cuando se ponga la interfaz de usuario. 
    // Esta se queda para probar en main. DE MOMENTO
    public Boolean verTodasMisNotificaciones(){
        if(usuarioLogueado == null) return false;
        if(this.usuarioLogueado.getNotificacion().isEmpty()) System.out.println("No hay notificaciones");
        for (Notificacion n : this.usuarioLogueado.getNotificacion()) {
            System.out.println(n);       
        }
        return true;
    }
    
    public Boolean verNotificacionesNoLeidas(){
        if(usuarioLogueado == null) return false;
        if(this.usuarioLogueado.getNotificacionNoLeidas().isEmpty()){
            System.out.println("No hay notificaciones");
            return false;
        } 
        System.out.println("\n    - - Nuevas notificaciones:\n");
        for (Notificacion n : this.usuarioLogueado.getNotificacionNoLeidas()) {
            System.out.println(n);       
        }
        return true;
    }

    // Para el controlador de la vista
    public List<Notificacion> verTodasMisNotificacionesGrafico(){
        if(usuarioLogueado == null) return null;
        if(this.usuarioLogueado.getNotificacion().isEmpty()) {
            System.out.println("No hay notificaciones");
            return null;
        } 

        return this.usuarioLogueado.getNotificacion();
    }

    public List<Notificacion> verMisNotificacionesNoLeidasGrafico(){
        if(usuarioLogueado == null) return null;
        if(this.usuarioLogueado.getNotificacionNoLeidas().isEmpty()) {
            System.out.println("No hay notificaciones");
            return null;
        } 

        return this.usuarioLogueado.getNotificacionNoLeidas();
    }

    private boolean obtenerAeropuertos(String origen, String destino, Aeropuerto[] aeropuertos) {
        if (this.aeropuertoPropio.getNombre().equals(origen)) {
            if (this.aeropuertoExternos.get(destino) == null) {
                return false; // No existe el aeropuerto externo
            } else {
                aeropuertos[0] = this.aeropuertoPropio;
                aeropuertos[1] = this.aeropuertoExternos.get(destino);
            }
        } else {
            if (this.aeropuertoExternos.get(origen) == null) {
                return false; // No existe el aeropuerto externo
            } else {
                aeropuertos[0] = this.aeropuertoExternos.get(origen);
                aeropuertos[1] = this.aeropuertoPropio;
            }
        }
        return true;
    }    

    public Boolean solicitarVueloRecurrente(String origen, String destino, LocalDate primeraFecha, LocalTime horaSalida, LocalTime horaLlegada, 
                                            Aerolinea aerolinea, Avion avion, int cantidad, Recurrencia recurrencia, CategoriaAvion tipoCarga){
        if (!checkLog(Rol.OPERADORAEROLINEA)) return false;
        if (cantidad > this.maxVuelosRecurrentes) return false;
        if(avion.getCategoria() != tipoCarga) return false;

        SolicitudRecurrente nuevaSolicitud = new SolicitudRecurrente(contadorSolicitudes++);

        for (int i = 0; i < cantidad; i++) {
            LocalDate fecha = primeraFecha;
            switch (recurrencia) {
                case Recurrencia.DIARIA:
                    fecha = fecha.plusDays(i);
                    break;
                case Recurrencia.SEMANAL:
                    fecha = fecha.plusWeeks(i);
                    break;
                case Recurrencia.MENSUAL:
                    fecha = fecha.plusMonths(i);
                    break;
                default:
                    break;
            }
            
            Aeropuerto[] aeropuertos = new Aeropuerto[2];
            if (!obtenerAeropuertos(origen, destino, aeropuertos)) {
                return false; // Si no se obtienen los aeropuertos, retornamos false
            }

            Vuelo vuelo = new Vuelo(aeropuertos[0], aeropuertos[1], horaSalida, horaLlegada, fecha, aerolinea, avion, contadorVuelos++);
            nuevaSolicitud.añadirVuelo(vuelo);
            this.solicitudRecurrente.put(vuelo.getCodigoVuelo(), vuelo);
     
            // Añadir notificacion
            List<Usuario> receptor = new ArrayList<>();
            receptor.add(this.aeropuertoPropio.getGestorDelAeropuerto());
            receptor.add(this.usuarioLogueado);
            String mensaje = "\nNueva solicitud de vuelo en estado: " + vuelo.getEstado() + " con codigo: " + vuelo.getCodigoVuelo() + "\nCon fecha: " + fecha + ", hora de salida: " + horaSalida + ", hora de llegada: " + horaLlegada + 
            "\n Con origen: "+ origen + " y destino: " + destino + ".\n Detalles.\nAerolinea: " + aerolinea.getNombre() + "\nAvion: " + avion;
            this.nuevaNotificacion(receptor, mensaje);
        }
        this.solicitudesPendientes.put(nuevaSolicitud.getIdSolicitud(), nuevaSolicitud);
        return true;
    }

    public List<SolicitudRecurrente> verSolicitudesVuelosRecurrentes(){
        return Collections.unmodifiableList(new ArrayList<>(this.solicitudesPendientes.values()));
    }

    /* No se ofrece modificacion alguna, se aprueban todos o se rechazan */
    public Boolean aprobarVuelosRecurrentes(String codigoSolicitud, String terminal, String controlador){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (this.solicitudesPendientes.get(codigoSolicitud) == null) return false;
        SolicitudRecurrente solicitud = this.solicitudesPendientes.get(codigoSolicitud);
        List<Vuelo> vuelos = solicitud.getVuelos();
        for (Vuelo v : vuelos) {
            if(aprobarSolicitudVuelo(v.getCodigoVuelo(), terminal, controlador) == false){
                /* Si alguno es rechazado no se aprueba niguno */
                for (Vuelo vr : vuelos) {
                    vr.rechazarVuelo("No posible");
                }
                this.solicitudesPendientes.remove(codigoSolicitud);
                this.solicitudRecurrente.remove(v.getCodigoVuelo());
                return false;
            }
            if(v.getOrigen().equals(this.aeropuertoPropio)) this.salidas.put(v.getCodigoVuelo(), v);
            else this.llegadas.put(v.getCodigoVuelo(), v); 
        }
        this.solicitudesPendientes.remove(codigoSolicitud);
        return true;
    }

    public Boolean rechazarVuelosRecurrentes(String codigoSolicitud, String motivo){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (this.solicitudesPendientes.get(codigoSolicitud) == null) return false;
        SolicitudRecurrente solicitud = this.solicitudesPendientes.get(codigoSolicitud);
        List<Vuelo> vuelos = solicitud.getVuelos();
        for (Vuelo v : vuelos) {
            v.rechazarVuelo(motivo);
        }
        this.solicitudesPendientes.remove(codigoSolicitud);
        return true;
    }

    //GM Método aprobarSolicitudVuelo demasiado complejo y repetitivo
    //GM Hay que comprobar la suma de salidas y llegadas
    //GM Os paso un prototipo de simplificación de la primera parte del código de la función

    // public Boolean aprobarSolicitudVuelo(String codigo, String terminal, String controlador){
    //
    //     ... //comprobaciones varias 
    //
    //     LocalTime hora = vuelo.getOrigen()==this.aeropuertoPropio ? vuelo.getHoraSalida() : vuelo.getHoraLlegada();
    //     if (getNumVuelos(hora) >= this.aeropuertoPropio.getMaxVuelosEnUnaHora()) {
    //          if (getNumVuelos(hora.plusHours(1)) >= this.aeropuertoPropio.getMaxVuelosEnUnaHora()) {
    //              vuelo.rechazarVuelo("Aeropuerto posiblemente lleno en ese momento");
    //          } else {
    //              vuelo.modificarVuelo(hora.plusHours(1), vuelo.getLlegada().plusHours(1));
    //              // Enviar notificación etc
    //          }
    //          return false;
    //     }
    //     
    //     //Aqui reservar
    //     //Aqui comprobar horario de forma similar a alo de arriba 
    //     //Aqui aprobar vuelo   

    private int getNumVuelos(LocalDate fecha, LocalTime hora) {
        int numVuelos = 0;
        for (Vuelo v : this.llegadas.values()) {
            if (v.getFecha().equals(fecha) && ((v.getHoraLlegada().isAfter(hora) && v.getHoraLlegada().isBefore(hora.plusHours(1))) || v.getHoraLlegada().equals(hora))) {
                numVuelos++;
            }
        }
        for (Vuelo v : this.salidas.values()) {
            if (v.getFecha().equals(fecha) && ((v.getHoraSalida().isAfter(hora) && v.getHoraSalida().isBefore(hora.plusHours(1))) || v.getHoraSalida().equals(hora))) {
                numVuelos++;
            }
        }
        return numVuelos;
    }

    public Boolean rechazarSolicitudVuelo(String codigo, String motivo){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        Vuelo vuelo = this.solicitudes.get(codigo);
        if (vuelo.getEstado() != EstadosVuelo.PENDIENTE) return false;
        vuelo.rechazarVuelo(motivo);
        this.solicitudes.remove(codigo);
        return true;
    }

    public Boolean aprobarSolicitudVuelo(String codigo, String terminal, String controlador){
        /* Comprobaciones varias */
        if (codigo == null || terminal == null || controlador == null) return false;
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (this.aeropuertoPropio.getTerminal(terminal) == null) return false;
        if (this.usuarios.get(controlador) == null) return false;
        if (!this.usuarios.get(controlador).checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!(((ControladorAereo)this.usuarios.get(controlador)).getTerminal().equals(this.aeropuertoPropio.getTerminal(terminal)))) return false;
        Vuelo vuelo = this.solicitudes.get(codigo);
        if (vuelo == null) {
            vuelo = this.solicitudRecurrente.get(codigo);
        } 
        if (vuelo == null) return false; // No existe el vuelo
        if (vuelo.getEstado() != EstadosVuelo.PENDIENTE) return false;
        
        /* Comprobar que el aeropuerto no estará lleno a esa hora */
        List<Usuario> receptor = new ArrayList<>();
        LocalTime hora = vuelo.getOrigen() == this.aeropuertoPropio ? vuelo.getHoraSalida() : vuelo.getHoraLlegada();
        LocalDate fecha = vuelo.getFecha();
        if (getNumVuelos(fecha, hora) >= this.aeropuertoPropio.getMaxVuelosEnUnaHora()) {
            if (getNumVuelos(fecha, hora.plusHours(1)) >= this.aeropuertoPropio.getMaxVuelosEnUnaHora()) {
               vuelo.rechazarVuelo("Aeropuerto posiblemente lleno en ese momento");
            } else {
               vuelo.modificarVuelo(hora.plusHours(1), vuelo.getHoraLlegada().plusHours(1));
                receptor.add(vuelo.getAerolineaOperadora().getOperadorAerolinea());
                this.nuevaNotificacion(receptor, "\nTu vuelo " + vuelo.getCodigoVuelo() + " ha sido modificado, se ha movido a una hora posterior.");
                this.solicitudes.remove(codigo);
                /* retornamos false porque no se aprobo pero se notifica de la modificacion */
                return false; 
            }

            
            this.solicitudes.remove(codigo);
            receptor.add(vuelo.getAerolineaOperadora().getOperadorAerolinea());
            String mensaje = "\nTu vuelo " + vuelo.getCodigoVuelo() + " no ha podido ser aprobado.\n";
            this.nuevaNotificacion(receptor, mensaje);
            return false;
        }
        
        /* Si el vuelo es de llegada verificar que hay sitio en los hangares */
        
        if (vuelo.getOrigen().equals(this.aeropuertoPropio)) {
            if (!this.aeropuertoPropio.sePuedeAparcar() || !this.aeropuertoPropio.reservarHangar(fecha)) {
                vuelo.rechazarVuelo("Aeropuerto posiblemente lleno en ese momento");
                this.solicitudes.remove(codigo);
                this.solicitudes.remove(codigo);
                receptor.add(vuelo.getAerolineaOperadora().getOperadorAerolinea());
                String mensaje = "\nTu vuelo " + vuelo.getCodigoVuelo() + " no ha podido ser aprobado.\n";
                this.nuevaNotificacion(receptor, mensaje);
                return false;
            }
        } else if (!this.aeropuertoPropio.sePuedeAparcar()) {
                vuelo.rechazarVuelo("Aeropuerto posiblemente lleno en ese momento");
                this.solicitudes.remove(codigo);
                receptor.add(vuelo.getAerolineaOperadora().getOperadorAerolinea());
                String mensaje = "\nTu vuelo " + vuelo.getCodigoVuelo() + " no ha podido ser aprobado. No hay aparcamiento\n";
                this.nuevaNotificacion(receptor, mensaje);
                return false;
        }

        /* Ya se puede aprobar */

        if(vuelo.aprobarVuelo(this.aeropuertoPropio.getTerminal(terminal), this.usuarios.get(controlador))){
            // Se ha aprobado
            if(vuelo.getOrigen().equals(this.aeropuertoPropio)){
                // Es salida
                this.salidas.put(vuelo.getCodigoVuelo(), vuelo);
            }
            else {
                // es llegada
                this.llegadas.put(vuelo.getCodigoVuelo(), vuelo);
            }
            this.solicitudes.remove(codigo);
            // Añadir notificacion
            receptor.add(vuelo.getAerolineaOperadora().getOperadorAerolinea());
            receptor.add(this.getUsuario(controlador));
            String mensaje = "\nTu vuelo " + vuelo.getCodigoVuelo() + " ha sido aprobado.\nCon fecha: " + fecha + ", hora de salida: " + 
            vuelo.getHoraSalida() + ", hora de llegada: " + vuelo.getHoraLlegada() + ", terminal: " + terminal + " y controlador: " + controlador;
            this.nuevaNotificacion(receptor, mensaje);
            // Añadir el vuelo al controlador
            ((ControladorAereo)this.usuarios.get(controlador)).asignarVuelo(vuelo);
            return true;
        } else {
            // No se ha podido aprobar
            vuelo.rechazarVuelo("No se ha podido aprobar el vuelo");
            this.solicitudes.remove(codigo);
            // Añadir notificacion
            receptor.add(vuelo.getAerolineaOperadora().getOperadorAerolinea());
            String mensaje = "\nTu vuelo " + vuelo.getCodigoVuelo() + " no ha podido ser aprobado.\n";
            this.nuevaNotificacion(receptor, mensaje);
            return false;
        }
    }

    public List<Vuelo> getVuelosEstadoPendiente(){
        return Collections.unmodifiableList(new ArrayList<>(this.solicitudes.values()));
    }

    /* Ejemplo llamar al metodo con LocalDateTime.of(2026, 1, 27, 16, 0) para */
    /* vuelos del 27 de enero del 2026 entre las 16:00 y las 17:00 horas */
    public List<Vuelo> verVuelosEnHoraYFecha(LocalDateTime fechaHora) {
        if (!checkLog(Rol.GESTORAEROPUERTO)) return null;
    
        // Calcular el rango de tiempo: desde fechaHora hasta una hora más tarde
        LocalDateTime horaFin = fechaHora.plusHours(1);
        List<Vuelo> vuelosEnRango = new ArrayList<>();
    
        llegadas.values().stream()
            .filter(v -> {
                LocalDateTime salida = v.getFecha().atTime(v.getHoraSalida());
                return !salida.isBefore(fechaHora) && salida.isBefore(horaFin);
            })
            .forEach(vuelosEnRango::add);
    
        salidas.values().stream()
            .filter(v -> {
                LocalDateTime salida = v.getFecha().atTime(v.getHoraSalida());
                return !salida.isBefore(fechaHora) && salida.isBefore(horaFin);
            })
            .forEach(vuelosEnRango::add);
    
        return vuelosEnRango;
    }

    public int cantidadVuelosEnFechaYHora(LocalDateTime fechaHora){
        return this.verVuelosEnHoraYFecha(fechaHora).size();
    }

    public int getCapacidadVuelosEnHora(){
        return this.aeropuertoPropio.getMaxVuelosEnUnaHora();
    }

    public int getMaxAvionesEnAeropuerto(){
        return this.aeropuertoPropio.getMaxAvionesEnAeropuerto();
    }

    public List<Factura> getFacturas(){
        return Collections.unmodifiableList(this.facturas);
    }

    /* --------------------------------------------------------------- */

    public List<Vuelo> getVuelosDelDia(){
        List<Vuelo> vuelos = new ArrayList<>();
        LocalDate hoy = this.realTime.toLocalDate();
        for (Vuelo v : this.vuelosLlegadas()) {
            if(v.getFecha().equals(hoy))
                vuelos.add(v);
        }
        for (Vuelo v : this.vuelosSalidas()) {
            if(v.getFecha().equals(hoy))
                vuelos.add(v);
        }
        return vuelos;
    }

    public List<Vuelo> getVuelosPasadosPendientes(){
        List<Vuelo> vuelos = new ArrayList<>();
        LocalDate hoy = this.realTime.toLocalDate();
        for (Vuelo v : this.vuelosLlegadas()) {
            if(v.getFecha().isBefore(hoy) && v.getEstado() == EstadosVuelo.PENDIENTE)
                vuelos.add(v);
        }
        for (Vuelo v : this.vuelosSalidas()) {
            if(v.getFecha().isBefore(hoy) && v.getEstado() == EstadosVuelo.PENDIENTE)
                vuelos.add(v);
        }
        return vuelos;
    }

    public AeropuertoPropio getAeropuertoPropio(){
        return this.aeropuertoPropio;
    }

    public void enviarNotificacionDeOlvidoGestorAeropuerto(String usuario){
        // Verificar si el aeropuerto propio está creado
        if (this.aeropuertoPropio == null) {
            JOptionPane.showMessageDialog(null,
                "No hay ningún aeropuerto configurado.\nPrimero debes crear o cargar una aplicación.",
                "Aeropuerto no disponible", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Verificar si el gestor está configurado
        Usuario gestor = this.aeropuertoPropio.getGestorDelAeropuerto();
        if (gestor == null) {
            JOptionPane.showMessageDialog(null,
                "No hay gestor asignado al aeropuerto.\nNo se puede enviar la solicitud.",
                "Gestor no disponible", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Verificar si el usuario que solicita existe
        Usuario solicitante = this.getUsuarioLogueado();
        if (solicitante == null) {
            JOptionPane.showMessageDialog(null,
                "No se encontró el usuario solicitado.\nVerifica el nombre ingresado.",
                "Usuario no encontrado", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.aeropuertoPropio.getGestorDelAeropuerto());
        this.nuevaNotificacion(receptores, "El usuario " + usuario + " ha olvidado su contraseña, por favor asignale una nueva.");
    }

    public Boolean asignarNuevaContraseña(String usuario, String nuevaContraseña){
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (this.usuarios.get(usuario) == null) return false;
        this.usuarios.get(usuario).setContraseña(nuevaContraseña);
        return true;
    }

    public void actualizar(){
        Iterator<Map.Entry<String, Vuelo>> it = this.salidas.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Vuelo> entry = it.next();
            Vuelo v = entry.getValue();
            if (v.getEstado() == EstadosVuelo.FINALIZADO
             || v.getEstado() == EstadosVuelo.VOLANDO) {
                // 1) guardo en histórico
                this.historico.put(entry.getKey(), v);
                // 2) quito del map original
                it.remove();
            }
        }
        
        it = this.llegadas.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Vuelo> entry = it.next();
            Vuelo v = entry.getValue();
            if (v.getEstado() == EstadosVuelo.FINALIZADO
             || v.getEstado() == EstadosVuelo.VOLANDO) {
                // 1) guardo en histórico
                this.historico.put(entry.getKey(), v);
                // 2) quito del map original
                it.remove();
            }
        }

        for (Vuelo v : this.getVuelosDelDia()) {
            if (v.getDestino().equals(this.aeropuertoPropio)){

                // Es de llegada
                if(v.getHoraLlegada().minusMinutes(15).isBefore(this.realTime.toLocalTime())){
                    if (v.getEstado() == EstadosVuelo.APROBADO) {
                        v.enEspacioAereo();
                    }
                }
                if(v.getHoraLlegada().isBefore(this.realTime.toLocalTime()) && v.getEnTiempo() && v.getEstado() != EstadosVuelo.FINALIZADO){
                    // retrasado
                    v.setRetraso();
                    List<Usuario> receptores = new ArrayList<>();
                    receptores.add(this.aeropuertoPropio.getGestorDelAeropuerto());
                    receptores.add(v.getControladorAereo());
                    receptores.add(v.getAerolineaOperadora().getOperadorAerolinea());
                    this.nuevaNotificacion(receptores, "El vuelo: "+ v.getCodigoVuelo()+ " se encuentra retrasado");
                }
            } else {
                if(v.getHoraSalida().isBefore(this.realTime.toLocalTime()) && v.getEnTiempo() && v.getEstado() != EstadosVuelo.FINALIZADO){
                    // retrasado
                    v.setRetraso();
                    List<Usuario> receptores = new ArrayList<>();
                    receptores.add(this.aeropuertoPropio.getGestorDelAeropuerto());
                    receptores.add(v.getControladorAereo());
                    receptores.add(v.getAerolineaOperadora().getOperadorAerolinea());
                    this.nuevaNotificacion(receptores, "El vuelo: "+ v.getCodigoVuelo()+ " se encuentra retrasado");
                }
            }
        }

        /* En caso de que se hayan saltado dias y los vuelos no se hubiesen actualizado */
        for (Vuelo v : this.getVuelosPasadosOperativos()){
            if(v.getEstado() == EstadosVuelo.APROBADO){
                v.enEspacioAereo();
            }
        }

        /* Rechazar vuelos pasados pendientes */
        for (Vuelo v: this.getVuelosPasadosPendientes()){
            if(v.getOrigen().getNombre().equals(this.aeropuertoPropio.getNombre())){
                // Es de salida
                this.salidas.remove(v.getCodigoVuelo());
            }
            else {
                // Es de llegada
                this.llegadas.remove(v.getCodigoVuelo());
            }

            v.rechazarVueloSistema("por el sistema");
            this.salidas.remove(v.getCodigoVuelo());
            this.historico.put(v.getCodigoVuelo(), v);
        }

        /* Rechazar vuelos pendientes nunca aprobados */
        for (Vuelo v : this.solicitudes.values()) {
            if(v.getFecha().isBefore(this.realTime.toLocalDate()) && v.getEstado() == EstadosVuelo.PENDIENTE){
                v.rechazarVueloSistema("por el sistema");
                this.solicitudes.remove(v.getCodigoVuelo());
            }
        }
    }

    private List<Vuelo> getVuelosPasadosOperativos(){
        List<Vuelo> vuelos = new ArrayList<>();
        LocalDate hoy = this.realTime.toLocalDate();
        for (Vuelo v : this.vuelosLlegadas()) {
            if(v.getFecha().isBefore(hoy) && v.getEstado() == EstadosVuelo.APROBADO)
                vuelos.add(v);
                v.setRetraso();
        }
        // TODO: ver si hace falta o se puede quitar
        // for (Vuelo v : this.vuelosSalidas()) {
        //     if(v.getFecha().isBefore(hoy) && v.getEstado() == EstadosVuelo.APROBADO)
        //         vuelos.add(v); esto es distinto
        // }
        return vuelos;
    }

    public Boolean salvarAplicacion(String nombreFichero) {
        try (FileOutputStream fileOut = new FileOutputStream(nombreFichero);  // El archivo donde se guarda
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut)) {

            // Escribir el objeto 'Aplicacion' en el archivo
            objectOut.writeObject(this);
            System.out.println("La aplicación ha sido guardada correctamente.");
            return true;  // Si todo salió bien

        } catch (IOException e) {
            e.printStackTrace();
            return false;  // Si ocurrió un error
        }
    }
    
    public Boolean cargarAplicacion(String nombreFichero) {
        File archivo = new File(nombreFichero);
        if (!archivo.exists()) {
            JOptionPane.showMessageDialog(null,
                "No se encontró el archivo de datos guardado.\nVerifica la ruta o crea una nueva aplicación.",
                "Archivo no encontrado", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        try (FileInputStream fileIn = new FileInputStream(nombreFichero);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {

            // Leer el objeto del archivo
            Aplicacion appCargada = (Aplicacion) objectIn.readObject();
            // Restaurar el estado de la aplicación
            this.nombre = appCargada.nombre;
            this.usuarios = appCargada.usuarios;
            this.usuarioLogueado = null; //o el que estuviera logueado?
            // o no se cambia?
            this.contadorVuelos = appCargada.contadorVuelos;
            this.contadorSolicitudes = appCargada.contadorSolicitudes;
            this.facturas = appCargada.facturas;
            this.tiposDeAviones = appCargada.tiposDeAviones;
            this.aerolineas = appCargada.aerolineas;
            this.solicitudes = appCargada.solicitudes;
            this.solicitudRecurrente = appCargada.solicitudRecurrente;
            this.llegadas = appCargada.llegadas;
            this.salidas = appCargada.salidas;
            this.historico = appCargada.historico;
            this.aeropuertoPropio = appCargada.aeropuertoPropio;
            this.aeropuertoExternos = appCargada.aeropuertoExternos;
            this.solicitudesPendientes = appCargada.solicitudesPendientes;
            this.notificacionesActivas = appCargada.notificacionesActivas;
            this.realTime = appCargada.realTime;            

            // this.aeropuerto = appCargada.aeropuerto;
            // this.usuarios = appCargada.usuarios;
            // ... Restaurar el resto de campos

            System.out.println("La aplicación ha sido cargada correctamente.");
            return true;  // Si todo salió bien

        } catch (java.io.InvalidClassException ice) {
            System.err.println("❌ Archivo incompatible: " + ice.getMessage());
            JOptionPane.showMessageDialog(null,
                "El archivo guardado no es compatible con esta versión del sistema.\n" +
                "Es probable que se haya actualizado la aplicación.\n\n" +
                "Puedes eliminar el archivo y crear uno nuevo.",
                "Error de compatibilidad", JOptionPane.ERROR_MESSAGE);
            return false;

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Ocurrió un error al cargar los datos de la aplicación.",
                "Error de carga", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public Boolean cargarAeropuertosExternos(String filePath) {
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        try {
            // Leer todas las líneas del fichero
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            
            // Verificar que hay al menos dos líneas (encabezado + datos)
            if (lines.size() < 2) {
                System.err.println("El fichero no contiene datos.");
                return false;
            }
            
            // Procesar las líneas (omitiendo la primera línea, el encabezado)
            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i).trim();
                if (line.isEmpty()) continue; // omitir líneas vacías
                
                // Separamos por punto y coma
                String[] parts = line.split(";");
                if (parts.length < 7) {
                    System.err.println("Línea mal formateada en el fichero: " + line);
                    continue;
                }
                
                // Extraer y limpiar los campos
                String nombre = parts[0].trim();
                String ciudadMasCercana = parts[1].trim();
                int distanciaCiudad = Integer.parseInt(parts[2].trim());
                String direccion = parts[3].trim();
                String codigo = parts[4].trim();
                
                // El campo de horario tiene el formato "HH:MM-HH:MM"
                String horario = parts[5].trim();
                String[] horarios = horario.split("-");
                if (horarios.length < 2) {
                    System.err.println("Horario mal formateado en: " + line);
                    continue;
                }
                LocalTime apertura = LocalTime.parse(horarios[0].trim());
                LocalTime cierre = LocalTime.parse(horarios[1].trim());
                // La diferencia horaria (con respecto a Madrid) puede ser un número decimal.
                float diferenciaHoraria = Float.parseFloat(parts[6].trim());

                
                if(!this.aeropuertoExternos.containsKey(codigo)) {
                    // Crear el AeropuertoExterno
                    AeropuertoExterno aeropuerto = new AeropuertoExterno(
                        nombre, ciudadMasCercana, distanciaCiudad, direccion, codigo, 
                        apertura, cierre, diferenciaHoraria);

                    // Comprobar que no hay ningun error al añadir la conexion
                    if(!this.aeropuertoPropio.añadirConexion(aeropuerto)) {
                        System.err.println("No se pudo añadir conexion, abortando");
                        return false;
                    }
                    // Añadir al mapa usando el nombre como clave
                    this.aeropuertoExternos.put(nombre, aeropuerto);
                }
            }
            return true;
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return false;
        }
    }

    // cargar una "revista?" con todos los tipos de aviones disponibles
    public Boolean cargarTiposDeAviones(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String linea;
            boolean primeraLinea = true;

            while ((linea = br.readLine()) != null) {
                if (primeraLinea) { // Saltar la cabecera
                    primeraLinea = false;
                    continue;
                }

                String[] parts = linea.split(";");
                if (parts.length != 9) {
                    System.err.println("Formato incorrecto en línea: " + linea);
                    continue;
                }

                String identificador = parts[0].trim();
                String marca = parts[1].trim();
                String modelo = parts[2].trim();
                int capacidad = Integer.parseInt(parts[3].trim());
                boolean controlTemperatura = parts[4].trim().equals("1");
                int largo = Integer.parseInt(parts[5].trim());
                int alto = Integer.parseInt(parts[6].trim());
                int ancho = Integer.parseInt(parts[7].trim());
                int categoriaInt = Integer.parseInt(parts[8].trim()); // Leer el valor de la categoría

                // Asignar la categoría según el valor 0 o 1
                CategoriaAvion categoria = (categoriaInt == 1) ? CategoriaAvion.MERCANCIAS : CategoriaAvion.PASAJEROS;

                if(!this.tiposDeAviones.containsKey(identificador)) {
                    // Crear un nuevo TipoAvion y añadirlo al mapa
                    TipoAvion tipoAvion = new TipoAvion(identificador, marca, modelo, capacidad, controlTemperatura, largo, alto, ancho, categoria);
                    tiposDeAviones.put(identificador, tipoAvion);
                } else {
                    //System.err.println("El tipo de avión con identificador " + identificador + " ya existe.");
                    continue;
                }

            }
            return true;
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            return false;
        }   
    }

    public Boolean añadirAeropuertoExterno(String nombre, String ciudadMasCercana, int distanciaCiudad, String direccion, String codigo,
                                        LocalTime horaApertura, LocalTime horaCierre, int diferenciaHoraria){
        
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        if (this.aeropuertoExternos.containsKey(codigo)) return false; // o true??
        AeropuertoExterno aeropuertoExterno = new AeropuertoExterno(nombre, ciudadMasCercana, distanciaCiudad, direccion, codigo, horaApertura, horaCierre, diferenciaHoraria);
        this.aeropuertoExternos.put(codigo, aeropuertoExterno);
        return this.aeropuertoPropio.añadirConexion(aeropuertoExterno);
    }

    public Boolean emitirFactura(Aerolinea aerolinea, LocalDate fecha) throws Exception {
        if (!checkLog(Rol.GESTORAEROPUERTO)) return false;
        Factura factura = new Factura(fecha, aerolinea);
        
        if(aerolinea.vincularFactura(factura)){
            this.facturas.add(factura);
        }

        if (aerolinea.getVuelos().isEmpty() && aerolinea.getVueloCompartido().isEmpty()) throw new IllegalStateException("No hay vuelos para emitir factura");

        for (Vuelo v : aerolinea.getVuelos()) {
            if(v.getEstado().equals(EstadosVuelo.FINALIZADO) || v.getEstado().equals(EstadosVuelo.VOLANDO)){
                if (Aplicacion.init("").historico.containsKey(v.getCodigoVuelo())){
                    if (v.getFecha().getYear() == fecha.getYear() && v.getFecha().getMonthValue() == fecha.getMonthValue()){
                        // TODO AÑADIR IF PARA COMPROBAR QUE EL VUELO NO ESTÉ COBRADO YA en su totalidad
                        factura.añadirVueloACobro(v);
                        v.setFacturaACobrar(factura);
                    }
                }
            }
        }

        for (Vuelo v : aerolinea.getVueloCompartido()) {
            if(v.getEstado().equals(EstadosVuelo.FINALIZADO) || v.getEstado().equals(EstadosVuelo.VOLANDO)){
                if (Aplicacion.init("").historico.containsKey(v.getCodigoVuelo())){
                    if (v.getFecha().getYear() == fecha.getYear() && v.getFecha().getMonthValue() == fecha.getMonthValue()){
                        // TODO AÑADIR IF PARA COMPROBAR QUE EL VUELO NO ESTÉ COBRADO YA en su totalidad
                        factura.añadirVueloACobro(v);
                        v.setFacturaACobrar(factura);
                    }
                }
            }
        }

        try {
            generarPDFFactura(factura);
        } catch (Exception e) {
            throw e;
        }

        
        return false;
    }

    public Factura getFacturaById(String id){
        for (Factura f : this.facturas) {
            if(f.getId().equals(id)) return f;
        }
        
        return null;
    }

    public boolean facturaYaEmitida(Aerolinea aerolinea, LocalDate fecha) {
        for (Factura f : this.facturas) {
            if (f.getAerolinea().equals(aerolinea)
                && f.verFechaEmision().getYear() == fecha.getYear()
                && f.verFechaEmision().getMonth() == fecha.getMonth()) {
                return true;
            }
        }
        return false;
    }

    public List<Aerolinea> getAerolineasDisponibles(){
        return Collections.unmodifiableList(new ArrayList<>(this.aerolineas.values()));
    }

    public Boolean generarPDFFactura(Factura factura) throws Exception {
        if (factura.getVuelosCobrados().isEmpty()) return false;

        System.out.println("Generando PDF de la factura: " + factura.getCompanyLogo());

        try {
            InvoiceSystem.createInvoice(factura, "./tmp/");   
            return true;
        } catch (NonExistentFileException | UnsupportedImageTypeException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Boolean aceptarPagoFactura(Factura factura){
        if(!checkLog(Rol.GESTORAEROPUERTO)) return false;
        List<Usuario> receptores = new ArrayList<>();
        receptores.add(this.getAeropuertoPropio().getGestorDelAeropuerto());
        receptores.add(this.usuarioLogueado);
        this.nuevaNotificacion(receptores, "Factura: "+ factura.getId() + " ha sido recibido su pago por el gestor");
        factura.facturaPagada();
        return true;
    }
    
    public Boolean pagarFactura(Factura factura, String cardNumber) {
        if(!checkLog(Rol.OPERADORAEROLINEA)) return false;
        if(!this.usuarioLogueado.getNombreUsuario().equals(this.getAerolinea(factura.getAirline()).getOperadorAerolinea().getNombreUsuario())) return false;
        try {
            TeleChargeAndPaySystem.charge(cardNumber, "Pago factura de: " + factura.getAirline(), factura.getPrice(), true);
            List<Usuario> receptores = new ArrayList<>();
            receptores.add(this.getAeropuertoPropio().getGestorDelAeropuerto());
            receptores.add(this.usuarioLogueado);
            this.nuevaNotificacion(receptores, "Factura: "+ factura.getId() + " ha sido pagada, pendiente de aprobar por el gestor");
            return true;
        } catch (OrderRejectedException e) { 
            e.printStackTrace();
            return false;
        }
    }
    

    /* Se entiende que se usa a efectos de la simulacion unicamente */
    public void setRealTime(LocalDateTime nuevaFechaHora){
        this.realTime = nuevaFechaHora;
        actualizar();
    }

    public void avanzarCincoMinutos(){
        this.realTime = this.realTime.plusMinutes(5);
        actualizar();
    }

    public void avanzarTreintaMinutos(){
        this.realTime = this.realTime.plusMinutes(30);
        actualizar();
    }

    public void avanzarUnaHora(){
        this.realTime = this.realTime.plusHours(1);
        actualizar();
    }

    public void avanzarUnDia(){
        this.realTime = this.realTime.plusDays(1);
        actualizar();
    }

    public LocalDateTime getRealTime(){
        return this.realTime;
    }

    public String getNombre(){
        return this.nombre;
    }

    public EstadosVuelo getEstadoVuelo(String codigo) {
        Vuelo vuelo = buscarVueloxCodigo(codigo);
        return (vuelo != null) ? vuelo.getEstado() : null;
    } 

    @Override
    public String toString() {
        return "Aplicacion [horaReal= " + realTime + ", nombre=" + nombre + ", \nusuarios=" + usuarios.keySet() + ", \nusuarioLogueado=" + (usuarioLogueado == null ? "Nadie conectado" : usuarioLogueado.getNombreUsuario()) 
                + ", \nfacturas=" + facturas + ", \ntiposDeAviones=" + tiposDeAviones.keySet() + ", \naerolineas=" + aerolineas.keySet()
                + ", \nllegadas=" + llegadas.keySet() + ", \nsalidas=" + salidas.keySet() + ", \nhistorico=" + historico.entrySet() + ", \naeropuertoPropio="
                + aeropuertoPropio.getNombre() + ", \naeropuertoExternos=" + aeropuertoExternos.keySet() + ", \nsolicitudesPendientes="
                + solicitudesPendientes + ", \nnotificacionesActivas=" + notificacionesActivas + ", maxVuelosRecurrentes="
                + maxVuelosRecurrentes + "]";
    }

    
}
