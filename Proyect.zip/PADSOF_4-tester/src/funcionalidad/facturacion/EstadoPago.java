package funcionalidad.facturacion;
public enum EstadoPago {
    PENDIENTE,
    PAGADA,
    VENCIDA
}