package funcionalidad.facturacion;
import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aeropuerto.elementos.ElementoFacturable;
import funcionalidad.aplicacion.Aplicacion;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.uam.eps.padsof.invoices.*;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;

public class Factura implements Serializable, IInvoiceInfo {
    private static int ID = 0;
    private int idFactura;
    private LocalDate fechaEmision;
    private List<Vuelo> vuelosCobrados;
    private double surcharge = 0;
    
    //private double surcharge;

    /* REFERENCIAS */
    private Aerolinea aerolinea;
    private EstadoPago estado;

    public Factura(LocalDate fechaEmision, Aerolinea aerolinea) {
        Factura.ID ++;
        this.idFactura = Factura.ID;
        this.fechaEmision = fechaEmision;
        this.aerolinea = aerolinea;
        this.estado = EstadoPago.PENDIENTE;
        this.vuelosCobrados = new ArrayList<>();
    }

    /* RELACION BIDIRECCIONAL (ESTO LO HIZO SEBITAS, PORQUE ES NECESARIO Y PARA QUE NO DE ERRORES) */
    public void agregarAerolinea (Aerolinea aerolinea) {
        if (this.aerolinea == null) {  // Asegúrate de que no se agregue más de una aerolínea
            this.aerolinea = aerolinea;
            aerolinea.vincularFactura(this);  // Relación bidireccional
        }
    }

    public void desvincularAerolinea (Aerolinea aerolinea) {
        if (this.aerolinea != null) {  // Asegúrate de que no se elimine si no hay una aerolínea
            this.aerolinea = null;
            aerolinea.desvincularFactura(this); // Relación bidireccional
        }
    }

    public String getId(){
        return String.format("F-%05d", this.idFactura);
    }

    public void añadirVueloACobro(Vuelo vuelo){
        if (vuelo.getEnTiempo()) {
            this.surcharge += 50;
        }

        vuelo.vueloCobrado();
        this.vuelosCobrados.add(vuelo);
    }

    public void facturaPagada(){
        Aplicacion app = Aplicacion.init("acceso");
        if(app.getUsuarioLogueado() == null) return;
        if(!app.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return;
        this.estado = EstadoPago.PAGADA;
    }

    public LocalDate verFechaEmision(){
        return this.fechaEmision;
    }

    public EstadoPago getEstadoPago(){
        return this.estado;
    }

    @Override
    public String getAirline() {
        return this.aerolinea.getNombre();
    }

    public Aerolinea getAerolinea(){
        return this.aerolinea;
    }

    @Override
    public double getBasePrice() {
        return Aplicacion.init("a").getAeropuertoPropio().getPrecioBase();
    }

    @Override
    public String getCompanyName() {
        return Aplicacion.init("a").getNombre();
    }

    @Override
    public String getInvoiceDate() {
        return this.fechaEmision.toString();
    }

    @Override
    public String getInvoiceIdentifier() {
        return String.format("F-%05d", this.idFactura);
    }

    @Override
    public double getPrice() {
        double price = 0;
        price += getBasePrice();
        price += getSurcharge();
        for (IResourceUsageInfo r : getResourcePrices()) {
            price+=r.getPrice();
        }
        return price;
    }

    public List<IResourceUsageInfo> getResourcePrices () { 
		List<IResourceUsageInfo> lista = new ArrayList<>();
        for (Vuelo v : this.vuelosCobrados) {
            for (ElementoFacturable ef : v.getAllElementosFacturable()) {
                ef.setVueloTemporal(v);
                lista.add(ef);
            }
        }
        return lista;
	}

    public String getCompanyLogo () { return "./resources/elbicho.jpg"; }

    @Override
    public double getSurcharge() {
        return surcharge;
    }

    public List<Vuelo> getVuelosCobrados(){
        return Collections.unmodifiableList(this.vuelosCobrados);
    }

    @Override
    public String toString() {
        return "Factura [idFactura=" + idFactura + ", fechaEmision=" + fechaEmision + ", vuelosCobrados="
                + vuelosCobrados.toString() + ",\naerolinea=" + aerolinea.getNombre() + ", estado=" + estado + "]";
    }

}
