package funcionalidad.otro;

public enum ElementosFacturables {
    APARCAMIENTO,
    FINGER,
    PUERTA,
    HANGAR
}
