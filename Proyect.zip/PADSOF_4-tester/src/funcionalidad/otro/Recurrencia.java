package funcionalidad.otro;

public enum Recurrencia {
    DIARIA,
    SEMANAL,
    MENSUAL
}
