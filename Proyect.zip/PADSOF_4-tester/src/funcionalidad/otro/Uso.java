package funcionalidad.otro;
public enum Uso {
    DESPEGUE,
    ATERRIZAJE
}
