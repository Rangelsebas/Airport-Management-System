package funcionalidad.otro;

import java.io.Serializable;
import java.util.Objects;

public class Dimension implements Serializable{
    private int largo;
    private int ancho;
    private int alto;

    public Dimension(int largo, int ancho, int alto){
        this.largo = largo;
        this.ancho = ancho;
        this.alto = alto;
    }

    public Dimension(int largo, int ancho){
        this.largo = largo;
        this.ancho = ancho;
        this.alto = -1;
    }

    /* GETTERS  */
    public int getLargo() {
        return this.largo;
    }

    public int getAncho() {
        return this.ancho;
    }

    public int getAlto() {
        return this.alto;
    }

    /* Esto lo hizo angelito para comprobar si un avion cabe en un hangar por ejemplo */
    public Boolean puedeContener(Dimension contenido){
        if (this.alto >= contenido.alto){
            if(this.ancho >= contenido.ancho){
                if(this.largo >= this.largo){
                    return true;
                }
            }
        }
        return false;
    }

    public Boolean puedeContenerHorizontal(Dimension contenido){
        if(this.ancho >= contenido.ancho){
            if(this.largo >= this.largo){
                return true;
            }
        }
        return false;
    }

    /*  ESTO LO HIZO SEBITAS PARA BLINDAR LOS TESTS, PARA QUE EJECUTE CORRECTAMENTE LOS TESTS NEGATIVOS 
     * 
     * Expliacacion de esto (para que Ángel despues no me eche broma que tal y blablablabla jajajj)
     * 
     * - En assertEquals(new Dimension(40, 35, 12), tipoAvion.getDimension());
     * - Estamos comparando dos objetos diferentes de Dimension, aunque tengan los mismos valores.
     * - Java compara objetos por referencia, no por contenido, a menos que equals() esté sobreescrito en Dimension.
     * 
    */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Dimension that = (Dimension) obj;
        return this.largo == that.largo &&
            this.ancho == that.ancho &&
            this.alto == that.alto;
    }

    @Override
    public int hashCode() {
        return Objects.hash(largo, ancho, alto);
    }

    @Override
    public String toString() {
        return "Dimensiones: largo: " + largo + ", ancho: " + ancho + ", alto: " + alto + "";
    }

    
}
