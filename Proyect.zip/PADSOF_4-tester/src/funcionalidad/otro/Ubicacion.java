package funcionalidad.otro;

public enum Ubicacion {
    EN_AEROPUERTO,
    FUERA_DEL_AEROPUERTO
}
