package funcionalidad.aeropuerto.elementos;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;

public class Bus extends ElementoAeropuerto {
    private String nombre;
    private int capacidad = 100;

    public Bus(String nombre){
        super();
        this.nombre = String.format("%s%d", nombre, this.id);
    }

    @Override
    public Boolean ocupar(Vuelo vuelo){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if(this.ocupadoPor.isEmpty()){ 
            this.ocupadoPor.add(vuelo);                                         // varios buses?
            return true;
        }
        return false;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }
}
