package funcionalidad.aeropuerto.elementos;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;

public abstract  class ElementoAeropuerto implements Serializable {
    private static int ID = 0;
    protected final int id;
    protected List<Vuelo> ocupadoPor;

    public ElementoAeropuerto(){
        ElementoAeropuerto.ID++;
        this.id = ElementoAeropuerto.ID;
        this.ocupadoPor = new ArrayList<Vuelo>();
    }

    public Boolean ocupar(Vuelo vuelo){
        /* COMPROBAR QUE EL USUARIO TIENE PERMISO */
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        /* En esta clase el metodo solo vale para elementos que solo pueden tener como maximo un vuelo */
        if(this.ocupadoPor.isEmpty()){
            this.ocupadoPor.add(vuelo);
            return true;
        }
        else if(this.ocupadoPor.contains(vuelo)) return true;
        return false;
    }
    
    public Boolean liberar(Vuelo vuelo){
        /* COMPROBAR QUE EL USUARIO TIENE PERMISO */
        /* Esto valdría? */
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        /* En esta clase el metodo solo vale para elementos que solo pueden tener como maximo un vuelo */
        if (!this.ocupadoPor.isEmpty()){
            this.ocupadoPor.removeFirst();
            return true;
        }
        return false; // o true?
    }

    public Boolean checkDisponible(){
        /* En esta clase el metodo solo vale para elementos que solo pueden tener como maximo un vuelo */
        return this.ocupadoPor.isEmpty();
    }

    @Override
    public String toString() {
        return "ElementoAeropuerto [id=" + id + "]";
    }

}