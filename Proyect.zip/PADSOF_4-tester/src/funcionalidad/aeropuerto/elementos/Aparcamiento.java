package funcionalidad.aeropuerto.elementos;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Dimension;
import funcionalidad.otro.ElementosFacturables;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;

public class Aparcamiento extends ElementoFacturable {
    private int capacidad;
    private Dimension dimensionesDePlaza;

    public Aparcamiento(String nombre, int capacidad, double costexhora, Dimension dimensionesDePlaza) {
        super(nombre, costexhora);
        this.capacidad = capacidad;
        this.dimensionesDePlaza = dimensionesDePlaza;
    }

    @Override
    public Boolean ocupar(Vuelo vuelo){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (this.ocupadoPor.contains(vuelo)) return true;
        else if (this.ocupadoPor.size() < capacidad){
            if (this.dimensionesDePlaza.puedeContenerHorizontal(vuelo.getAvion().getTipoAvion().getDimension())){
                this.ocupadoPor.add(vuelo);
            }
        }
        return true;
    }

    @Override
    public Boolean liberar(Vuelo vuelo){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(aplicacion.getUsuarioLogueado() == null) return false;;
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (this.ocupadoPor.contains(vuelo)){
            this.ocupadoPor.remove(vuelo);
        }
        return false;
    }

    public int vuelosOcupando(Vuelo vuelo){
        return this.ocupadoPor.size();
    }

    public Boolean askVueloEnAparcamiento(Vuelo vuelo){
        return this.ocupadoPor.contains(vuelo);
    }

    public Boolean cambiarCostexhora(int nuevoCoste){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if (nuevoCoste <= 0) return false;
        this.costexhora = nuevoCoste;
        return true;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public Dimension getDimensionesDePlaza() {
        return dimensionesDePlaza;
    }

    @Override
    public Boolean checkDisponible(){
        if (this.ocupadoPor.size() < capacidad) return true;
        return false;
    }

    /* ----- funciones exclusivas facturacion ------ */
    @Override
    public double getHourlyPrice() {
        return costexhora;
    }

    @Override
    public double getPrice() {
        long minutos = this.vueloTemporalCobro.getMinutosUso(ElementosFacturables.APARCAMIENTO);
        double ret = costexhora * ((double) minutos / 60.0);
        return (ret * this.vueloTemporalCobro.getParticipacionAerolinea(this.vueloTemporalCobro.getFacturaACobrar().getAerolinea())) / 100;
    }

    @Override
    public String getResourceDescription() {
        return this.vueloTemporalCobro.getElementoEspecifico(ElementosFacturables.APARCAMIENTO).getNombre();
    }

    @Override
    public String getUsageTime() {
        return this.vueloTemporalCobro.getMinutosUso(ElementosFacturables.APARCAMIENTO) + " minutos";
    }
   

    @Override
    public String toString() {
        return "Aparcamiento " + nombre + ", capacidad: " + capacidad + ", coste por hora: " + costexhora + ", dimensiones de plaza: "
                + dimensionesDePlaza.toString();
    }

        
}
