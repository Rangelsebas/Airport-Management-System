package funcionalidad.aeropuerto.elementos;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Dimension;
import funcionalidad.usuarios.ControladorAereo;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Terminal extends ElementoAeropuerto {
    private String nombre;
    private int capacidad;
    private HashMap<String, Puerta> puertas;
    private List<Bus> buses;
    private List<Finger> fingers; // Necesario??
    private HashMap<String, ControladorAereo> controladoresAsignados;

    private char letra = 'A';

    public Terminal(String nombre){
        super();
        this.nombre = nombre;
        this.capacidad = 0;
        this.puertas = new HashMap<>();
        this.buses = new ArrayList<>();
        this.fingers = new ArrayList<>();
        this.controladoresAsignados = new HashMap<>();
    }

    @Override
    public Boolean ocupar(Vuelo vuelo){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if(this.ocupadoPor.contains(vuelo)) return true;
        if (this.ocupadoPor.size() < capacidad) {
            this.ocupadoPor.add(vuelo);
            return true;
        }
        return false;
    }

    @Override
    public Boolean liberar(Vuelo vuelo){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if(this.ocupadoPor.contains(vuelo)){
            this.ocupadoPor.remove(vuelo);
            return true;
        }
        return false;
    }

    /* Dimensiones para el finger asociado al par de puertas */
    public Boolean añadirPuertas(double costexhora, int largo, int ancho, int alto, int cantidad){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if (cantidad <= 0 || costexhora <= 0 || largo <= 0 || ancho <= 0 || alto <= 0){
            return false;
        }

        int sumaCapacidad = cantidad/2;
        this.capacidad += sumaCapacidad;

        Dimension dimensiones = new Dimension(largo, ancho, alto);
        Finger finger = new Finger(costexhora, dimensiones);
        this.fingers.add(finger);

        for (int i = 1; i <= cantidad; i++){
            if(i%2 == 1 && i > 1){ // i > 1 para no desperdiciar la primera instancia
                finger = new Finger(costexhora, dimensiones);
                this.fingers.add(finger);
            }
            String nombre = String.format("%c%02d", this.letra, i);
            Puerta puerta = new Puerta(nombre, costexhora, finger); 
            finger.setPertenencia(puerta);
            this.puertas.put(puerta.getNombre(), puerta);
        }
        this.letra++;
        return true;
    }

    public Boolean añadirBuses(int cantidad){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if (cantidad <= 0){
            return false;
        }

        for (int i = 0; i < cantidad; i++){
            Bus bus = new Bus(this.nombre);
            this.buses.add(bus);
        }
        return true;
    }

    public int getVuelosOcupando(){
        return this.ocupadoPor.size();
    }

    public Boolean askVueloEnTerminal(Vuelo vuelo){
        return this.ocupadoPor.contains(vuelo);
    }

    public String getNombre(){
        return this.nombre;
    }

    public int getCapacidad(){
        return this.capacidad;
    }

    public Puerta getPuerta(String nombre){
        return this.puertas.get(nombre);
    }

    public List<Puerta> getPuertas(){
        return Collections.unmodifiableList(new ArrayList<>(this.puertas.values()));
    }

    public int getNumeroPuertas(){
        return this.puertas.size();
    }

    public Bus getBusDisponible(){
        for (Bus b : this.buses) {
            if(b.checkDisponible()){
                return b;
            }            
        }
        return null;
    }

    @Override
    public Boolean checkDisponible(){
        if (this.ocupadoPor.size() < capacidad) return true;
        return false;
    }

    public Boolean añadirControlador(ControladorAereo controlador) {
        if(controlador == null) return false;
        if(!controlador.checkRol(Rol.CONTROLADORAEREO)) return false;

        /* Comprobamos que no esté en otra terminal, en principio nunca lo estará ya que solo se asigna cuando se crea el usuario */
        for (Terminal t : Aplicacion.init("").getAeropuertoPropio().getTerminales()) {
            if(t.checkControladorEnTerminal(controlador.getNombreUsuario())){
                return false;
            }
        }

        if (!controlador.asignarTerminal(this)) {
            return false;
        }
        controladoresAsignados.put(controlador.getNombreUsuario(), controlador);

        return true;
    }

    public Boolean eliminarControlador(ControladorAereo controlador) {
        if(controlador == null) return false;
        if(!controlador.checkRol(Rol.CONTROLADORAEREO)) return false;

        if(controladoresAsignados.containsKey(controlador.getNombreUsuario())){
            controladoresAsignados.remove(controlador.getNombreUsuario());
            return true;
        }
        return false;
    }

    public List<ControladorAereo> getControladores(){
        return Collections.unmodifiableList(new ArrayList<>(this.controladoresAsignados.values()));
    }

    public int getNumeroControladores(){
        return this.controladoresAsignados.size();
    }

    public Boolean checkControladorEnTerminal(String nombreUsuario) {
        if (nombreUsuario == null) return false;
        return this.controladoresAsignados.containsKey(nombreUsuario);
    }

    @Override
    public String toString() {
        return "Terminal nombre=" + nombre + ", capacidad=" + capacidad + ", puertas=" + puertas.size() + ", buses=" + buses.size()
                + ", fingers=" + fingers.size() + "";
    }

    
}
