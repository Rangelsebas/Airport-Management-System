package funcionalidad.aeropuerto.elementos;

import funcionalidad.aplicacion.Aplicacion;
import es.uam.eps.padsof.invoices.IResourceUsageInfo;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;

public class ElementoFacturable extends ElementoAeropuerto implements IResourceUsageInfo{
    protected double costexhora;
    protected Vuelo vueloTemporalCobro;
    protected String nombre;

    public ElementoFacturable(String nombre, double costexhora){
        this.costexhora = costexhora;
        this.nombre = nombre;
    }

    public String getNombre(){
        return this.nombre;
    }

    /* ----- funciones exclusivas facturacion ------ */
    public void setVueloTemporal(Vuelo vuelo){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(aplicacion.getUsuarioLogueado() == null) return;
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return;

        this.vueloTemporalCobro = vuelo;
    }

    public void añadirVueloACobro(Vuelo vuelo){
        this.vueloTemporalCobro = vuelo;
    }

    @Override
    public double getHourlyPrice() {
        return this.costexhora;
    }

    @Override
    public double getPrice() {
        return -1;
    }

    @Override
    public String getResourceDescription() {
        return "";
    }

    @Override
    public String getUsageTime() {
        return "";
    }
}
