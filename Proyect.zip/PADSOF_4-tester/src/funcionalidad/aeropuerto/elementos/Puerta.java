package funcionalidad.aeropuerto.elementos;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.ElementosFacturables;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;

public class Puerta extends ElementoFacturable{
    private Finger finger;

    public Puerta(String nombre, double costexhora, Finger finger){
        super(nombre, costexhora);
        this.nombre = nombre;
        this.finger = finger;
    }

    @Override
    public boolean equals(Object puerta){
        if (this == puerta) return true;
        if (puerta == null || getClass() != puerta.getClass()) return false;
        Puerta that = (Puerta) puerta;
        return this.id == that.id;
    }

    public Boolean ocupar(Vuelo vuelo){
        /* COMPROBAR QUE EL USUARIO TIENE PERMISO */
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA) && !aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        /* En esta clase el metodo solo vale para elementos que solo pueden tener como maximo un vuelo */
        if(this.ocupadoPor.isEmpty()){
            this.ocupadoPor.add(vuelo);
            return true;
        }
        throw new IllegalStateException("La puerta ya está ocupada por otro vuelo.");
    }

    public Boolean cambiarCostexhora(int nuevoCoste){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if (nuevoCoste <= 0) return false;
        this.costexhora = nuevoCoste;
        return true;
    }

    public Boolean usarFinger(Vuelo vuelo){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if(this.finger.checkDisponible()){
            if (this.finger.getDimensiones().getAlto() >= vuelo.getAvion().getTipoAvion().getDimension().getAlto()){
                vuelo.asignarFinger(this.finger);
                return true;
            }
        }
        return false;
    }

    public Boolean dejarFinger(){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        return finger.dejarPuerta(this);
    }

    /* ----- funciones exclusivas facturacion ------ */

    @Override
    public double getHourlyPrice() {
        return costexhora;
    }

    @Override
    public double getPrice() {
        long minutos = this.vueloTemporalCobro.getMinutosUso(ElementosFacturables.PUERTA);
        double ret = costexhora * ((double) minutos / 60.0);
        return (ret * this.vueloTemporalCobro.getParticipacionAerolinea(this.vueloTemporalCobro.getFacturaACobrar().getAerolinea())) / 100;
    }

    @Override
    public String getResourceDescription() {
        return this.vueloTemporalCobro.getElementoEspecifico(ElementosFacturables.PUERTA).getNombre();
    }

    @Override
    public String getUsageTime() {
        return this.vueloTemporalCobro.getMinutosUso(ElementosFacturables.PUERTA) + " minutos";
    }

    @Override
    public String toString() {
        return "Puerta [id=" + id + ", nombre=" + nombre + "]";
    }

    
}
