package funcionalidad.aeropuerto.elementos;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Dimension;
import funcionalidad.otro.ElementosFacturables;
import funcionalidad.otro.Ubicacion;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Hangar extends ElementoFacturable {
    private int capacidad;
    private Dimension dimensiones;
    private HashMap<String, Avion> aviones;
    private HashMap<LocalDate, Integer> reservas;
    private CategoriaAvion tipo;
    private Boolean permiteMercanciaPeligrosa;

    public Hangar(String nombre, int capacidad, double costexhora, Dimension dimensiones, CategoriaAvion tipo, Boolean permiteMercanciaPeligrosa) {
        super(nombre, costexhora);
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.dimensiones = dimensiones;
        this.aviones = new HashMap<>();
        this.reservas = new HashMap<>();
        this.tipo = tipo;
        this.permiteMercanciaPeligrosa = permiteMercanciaPeligrosa;
    }

    @Override
    public Boolean ocupar(Vuelo vuelo){
        return false;
    }

    @Override
    public Boolean liberar(Vuelo vuelo){
        return false;
    }

    public Boolean guardarAvion(Avion avion){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if(!avion.getTipoAvion().getCategoria().equals(this.tipo)) return false;
        if(avion.getTipoAvion().getCategoria().equals(CategoriaAvion.MERCANCIAS) && this.tipo.equals(CategoriaAvion.MERCANCIAS)){
            if(avion.tieneMaterialPeligroso() && !this.permiteMercanciaPeligrosa) return false;
        }
        if (this.aviones.containsKey(avion.getMatricula())) return true;
        else if (this.ocupadoPor.size() < capacidad){
            if (this.dimensiones.puedeContener(avion.getTipoAvion().getDimension())){
                this.aviones.put(avion.getMatricula(), avion);
                avion.guardarEnHangar();
                return true;
            }
        }
        return false;
    }

    public Boolean guardarAvionAlCrearse(Avion avion){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.OPERADORAEROLINEA)) return false;
        if (this.aviones.containsKey(avion.getMatricula())) return true;
        else if (this.ocupadoPor.size() < capacidad){
            if (this.dimensiones.puedeContener(avion.getTipoAvion().getDimension())){
                this.aviones.put(avion.getMatricula(), avion);
                avion.guardarEnHangar();
                return true;
            }
        }
        return false;
    }

    public Boolean sacarAvion(Avion avion){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if (!this.aviones.containsKey(avion.getMatricula())) return false;
        this.aviones.remove(avion.getMatricula());
        avion.sacarDeHangar();
        return false;
    }

    public Boolean getPermiteMercanciaPeligrosa() {
        return permiteMercanciaPeligrosa;
    }

    public CategoriaAvion getTipo() {
        return tipo;
    }

    public int avionesOcupando(){
        return  this.aviones.size();
    }

    public List<Avion> avionesEnHangar() {
        return Collections.unmodifiableList(new ArrayList<>(this.aviones.values()));
    }
    
    public Boolean askAvionEnHangar(String avion){
        return this.aviones.containsKey(avion);
    }

    public Boolean reservarHangar(LocalDate fecha){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if (!this.reservas.containsKey(fecha)){
            this.reservas.put(fecha, 1);
            return true;
        } else {
            int numReservas = this.reservas.get(fecha);
            if (numReservas < this.capacidad){
                this.reservas.put(fecha, numReservas + 1);
                return true;
            }
        }
        return false;
    }

    public Boolean cambiarCostexhora(int nuevoCoste){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if (nuevoCoste <= 0) return false;
        this.costexhora = nuevoCoste;
        return true;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public Dimension getDimensiones() {
        return dimensiones;
    }

    @Override
    public Boolean checkDisponible(){
        if (this.ocupadoPor.size() < capacidad) return true;
        return false;
    }

    /* ----- funciones exclusivas facturacion ------ */

    @Override
    public double getHourlyPrice() {
        return costexhora;
    }

    @Override
    public double getPrice() {
        // double ret = 0;
        // Avion avion = this.vueloTemporalCobro.getAvion();
        // LocalDate fecha = this.vueloTemporalCobro.getFecha();
        // Ubicacion ubicacion = avion.getUbicacion(fecha);

        // int dias = 1;
        // while (ubicacion == null) {
        //     ubicacion = avion.getUbicacionAnteriorA(fecha);
        //     fecha = fecha.minusDays(1);
        //     dias++;
        //     if (!fecha.getMonth().equals(fecha.getMonth()))
        //         break;
        // }
        // if (ubicacion == null) return 0;
        // else if (ubicacion.equals(Ubicacion.EN_AEROPUERTO)) {
        //     ret = this.costexhora * 8 * dias; // Digamos que pasó la noche en el hangar
        // } else if (ubicacion.equals(Ubicacion.FUERA_DEL_AEROPUERTO)) {
        //     return 0;
        // }
        // return (ret * this.vueloTemporalCobro.getParticipacionAerolinea(this.vueloTemporalCobro.getFacturaACobrar().getAerolinea())) / 100;
        Avion avion = this.vueloTemporalCobro.getAvion();

        // Último día del mes anterior a la fecha del vuelo
        LocalDate vueloDate = this.vueloTemporalCobro.getFecha();
        LocalDate fechaInicio = vueloDate.minusMonths(1).withDayOfMonth(vueloDate.minusMonths(1).lengthOfMonth());

        int diasContados = 0;
        int diasFacturados = 0;
        LocalDate fechaActual = fechaInicio;
        Ubicacion ubicacion = null;

        // Buscar la última ubicación conocida hacia atrás
        while (diasContados < 30) {
            ubicacion = avion.getUbicacion(fechaActual);

            if (ubicacion == null) {
                ubicacion = avion.getUbicacionAnteriorA(fechaActual);
            }

            if (ubicacion != null) {
                break;
            }

            fechaActual = fechaActual.minusDays(1);
            diasContados++;
        }

        // Si después de 30 días no sabemos nada, no cobramos
        if (ubicacion == null || ubicacion != Ubicacion.EN_AEROPUERTO) return 0;

        // Volvemos a contar hacia atrás máximo 30 días, mientras siga en el aeropuerto
        fechaActual = fechaInicio;
        for (int i = 0; i < 30; i++) {
            Ubicacion ub = avion.getUbicacion(fechaActual);
            if (ub == null || ub == Ubicacion.EN_AEROPUERTO) {
                diasFacturados++;
            } else {
                break;
            }
            fechaActual = fechaActual.minusDays(1);
        }

        // Cálculo del precio base (8 horas por día)
        double bruto = this.costexhora * 8 * diasFacturados;

        // Aplicar porcentaje de participación de la aerolínea
        double participacion = this.vueloTemporalCobro.getParticipacionAerolinea(this.vueloTemporalCobro.getFacturaACobrar().getAerolinea());
        return (bruto * participacion) / 100;
    }

    @Override
    public String getResourceDescription() {
        return this.vueloTemporalCobro.getElementoEspecifico(ElementosFacturables.HANGAR).getNombre();
    }

    @Override
    public String getUsageTime() {
        return this.vueloTemporalCobro.getMinutosUso(ElementosFacturables.HANGAR) + " minutos";
    }

    @Override
    public String toString() {
        return "Hangar: " + nombre + " Capacidad = " + capacidad + ", Dimensiones = " + dimensiones + ", Categoría " + tipo + 
        (tipo.equals(CategoriaAvion.MERCANCIAS) ? (", Mercancias Peligrosas: " + ((this.permiteMercanciaPeligrosa) ? "si" : "no")) : "") + ", Aviones guardados = " + this.avionesOcupando() +"";
    }

    
}