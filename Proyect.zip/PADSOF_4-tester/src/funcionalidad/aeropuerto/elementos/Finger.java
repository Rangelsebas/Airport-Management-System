package funcionalidad.aeropuerto.elementos;
import java.util.ArrayList;
import java.util.List;

import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Dimension;
import funcionalidad.otro.ElementosFacturables;
import funcionalidad.usuarios.Rol;

public class Finger extends ElementoFacturable {
    private Puerta usadoPor;
    private List<Puerta> perteneceA;
    private Dimension dimensiones;
    private Boolean puertasSeteadas;

    public Finger(double costexhora, Dimension dimensiones){
        super("Finger", costexhora);
        this.dimensiones = dimensiones;
        this.perteneceA = new ArrayList<Puerta>();
        puertasSeteadas = false;
    }

    public Boolean cambiarCostexhora(int nuevoCoste){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if (nuevoCoste <= 0) return false;
        this.costexhora = nuevoCoste;
        return true;
    }

    public Dimension getDimensiones(){
        return this.dimensiones;
    }

    public Boolean setPertenencia(Puerta puerta){
        // Esto solo podrá hacerlo el gestor del aeropuerto al crear puertas
        // no se puede pedir finger en el constructor de puerta y puertas en el constructor de fingers al mismo tiempo
        if(this.puertasSeteadas) return false;
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        if(perteneceA.size() >= 2) return false;
        this.perteneceA.add(puerta);
        return true;
    }

    public Boolean asignarPuerta(Puerta puerta){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if(!perteneceA.contains(puerta)) return false;
        if (this.usadoPor == null || puerta.equals(this.usadoPor)){
            this.usadoPor = puerta;
            return true;
        }
        return false;
    }

    public Boolean dejarPuerta(Puerta puerta){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        if(!perteneceA.contains(puerta)) return false;
        else if (puerta.equals(this.usadoPor)){
            this.usadoPor = null;
            return true;
        }
        return false;
    }

    /* ----- funciones exclusivas facturacion ------ */
    @Override
    public double getHourlyPrice() {
        return costexhora;
    }

    @Override
    public double getPrice() {
        long minutos = this.vueloTemporalCobro.getMinutosUso(ElementosFacturables.FINGER);
        double ret = costexhora * ((double) minutos / 60.0);
        return (ret * this.vueloTemporalCobro.getParticipacionAerolinea(this.vueloTemporalCobro.getFacturaACobrar().getAerolinea())) / 100;
    }

    @Override
    public String getResourceDescription() {
        return this.vueloTemporalCobro.getElementoEspecifico(ElementosFacturables.FINGER).getNombre();
    }

    @Override
    public String getUsageTime() {
        return this.vueloTemporalCobro.getMinutosUso(ElementosFacturables.FINGER) + " minutos";
    }

    @Override
    public Boolean checkDisponible(){
        if(usadoPor == null){
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Finger [perteneceA=" + perteneceA + ", dimensiones=" + dimensiones + "]";
    }

}
