package funcionalidad.aeropuerto.elementos;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.Deque;
import java.util.PriorityQueue;

import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Orientacion;
import funcionalidad.otro.Uso;
import funcionalidad.usuarios.Rol;
import funcionalidad.vuelo.Vuelo;

public class Pista extends ElementoAeropuerto {
    private String nombre;
    private int longitud;
    private Orientacion orientacion;
    private Uso uso;
    private Deque<Vuelo> cola;
    private LocalTime ultimoTiempoOcupacion;
    private LocalDate fechaUltimoUso;

    public Pista(String nombre, int longitud, Orientacion orientacion, Uso uso){
        super();
        this.nombre = nombre;
        this.longitud = longitud;
        this.orientacion = orientacion;
        this.uso = uso;
        this.cola = new ArrayDeque<>();
        this.ultimoTiempoOcupacion = Aplicacion.init("acceder").getRealTime().toLocalTime().minusMinutes(5);
        this.fechaUltimoUso = Aplicacion.init("acceder").getRealTime().toLocalDate().minusDays(1);
    }

    /* Los vuelos en tiempo tienen prioridad.
    Los vuelos de pasajeros tienen más prioridad que los de mercancías.
    Se reordena la cola de despegues según tiempo de retraso y cantidad de pasajeros.
    No pueden haber dos vuelos esperando aterrizar en la misma pista.
    Entre cada vuelo debe haber al menos 5 minutos de diferencia.
    */
    public void reorganizarCola() {
        // Creamos una PriorityQueue usando un comparador que prioriza primero el retraso y luego la categoría del avión
        PriorityQueue<Vuelo> pq = new PriorityQueue<>(new Comparator<Vuelo>() {
            @Override
            public int compare(Vuelo v1, Vuelo v2) {
                // Retraso: getEnTiempo() == false indica que el vuelo está retrasado
                boolean delayed1 = !v1.getEnTiempo();
                boolean delayed2 = !v2.getEnTiempo();
                if (delayed1 != delayed2) {
                    // Los vuelos retrasados tienen mayor prioridad
                    return delayed1 ? -1 : 1;
                }

                // Categoría: pasajeros antes que mercancías
                boolean pass1 = v1.getAvion().getCategoria() == CategoriaAvion.PASAJEROS;
                boolean pass2 = v2.getAvion().getCategoria() == CategoriaAvion.PASAJEROS;
                if (pass1 != pass2) {
                    return pass1 ? -1 : 1;
                }

                // A igualdad de retraso y categoría, quedan en orden indeterminado (o FIFO si el PriorityQueue lo soporta)
                return 0;
            }
        });

        // Añadimos todos los vuelos actuales y actualizamos la cola
        pq.addAll(cola);
        cola = new ArrayDeque<>(pq);
    }

    /**
     * Añade un vuelo a la cola.
     * La restricción de los 5 minutos se gestiona en ocupar(), no en la inserción en la cola.
     */
    public Boolean añadirVueloACola(Vuelo vuelo) {
        return cola.offer(vuelo);
    }

    // Ver el primero de la cola sin sacarlo
    public Vuelo verPrimeroDeCola() {
        return cola.peek();
    }

    /* Ver toda la cola */
    public Deque<Vuelo> verCola() {
        return cola;
    }

    // Sacar el primer vuelo de la cola
    public Vuelo sacarPrimeroDeCola() {
        return cola.poll();
    }

    /* Es responsabilidad del controlador chequear el uso de la pista y asignar vuelos como corresponde */
    /* Pista no sabe si el vuelo despega o aterriza */
    public int getLongitud(){
        return this.longitud;
    }

    public Orientacion getOrientacion(){
        return this.orientacion;
    }

    public Uso getUso(){
        return this.uso;
    }

    public String getNombre(){
        return this.nombre;
    }

    /* Responsabilidad del controlador verificarlo */
    public Boolean cambiarUso(Uso nuevoUso){
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.GESTORAEROPUERTO)) return false;
        this.uso = nuevoUso;
        return true;
    }

    @Override
    public Boolean ocupar(Vuelo vuelo) throws IllegalStateException {
        Aplicacion aplicacion = Aplicacion.init("acceder");

        // 1. Autorización: solo CONTROLADORAEREO
        if (aplicacion.getUsuarioLogueado() == null ||
            !aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) {
            return false;
        }

        // Fecha y hora actuales
        LocalDateTime ahora = aplicacion.getRealTime();

        // Fecha y hora del último uso
        LocalDateTime ultimoUso = LocalDateTime.of(fechaUltimoUso, ultimoTiempoOcupacion);

        // 2. Comprobar pista libre
        if (!this.ocupadoPor.isEmpty()) {
            throw new IllegalStateException("La pista ya está ocupada por otro vuelo.");
        }

        // 3. Comprobar separación mínima de 5 minutos
        long minutosDesdeUltimo = Duration.between(ultimoUso, ahora).toMinutes();
        if (minutosDesdeUltimo < 5) {
            throw new IllegalStateException(
                "Debe esperar al menos 5 minutos desde el último uso de la pista. " +
                "Han pasado solo " + minutosDesdeUltimo + " minutos."
            );
        }

        // 4. Si todo OK, ocupar la pista
        this.ocupadoPor.addLast(vuelo);

        // 5. Actualizar fechas
        this.ultimoTiempoOcupacion = ahora.toLocalTime();
        this.fechaUltimoUso = ahora.toLocalDate();

        return true;
    }

    

    @Override
    public Boolean liberar(Vuelo vuelo){
        /* COMPROBAR QUE EL USUARIO TIENE PERMISO */
        Aplicacion aplicacion = Aplicacion.init("acceder");
        if(aplicacion.getUsuarioLogueado() == null) return false;
        if(!aplicacion.getUsuarioLogueado().checkRol(Rol.CONTROLADORAEREO)) return false;
        /* En esta clase el metodo solo vale para elementos que solo pueden tener como maximo un vuelo */
        if (!this.ocupadoPor.isEmpty()){
            this.ocupadoPor.removeFirst();
            this.ultimoTiempoOcupacion = aplicacion.getRealTime().toLocalTime();
            return true;
        }
        return false; // o true?
    }

    @Override
    public String toString() {
        return "Pista: " +
                "Nombre = '" + nombre + '\'' +
                ", Longitud = " + longitud +
                ", Orientacion = " + orientacion +
                ", Uso = " + uso +
                ", Aviones en cola = " + cola.size();
    }
}
