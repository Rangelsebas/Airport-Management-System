package funcionalidad.aeropuerto;
import java.io.Serializable;
import java.time.*;

public abstract class Aeropuerto implements Serializable {
    private String nombre;
    private String ciudadMasCercana;
    private int distanciaCiudad;
    private String direccion;
    private String codigo;
    protected LocalTime horaApertura;
    protected LocalTime horaCierre;
    protected float diferenciaHoraria;

    public Aeropuerto(String nombre, String ciudadMasCercana, int distanciaCiudad, String direccion, String codigo,
                        LocalTime horaApertura, LocalTime horaCierre, float diferenciaHoraria) {
        this.nombre = nombre;
        this.ciudadMasCercana = ciudadMasCercana;
        this.distanciaCiudad = distanciaCiudad;
        this.direccion = direccion;
        this.codigo = codigo;
        this.horaApertura = horaApertura;
        this.horaCierre = horaCierre;
        this.diferenciaHoraria = diferenciaHoraria;
    }

    public String getNombre(){
        return this.nombre;
    }

    public String getCiudad(){
        return this.ciudadMasCercana;
    }

    public int getDistancia(){
        return this.distanciaCiudad;
    }

    public String getDireccion(){
        return this.direccion;
    }

    public String getCodigo(){
        return this.codigo;
    }

    public LocalTime getHoraApertura(){
        return this.horaApertura;
    }

    public LocalTime getHoraCierre(){
        return this.horaCierre;
    }

    public float getDiferenciaHoraria(){
        return this.diferenciaHoraria;
    }

    public abstract Boolean checkHorario(LocalTime hora);

    @Override
    public String toString() {
        return "Aeropuerto " + nombre + ", ciudadMasCercana: " + ciudadMasCercana + ", distancia: "
                + distanciaCiudad + ", direccion: " + direccion + ", codigo: " + codigo + ", horaApertura: " + horaApertura.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
                + ", horaCierre: " + horaCierre.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")) + "";
    }
}