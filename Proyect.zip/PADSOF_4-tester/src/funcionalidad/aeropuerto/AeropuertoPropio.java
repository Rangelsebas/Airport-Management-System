package funcionalidad.aeropuerto;

import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aeropuerto.elementos.*;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.otro.Dimension;
import funcionalidad.otro.Orientacion;
import funcionalidad.otro.Uso;
import funcionalidad.usuarios.Usuario;
import funcionalidad.vuelo.Vuelo;
import java.time.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class AeropuertoPropio extends Aeropuerto{
    private static AeropuertoPropio instance;
    private double precioBase;
    private List<AeropuertoExterno> aeropuertosConectados;
    private HashMap<String, Terminal> terminales;
    private HashMap<String, Pista> pistas;
    private HashMap<String, Aparcamiento> aparcamientos;
    private HashMap<String, Hangar> hangares;
    private final Usuario gestorAeropuerto;
    private int maxVuelosEnUnaHora = 0;
    private int maxAvionesEnAeropuerto = 0;

    private AeropuertoPropio(String nombre, double precioBase, String ciudadMasCercana, int distanciaCiudad, String direccion, String codigo,
                            LocalTime horaApertura, LocalTime horaCierre, Usuario gestorAeropuerto) {
        super(nombre, ciudadMasCercana, distanciaCiudad, direccion, codigo, horaApertura, horaCierre, 0);
        this.precioBase = precioBase;
        this.aeropuertosConectados = new ArrayList<>();
        this.terminales = new HashMap<>();
        this.aparcamientos = new HashMap<>();
        this.hangares = new HashMap<>();
        this.pistas = new HashMap<>();
        this.gestorAeropuerto = gestorAeropuerto;
    }
    
    public static AeropuertoPropio init(String nombre, double precioBase, String ciudadMasCercana, int distanciaCiudad, String direccion, String codigo,
                                        LocalTime horaApertura, LocalTime horaCierre, Usuario gestorAeropuerto){
        if (instance == null) {
            instance = new AeropuertoPropio(nombre, precioBase, ciudadMasCercana, distanciaCiudad, direccion, codigo, horaApertura, horaCierre, gestorAeropuerto);
            return  instance;
        }
        return  AeropuertoPropio.instance;
    }

    public Boolean añadirConexion(AeropuertoExterno aeropuertoExterno){
        Aplicacion aplicacion = Aplicacion.init("");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if (!aplicacion.getUsuarioLogueado().equals(this.gestorAeropuerto)) return false;

        if(this.aeropuertosConectados.contains(aeropuertoExterno)) return true;
        this.aeropuertosConectados.add(aeropuertoExterno);
        return true;
    }

    public Boolean eliminarConexion(AeropuertoExterno aeropuertoExterno){
        Aplicacion aplicacion = Aplicacion.init("");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if (!aplicacion.getUsuarioLogueado().equals(this.gestorAeropuerto)) return false;
        /* Se debería comprobar aqui o mejor en otro sitio si hay vuelos pendientes a ese aeropuerto?? */
        if(this.aeropuertosConectados.contains(aeropuertoExterno)){
            this.aeropuertosConectados.remove(aeropuertoExterno);
            return true;
        }
        return false;
    }

    public Boolean añadirPista(String nombre, int longitud, Orientacion orientacion, Uso uso){
        Aplicacion aplicacion = Aplicacion.init("");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if (!aplicacion.getUsuarioLogueado().equals(this.gestorAeropuerto)) return false;
        if (longitud <= 0){
            return false;
        }
        this.pistas.put(nombre, new Pista(nombre, longitud, orientacion, uso));
        return true;
    }

    public Boolean añadirTerminal(String nombre, int busesDisponibles){
        Aplicacion aplicacion = Aplicacion.init("");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if (!aplicacion.getUsuarioLogueado().equals(this.gestorAeropuerto)) return false;
        if (busesDisponibles <= 0){
            return false;
        }
        System.out.println("Entró");
        Terminal terminal = new Terminal(nombre);
        terminal.añadirBuses(busesDisponibles);
        this.terminales.put(nombre, terminal);
        return true;
    }

    public Boolean añadirPuertasTerminal(String terminal, double costexhora, int largo, int ancho, int alto, int cantidad){
        Aplicacion aplicacion = Aplicacion.init("");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if (!aplicacion.getUsuarioLogueado().equals(this.gestorAeropuerto)) return false;
        if (cantidad > 100 || cantidad < 0) return false;
        
        
        if (this.terminales.get(terminal).añadirPuertas(costexhora, largo, ancho, alto, cantidad)){
            // Se asume que un vuelo puede estar hasta 2 horas en una puerta;
            int sumaCapacidad = cantidad/2;
            this.maxVuelosEnUnaHora += sumaCapacidad;
            return true;
        }
        return false;
    }

    public Boolean añadirAparcamiento(String nombre, int capacidad, double costexhora, int largo, int ancho){
        Aplicacion aplicacion = Aplicacion.init("");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if (!aplicacion.getUsuarioLogueado().equals(this.gestorAeropuerto)) return false;
        System.out.println("Creando aparcamiento..." + "capacidad: " + capacidad + " largo: " + largo + " ancho: " + ancho + " costexhora: " + costexhora);
        if (capacidad <= 0 || costexhora <= 0 || largo <= 0 || ancho <= 0){
            return false;
        }
        if(this.aparcamientos.containsKey(nombre)) return false;
        Dimension dimensiones = new Dimension(largo, ancho);
        this.aparcamientos.put(nombre, new Aparcamiento(nombre, capacidad, costexhora, dimensiones));
        return true;
    }

    public Boolean añadirHangar(String nombre, int capacidad, double costexhora, int largo, int ancho, int alto, CategoriaAvion tipo, Boolean permiteMercanciaPeligrosa){
        Aplicacion aplicacion = Aplicacion.init("");
        if (aplicacion.getUsuarioLogueado() == null) return false;
        if (!aplicacion.getUsuarioLogueado().equals(this.gestorAeropuerto)) return false;
        if (capacidad <= 0 || costexhora <= 0 || largo <= 0 || ancho <= 0 || alto <= 0){
            return false;
        }

        this.maxAvionesEnAeropuerto+=capacidad;
        Dimension dimensiones = new Dimension(largo, ancho, alto);
        this.hangares.put(nombre, new Hangar(nombre, capacidad, costexhora, dimensiones, tipo, permiteMercanciaPeligrosa));
        return true;
    }
    
    public Hangar buscarAvionEnHangar(String matricula){
        for (Hangar h : this.hangares.values()) {
            if(h.askAvionEnHangar(matricula)) return h;
        }
        return null;
    }

    public Aparcamiento buscarVueloEnAparcamiento(Vuelo vuelo){
        for (Aparcamiento a : this.aparcamientos.values()) {
            if(a.askVueloEnAparcamiento(vuelo)) return a;
        }
        return null;
    }

    public Terminal getTerminal(String nombre){
        return this.terminales.get(nombre);
    }

    public List<Terminal> getTerminales() {
        return Collections.unmodifiableList(new ArrayList<>(this.terminales.values()));
    }

    public Pista getPista(String nombre){
        return this.pistas.get(nombre);
    }

    public List<Pista> getPistas() {
        return Collections.unmodifiableList(new ArrayList<>(this.pistas.values()));
    }

    public Aparcamiento getAparcamiento(String nombre){
        return this.aparcamientos.get(nombre);
    }

    public List<Aparcamiento> getAparcamientosApropiado(Avion avion){
        if (avion == null) return null;
        List<Aparcamiento> aparcamientosApropiados = new ArrayList<>();
        for (Aparcamiento aparcamiento : this.aparcamientos.values()) {
            if (aparcamiento.checkDisponible() && aparcamiento.getDimensionesDePlaza().puedeContenerHorizontal(avion.getDimensiones())) {
                aparcamientosApropiados.add(aparcamiento);
            }
        }
        return Collections.unmodifiableList(aparcamientosApropiados);
    }

    public Hangar getHangar(String nombre){
        return this.hangares.get(nombre);
    }

    public List<Hangar> getHangares() {
        return Collections.unmodifiableList(new ArrayList<>(this.hangares.values()));
    }

    public List<Hangar> getHangaresApropiados(Avion avion){
        if (avion == null) return null;
        List<Hangar> hangaresApropiados = new ArrayList<>();
        for (Hangar hangar : this.hangares.values()) {
            if (hangar.checkDisponible() && hangar.getDimensiones().puedeContener(avion.getDimensiones())) {
                //hangaresApropiados.add(hangar);
                switch (avion.getTipoAvion().getCategoria()) {
                    case CategoriaAvion.PASAJEROS:
                        if (hangar.getTipo().equals(CategoriaAvion.PASAJEROS)) {
                            hangaresApropiados.add(hangar);
                        }
                        break;
                
                    case CategoriaAvion.MERCANCIAS:
                        if (hangar.getTipo().equals(CategoriaAvion.MERCANCIAS)) {
                            if (avion.tieneMaterialPeligroso() && hangar.getPermiteMercanciaPeligrosa()) {
                                hangaresApropiados.add(hangar);
                            } else if (!avion.tieneMaterialPeligroso()) {
                                hangaresApropiados.add(hangar);
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        return Collections.unmodifiableList(hangaresApropiados);
    }

    public List<Aparcamiento> getAparcamientos() {
        return Collections.unmodifiableList(new ArrayList<>(this.aparcamientos.values()));
    }

    public Hangar getHangarDisponible(){
        for (Hangar hangar : this.hangares.values()) {
            if (hangar.checkDisponible()) {
                return hangar;
            }
        }
        return null;
    }

    @Override
    public Boolean checkHorario(LocalTime hora) {
        if ((hora.isAfter(this.horaApertura) && hora.isBefore(this.horaCierre)) || hora.equals(this.horaApertura) || hora.equals(this.horaCierre)) return true; 
        System.out.println("El aeropuerto está cerrado");
        return false;
    }

    public Boolean sePuedeAparcar(){
        if(this.aparcamientos.isEmpty()) return false;
        return true;
    }

    public Boolean reservarHangar(LocalDate fecha){
        if(this.hangares.isEmpty()) return false;
        for (Hangar hangar : this.hangares.values()) {
            if (hangar.checkDisponible()) {
                return hangar.reservarHangar(fecha);
            }
        }
        return false;
    }

    public int getMaxVuelosEnUnaHora(){
        return this.maxVuelosEnUnaHora;
    }

    public int getCantidadAvionesEnAeropuerto(){
        //TODO PENDIENTE
        return -1;
    }

    public double getPrecioBase(){
        return this.precioBase;
    }

    public int getMaxAvionesEnAeropuerto(){
        return this.maxAvionesEnAeropuerto;
    }

    public Usuario getGestorDelAeropuerto(){
        return this.gestorAeropuerto;
    }

    public List<AeropuertoExterno> getConexiones(){
        return Collections.unmodifiableList(this.aeropuertosConectados);
    }

    @Override
    public String toString() {
        return super.toString() + ", precioBase: " + precioBase + ", númeroDeTerminales: " + terminales.size()
                + ", númeroDePistas: " + pistas.size() + ", númeroDeAparcamientos: " + aparcamientos.size() + ", númeroDeHangares: " + hangares.size() + ", gestorAeropuerto: " + gestorAeropuerto.getNombre()
                + ", maximoDeVuelosEnUnaHora: " + maxVuelosEnUnaHora + ", maxAvionesEnAeropuerto: " + maxAvionesEnAeropuerto
                + ", aeropuertosConectados: " + aeropuertosConectados.size() + "\n";
    }
}