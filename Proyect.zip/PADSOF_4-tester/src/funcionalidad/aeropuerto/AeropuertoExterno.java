package funcionalidad.aeropuerto;
import java.time.*;

public class AeropuertoExterno extends Aeropuerto {

    public AeropuertoExterno(String nombre, String ciudadMasCercana, int distanciaCiudad, String direccion, String codigo, 
                                LocalTime horaApertura, LocalTime horaCierre, float diferenciaHoraria){
        super(nombre, ciudadMasCercana, distanciaCiudad, direccion, codigo, horaApertura, horaCierre, diferenciaHoraria);
    }

    @Override
    public Boolean checkHorario(LocalTime hora) {
        long diferencia = (long) this.diferenciaHoraria * 60;
        if ((hora.plusMinutes(diferencia).isAfter(this.horaApertura) && hora.plusMinutes(diferencia).isBefore(this.horaCierre)) || 
            hora.plusMinutes(diferencia).equals(this.horaApertura) || hora.plusMinutes(diferencia).equals(this.horaCierre)) return true;
        System.out.println("El aeropuerto " + this.getNombre() + " no está abierto en este momento.");
        return false;
    }
}