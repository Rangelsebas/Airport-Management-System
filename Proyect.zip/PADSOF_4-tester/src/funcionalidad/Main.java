package funcionalidad;

import funcionalidad.aerolinea.Aerolinea;
import funcionalidad.aerolinea.Avion;
import funcionalidad.aerolinea.CategoriaAvion;
import funcionalidad.aerolinea.TipoAvion;
import funcionalidad.aeropuerto.AeropuertoPropio;
import funcionalidad.aplicacion.Aplicacion;
import funcionalidad.facturacion.Factura;
import funcionalidad.otro.Orientacion;
import funcionalidad.otro.Uso;
import funcionalidad.usuarios.Usuario;
import funcionalidad.vuelo.EstadosVuelo;
import funcionalidad.vuelo.Vuelo;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public class Main {
    public static void main(String[] args) {
         /* Crear la app y gestor */
        Aplicacion app = Aplicacion.init("Aena");
        System.out.println("App creada correctamente");
        System.out.println("Intentando iniciar sesión con usuario inexistente: " + app.iniciarSesion("Noexisto", "1234"));
        
        app.crearGestor("GestorAngel", "1234", "55242141M", "Angel Dal", "angel.dal@estudiante.uam.es");
        System.out.println("Gestor creado");
        
        /* Añadir aeropuerto propio */
        app.iniciarSesion("GestorAngel", "1234");
        app.crearAeropuertoPropio("Adolfo Suarez de Barajas", 2000, "Madrid", 10, "Barajas, Madrid", "MAD",
         LocalTime.of(6, 0), LocalTime.of(23, 0), "GestorAngel");
        System.out.println("Aeropuerto añadido");
        
        System.out.println(app);
        
        /* Añadir aeropuertos externos y conexiones */
        app.cargarAeropuertosExternos("aeropuertosExternos.txt");
        System.out.println("Aeropuertos cargados");
        
        /* Añadir una terminal, un hangar y una pista */
        AeropuertoPropio airport = app.getAeropuertoPropio();
        airport.añadirPista("Pista 1", 4000, Orientacion.ESTE, Uso.DESPEGUE);
        airport.añadirPista("Pista 2", 4000, Orientacion.NORTE, Uso.ATERRIZAJE);
        airport.añadirTerminal("T1", 20);
        airport.añadirHangar("H1", 20, 50, 80, 80, 35, CategoriaAvion.PASAJEROS, false);
        airport.añadirAparcamiento("A1", 200, 30, 95, 120);
        
        /* Añadir tipos de aviones */
        app.cargarTiposDeAviones("tiposAviones.txt");
        System.out.println("Aviones cargados");
        
        System.out.println(app);
        
        /* Obtener el avion BO737V2 */
        TipoAvion avion = app.getTipoAvion("BO777X1");
        System.out.println("Detalles del avión: \n" + avion);
        
        /* Registrar aerolíneas y operadores */
        app.añadirAerolinea("Iberia", "IBE");
        app.añadirAerolinea("Ryanair", "RYA");
        app.añadirAerolinea("KLM", "KLM");
        app.añadirAerolinea("AirEuropa", "AIR");
        
        app.registrarOperador("IberiaOperador", "111111Z", "Cristiano Ronaldo", "cirs@uam.es", "1234");
        app.asignarAerolineaOperador("IberiaOperador", "Iberia");
        
        app.registrarOperador("RyanairOperador", "111111A", "Cristiano Ronaldo Jr", "cirsjr@uam.es", "1234");
        app.asignarAerolineaOperador("RyanairOperador", "Ryanair");
        
        app.registrarOperador("KLMOperador", "111111B", "Neymar Jr", "ney@uam.es", "1234");
        app.asignarAerolineaOperador("KLMOperador", "KLM");
        
        app.registrarOperador("AirEuropaOperador", "111111C", "Iker Casillas", "mipadre@uam.es", "1234");
        app.asignarAerolineaOperador("AirEuropaOperador", "AirEuropa");
        
        System.out.println(app);
        
        /* Registrar controladores */
        app.registrarControlador("Controlador1", "222222A", "Fernando Alonso", "nuestropadre@uam.es", "1234");
        app.registrarControlador("Controlador2", "222222B", "Marc Marquez", "leyenda@uam.es", "1234");
        app.registrarControlador("Controlador3", "222222C", "Alex Marquez", "hermano@uam.es", "1234");
        
        /* Ver usuarios */
        List<Usuario> usuarios = app.listarUsuarios();
        System.out.println("Lista de usuarios:\n" + usuarios);
        
        /* Cerrar sesión de gestor, iniciar en operador y añadir aviones */
        app.cerrarSesion();

        //TODO
        app.iniciarSesion("IberiaOperador", "1234");
        
        Aerolinea iberia = app.getAerolinea("Iberia");
        iberia.anadirAvion(CategoriaAvion.PASAJEROS, avion, LocalDate.of(2020, 5, 25), LocalDate.of(2024, 5, 25));
        
        System.out.println("Información de la aerolínea al añadir avión:\n" + iberia);
        
        añadirAviones(20, avion, iberia);
        System.out.println("Información de la aerolínea al añadir 20 aviones:\n" + iberia);
        
        /* Solicitar vuelo */
        Avion avionVuelo = iberia.getAvion("BO774268");
        try {
            app.solicitarNuevoVuelo("Pamplona", "Adolfo Suarez de Barajas", app.getRealTime().plusDays(4).toLocalDate(), LocalTime.of(12, 0), LocalTime.of(14, 0), iberia, avionVuelo);
        } catch (Exception e) {
            System.err.println("Error al solicitar vuelo: " + e.getMessage());
        }
        
        app.cerrarSesion();
        app.iniciarSesion("GestorAngel", "1234");
        app.verNotificacionesNoLeidas();
        app.aprobarSolicitudVuelo("IBE00001", "T1", "Controlador1");
        
        /* Añadir puertas y hangares */
        airport.añadirPuertasTerminal("T1", 200, 30, 10, 30, 20);
        airport.añadirHangar("H2", 10, 50, 80, 80, 35, CategoriaAvion.PASAJEROS, false);
        
        /* Simulación de vuelos */
        app.setRealTime(LocalDateTime.of(2025, 3, 1, 8, 0));
        app.cerrarSesion();
        app.iniciarSesion("IberiaOperador", "1234");
        solicitarVuelos(app, 20, 10, iberia, "Adolfo Suarez de Barajas", "Aeropuerto de Tenerife Norte-Ciudad de La Laguna");
        app.cerrarSesion();
        /* Aceptamos los vuelos */
        app.iniciarSesion("GestorAngel", "1234");
        app.verNotificacionesNoLeidas();
        for (int i = 2; i < 22; i++) {
            if(app.aprobarSolicitudVuelo("IBE" + String.format("%05d", i), "T1", "Controlador1") == false)
                System.err.println("Error al aceptar vuelo");
        }

        app.cerrarSesion();

        //TODO
        app.iniciarSesion("Controlador1", "1234");

        /* Vamos a la fecha de los vuelos */
        app.setRealTime(LocalDateTime.of(2025, 3, 18, 8, 50));
        app.actualizar();
        System.out.println("\nVer fecha y hora " + app.getRealTime());
        System.out.println("\nVuelos del dia:\n");
        System.out.println(app.getVuelosDelDia());

        Vuelo vueloGestionado = app.buscarVueloxCodigo("IBE00002");
        vueloGestionado.sacarAvionHangar();
        System.out.println("\n\n ---------- Vuelo gesionado actualmente: \n" + vueloGestionado.toString());
        //vueloGestionado.moverAvionAAparcamiento(app.getAeropuertoPropio().getAparcamiento("A1"));

        System.out.println("Notificaciones del controlador");
        app.verNotificacionesNoLeidas();

        app.cerrarSesion();
        app.iniciarSesion("IberiaOperador", "1234");

        vueloGestionado.pasarAPreparacionCambioEstado();
        
        app.avanzarTreintaMinutos();

        //vueloGestionado.iniciarEmbarqueCambioEstado(app.getAeropuertoPropio().getTerminal("T1").getPuerta("A01"));

        app.avanzarTreintaMinutos();
        app.actualizar();

        vueloGestionado.embarqueFinalizadoCambioEstado();

        app.verNotificacionesNoLeidas();
        app.cerrarSesion();
        app.iniciarSesion("Controlador1", "1234");
        app.verNotificacionesNoLeidas();

        System.out.println("Notificaciones del operador");
        app.verNotificacionesNoLeidas();

        System.out.println("Vuelo gesionado actualmente: \n" + vueloGestionado.toString());

        vueloGestionado.asignarPistaDespegueCambioEstado(app.getAeropuertoPropio().getPista("Pista 1"));
        //vueloGestionado.autorizarDespegueCambioEstado(app.getAeropuertoPropio().getPista("Pista 1"));

        app.avanzarCincoMinutos();
        app.actualizar();
        
        /* El vuelo ya está volando =D */
        System.out.println("Vuelo gesionado actualmente: \n" + vueloGestionado.toString());

        // Ignoraremos el resto de vuelos, ahora haremos un vuelo de llegada para la demostracion

        app.cerrarSesion();
        app.iniciarSesion("IberiaOperador", "1234");

        avionVuelo = iberia.getAvion("BO774268");

        try {
            app.solicitarNuevoVuelo("Los Angeles International", "Adolfo Suarez de Barajas", app.getRealTime().plusDays(4).toLocalDate(), LocalTime.of(6, 0), LocalTime.of(14, 0), iberia, avionVuelo);
        } catch (Exception e) {
            System.err.println("Error al solicitar vuelo: " + e.getMessage());
        }

        app.verNotificacionesNoLeidas();
        app.cerrarSesion();
        app.iniciarSesion("GestorAngel", "1234");
        app.verNotificacionesNoLeidas();

        if(!app.aprobarSolicitudVuelo("IBE00022", "T1", "Controlador2")) System.err.println("Solicitud denegada");

        vueloGestionado = app.buscarVueloxCodigo("IBE00022");

        System.out.println(vueloGestionado);

        /* Vamos a hacerlo compartido */

        app.cerrarSesion();

        //TODO
        app.iniciarSesion("RyanairOperador", "1234");

        app.verNotificacionesNoLeidas();

        //if(!vueloGestionado.solicitarVueloCompartido(20, app.getAerolinea("Ryanair"))) System.err.println("No se ha podido realizar la solicitud");

        app.cerrarSesion();
        app.iniciarSesion("IberiaOperador", "1234");
        app.verNotificacionesNoLeidas();

        vueloGestionado.aceptarVueloCompartido(vueloGestionado.getOcupaciones().getLast());

        app.cerrarSesion();
        app.iniciarSesion("RyanairOperador", "1234");

        app.verNotificacionesNoLeidas();

        //Guardamos el estado de la app para más adelante probar que funciona
        app.salvarAplicacion("aplicacion.dat");
        //Estado de la app:
        System.out.println("\n\n - - - - - IMPRIMIENDO ESTADO DE LA APLICACION - - - - - \n\n");
        System.out.println(app.toString());
        System.out.println("\n\n - - - - - Pulse enter para continuar - - - - - \n\n");
        System.console().readLine();

        app.cerrarSesion();
        app.iniciarSesion("IberiaOperador", "1234");
        app.verNotificacionesNoLeidas();

        //Fecha y hora actual
        System.out.println("\n" + app.getRealTime());

        // Datos del vuelo
        System.out.println("\n" + vueloGestionado.toString());

        // Seteamos la hora a la hora del vuelo

        app.setRealTime(LocalDateTime.of(2025, 3, 18, 13, 50));
        app.actualizar();

        //Fecha y hora actual
        System.out.println("\n" + app.getRealTime());

        // Datos del vuelo
        System.out.println("\n" + vueloGestionado.toString());

        // Empezamos a gestionarlo
        app.cerrarSesion();

        //TODO
        app.iniciarSesion("Controlador2", "1234");
        vueloGestionado.asignarPistaCambioEstado(app.getAeropuertoPropio().getPista("Pista 2"));
        vueloGestionado.autorizarAterrizajeCambioEstado(app.getAeropuertoPropio().getAparcamiento("A1"), app.getAeropuertoPropio().getTerminal("T1").getPuerta("A05"));
        app.avanzarTreintaMinutos();
        // Datos del vuelo
        System.out.println("\n" + vueloGestionado.toString());

        app.verNotificacionesNoLeidas();

        app.cerrarSesion();
        app.iniciarSesion("IberiaOperador", "1234");
        vueloGestionado.iniciarDescargaCambioEstado();
        app.avanzarCincoMinutos();
        app.avanzarCincoMinutos();
        app.avanzarCincoMinutos();
        app.avanzarCincoMinutos();
        app.actualizar();
        vueloGestionado.descargaFinalizadaCambioEstado();
        app.verNotificacionesNoLeidas(); // No habia visto sus notificaciones desde el cambio de hora brusco por eso se muestran los vuelos retrasados

        app.cerrarSesion();
        app.iniciarSesion("Controlador2", "1234");

        vueloGestionado.guardarAvionEnHangar(app.getAeropuertoPropio().getHangarDisponible());
        app.verNotificacionesNoLeidas(); // No habia visto sus notificaciones desde el cambio de hora brusco por eso se muestran los vuelos retrasados
        // Datos del vuelo finalizado =D
        System.out.println("\n" + vueloGestionado.toString());

        // Llega el momento de generar factura y cobrar
        app.cerrarSesion();
        app.iniciarSesion("GestorAngel", "1234");
        //if(!app.emitirFactura(iberia, app.getRealTime().toLocalDate())) System.out.println("\n --- Error al emitir factura - - - \n");
        //GMM Este bucle mejor que se haga en emitirFactura y que los costes se hagan en factura en el momento de forma
        //    que generar factura no haga nada más que crear la facturua. Además en  Factura tiene la aerolinea por lo que
        //    podéis multiplicar todos los costes por el porcentaje de uso del vuelo por parte de la aerolinea
        Factura fac = iberia.getFacturas().getFirst();
        for (Vuelo v : iberia.getVuelos()) {
            if(v.getEstado() == EstadosVuelo.FINALIZADO || v.getEstado() == EstadosVuelo.VOLANDO){
                fac.añadirVueloACobro(v);
            }
        }
        System.out.println(fac.toString());
        //app.generarPDFFactura(fac);

        // Vamos a pagar la factura
        System.out.println("\n\n");
        app.cerrarSesion();
        app.iniciarSesion("IberiaOperador", "1234");
        if(!app.pagarFactura(fac, "5551368433452679")) System.out.println("Factura no pagada");

        app.cerrarSesion();
        app.iniciarSesion("GestorAngel", "1234");
        app.verNotificacionesNoLeidas();

        app.aceptarPagoFactura(fac);

        app.verNotificacionesNoLeidas();

        //Con esto acabamos esta pequeña demostracion =D

        // Pero antes, comprobemos que se puede cargar la app
        //Estado de la app:
        System.out.println("\n\n - - - - - IMPRIMIENDO ESTADO DE LA APLICACION ANTES DE CARGAR- - - - - \n\n");
        System.out.println(app.toString());
        System.out.println("\n\n - - - - - Pulse enter para continuar - - - - - \n\n");
        System.console().readLine();

        // Cargamos la app
        app.cargarAplicacion("aplicacion.dat");
        System.out.println("\n\n - - - - - IMPRIMIENDO ESTADO DE LA APLICACION DESPUES DE CARGAR- - - - - \n\n");
        System.out.println(app.toString());
        System.out.println("\n\n - - - - - Pulse enter para FINALIZAR - - - - - \n\n");
        System.console().readLine();
    }

    private static void añadirAviones(int cantidad, TipoAvion tipoAvion, Aerolinea aerolinea) {
        for (int i = 0; i < cantidad; i++) {
            aerolinea.anadirAvion(CategoriaAvion.PASAJEROS, tipoAvion, LocalDate.of(2020, 5, 25), LocalDate.of(2024, 5, 25));
        }
    }

    private static void solicitarVuelos(Aplicacion app, int cantidad, int intervaloMinutos, Aerolinea aerolinea, String origen, String destino) {
        LocalTime primerVuelo = LocalTime.of(9, 0);
        List<Avion> aviones = aerolinea.getAviones();
        for (int i = 0; i < cantidad; i++) {
            Avion avion = aviones.get(i);
            try {
                if(app.solicitarNuevoVuelo(origen, destino, LocalDate.of(2025, 3, 22), primerVuelo.plusMinutes(i * intervaloMinutos), primerVuelo.plusMinutes((i * intervaloMinutos) + 120), aerolinea, avion) == false){
                    System.err.println("\n ------ No se pudo solicitar el vuelo ------- \n");
                }            
            } catch (Exception e) {
                System.err.println("Error al solicitar vuelo: " + e.getMessage());
            }
        }
    }
}
